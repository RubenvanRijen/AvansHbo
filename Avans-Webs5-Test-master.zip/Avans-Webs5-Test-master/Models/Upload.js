const mongoose = require("mongoose");

let uploadSchema = new mongoose.Schema(
    {
        uploadTitle: {type: String, required: true, minlength: 4, maxlength: 20, lowercase: true},
        attempts: [{
            image: {type: String, required: true},
            score: {type: Number, required: true, min: 0, max: 99}
        }],
        creator: {type: String, ref: "User", required: true, lowercase: true},
        tags: {type: Object, required: true},
        date: {type: Date, required: true}
    },
    {
        toJSON: {virtuals: true},
        toObject: {virtuals: true}
    }
);


// Create a model
const upload = mongoose.model('Upload', uploadSchema);

module.exports = upload;



