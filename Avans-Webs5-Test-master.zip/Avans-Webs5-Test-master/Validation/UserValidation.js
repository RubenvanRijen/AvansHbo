const mongoose = require('mongoose');
const userModel = require("../Models/User");


async function loginValidation(req, res, next) {
    const {email, password} = req.body;
    let errors = [];
    if (!email) {
        errors.push("No email was given");
    }
    if (!password) {
        errors.push("No password was given");
    }
    if (errors.length > 0) {
        if (res.contentType === 'application/json') {
            return res.status(400).json({message: errors});
        } else {
            return res.status(400).render('./user/login', {
                errors: errors
            });
        }
    }
    next();
}

async function signUpValidation(req, res, next) {
    const {email, password, username} = req.body;
    let errors = [];
    if (!email) {
        errors.push("No email was given");
    }
    if (!password) {
        errors.push("No password was given");
    }
    if (!username) {
        errors.push("No username was given");
    }
    if (errors.length > 0) {
        if (res.contentType === 'application/json') {
            return res.status(400).json({message: errors});
        } else {
            return res.status(400).render('./user/signUp', {
                errors: errors
            });
        }
    }
    next();
}


module.exports = {
    loginValidation,
    signUpValidation
}