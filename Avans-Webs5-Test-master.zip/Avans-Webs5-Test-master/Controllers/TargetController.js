const express = require("express");
const mongoose = require('mongoose');
const userModel = require("../Models/User");
const targetModel = require("../Models/Target");
const JWT = require('jsonwebtoken');
const http = require('http');
const paginate = require('paginate')({
    mongoose: mongoose
});

//route - tests - controller - views
async function getAllTargets(req, res, next) {
    let targets;
    try {
        targets = res.paginatedResults;
        if (res.contentType === 'application/json') {
            return res.status(200).json(targets);
        } else {
            await targetModel.find({}).paginate({page: req.query.page}, function (err, targets) {
                return res.status(200).render('./target/allTargets', {
                    targets: targets,
                    user: req.tokenUser
                });
            });
        }
    } catch (err) {
        if (res.contentType === 'application/json') {
            return res.status(500).json(err.message);
        } else {
            return res.status(500).render('error', {
                user: req.tokenUser
            });
        }
    }
}

//route - tests - controller - views
async function getTargetById(req, res, next) {
    let target, targetTitle;
    if (req.params.targetTitle) {
        targetTitle = req.params.targetTitle;
    }
    try {
        target = await targetModel.findOne({targetTitle: targetTitle});
        if (target === null) {
            if (res.contentType === 'application/json') {
                console.log()
                return res.status(404).json({message: "no target has been found"});
            } else {
                return res.status(404).render('./target/targetInfo', {
                    target: target,
                    user: req.tokenUser
                });
            }
        }

        if (res.contentType === 'application/json') {
            console.log()
            return res.status(200).json(target);
        } else {
            return res.status(200).render('./target/targetInfo', {
                target: target,
                user: req.tokenUser
            });
        }
    } catch (err) {
        if (res.contentType === 'application/json') {
            return res.status(500).json(err.message);
        } else {
            return res.status(500).render('error', {
                user: req.tokenUser
            });
        }
    }
}

module.exports = {
    getAllTargets,
    getTargetById
}