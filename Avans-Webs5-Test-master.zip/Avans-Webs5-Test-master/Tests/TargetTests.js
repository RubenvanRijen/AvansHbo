const app = require("../app");
const passportStub = require('passport-stub');
const request = require("supertest");
const chai = require('chai');
const {expect} = chai;
const chaiHttp = require('chai-http');
const faker = require('faker');
const userModel = require("../Models/User");
const targetModel = require("../Models/Target");
passportStub.install(app);
chai.use(chaiHttp);
const passport = require("passport");
const passportConfig = require("../Middleware/passport");

describe("Tests for authentication", function () {
    let tokenAdmin;
    let tokenNoAdmin;

    const constantUserAdmin = {
        username: "TestAdmin",
        email: "testadmin@gmail.com",
        password: "Test123?",
        isAdmin: true,
        method: 'local'
    }
    const userAdminData = {
        email: "testadmin@gmail.com",
        password: "Test123?"
    }

    const constantUserNoAdmin = {
        username: "TestNoAdmin",
        email: "testnoadmin@gmail.com",
        password: "Test123?",
        isAdmin: false,
        method: 'local'
    }
    const userNoAdminData = {
        email: "testnoadmin@gmail.com",
        password: "Test123?",
    }

    this.beforeAll(async function () {
        let admin = await userModel.findOne({username: constantUserAdmin.username});
        if (admin === null) {
            let result1 = await request(app)
                .post('/users/signUp')
                .set('content-type', 'application/json')
                .send(constantUserAdmin)
                .expect(201);
            tokenAdmin = result1.body.token;
        } else {
            let result2 = await request(app)
                .post('/users/signIn')
                .set('content-type', 'application/json')
                .send(userAdminData)
                .expect(200);
            tokenAdmin = result2.body.token;
        }

        let noAdmin = await userModel.findOne({username: constantUserNoAdmin.username});
        if (noAdmin === null) {
            let result3 = await request(app)
                .post('/users/signUp')
                .set('content-type', 'application/json')
                .send(constantUserNoAdmin)
                .expect(201);
            tokenNoAdmin = result3.body.token;
        } else {
            let result4 = await request(app)
                .post('/users/signIn')
                .set('content-type', 'application/json')
                .send(userNoAdminData)
                .expect(200);
            tokenNoAdmin = result4.body.token;
        }
    });

    // get all the targets test with token and no token
    describe("get targets", function () {
        it("should return 401 for getting targets without token json", function (done) {
            passportStub.logout()
            request(app)
                .get('/targets/')
                .set('content-type', 'application/json')
                .expect(401)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });

        it("should return 401 for getting targets without token html", function (done) {
            passportStub.logout()
            request(app)
                .get('/targets/')
                .set('content-type', 'text/html')
                .expect(401)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });

        it("should return 200 for getting targets with token json", function (done) {
            passportStub.logout()
            request(app)
                .get('/targets/')
                .set('content-type', 'application/json')
                .set('Authorization', tokenAdmin)
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });

        it("should return 200 for getting targets with token html", function (done) {
            passportStub.logout()
            request(app)
                .get('/targets/')
                .set('content-type', 'text/html')
                .set('Authorization', tokenAdmin)
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });


    });

    // get all the targets test with token and no token
    describe("get target", function () {
        it("should return 200 for getting target with token html", function (done) {
            passportStub.logout()
            request(app)
                .get('/targets/target1')
                .set('content-type', 'text/html')
                .set('Authorization', tokenAdmin)
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });

        it("should return 200 for getting target with token json", function (done) {
            passportStub.logout()
            request(app)
                .get('/targets/target1')
                .set('content-type', 'application/json')
                .set('Authorization', tokenAdmin)
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });

        it("should return 404 for getting target with token json", function (done) {
            passportStub.logout()
            request(app)
                .get('/targets/target3')
                .set('content-type', 'application/json')
                .set('Authorization', tokenAdmin)
                .expect(404)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });

        it("should return 404 for getting target with token html", function (done) {
            passportStub.logout()
            request(app)
                .get('/targets/target3')
                .set('content-type', 'text/html')
                .set('Authorization', tokenAdmin)
                .expect(404)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });

        it("should return 401 for getting target with no token html", function (done) {
            passportStub.logout()
            request(app)
                .get('/targets/target3')
                .set('content-type', 'text/html')
                .expect(401)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });

        it("should return 401 for getting target with no token json", function (done) {
            passportStub.logout()
            request(app)
                .get('/targets/target3')
                .set('content-type', 'application/json')
                .expect(401)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });
    });

});