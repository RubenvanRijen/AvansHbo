// set imports
const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const cors = require("cors");
require('dotenv').config()
const mongoose = require("mongoose");

//models
require("./Models/User");
require("./Models/Upload");
require("./Models/Target");


//passport
const passport = require("passport");
const passportConfig = require("./Middleware/passport");
const passJWT = passport.authenticate('jwt', {session: false});

//routes
const indexRouter = require('./routes/index');
const usersRouter = require('./routes/users');
const targetsRouter = require('./routes/targets');

// set options
const corsOptions = {
    origin: ['http://localhost:3000', 'https://still-bayou-42597.herokuapp.com'],
    optionsSuccessStatus: 200, // some legacy browsers (IE11, various SmartTVs) choke on 204
    credentials: true
}
port = process.env.SITE_PORT || 8000

// set app
const app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
// app setup
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(cookieParser());
app.use(passport.initialize());
app.use(express.static(path.join(__dirname, 'public')));
app.use(cors(corsOptions));

//routes
app.use('/', indexRouter, setContentType, passportConfig.decodeToken);
app.use('/users', usersRouter, setContentType, passportConfig.decodeToken);
app.use('/targets', targetsRouter, setContentType, passportConfig.decodeToken);

app.listen(port);
connectToDatabase();

// catch 404 and forward to error handler
app.use(setContentType, function (req, res, next) {
    if (res.contentType === 'application/json') {
        next(createError(404));
    } else {
        return res.status(404).render('error', {
            user: req.user
        });
    }
});

// error handler
app.use(function (err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render('error');
});

// set functions
function connectToDatabase() {
    mongoose
        .connect(process.env.DB_CONNECTION, {
            useUnifiedTopology: true,
            useNewUrlParser: true,
            useCreateIndex: true,
        })
        .then(() => console.log("DB Connected!"))
        .catch(err => {
            console.log("Connection error");
        });
}

function handleError(req, res, statusCode, message) {
    console.log();
    console.log("-------- Error handled --------");
    console.log("Request Params: " + JSON.stringify(req.params));
    console.log("Request Body: " + JSON.stringify(req.body));
    console.log(
        "Response sent: Statuscode " + statusCode + ', Message "' + message + '"'
    );
    console.log("-------- /Error handled --------");
    res.status(statusCode);
    res.json(message);
}

function setContentType(req, res, next) {
    let content = req.headers['content-type'];
    if (content === 'application/json') {
        res.contentType = 'application/json'
    } else {
        res.contentType = "text/html";
    }
    next();
}

//testData
require("./Models/FillTestData")();


module.exports = app;
