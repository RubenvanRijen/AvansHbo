// Initialize Firebase
export const firebaseConfig = {
    apiKey: 'AIzaSyCxM94XLHJPy3FCD2WJDUCsbaq_8yAXUMM',
    authDomain: '953725378636-2subf992ghv9bbnuk5d5d6jl579ohoi0.apps.googleusercontent.com',
    databaseURL: 'https://pokedex-6d573.firebaseio.com',
    projectId: 'pokedex-6d573',
    storageBucket: 'pokedex-6d573.appspot.com',
    messagingSenderId: '953725378636'
  };