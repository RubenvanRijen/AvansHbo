import {NgModule} from '@angular/core';
import {PreloadAllModules, RouterModule, Routes} from '@angular/router';
import {AuthGuard as AuthGaurd} from '../app/service/auth/auth.guard';

const routes: Routes = [
    {path: '', redirectTo: '/login', pathMatch: 'full'},
    {
        path: 'home',
        loadChildren: () =>
            import('./home/home.module').then(m => m.HomePageModule),
        canActivate: [AuthGaurd]
    },
    {
        path: 'home/:index/:type/:caughtID',
        loadChildren: () =>
            import('./details/details.module').then(m => m.DetailsPageModule),
        canActivate: [AuthGaurd]
    },
    {
        path: 'geocaches',
        loadChildren: () =>
            import('./geocaches/geocaches.module').then(m => m.GeocachesPageModule),
        canActivate: [AuthGaurd]
    },
    {
        path: 'geocaches/:index',
        loadChildren: () =>
            import('./geocache-details/geocache-details.module').then(
                m => m.GeocacheDetailsPageModule
            ),
        canActivate: [AuthGaurd]
    },
    {
        path: 'login',
        loadChildren: () =>
            import('./login/login.module').then(m => m.LoginPageModule)
    },
    {
        path: 'register',
        loadChildren: () =>
            import('./register/register.module').then(m => m.RegisterPageModule)
    },
    {
        path: 'reset',
        loadChildren: () =>
            import('./reset/reset.module').then(m => m.ResetPageModule)
    }
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes, {preloadingStrategy: PreloadAllModules})
    ],
    exports: [RouterModule]
})
export class AppRoutingModule {
}
