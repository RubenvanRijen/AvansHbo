import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import {PokemonModel} from '../../model/PokemonModel';
import {Storage} from '@ionic/storage';

@Injectable({
    providedIn: 'root'
})
export class PokemonService {
    baseUrl = 'https://pokeapi.co/api/v2';
    imageUrl =
        'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/';

    constructor(private http: HttpClient, private storage: Storage) {
    }

    getPokemon(offset = 0) {
        return this.http
            .get(`${this.baseUrl}/pokemon?offset=${offset}&limit=25`)
            .pipe(
                map(result => {
                    return result['results'];
                }),
                map(pokemons => {
                    return pokemons.map((poke, index) => {
                        poke.image = this.getPokeImage(index + offset + 1);
                        poke.pokeIndex = offset + index + 1;
                        poke.caughtID = null;
                        poke.nickName = null;
                        return poke;
                    });
                })
            );
    }

    getPokeImage(index) {
        return `${this.imageUrl}${index}.png`;
    }

    findPokemon(pokemonName) {
        if (typeof pokemonName === 'string') {
            pokemonName = pokemonName.toLowerCase();
        }

        return this.http.get(`${this.baseUrl}/pokemon/${pokemonName}`).pipe(
            map(pokemon => {
                pokemon['image'] = this.getPokeImage(pokemon['id']);
                pokemon['pokeIndex'] = pokemon['id'];
                return pokemon;
            })
        );
    }

    getPokeDetails(index) {
        return this.http.get(`${this.baseUrl}/pokemon/${index}`).pipe(
            map(poke => {
                const sprites = Object.keys(poke['sprites']);
                poke['images'] = sprites
                    .map(spriteKey => poke['sprites'][spriteKey])
                    .filter(img => img);
                return poke;
            })
        );
    }

    setPokemons() {
        let key = 'caughtPokemon';
        key = key.toString();
        this.storage.get(key).then(data => {
            if (!data) {
                this.storage.set('caughtPokemon', []);
            } else {
                return;
            }
        });
    }

    getCaughtPokemon() {
        this.setPokemons();
        let pokemons = [];
        this.storage.get('caughtPokemon').then(caughtPokemon => {
            if (!caughtPokemon) {
                return pokemons;
            }
            caughtPokemon.forEach(pokemon => {
                this.findPokemon(pokemon.name).subscribe(
                    res => {
                        res['caughtID'] = pokemon.caughtID;
                        res['nickName'] = pokemon.nickName;
                        pokemons.push(res);
                    },
                    err => {
                        pokemons = [];
                    }
                );
            });
        });
        return pokemons;
    }

    async getOneCaughtPokemon(pokemonName) {
        let data = null;
        await this.storage.get('caughtPokemon').then(caughtPokemon => {
            caughtPokemon.forEach(pokemon => {
                if (pokemon.caughtID === parseInt(pokemonName)) {
                    data = pokemon;
                }
            });
        });
        return data;
    }

    getMaxID(arr, prop) {
        let max;
        for (let i = 0; i < arr.length; i++) {
            if (max == null || parseInt(arr[i][prop]) > parseInt(max[prop])) {
                max = arr[i];
            }
        }
        return max;
    }

    async addCaughtPokemon(pokemonName, pokemonImage) {
        this.setPokemons();
        let caughtPokemons = [];
        let number;
        await this.storage.get('caughtPokemon').then(res => {
            if (res !== null) {
                caughtPokemons = [...res];
                if (caughtPokemons.length === 0) {
                    number = 0;
                } else {
                    const value = this.getMaxID(res, 'caughtID');
                    number = value.caughtID + 1;
                }
            }
        });
        const newPokemon: PokemonModel = {
            name: pokemonName,
            image: pokemonImage,
            caughtID: number,
            nickName: pokemonName
        };
        caughtPokemons.push(newPokemon);
        await this.storage.set('caughtPokemon', caughtPokemons);
    }

    async EditPokemon(id, updatedname) {
        this.setPokemons();
        let caughtPokemons = [];
        await this.storage.get('caughtPokemon').then(res => {
            if (res !== null) {
                caughtPokemons = [...res];
            }
        });

        for (let i = 0; i < caughtPokemons.length; i++) {
            const obj = caughtPokemons[i];

            if (obj.caughtID === parseInt(id)) {
                obj.nickName = updatedname;
            }
        }
        await this.storage.set('caughtPokemon', caughtPokemons);

    }

    async deleteCaughtPokemon(id) {
        let pokemons = [];
        await this.storage.get('caughtPokemon').then(res => {
            if (res !== null) {
                pokemons = [...res];
            }
        });
        for (let i = 0; i < pokemons.length; i++) {
            const obj = pokemons[i];

            if (obj.caughtID === parseInt(id)) {
                pokemons.splice(i, 1);
            }
        }

        await this.storage.set('caughtPokemon', pokemons);
    }
}
