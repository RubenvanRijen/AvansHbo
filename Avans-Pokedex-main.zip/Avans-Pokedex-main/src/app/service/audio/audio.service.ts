import { Injectable } from '@angular/core';
import { NativeAudio } from '@ionic-native/native-audio/ngx';

@Injectable({
  providedIn: 'root'
})
export class AudioService {

  constructor(private nativeAudio: NativeAudio) {
    this.nativeAudio.preloadComplex('wildPokemonEncounter', 'assets/audio/wildPokemonEncounter.mp3', 0.5, 1, 1);
    this.nativeAudio.preloadSimple('successfullyCaughtPokemon', 'assets/audio/successfullyCaughtPokemon.mp3');
    this.nativeAudio.preloadSimple('pokeballWiggle', 'assets/audio/pokeballWiggle.mp3');
    this.nativeAudio.preloadSimple('pokemonOutOfPokeball', 'assets/audio/pokemonOutOfPokeball.mp3');
    this.nativeAudio.preloadSimple('pokeballThrow', 'assets/audio/pokeballThrow.mp3');
  }

  playEncounter() { 
    this.nativeAudio.loop('wildPokemonEncounter');
  }

  stopEncounter() {
    this.nativeAudio.stop('wildPokemonEncounter');
  }

  playSuccessfullyCaught() { 
    this.nativeAudio.play('successfullyCaughtPokemon');
  }

  playPokeballWiggle() { 
    this.nativeAudio.play('pokeballWiggle');
  }

  playPokemonOutOfPokeball() { 
    this.nativeAudio.play('pokemonOutOfPokeball');
  }

  playPokeballThrow() { 
    this.nativeAudio.play('pokeballThrow');
  }
}
