import {Injectable} from '@angular/core';
import {Storage} from '@ionic/storage';
import {GeocacheDataSeeder} from '../../geocacheDataSeeder';
import {GeocacheModel} from '../../model/GeocacheModel';

@Injectable({
    providedIn: 'root'
})
export class GeocacheService {
    minLat = 51.685718;
    minLong = 5.275479;
    maxLat = 51.719601;
    maxLong = 5.335585;

    constructor(
        private storage: Storage,
        private geocacheDataSeeder: GeocacheDataSeeder
    ) {
        this.setGeocaches();
    }

    async setGeocaches() {
        let key = 'geocaches';
        key = key.toString();
        await this.storage.get(key).then(async data => {
            if (!data) {
                let randomCaches = await this.geocacheDataSeeder.geocaches;
                randomCaches = await randomCaches.concat(this.getRandomGeocaches(5));
                await this.storage.set('geocaches', randomCaches);
            } else {
                return;
            }
        });
    }

    async getGeocaches() {
        await this.setGeocaches();
        return this.storage.get('geocaches');
    }

    async getGeocacheDetails(index) {
        let geo = null;
        await this.getGeocaches().then(res => {
            geo = res[index];
        });
        return geo;
    }

    getRandomGeocaches(amount: number) {
        const randomGeocaches: GeocacheModel[] = [];

        for (let i = 0; i < amount; i++) {
            const lat = Math.fround(
                Math.random() * (this.maxLat - this.minLat + 1) + this.minLat
            ).toFixed(6);
            const long = Math.fround(
                Math.random() * (this.maxLong - this.minLong + 1) + this.minLong
            ).toFixed(6);
            const backgroundImageIndex = Math.floor(Math.random() * (6 - 1 + 1) + 1);
            const randomGeocache: GeocacheModel = {
                longitude: long.toString(),
                latitude: lat.toString(),
                description: 'Unknown',
                image: `../assets/battle-backgrounds/place-${backgroundImageIndex}.png`,
                id: i + 6
            };
            randomGeocaches.push(randomGeocache);
        }
        return randomGeocaches;
    }
}
