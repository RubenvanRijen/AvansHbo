import {Injectable} from '@angular/core';
import {Camera, CameraOptions} from '@ionic-native/camera/ngx';
import {AndroidPermissions} from '@ionic-native/android-permissions/ngx';

@Injectable({
    providedIn: 'root'
})
export class CameraService {

    options: CameraOptions = {
        quality: 100,
        destinationType: this.camera.DestinationType.DATA_URL,
        encodingType: this.camera.EncodingType.JPEG,
        mediaType: this.camera.MediaType.PICTURE
    };

    constructor(
        private camera: Camera,
        private androidPermissions: AndroidPermissions) {
    }

    async openCamera() {
        // tslint:disable-next-line:max-line-length
        let base64Image = '';
        await this.camera.getPicture(this.options).then(
            imageData => {
                base64Image = 'data:image/jpeg;base64,' + imageData;
            },
            err => {
                // Handle error
            }
        );
        return base64Image;
    }

    getCameraPermissions() {
        this.androidPermissions
            .checkPermission(this.androidPermissions.PERMISSION.CAMERA)
            .then(
                result => console.log('Has permission?', result.hasPermission),
                err => {
                    this.androidPermissions.requestPermission(
                        this.androidPermissions.PERMISSION.CAMERA
                    );
                }
            );
        // tslint:disable-next-line:max-line-length
        this.androidPermissions.requestPermissions([
            this.androidPermissions.PERMISSION.CAMERA,
            this.androidPermissions.PERMISSION.GET_ACCOUNTS
        ]);
    }
}
