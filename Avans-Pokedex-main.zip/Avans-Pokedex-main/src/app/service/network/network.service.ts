import {Injectable} from '@angular/core';
import {Network} from '@ionic-native/network/ngx';
import {AlertController, ToastController} from '@ionic/angular';
import {Router} from '@angular/router';
import {Plugins} from '@capacitor/core';


@Injectable({
    providedIn: 'root'
})
export class NetworkService {

    constructor(
        private network: Network,
        private routes: Router,
        private alertController: AlertController,
        private toastController: ToastController) {
    }

    async checkForConnection() {
        return Plugins.Network.addListener('networkStatusChange', async (status) => {
            
            if (status.connected === false) {
                await this.routes.navigateByUrl('/login');
                await this.displayNoConnectionToast();
            }
        });

    }

    async lostConnection() {
        // watch network for a disconnection
        this.network.onDisconnect().subscribe(() => {
            this.alertController.create({
                header: 'Alert !',
                message: 'You do not have any connection anymore',
                buttons: [
                    {
                        text: 'Okay',
                        handler: async () => {
                            await this.routes.navigateByUrl('/login');
                            await this.displayNoConnectionToast();
                        }
                    }
                ]
            }).then(alertEl => {
                alertEl.present();
            });
        });
    }

    async displayNoConnectionToast() {
        const toast = await this.toastController.create({
            message: 'No more connection',
            duration: 2000,
            position: 'bottom'
        });
        await toast.present();
    }


    gotConnection(stop) {
        let connection = false;
        const connectSubscription = this.network.onConnect().subscribe(() => {
            console.log('network connected!');
            setTimeout(() => {
                if (this.network.type === 'wifi') {
                    connection = true;
                }
            }, 3000);
        });
        if (stop === true) {
            // stop connect watch
            connectSubscription.unsubscribe();
        }
        return connection;

    }

}
