import {Injectable} from '@angular/core';
import {Geolocation} from '@ionic-native/geolocation/ngx';
import * as geolib from 'geolib';
import {AndroidPermissions} from '@ionic-native/android-permissions/ngx';
import {LocationAccuracy} from '@ionic-native/location-accuracy/ngx';

@Injectable({
    providedIn: 'root'
})
export class GeoLocationService {
    deviceLocation: any = {};
    range = 3000;

    constructor(
        private geolocation: Geolocation,
        private androidPermissions: AndroidPermissions,
        private locationAccuracy: LocationAccuracy) {
    }

    getDistance(lat1, lon1, lat2, lon2) {
        const meters = geolib.getPreciseDistance(
            {latitude: lat1, longitude: lon1},
            {latitude: lat2, longitude: lon2}
        );
        return meters;
    }

    setGeoLocation() {
        this.geolocation
            .getCurrentPosition()
            .then(resp => {
                this.deviceLocation.latitude = resp.coords.latitude;
                this.deviceLocation.longitude = resp.coords.longitude;
            })
            .catch(error => {
                console.log('Error getting location', error);
            });
    }

    getGeolocation() {
        return this.deviceLocation;
    }

    watchGeoPosition() {
        const watch = this.geolocation.watchPosition();
        return watch;
    }

    checkGPSPermission() {
        return new Promise((resolve, reject) => {
            this.androidPermissions
                .checkPermission(
                    this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION
                )
                .then(
                    result => {
                        if (result.hasPermission) {
                            this.askToTurnOnGPS().then(e => {
                                if (e === false) {
                                    resolve(false);
                                } else {
                                    resolve(true);
                                }
                            });

                        } else {
                            this.requestGPSPermission().then(e => {
                                if (e === false) {
                                    resolve(false);
                                } else {
                                    resolve(true);
                                }
                            });
                        }
                    },
                    err => {
                        alert(err);
                        resolve(false);
                    }
                );
        });
    }

    requestGPSPermission() {
        return new Promise((resolve, reject) => {

            this.locationAccuracy.canRequest().then((canRequest: boolean) => {
                if (canRequest) {
                    console.log('4');
                } else {
                    this.androidPermissions
                        .requestPermission(
                            this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION
                        )
                        .then(
                            () => {
                                this.askToTurnOnGPS().then(e => {
                                    if (e === false) {
                                        alert(
                                            'requestPermission Error requesting location permissions ' +
                                            e
                                        );
                                        resolve(false);
                                    } else {
                                        resolve(true);
                                    }
                                });
                            },
                            error => {
                                alert(
                                    'requestPermission Error requesting location permissions ' +
                                    error
                                );
                                resolve(false);
                            }
                        );
                }
            });
        });
    }

    askToTurnOnGPS() {
        return new Promise((resolve, reject) => {

            this.locationAccuracy
                .request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY)
                .then(
                    () => {
                        this.getGeolocation();
                        resolve(true);
                    },
                    error => {
                        alert(
                            'Error requesting location permissions ' + JSON.stringify(error)
                        );
                        resolve(false);
                    }
                );
        });
    }
}
