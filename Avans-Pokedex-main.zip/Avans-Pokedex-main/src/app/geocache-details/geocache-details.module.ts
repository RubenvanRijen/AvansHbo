import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GeocacheDetailsPageRoutingModule } from './geocache-details-routing.module';

import { GeocacheDetailsPage } from './geocache-details.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GeocacheDetailsPageRoutingModule
  ],
  declarations: [GeocacheDetailsPage]
})
export class GeocacheDetailsPageModule {}
