import {Component, OnInit} from '@angular/core';
import {GeocacheService} from '../service/geocache/geocache.service';
import {ActivatedRoute} from '@angular/router';
import {GeoLocationService} from '../service/geoLocation/geo-location.service';
import {PokemonService} from '../service/pokemon/pokemon.service';
import {AudioService} from '../service/audio/audio.service';
import {CameraService} from '../service/camera/camera.service';

@Component({
    selector: 'app-geocache-details',
    templateUrl: './geocache-details.page.html',
    styleUrls: ['./geocache-details.page.scss']
})
export class GeocacheDetailsPage implements OnInit {
    details: any;
    geoPosition: any = {};
    pokemon: any;
    isInRange: boolean = false;
    imgSrc: string = '';
    hasPokeball: boolean = true;
    pokemonImgSrc: string;
    description: string;
    maxOffset: number = 775;
    wigglePokeballDelay: number = 1000;
    catchPokemonDelay: number = 3200;
    openCameraDelay: number = 6000;

    constructor(
        private route: ActivatedRoute,
        private geocacheService: GeocacheService,
        private geoLocationService: GeoLocationService,
        private pokemonService: PokemonService,
        private cameraService: CameraService,
        private audioService: AudioService
    ) {
    }

    async ionViewWillEnter() {
        this.cameraService.getCameraPermissions();
        const index = this.route.snapshot.paramMap.get('index');
        this.geoLocationService.setGeoLocation();
        this.geoPosition = this.geoLocationService.getGeolocation();
        this.geoLocationService.watchGeoPosition().subscribe(e => {
            this.geoPosition.latitude = e.coords.latitude;
            this.geoPosition.longitude = e.coords.longitude;
        });
        await this.geocacheService.getGeocacheDetails(index).then(res => {
            this.details = res;
        });
        this.isInRange = this.getIsInRange(
            this.geoPosition.latitude,
            this.geoPosition.longitude,
            this.details.latitude,
            this.details.longitude
        );
        if (this.isInRange) {
            this.loadWildPokemon();
            this.audioService.playEncounter();
            this.imgSrc = '../../assets/pokeball.png';
        }
    }

    ngOnInit() {
    }

    stopEncounterMusic() {
        this.audioService.stopEncounter();
    }

    getDistance(lat1, lon1, lat2, lon2) {
        return this.geoLocationService.getDistance(lat1, lon1, lat2, lon2);
    }

    getIsInRange(lat1, lon1, lat2, lon2) {
        return (
            this.getDistance(lat1, lon1, lat2, lon2) <= this.geoLocationService.range
        );
    }

    loadWildPokemon() {
        const index = Math.floor(Math.random() * this.maxOffset) + 1;
        this.pokemonService.findPokemon(index).subscribe(res => {
            this.pokemon = res;
            this.pokemonImgSrc = this.pokemonService.getPokeImage(index);
            this.pokemon = this.pokemon.name;
            this.description = `A wild ${this.pokemon} appeared!`;
        });
    }

    throwPokeball() {
        if (this.hasPokeball) {
            this.hasPokeball = false;
            this.audioService.stopEncounter();
            this.audioService.playPokeballThrow();
            this.description = `Player threw a pokeball!`;
            this.imgSrc = '../../assets/pokeballThrow.gif';
            setTimeout(() => this.wigglePokeball(), this.wigglePokeballDelay);
        }
    }

    wigglePokeball() {
        this.imgSrc = '../../assets/pokeballWiggle.gif';
        this.description = `...`;
        this.audioService.playPokeballWiggle();
        setTimeout(() => this.catchPokemon(), this.catchPokemonDelay);
    }

    catchPokemon() {
        const isCaught = true;
        // Math.round(Math.random())
        if (isCaught) {
            this.audioService.playSuccessfullyCaught();
            this.imgSrc = '../../assets/pokemonInPokeball.gif';
            this.description = `Gotcha!`;
            setTimeout(() => {
                this.cameraService.openCamera().then(r => {
                    this.pokemonService.addCaughtPokemon(this.pokemon, r);
                });
            }, this.openCameraDelay);
        } else {
            this.audioService.playPokemonOutOfPokeball();
            this.description = `${this.pokemon} fleed!`;
            this.imgSrc = '../../assets/openPokeball.png';
        }
    }
}
