export interface GeocacheModel {
    longitude: string;
    latitude: string;
    description: string;
    image: string;
    id: number;
}