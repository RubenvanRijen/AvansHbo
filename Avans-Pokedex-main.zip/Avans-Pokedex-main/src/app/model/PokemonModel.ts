export interface PokemonModel {
    caughtID: string;
    name: string;
    image: string;
    nickName: string;
}
