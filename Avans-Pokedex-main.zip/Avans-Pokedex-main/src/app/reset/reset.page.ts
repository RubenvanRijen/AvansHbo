import { Component, OnInit } from "@angular/core";
import { AuthService } from "../service/auth/auth.service";
import { AlertController } from "@ionic/angular";
import { Router } from "@angular/router";

@Component({
  selector: "app-reset",
  templateUrl: "./reset.page.html",
  styleUrls: ["./reset.page.scss"]
})
export class ResetPage implements OnInit {
  constructor(
    private authService: AuthService,
    private alertCtrl: AlertController,
    private router: Router
  ) {}

  ngOnInit() {}

  resetPassword(email): void {
    this.authService.resetPassword(email).then(
      async () => {
        const alert = await this.alertCtrl.create({
          message: "Check your email for a password reset link",
          buttons: [
            {
              text: "Ok",
              role: "cancel",
              handler: () => {
                this.router.navigateByUrl("login");
              }
            }
          ]
        });
        await alert.present();
      },
      async error => {
        const errorAlert = await this.alertCtrl.create({
          message: error.message,
          buttons: [{ text: "Ok", role: "cancel" }]
        });
        await errorAlert.present();
      }
    );
  }
}
