import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {RouteReuseStrategy} from '@angular/router';

import {IonicModule, IonicRouteStrategy} from '@ionic/angular';
import {SplashScreen} from '@ionic-native/splash-screen/ngx';
import {StatusBar} from '@ionic-native/status-bar/ngx';

import {AppComponent} from './app.component';
import {AppRoutingModule} from './app-routing.module';
import {HttpClientModule} from '@angular/common/http';
import {IonicStorageModule} from '@ionic/storage';
import {Geolocation} from '@ionic-native/geolocation/ngx';
import {Camera} from '@ionic-native/camera/ngx';
import {NativeAudio} from '@ionic-native/native-audio/ngx';
import {NavigationBar} from '@ionic-native/navigation-bar/ngx';
import {LocationAccuracy} from '@ionic-native/location-accuracy/ngx';
import {AndroidPermissions} from '@ionic-native/android-permissions/ngx';
import {GeocacheDataSeeder} from './geocacheDataSeeder';
import {OneSignal} from '@ionic-native/onesignal/ngx';
import {Toast} from '@ionic-native/toast/ngx';
import {NotificationsComponent} from './notifications/notifications.component';
import {Network} from '@ionic-native/network/ngx';


@NgModule({
    declarations: [AppComponent, NotificationsComponent],
    entryComponents: [NotificationsComponent],
    imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule, HttpClientModule, IonicStorageModule.forRoot()],
    providers: [
        StatusBar,
        SplashScreen,
        Geolocation,
        Camera,
        NativeAudio,
        NavigationBar,
        LocationAccuracy,
        AndroidPermissions,
        GeocacheDataSeeder,
        OneSignal,
        Toast,
        Network,
        {provide: RouteReuseStrategy, useClass: IonicRouteStrategy,}
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
