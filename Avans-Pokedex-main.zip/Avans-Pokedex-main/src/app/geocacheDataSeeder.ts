import {GeocacheModel} from './model/GeocacheModel';
import {Injectable} from '@angular/core';

@Injectable()
export class GeocacheDataSeeder {

    public geocaches: GeocacheModel[] = [
        {
            longitude: '5.2966174',
            latitude: '51.690227',
            description: 'Bossche bollen',
            image: '../assets/fixed-geocaches/jan-de-groot.jpg',
            id: 0
        },

        {
            longitude: '5.2869727',
            latitude: '51.6886659',
            description: 'People study here',
            image: '../assets/fixed-geocaches/onderwijsboulevard.jpg',
            id: 1
        },

        {
            longitude: '5.3036748',
            latitude: '51.6978162',
            description: 'Center of Den Bosch',
            image: '../assets/fixed-geocaches/draken-fontein.jpg',
            id: 2
        },
        {
            longitude: '5.321985',
            latitude: '51.732461',
            description: 'Teaching kids at village',
            image: '../assets/fixed-geocaches/wikveld.jpg',
            id: 3
        },
        {
            longitude: '5.315833',
            latitude: '51.736769',
            description: 'Protecting the village from water',
            image: '../assets/fixed-geocaches/dijk.jpg',
            id: 4
        },
        {
            longitude: '5.559137',
            latitude: '51.820148',
            description: 'Guiding Cargo',
            image: '../assets/fixed-geocaches/cg.jpg',
            id: 5
        }
    ];
}
