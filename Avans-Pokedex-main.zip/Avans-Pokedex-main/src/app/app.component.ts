import {Component} from '@angular/core';

import {Platform, ToastController} from '@ionic/angular';
import {SplashScreen} from '@ionic-native/splash-screen/ngx';
import {StatusBar} from '@ionic-native/status-bar/ngx';
import {NavigationBar} from '@ionic-native/navigation-bar/ngx';
import * as firebase from 'firebase/app';
import {firebaseConfig} from './credentials';
import {Router} from '@angular/router';


@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
    styleUrls: ['app.component.scss']
})
export class AppComponent {
    constructor(
        private toastController: ToastController,
        private routes: Router,
        private platform: Platform,
        private splashScreen: SplashScreen,
        private statusBar: StatusBar,
        private navigationBar: NavigationBar,
    ) {
        this.initializeApp();
        firebase.initializeApp(firebaseConfig);

    }

    initializeApp() {
        this.platform.ready().then(() => {
            this.statusBar.hide();
            this.splashScreen.hide();
            let autoHide: boolean = true;
            this.navigationBar.setUp(autoHide);

            window['plugins'].OneSignal.startInit(
                '9147b8d3-7e45-43b3-bbd3-a1001d1db345',
                'MjU0NDlkYTEtZWY3OC00MGIzLWI5YjItNTg0NGYwZTIyNjg3'
            ).endInit();
        });
    }
}
