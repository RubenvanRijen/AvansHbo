import {Component, OnInit, ViewChild} from '@angular/core';
import {PokemonService} from '../service/pokemon/pokemon.service';
import {IonInfiniteScroll} from '@ionic/angular';
import {PopoverController, AlertController} from '@ionic/angular';
import {NotificationsComponent} from '../notifications/notifications.component';
import {MenuController} from '@ionic/angular';
import {NetworkService} from '../service/network/network.service';
import {Plugins} from '@capacitor/core';


@Component({
    selector: 'app-home',
    templateUrl: 'home.page.html',
    styleUrls: ['home.page.scss']
})
export class HomePage implements OnInit {
    offset = 0;
    pokemon = [];
    maxOffset = 775;
    segment = 'pokedex';
    caugthpokemons = [];

    @ViewChild(IonInfiniteScroll, {static: false}) infinite: IonInfiniteScroll;

    constructor(
        private pokeService: PokemonService,
        private popoverController: PopoverController,
        private menuController: MenuController,
        private networkService: NetworkService,
        public alertController: AlertController
    ) {
    }

    ionViewWillEnter() {
        this.initializePokemons();
    }

    async ngOnInit() {
        this.networkService.checkForConnection();
    }

    initializePokemons() {
        this.caugthpokemons = this.pokeService.getCaughtPokemon();
        if (this.segment === 'pokedex') {
            this.loadPokemon();
        } else if (this.segment === 'caught') {
            this.loadCaughtPokemon();
        }
    }

    doRefresh(event) {
        if (this.segment === 'caught') {
            this.loadCaughtPokemon();
        }

        setTimeout(() => {
            event.target.complete();
        }, 2000);
    }

    openFirst() {
        this.menuController.enable(true, 'first');
        this.menuController.open('first');
    }

    openEnd() {
        this.menuController.open('end');
    }

    openCustom() {
        this.menuController.enable(true, 'custom');
        this.menuController.open('custom');
    }

    async notifications(ev: any) {
        const popover = await this.popoverController.create({
            component: NotificationsComponent,
            event: ev,
            animated: true,
            showBackdrop: true,
            componentProps: {data: this.caugthpokemons.length}
        });
        return await popover.present();
    }

    loadMorePokemon(loadMore = false, event?) {
        if (loadMore) {
            this.offset += 25;
        }

        this.pokeService.getPokemon(this.offset).subscribe(res => {
            this.pokemon = [...this.pokemon, ...res];

            if (event) {
                event.target.complete();
            }

            if (this.offset === this.maxOffset) {
                this.infinite.disabled = true;
            }
        });
    }

    loadPokemon() {
        this.offset = 0;

        this.pokeService.getPokemon(this.offset).subscribe(res => {
            this.pokemon = [...this.pokemon, ...res];
        });
        this.offset += 25;
    }

    segmentChanged(e) {
        if (e.target.value === this.segment) {
            return;
        }

        if (e.target.value === 'pokedex') {
            this.pokemon = [];
            this.loadPokemon();
            this.segment = 'pokedex';
        } else {
            this.segment = 'caught';
            this.loadCaughtPokemon();
        }
    }

    loadCaughtPokemon() {
        this.pokemon = this.pokeService.getCaughtPokemon();
    }

    getOneCaughtPokemon(id) {
        this.pokeService.getOneCaughtPokemon(id).then(e => {
            return e;
        });
    }

    async onSearchChange(e) {
        let value = e.detail.value;
        value = value.toLowerCase();
        if (value === '') {
            this.offset = 0;
            this.pokemon = [];
            if (this.segment === 'pokedex') {
                this.loadPokemon();
            } else {
                this.loadCaughtPokemon();
            }
            return;
        }

        if (this.segment === 'pokedex') {
            this.pokeService.findPokemon(value).subscribe(
                res => {
                    this.pokemon = [res];
                },
                () => {
                    this.pokemon = [];
                }
            );
        } else {
            const filteredPokemon = this.caugthpokemons;
            this.pokemon = [];
            filteredPokemon.forEach(element => {
                if (element.name === value.toString()) {
                    this.pokemon.push(element);
                }
            });
        }
    }
}
