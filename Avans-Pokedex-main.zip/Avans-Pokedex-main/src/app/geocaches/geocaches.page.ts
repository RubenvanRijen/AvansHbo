import {Component, OnInit} from '@angular/core';
import {GeocacheService} from '../service/geocache/geocache.service';
import {GeoLocationService} from '../service/geoLocation/geo-location.service';
import {Router} from '@angular/router';

@Component({
    selector: 'app-geocaches',
    templateUrl: './geocaches.page.html',
    styleUrls: ['./geocaches.page.scss']
})
export class GeocachesPage implements OnInit {
    geocaches: any = [];
    geoPosition: any;
    deviceLocation: any = {};
    data: any = {};

    constructor(
        private geocacheService: GeocacheService,
        private geoLocationService: GeoLocationService,
        private routes: Router,
    ) {
    }

    async ngOnInit() {
        await this.geoLocationService.checkGPSPermission().then(async e => {
            if (e === true) {
                await this.geoLocationService.setGeoLocation();
                this.deviceLocation = await this.geoLocationService.getGeolocation();
                this.geoLocationService.watchGeoPosition().subscribe(loc => {
                    if (loc.coords.latitude != null) {
                        this.deviceLocation.latitude = loc.coords.latitude;
                    }
                    if (loc.coords.longitude != null) {
                        this.deviceLocation.longitude = loc.coords.longitude;
                    }
                });
                await this.loadGeocaches();
            } else {
                await this.routes.navigateByUrl('/home');
            }
        }).catch(() => {
            console.error('Do that');
        });

    }

    async doRefresh(event) {
        await this.loadGeocaches();

        setTimeout(() => {
            event.target.complete();
        }, 2000);
    }

    getCeoChaes() {
        return this.deviceLocation;
    }

    getDistance(lat1, lon1, lat2, lon2) {
        return this.geoLocationService.getDistance(lat1, lon1, lat2, lon2);
    }

    isInRange(lat1, lon1, lat2, lon2) {
        return this.getDistance(lat1, lon1, lat2, lon2) <= this.geoLocationService.range;
    }

    async loadGeocaches() {
        this.geocaches = await this.geocacheService.getGeocaches();
    }
}
