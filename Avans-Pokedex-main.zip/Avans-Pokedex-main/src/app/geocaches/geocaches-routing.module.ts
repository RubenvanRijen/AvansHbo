import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GeocachesPage } from './geocaches.page';

const routes: Routes = [
  {
    path: '',
    component: GeocachesPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GeocachesPageRoutingModule {}
