import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { GeocachesPage } from './geocaches.page';

describe('GeocachesPage', () => {
  let component: GeocachesPage;
  let fixture: ComponentFixture<GeocachesPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GeocachesPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(GeocachesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
