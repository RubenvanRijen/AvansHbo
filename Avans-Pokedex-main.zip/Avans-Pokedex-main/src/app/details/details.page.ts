import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {PokemonService} from '../service/pokemon/pokemon.service';
import {AlertController, ToastController} from '@ionic/angular';


@Component({
    selector: 'app-details',
    templateUrl: './details.page.html',
    styleUrls: ['./details.page.scss']
})
export class DetailsPage implements OnInit {
    details: any;
    pokemonImage = '';
    caughtID;
    type;
    index: any;
    nickName: string;
    caughtPokemon: Boolean = false;
    slideOpts = {
        autoplay: {
            delay: 1000,
            disableOnInteraction: false
        }
    };

    constructor(
        private route: ActivatedRoute,
        private pokemonService: PokemonService,
        private routes: Router,
        private alertController: AlertController,
        private toastController: ToastController
    ) {
    }

    ngOnInit() {
        this.index = this.route.snapshot.paramMap.get('index');
        this.type = this.route.snapshot.paramMap.get('type');
        this.caughtID = this.route.snapshot.paramMap.get('caughtID');
        if (this.type === 'caught') {
            this.caughtPokemon = true;
            this.getPokemon(this.caughtID);
        }
        this.pokemonService.getCaughtPokemon();

        this.pokemonService.getPokeDetails(this.index).subscribe(details => {
            this.details = details;
        });
    }

    async getPokemon(index) {
        let pokemon;
        pokemon = this.pokemonService.getOneCaughtPokemon(index);
        pokemon.then(caught => {
            this.pokemonImage = caught.image;
            this.nickName = caught.nickName;
        });
    }

    async deletePokemon() {
        await this.onDeletePokemon();
    }

    async onDeletePokemon() {
        await this.alertController.create({
            header: 'Are you sure?',
            message: 'Do you really want to remove ' + this.details.name + ' from the pokedex?',
            buttons: [
                {
                    text: 'Cancel',
                    role: 'cancel'
                },
                {
                    text: 'Delete',
                    handler: async () => {
                        await this.pokemonService.deleteCaughtPokemon(this.caughtID);
                        await this.routes.navigateByUrl('/home');
                        await this.displaySuccessfullyDeletedToast();
                    }
                }
            ]
        }).then(alertEl => {
            alertEl.present();
        });
    }

    async displaySuccessfullyDeletedToast() {
        const toast = await this.toastController.create({
            message: 'Pokemon succesfully deleted',
            duration: 2000,
            position: 'bottom'
        });
        toast.present();
    }

    async displaySuccessfullyUpdatedToast() {
        const toast = await this.toastController.create({
            message: 'Pokemon succesfully updated',
            duration: 2000,
            position: 'bottom'
        });
        toast.present();
    }

    async editPokemon(id, input) {
        await this.pokemonService.EditPokemon(id, input.nickName);
        await this.displaySuccessfullyUpdatedToast();
    }
}
