import { Component, OnInit } from "@angular/core";
import { AuthService } from "../service/auth/auth.service";
import { AlertController } from "@ionic/angular";
import { Router } from "@angular/router";
import { ToastController } from '@ionic/angular';

@Component({
  selector: "app-register",
  templateUrl: "./register.page.html",
  styleUrls: ["./register.page.scss"]
})
export class RegisterPage implements OnInit {
  constructor(
    private authService: AuthService,
    private alertCtrl: AlertController,
    private router: Router,
    private toastController: ToastController
  ) {}

  ngOnInit() {}

  async signupUser(credentials): Promise<void> {
    this.authService.signupUser(credentials.email, credentials.password).then(
      async () => {
        await this.displaySuccessfullToast();
        this.router.navigateByUrl("home");
      },
      async error => {
        const alert = await this.alertCtrl.create({
          message: error.message,
          buttons: [{ text: "Ok", role: "cancel" }]
        });
        await alert.present();
      }
    );
  }

  async displaySuccessfullToast() {
    let toast = await this.toastController.create({
      message: "Account successfully created! Redirecting to pokedex",
      duration: 2000,
      position: "bottom"
    });
    toast.present();
  }
}
