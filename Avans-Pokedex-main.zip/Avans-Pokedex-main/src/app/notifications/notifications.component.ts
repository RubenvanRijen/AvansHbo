import {Component, OnInit} from '@angular/core';
import {NavParams} from '@ionic/angular';

@Component({
    selector: 'app-notifications',
    templateUrl: './notifications.component.html',
    styleUrls: ['./notifications.component.scss'],
})
export class NotificationsComponent implements OnInit {
    data: any;
    message: any;

    constructor(navParams: NavParams) {
        this.message = navParams.get('data');

    }

    ngOnInit() {

        this.data = this.message;
    }

}
