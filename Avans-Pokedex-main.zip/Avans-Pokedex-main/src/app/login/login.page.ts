import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {AuthService} from '../service/auth/auth.service';
import {AlertController} from '@ionic/angular';
import {NetworkService} from '../service/network/network.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.page.html',
    styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
    connection: boolean;

    constructor(
        private authService: AuthService,
        private router: Router,
        private alertCtrl: AlertController,
        private networkService: NetworkService) {
    }

    ngOnInit() {
    }

    async loginUser(credentials): Promise<void> {
        this.authService.loginUser(credentials.email, credentials.password).then(
            () => {
                this.router.navigateByUrl('home');
            },
            async error => {
                const alert = await this.alertCtrl.create({
                    message: error.message,
                    buttons: [{text: 'Ok', role: 'cancel'}],
                });
                await alert.present();
            }
        );
    }
}
