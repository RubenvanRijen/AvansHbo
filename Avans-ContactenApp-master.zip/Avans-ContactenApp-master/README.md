# ContactenApp
An app made in Android Studio for Avans MDA1 by Ruben en Jim.

Extras implemented:
- SQLite for contacts
- Endless scroll in recyclerview of pictures
- Search contacts (filter)
- Different layout in landscape due to fragments
