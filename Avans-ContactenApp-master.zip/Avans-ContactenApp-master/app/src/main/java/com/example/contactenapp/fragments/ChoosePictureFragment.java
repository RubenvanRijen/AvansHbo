package com.example.contactenapp.fragments;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.contactenapp.R;
import com.example.contactenapp.activities.PictureListActivity;

import java.io.IOException;
import java.io.InputStream;

import static android.app.Activity.RESULT_OK;

public class ChoosePictureFragment extends Fragment {

    public interface OnPictureSelect {
        void onSubmit(Bitmap bitmap);
    }

    private static final int GALLERY_REQUEST_CODE = 100;
    private static final int CAMERA_REQUEST_CODE = 200;
    private static final int PICTURE_LIST_REQUEST_CODE = 2;
    private ImageView imageView;
    private Context context;

    private OnPictureSelect onPictureSelect;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        onPictureSelect = (OnPictureSelect) context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.choosepicture_fragment, container, false);

        imageView = view.findViewById(R.id.UserPhoto);
        context = getActivity();

        Button choosePictureButton = view.findViewById(R.id.ChoosePictureButton);
        choosePictureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPictureDialog();
            }
        });

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK) {
            try {
                Uri selectedImage = data.getData();
                assert selectedImage != null;
                InputStream imageStream = context.getContentResolver().openInputStream(selectedImage);
                Bitmap image = BitmapFactory.decodeStream(imageStream);
                imageView.setImageBitmap(image);
                onPictureSelect.onSubmit(image);
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        }

        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            assert extras != null;
            Bitmap image = (Bitmap) extras.get("data");
            imageView.setImageBitmap(image);
            onPictureSelect.onSubmit(image);
        }

        if(requestCode == PICTURE_LIST_REQUEST_CODE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            assert extras != null;
            Bitmap image = (Bitmap) extras.get("image");
            imageView.setImageBitmap(image);
            onPictureSelect.onSubmit(image);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == CAMERA_REQUEST_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
                Toast.makeText(context, "Camera permissie afgewezen", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public Bitmap getDefaultPicture() {
        Drawable drawable = imageView.getDrawable();

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }

    private void showPictureDialog() {
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(context);
        pictureDialog.setTitle("Selecteer een actie");
        String[] pictureDialogItems = {
                "Selecteer foto van galerij",
                "Maak foto met camera",
                "Willekeurige foto"};
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int option) {
                        switch (option) {
                            case 0:
                                openGallery();
                                break;
                            case 1:
                                openCamera();
                                break;
                            case 2:
                                openPictureListActivity();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }

    private void openPictureListActivity() {
        Intent intent = new Intent(context, PictureListActivity.class);
        startActivityForResult(intent, PICTURE_LIST_REQUEST_CODE);
    }

    private void openGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Selecteer foto"), GALLERY_REQUEST_CODE);
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(context.getPackageManager()) != null) {

            if (context.checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA},
                        CAMERA_REQUEST_CODE);
                return;
            }

            try {
                startActivityForResult(intent, CAMERA_REQUEST_CODE);
            } catch (SecurityException s) {
                Toast.makeText(context, "Er ging iets fout", Toast.LENGTH_LONG)
                        .show();
            }
        }
    }
}
