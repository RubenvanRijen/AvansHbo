package com.example.contactenapp.activities;

import android.content.Context;
import android.content.res.Resources;

import androidx.appcompat.app.AppCompatActivity;

import com.example.contactenapp.R;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;


public class ChangeThemeActivity extends AppCompatActivity {

    private Context context;

    public ChangeThemeActivity(Context context) {
        this.context = context;
    }

    public Resources.Theme ChangeThemes(Resources.Theme theme) {
        String themeColor = readFileInternalStorage("Theme");
        switch (themeColor) {
            case "Default":
                theme.applyStyle(R.style.AppTheme, true);
                break;
            case "Green":
                theme.applyStyle(R.style.greenMode, true);
                break;
            case "Yellow":
                theme.applyStyle(R.style.yellowMode, true);
                break;
            case "Blue":
                theme.applyStyle(R.style.blueMode, true);
                break;
            case "Purple":
                theme.applyStyle(R.style.purpleMode, true);
                break;
            case "Black":
                theme.applyStyle(R.style.blackMode, true);
                break;
            case "DarkMode":
                theme.applyStyle(R.style.darkMode, true);
        }
        finish();
        return theme;
    }

    public void createUpdateFile(String fileName, String content, boolean update) {
        FileOutputStream outputStream;

        try {
            if (update) {
                outputStream = context.openFileOutput(fileName, Context.MODE_APPEND);
            } else {
                outputStream = context.openFileOutput(fileName, Context.MODE_PRIVATE);
            }
            outputStream.write(content.getBytes());
            outputStream.flush();
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String readFileInternalStorage(String filenameInternal) {
        String colorName = "";
        try {
            FileInputStream fileInputStream = context.openFileInput(filenameInternal);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fileInputStream));

            StringBuilder sb = new StringBuilder();
            String line = reader.readLine();

            while (line != null) {
                sb.append(line);
                colorName = line;
                line = reader.readLine();
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return colorName;
    }


}
