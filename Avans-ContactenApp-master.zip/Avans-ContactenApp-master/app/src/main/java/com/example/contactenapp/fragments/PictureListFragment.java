package com.example.contactenapp.fragments;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.contactenapp.R;
import com.example.contactenapp.adapters.PicturesAdapter;
import com.example.contactenapp.models.Picture;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

public class PictureListFragment extends Fragment {

    private static final String baseUrl = "https://picsum.photos/v2/list";
    private static final int limit = 3;
    private String parametersUrl = "";

    private RecyclerView recyclerView;
    private PicturesAdapter picturesAdapter;
    private ArrayList<Picture> picturesList = new ArrayList<>();
    private int loadedImages;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.picturelist_fragment, container, false);

        recyclerView = view.findViewById(R.id.RecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        Button cancelButton = view.findViewById(R.id.cancelPictureListButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Objects.requireNonNull(getActivity()).finish();
            }
        });

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if (!recyclerView.canScrollVertically(1)) {
                    setUrlParameters();
                    addImages();
                }
            }
        });
        setUrlParameters();
        addImages();

        return view;
    }

    private void setUrlParameters() {
        Random random = new Random();
        int page = random.nextInt((100 - 1) + 1) + 1;
        parametersUrl = "?page=" + page + "&limit=" + limit;
    }

    private void addImages() {
        RequestQueue queue = Volley.newRequestQueue(Objects.requireNonNull(getActivity()));

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, baseUrl + parametersUrl, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            loadedImages = 0;

                            for(int i = 0; i < response.length(); i++) {
                                JSONObject photo = response.getJSONObject(i);

                                String id = photo.getString("id");
                                String author = photo.getString("author");
                                String url = photo.getString("download_url");

                                Picture picture = new Picture(id, author, null);
                                setImageFromUrl(picture, url);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "Error retrieving pictures", Toast.LENGTH_LONG).show();
                    }
                });
        queue.add(request);
    }

    private void setImageFromUrl(final Picture picture, String imageUrl) {
        RequestQueue queue = Volley.newRequestQueue(Objects.requireNonNull(getActivity()));

        @SuppressWarnings("deprecation") ImageRequest request = new ImageRequest(imageUrl,
                new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap bitmap) {
                        Picture finalPicture = new Picture(picture.getId(), picture.getAuthor(), bitmap);
                        picturesList.add(finalPicture);
                        loadedImages++;
                        if(loadedImages == limit) {
                            initializeAdapter();
                        }
                    }
                }, 512, 512, Bitmap.Config.RGB_565, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        queue.add(request);
    }

    private void initializeAdapter() {
        if(picturesAdapter == null) {
            picturesAdapter = new PicturesAdapter(picturesList, getActivity());
            recyclerView.setAdapter(picturesAdapter);
        } else {
            picturesAdapter.notifyDataSetChanged();
        }
    }

}
