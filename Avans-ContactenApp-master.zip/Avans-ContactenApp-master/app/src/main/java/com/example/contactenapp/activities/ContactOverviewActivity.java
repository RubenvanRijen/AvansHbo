package com.example.contactenapp.activities;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;

import android.os.Bundle;


import com.example.contactenapp.adapters.ContactsAdapter;
import com.example.contactenapp.fragments.ContactListFragment;
import com.example.contactenapp.persistence.DatabaseHandler;
import com.example.contactenapp.R;
import com.example.contactenapp.models.Contact;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.MenuInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;

import java.util.ArrayList;
import java.util.List;

public class ContactOverviewActivity extends AppCompatActivity implements ContactListFragment.OnNewContactResult {

    public ContactListFragment contactListFragment;
    private ArrayList<Contact> contactList = new ArrayList<>();
    private ContactsAdapter contactsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contactoverview_activity);
        contactListFragment = (ContactListFragment) getSupportFragmentManager().findFragmentById(R.id.contact_list);

        DatabaseHandler db = new DatabaseHandler(this);
        List<Contact> contacts = db.getAllContacts();

        contactList.addAll(contacts);
        contactsAdapter = new ContactsAdapter(contactList, this);
        contactListFragment.setAdapter(contactsAdapter);
    }

    public Resources.Theme getTheme() {
        ChangeThemeActivity changeThemeActivity = new ChangeThemeActivity(this);
        Resources.Theme theme = super.getTheme();
        theme = changeThemeActivity.ChangeThemes(theme);
        return theme;
    }

    @Override
    public void onRestart() {
        super.onRestart();
        ChangeThemeActivity changeThemeActivity = new ChangeThemeActivity(this);
        String theme = changeThemeActivity.readFileInternalStorage("Theme");
        String changed = changeThemeActivity.readFileInternalStorage("ThemeChanged");
        Log.d("theme", theme);
        Log.d("theme1", changed);
        if (!theme.equals(changed)) {
            Intent intent = getIntent();
            finish();
            startActivity(intent);
        }
        changeThemeActivity.createUpdateFile("ThemeChanged", theme, false);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_main, menu);

        SearchManager searchManager = (SearchManager)
                getSystemService(Context.SEARCH_SERVICE);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchItem.getActionView();

        assert searchManager != null;
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setSubmitButtonEnabled(true);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                contactsAdapter.getFilter().filter(newText);
                return true;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.OpenSettingsButton) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onAddedContact(Contact contact) {
        contactList.add(contact);
        contactsAdapter.notifyItemInserted(contactList.size() - 1);
    }
}
