package com.example.contactenapp.activities;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.LinearLayout;


import androidx.appcompat.app.AppCompatActivity;

import com.example.contactenapp.R;

public class PictureListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.picturelist_activity);

        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
            LinearLayout linearLayout = findViewById(R.id.picturelist_layout);
            int width = Resources.getSystem().getDisplayMetrics().widthPixels;
            width = width / 3;
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(width, FrameLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(width, 0, 0, 0);
            linearLayout.setLayoutParams(params);
        }
    }

    public Resources.Theme getTheme() {
        ChangeThemeActivity changeThemeActivity = new ChangeThemeActivity(this);
        Resources.Theme theme = super.getTheme();
        theme = changeThemeActivity.ChangeThemes(theme);
        return theme;
    }

    public void pushImageResult(Bitmap image) {
        Intent intent = new Intent();
        intent.putExtra("image", image);
        setResult(RESULT_OK, intent);
        finish();
    }
}
