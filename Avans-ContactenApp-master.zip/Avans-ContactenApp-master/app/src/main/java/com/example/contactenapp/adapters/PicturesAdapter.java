package com.example.contactenapp.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.contactenapp.activities.PictureListActivity;
import com.example.contactenapp.R;
import com.example.contactenapp.models.Picture;

import java.util.ArrayList;

public class PicturesAdapter extends RecyclerView.Adapter<PicturesAdapter.Holder> {

    private ArrayList<Picture> pictureList;
    private Context context;

    public PicturesAdapter(ArrayList<Picture> pictures, Context context) {
        this.pictureList = pictures;
        this.context = context;
    }

    @NonNull
    @Override
    public PicturesAdapter.Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.picture_row, viewGroup, false);
        return new PicturesAdapter.Holder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull PicturesAdapter.Holder holder, int position) {
        holder.authorText.setText("Auteur - " + pictureList.get(position).getAuthor());
        holder.imageView.setImageBitmap(pictureList.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return pictureList.size();
    }

    class Holder extends RecyclerView.ViewHolder {

        private TextView authorText;
        private ImageView imageView;

        Holder(View view) {
            super(view);
            authorText = view.findViewById(R.id.author);
            imageView = view.findViewById(R.id.picture);

            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    BitmapDrawable drawable = (BitmapDrawable) imageView.getDrawable();
                    Bitmap bitmap = drawable.getBitmap();
                    ((PictureListActivity) context).pushImageResult(bitmap);
                }
            });
        }
    }
}
