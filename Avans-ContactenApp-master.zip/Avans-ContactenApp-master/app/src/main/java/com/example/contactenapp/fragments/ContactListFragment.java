package com.example.contactenapp.fragments;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.contactenapp.R;
import com.example.contactenapp.activities.NewContactActivity;
import com.example.contactenapp.adapters.ContactsAdapter;
import com.example.contactenapp.models.Contact;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Objects;

import static android.app.Activity.RESULT_OK;

public class ContactListFragment extends Fragment {

    private static final int CREATE_NEW_CONTACT_CODE = 1;
    private static final int CALL_PHONE_REQUEST_CODE = 300;
    private RecyclerView recyclerView;

    public interface OnNewContactResult {
        void onAddedContact(Contact contact);
    }

    private OnNewContactResult onNewContactResult;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        onNewContactResult = (OnNewContactResult) context;
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.contactlist_fragment, container, false);

        recyclerView = view.findViewById(R.id.RecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(Objects.requireNonNull(getActivity()).getApplicationContext()));

        FloatingActionButton fab = view.findViewById(R.id.NewContactButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), NewContactActivity.class);
                startActivityForResult(intent, CREATE_NEW_CONTACT_CODE);
            }
        });
        return view;
    }

    public void setAdapter(ContactsAdapter contactsAdapter) {
        recyclerView.setAdapter(contactsAdapter);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_NEW_CONTACT_CODE) {
            if (resultCode == RESULT_OK) {
                Contact contact = (Contact) data.getSerializableExtra("contact");
                onNewContactResult.onAddedContact(contact);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == CALL_PHONE_REQUEST_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getActivity(), "Bel permissie geaccepteerd", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "Bel permissie afgewezen", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void startCall(int phoneNumber) {
        Uri uri = Uri.parse("tel:" + phoneNumber);
        Intent i = new Intent(Intent.ACTION_CALL, uri);

        if (Objects.requireNonNull(getActivity()).checkSelfPermission(Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE},
                    CALL_PHONE_REQUEST_CODE);
            return;
        }

        try {
            startActivity(i);
        } catch (SecurityException s) {
            Toast.makeText(getActivity(), "Er is iets fout gegaan", Toast.LENGTH_LONG)
                    .show();
        }
    }
}
