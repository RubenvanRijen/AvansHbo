package com.example.contactenapp.adapters;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.contactenapp.MailLogic;
import com.example.contactenapp.activities.ContactOverviewActivity;
import com.example.contactenapp.R;
import com.example.contactenapp.models.Contact;

import java.util.ArrayList;

public class ContactsAdapter extends RecyclerView.Adapter<ContactsAdapter.Holder> implements Filterable {

    private ArrayList<Contact> contactList;
    private ContactFilter contactFilter;
    private ArrayList<Contact> filteredList;
    private Context context;

    public ContactsAdapter(ArrayList<Contact> contacts, Context context) {
        this.contactList = contacts;
        this.filteredList = contacts;
        this.context = context;
        getFilter();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.contact_row, viewGroup, false);

        if(context.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
            LinearLayout linearLayout = view.findViewById(R.id.contact_info_orientation);
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
            linearLayout.setGravity(Gravity.CENTER_VERTICAL);

            int width = Resources.getSystem().getDisplayMetrics().widthPixels;
            int spaceDivide = width / 4;

            TextView nameText = view.findViewById(R.id.ContactNameText);
            nameText.setLayoutParams(new LinearLayout.LayoutParams(spaceDivide, LinearLayout.LayoutParams.WRAP_CONTENT));
            TextView phoneText = view.findViewById(R.id.ContactPhoneText);
            phoneText.setLayoutParams(new LinearLayout.LayoutParams(spaceDivide, LinearLayout.LayoutParams.WRAP_CONTENT));
            TextView emailText = view.findViewById(R.id.ContactEmailText);
            emailText.setLayoutParams(new LinearLayout.LayoutParams(spaceDivide, LinearLayout.LayoutParams.WRAP_CONTENT));
        }

        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactsAdapter.Holder holder, int position) {
        holder.nameText.setText(filteredList.get(position).getName());
        holder.phoneText.setText(filteredList.get(position).getPhoneNumber());
        holder.emailText.setText(filteredList.get(position).getEmail());
        holder.imageView.setImageBitmap(filteredList.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return filteredList.size();
    }

    @Override
    public Filter getFilter() {
        if (contactFilter == null) {
            contactFilter = new ContactFilter();
        }
        return contactFilter;
    }

    class Holder extends RecyclerView.ViewHolder {

        private TextView nameText;
        private TextView emailText;
        private TextView phoneText;
        private ImageView imageView;

        Holder(View view) {
            super(view);
            nameText = view.findViewById(R.id.ContactNameText);
            emailText = view.findViewById(R.id.ContactEmailText);
            phoneText = view.findViewById(R.id.ContactPhoneText);
            imageView = view.findViewById(R.id.contact_image);

            phoneText.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int phoneNumber;
                    try {
                        phoneNumber = Integer.parseInt(phoneText.getText().toString());
                        ((ContactOverviewActivity) context).contactListFragment.startCall(phoneNumber);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                }
            });

            emailText.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    MailLogic mailLogic = new MailLogic(context);
                    mailLogic.openMail(emailText.getText().toString());
                }
            });
        }
    }

    private class ContactFilter extends Filter {

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults filterResults = new FilterResults();
            if (constraint != null && constraint.length() > 0) {
                ArrayList<Contact> tempList = new ArrayList<>();

                for (Contact contact : contactList) {
                    if (contact.getEmail().toLowerCase().contains(constraint.toString().toLowerCase())
                            || contact.getName().toLowerCase().contains(constraint.toString().toLowerCase())) {
                        tempList.add(contact);
                    }
                }
                filterResults.count = tempList.size();
                filterResults.values = tempList;
            } else {
                filterResults.count = contactList.size();
                filterResults.values = contactList;
            }
            return filterResults;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            filteredList = (ArrayList<Contact>) results.values;
            notifyDataSetChanged();
        }
    }
}
