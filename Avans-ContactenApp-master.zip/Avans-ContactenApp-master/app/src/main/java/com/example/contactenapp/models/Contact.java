package com.example.contactenapp.models;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.Serializable;

public class Contact implements Serializable {

    private static final int PREFERRED_WIDTH = 400;
    private static final int PREFERRED_HEIGHT = 400;

    private int id;
    private String name;
    private String phoneNumber;
    private String email;
    private String image;

    public Contact() {
    }

    public Contact(String name, String phoneNumber, String email, Bitmap image) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.image = convertBitmapToString(resizeBitmap(image));
    }

    public Contact(int id, String name, String phoneNumber, String email, String image) {
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Bitmap getImage() {
        return convertStringToBitmap(this.image);
    }

    public String getImageAsString() {
        return image;
    }

    public void setImageByString(String imageString) {
        this.image = imageString;
    }

    private String convertBitmapToString(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        byte[] bytes = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(bytes, Base64.DEFAULT);
    }

    private Bitmap convertStringToBitmap(String string) {
        Bitmap bitmap = null;
        try {
            byte[] encodeByte = Base64.decode(string, Base64.DEFAULT);
            bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return bitmap;
    }

    private Bitmap resizeBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float scaleWidth = ((float) PREFERRED_WIDTH) / width;
        float scaleHeight = ((float) PREFERRED_HEIGHT) / height;

        Matrix matrix = new Matrix();
        matrix.postScale(scaleWidth, scaleHeight);

        return Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, false);
    }

}
