package com.example.contactenapp.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.contactenapp.R;

import java.util.Objects;

public class ActionButtonsFragment extends Fragment {

    public interface OnAction {
        void onSave();
    }

    private OnAction actionButtonsFragment;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        actionButtonsFragment = (OnAction) context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.actionbuttons_fragment, container, false);

        Button cancelButton = view.findViewById(R.id.CancelButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Objects.requireNonNull(getActivity()).finish();
            }
        });

        Button saveButton = view.findViewById(R.id.SaveButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { actionButtonsFragment.onSave(); }
        });

        return view;
    }
}
