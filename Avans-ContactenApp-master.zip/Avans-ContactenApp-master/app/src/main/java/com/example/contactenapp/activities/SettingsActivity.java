package com.example.contactenapp.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;

import android.location.Location;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.ListPreference;
import androidx.preference.PreferenceFragmentCompat;


import com.example.contactenapp.LocationLogic;
import com.example.contactenapp.R;

import java.util.Objects;


public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.settings, new SettingsFragment(this, SettingsActivity.this))
                .commit();
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public Resources.Theme getTheme() {
        ChangeThemeActivity changeThemeActivity = new ChangeThemeActivity(this);
        Resources.Theme theme = super.getTheme();
        theme = changeThemeActivity.ChangeThemes(theme);
        return theme;
    }

    public static class SettingsFragment extends PreferenceFragmentCompat {
        Context context;
        String color;
        ChangeThemeActivity changeThemeActivity;
        Activity activity;

        SettingsFragment(Context context, Activity activity) {
            this.context = context;
            this.changeThemeActivity = new ChangeThemeActivity(this.context);
            this.activity = activity;
        }

        SharedPreferences.OnSharedPreferenceChangeListener preferenceChangeListener;

        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);
            final ListPreference location = findPreference("location");
            final ListPreference colors = findPreference("appColor");

            assert location != null;
            setSummary(location);

            preferenceChangeListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
                @Override
                public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
                    if (key.equals("appColor")) {
                        assert colors != null;
                        setColor(colors.getValue());
                        changeThemeActivity.createUpdateFile("Theme", colors.getValue(), false);
                        getTheme();
                        run();
                    }

                    if (key.equals("location")) {
                        setSummary(location);
                    }
                }
            };
            getTheme();
        }

        void setSummary(ListPreference location) {
            if (location.getValue().equals("Yes")) {
                LocationLogic locationlogic = new LocationLogic(context, activity);
                Location data = locationlogic.getPermission();
                if (data != null) {
                    location.setSummary(("Latitude:" + data.getLatitude() + ", Longitude:" + data.getLongitude()));
                } else {
                    location.setSummary("No location available");
                }
            } else {
                location.setSummary("No location available");
            }
        }

        void run() {
            Intent intent = Objects.requireNonNull(getActivity()).getIntent();
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            getActivity().overridePendingTransition(0, 0);
            getActivity().finish();

            getActivity().overridePendingTransition(0, 0);
            startActivity(intent);
        }

        void getTheme() {
            Resources.Theme theme = context.getTheme();
            changeThemeActivity.ChangeThemes(theme);
        }

        @Override
        public void onResume() {
            super.onResume();
            getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(preferenceChangeListener);
        }

        @Override
        public void onPause() {
            super.onPause();
            getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(preferenceChangeListener);
        }

        public String getColor() {
            return color;
        }

        public void setColor(String color) {
            this.color = color;
        }
    }
}