package com.example.contactenapp.fragments;

import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.contactenapp.R;
import com.google.android.material.textfield.TextInputLayout;

import java.util.regex.Matcher;

public class NewContactDetailsFragment extends Fragment {

    private EditText nameText;
    private EditText emailText;
    private EditText phoneText;
    private TextInputLayout textInputLayoutName;
    private TextInputLayout textInputLayoutPhone;
    private TextInputLayout textInputLayoutEmail;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.newcontactdetails_fragment, container, false);

        nameText = view.findViewById(R.id.ContactNameCreation);
        emailText = view.findViewById(R.id.ContactEmailCreation);
        phoneText = view.findViewById(R.id.ContactPhoneCreation);
        textInputLayoutName = view.findViewById(R.id.inputLayoutName);
        textInputLayoutPhone = view.findViewById(R.id.inputLayoutPhone);
        textInputLayoutEmail = view.findViewById(R.id.inputLayoutEmail);

        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public boolean isFormInputValid() {
        boolean isInputValid = true;
        if (nameText.getText().toString().equals("")) {
            textInputLayoutName.setError("Naam is niet ingevuld en/of ongeldig");
            isInputValid = false;
        } else {
            textInputLayoutName.setError(null);
        }
        Matcher matcher = Patterns.EMAIL_ADDRESS.matcher(emailText.getText().toString());
        if (!matcher.matches() || emailText.getText().toString().equals("")) {
            textInputLayoutEmail.setError("Email is niet ingevuld en/of ongeldig");
            isInputValid = false;
        } else {
            textInputLayoutEmail.setError(null);
        }
        matcher = Patterns.PHONE.matcher((phoneText.getText().toString()));
        if (!matcher.matches() || phoneText.getText().toString().equals("")) {
            textInputLayoutPhone.setError("Telefoonnummer is niet ingevuld en/of ongeldig");
            isInputValid = false;
        } else {
            textInputLayoutPhone.setError(null);
        }
        return isInputValid;
    }

    public String[] getContactDetails() {
        String[] details = new String[3];
        details[0] = nameText.getText().toString();
        details[1] = phoneText.getText().toString();
        details[2] = emailText.getText().toString();
        return details;
    }
}
