package com.example.contactenapp.activities;

import android.content.Intent;

import android.content.res.Resources;

import android.content.res.Configuration;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.example.contactenapp.fragments.ChoosePictureFragment;
import com.example.contactenapp.fragments.ActionButtonsFragment;
import com.example.contactenapp.fragments.NewContactDetailsFragment;
import com.example.contactenapp.persistence.DatabaseHandler;
import com.example.contactenapp.R;
import com.example.contactenapp.models.Contact;

public class NewContactActivity extends AppCompatActivity implements ActionButtonsFragment.OnAction, ChoosePictureFragment.OnPictureSelect {

    private NewContactDetailsFragment contactDetailsFragment;
    private ChoosePictureFragment choosePictureFragment;
    private Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newcontact_activity);
        contactDetailsFragment = (NewContactDetailsFragment) getSupportFragmentManager().findFragmentById(R.id.contactDetails);
        choosePictureFragment = (ChoosePictureFragment) getSupportFragmentManager().findFragmentById(R.id.contactPicture);

        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
            LinearLayout linearLayout = findViewById(R.id.details_orientation);
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);
            View choosePictureFragment = findViewById(R.id.contactPicture);
            choosePictureFragment.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
    }

    public Resources.Theme getTheme() {
        ChangeThemeActivity changeThemeActivity = new ChangeThemeActivity(this);
        Resources.Theme theme = super.getTheme();
        theme = changeThemeActivity.ChangeThemes(theme);
        return theme;
    }

    @Override
    public void onSubmit(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    @Override
    public void onSave() {
        if (contactDetailsFragment.isFormInputValid()) {
            addContact(contactDetailsFragment.getContactDetails());
            finish();
        }
    }

    private void addContact(String[] contactDetails) {
        if(bitmap == null) {
            bitmap = choosePictureFragment.getDefaultPicture();
        }
        Contact contact = new Contact(contactDetails[0], contactDetails[1], contactDetails[2], bitmap);
        DatabaseHandler databaseHandler = new DatabaseHandler(this);
        databaseHandler.addContact(contact);

        Intent intent = new Intent();
        intent.putExtra("contact", contact);
        setResult(RESULT_OK, intent);
    }
}
