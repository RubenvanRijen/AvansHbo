package com.example.contactenapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

public class MailLogic {

    private Context context;

    public MailLogic(Context context) {
        this.context = context;
    }

    public void openMail(String email) {
        try {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:" + email));
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
            intent.putExtra(Intent.EXTRA_SUBJECT, "App feedback");
            context.startActivity(intent);
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(context, "Er zijn geen mail apps gevonden op uw apparaat",
                    Toast.LENGTH_LONG).show();
        }
    }
}
