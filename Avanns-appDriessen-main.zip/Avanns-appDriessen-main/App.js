import React from 'react';

import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';

import { decode, encode } from 'base-64'

if (!global.btoa) { global.btoa = encode }

if (!global.atob) { global.atob = decode }

import IconFA from 'react-native-vector-icons/FontAwesome5';

import { Image, TouchableOpacity, StyleSheet, Text, View } from 'react-native';

import storage from './src/Storage';

import { User } from './src/models/IUser';// TODO: Change app.js to tsx

import LoginScreen from "./src/screens/LoginScreen";
import DetailScreen from "./src/screens/routes/RouteDetailScreen";
import RouteOverviewScreen from "./src/screens/routes/RouteOverviewScreen";
import RouteCreateScreen from "./src/screens/routes/RouteCreateScreen";
import WorkHourOverviewScreen from "./src/screens/workHours/WorkHourOverviewScreen";
import WorkHourDetailScreen from "./src/screens/workHours/WorkHourDetailScreen";
import WorkHourCreateScreen from "./src/screens/workHours/WorkHourCreateScreen";
import ProfileScreen from "./src/screens/profile/ProfileScreen";
import HelpScreen from "./src/screens/HelpScreen";
import RouteFilterScreen from "./src/screens/routes/RouteFilterScreen";
import PaymentsOverviewScreen from "./src/screens/payments/PaymentsOverviewScreen";

import UserService from './src/services/UserService';

console.disableYellowBox = true;

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();

function HomeTabs() {
  return (
    <Tab.Navigator initialRouteName="Routes"
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'Routes') {
            iconName = focused
              ? 'route'
              : 'route';
          } else if (route.name === 'Planning') {
            iconName = focused ? 'calendar' : 'calendar';
          }
          else if (route.name === 'Uitbetalingen') {
            iconName = focused ? 'wallet' : 'wallet';
          }

          return <IconFA name={iconName} size={size} color={color} />;
        },
      })}
      tabBarOptions={{
        activeTintColor: '#E71234',
        inactiveTintColor: 'gray',
      }}
    >
      <Tab.Screen name="Planning" component={StackWorkHourScreen} />
      <Tab.Screen name="Routes" component={StackRouteScreen} />
      <Tab.Screen name="Uitbetalingen" component={StackPaymentScreen} />
    </Tab.Navigator>
  );
}

function StackRouteScreen() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Routes" component={RouteOverviewScreen} options={({ navigation }) => ({
        headerLeft: () => {
          return <IconFA name={"bars"} color={"white"} size={30} style={{ paddingLeft: 20 }}
            onPress={() => navigation.openDrawer()}
          />
        },
        headerRight: () => (
          <IconFA name={"filter"} color={"white"} size={30} style={{ paddingRight: 20 }}
            onPress={() => navigation.navigate('RouteFilter')}
          />
        ),
        headerTitle: "",
        headerStyle: {
          backgroundColor: '#E71234',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        }
      })} />
    </Stack.Navigator>
  );
}


function StackPaymentScreen() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Uitbetalingen" component={PaymentsOverviewScreen} options={({ navigation }) => ({
        headerLeft: () => {
          return <IconFA name={"bars"} color={"white"} size={30} style={{ paddingLeft: 20 }}
            onPress={() => navigation.openDrawer()}
          />
        },
        headerTitle: "",
        headerStyle: {
          backgroundColor: '#E71234',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        }
      })} />
    </Stack.Navigator>
  );
}
function StackWorkHourScreen() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Planning" component={WorkHourOverviewScreen} options={({ navigation }) => ({
        headerLeft: () => {
          return <IconFA name={"bars"} color={"white"} size={30} style={{ paddingLeft: 20 }}
            onPress={() => navigation.openDrawer()}
          />
        },
        headerTitle: "",
        headerStyle: {
          backgroundColor: '#E71234',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        }
      })} />
    </Stack.Navigator>
  );
}



function TabRoutesScreen() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Login" options={{ headerShown: false }} component={LoginScreen} />
      <Stack.Screen name="Dashboard" options={({ navigation }) => ({
        headerShown: false,
      })}
        component={HomeTabs} />

      <Stack.Screen name="Details" options={{ headerShown: false }} component={DetailScreen} />

      <Stack.Screen name="Create" options={{
        title: 'Route Toevoegen',
        headerStyle: {
          backgroundColor: '#E71234',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }} component={RouteCreateScreen} />

      <Stack.Screen name="WorkHoursCreate" options={{
        title: 'Uren toevoegen',
        headerStyle: {
          backgroundColor: '#E71234',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
        component={WorkHourCreateScreen} />

      <Stack.Screen name="WorkHoursDetail" options={{
        title: 'Details',
        headerStyle: {
          backgroundColor: '#E71234',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
        component={WorkHourDetailScreen} />

      <Stack.Screen name="Profile" options={({ navigation }) => ({
        title: 'Profiel wijzigen',
        headerLeft: () => {
          return <IconFA name={"bars"} color={"white"} size={30} style={{ paddingLeft: 20 }}
            onPress={() => navigation.openDrawer()}
          />
        },
        headerStyle: {
          backgroundColor: '#E71234',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },

      })}
        component={ProfileScreen} />

      <Stack.Screen name="RouteFilter" options={({ navigation }) => ({
        title: "Filters",
        headerStyle: {
          backgroundColor: '#E71234',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      })}
       component={RouteFilterScreen} />

    </Stack.Navigator>
  )
}

function HelpStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Help" options={({ navigation }) => ({
        title: 'Help',
        headerLeft: (props) => {
          return <IconFA name={"bars"} color={"white"} size={30} style={{ paddingLeft: 20 }}
            onPress={() => navigation.openDrawer()}
          />
        },
        headerStyle: {
          backgroundColor: '#E71234',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },

      })}
        component={HelpScreen} />
    </Stack.Navigator>
  );
}

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.userService = new UserService(props.navigation);

    this.state = {
      jwt: null
    };

    defaultStyle = {
      headerStyle: {
        backgroundColor: '#E71234',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    }

    storage.getItem(storage.jwtKey)
      .then(jwt => {
        this.setState({
          jwt
        })

        if (jwt) {
          this.jwtToken = jwt;
          var base64Url = jwt.split('.')[1];
          var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
          var jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
          }).join(''));

          this.jwt = JSON.parse(jsonPayload);

        this.userService.get(this.jwt?.sub)
            .then((responseJson) => {
              this.setState({ user: responseJson });
              storage.removeItem("userLoggedIn");
            });
        }
      })
      .catch(error => console.error(error));
  }
  
  render() {
    let user = "";
    if (this.state.user) {
      user = this.state.user;
    }
    return (
      <NavigationContainer>
        <Drawer.Navigator initialRouteName="Home" drawerContent={props => this.CustomDrawer(props)} drawerStyle={{ width: '80%' }}>
          <Drawer.Screen name="Home" component={TabRoutesScreen} />
          <Drawer.Screen name="Help" component={HelpStack} />
        </Drawer.Navigator>
      </NavigationContainer>
    );
  }

  CustomDrawer = (props) => {
    storage.getItem("userLoggedIn").then(value => {
      if (value) {
        storage.removeItem("userLoggedIn");

        storage.getItem("user")
          .then(user => {
            this.setState({ user: JSON.parse(user) })
          });
        storage.getItem(storage.jwtKey)
          .then(jwt => {
            this.setState({
              jwt
            })

            if (jwt) {
              this.jwtToken = jwt;
              var base64Url = jwt.split('.')[1];
              var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
              var jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
                return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
              }).join(''));

              this.jwt = JSON.parse(jsonPayload);
            }
          })
          .catch(error => console.error(error));
      }
    });

    if (this.state.user) {
      let user = this.state.user;
      return (
        <View style={{ height: "100%" }}>
          <View style={{ height: 250, backgroundColor: "#E71234", alignItems: "center", justifyContent: 'center', }}>
            <View style={styles.profileImage}>
              <Image source={{ uri: user.image }} style={styles.ViewImage} />
            </View>
            <Text style={{ fontWeight: "bold", color: "white", fontSize: 16 }}>{user.firstName} {user.lastName}</Text>
            <Text style={{ color: "white", fontSize: 15 }}>{user.email}</Text>
          </View>

          <View style={{ marginTop: 20 }}>
            <View style={{ alignItems: "center", justifyContent: 'center', }}>
              <View style={{ width: "80%" }}>
                <TouchableOpacity activeOpacity={0.9} onPress={() => { props.navigation.navigate('Dashboard', { user, jwt: this.jwt, jwtToken: this.jwtToken }) }} style={styles.navButton}>
                  <IconFA name="home" size={25} color={"#878787"} /><Text style={styles.navButtonText}>Home</Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={{ alignItems: "center", justifyContent: 'center', }}>
              <View style={{ width: "80%" }}>
                <TouchableOpacity activeOpacity={0.9} onPress={() => { props.navigation.navigate('Profile', { user, jwt: this.jwt, jwtToken: this.jwtToken }) }} style={styles.navButton}>
                  <IconFA name="pen" size={25} color={"#878787"} /><Text style={styles.navButtonText}>Profiel wijzigen</Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={{ alignItems: "center", justifyContent: 'center', }}>
              <View style={{ width: "80%" }}>
                <TouchableOpacity activeOpacity={0.9} onPress={() => { props.navigation.navigate('Help') }} style={styles.navButton}>
                  <IconFA name="question" size={25} color={"#878787"} /><Text style={styles.navButtonText}>Help</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>

          <View style={{ bottom: 0, width: "100%", position: "absolute", height: 70, backgroundColor: "white", alignItems: "center", justifyContent: 'center', borderTopColor: "#E2E2E2", borderTopWidth: 1 }}>
            <TouchableOpacity activeOpacity={0.9} onPress={() => { storage.removeItem("jwt").then(props.navigation.navigate('Login')) }} style={{ flexDirection: "row", borderWidth: 1, borderColor: "#C3C5C3", width: "85%", height: 60, borderRadius: 7, alignItems: "center", justifyContent: 'center', }}>
              <IconFA name="sign-out-alt" size={25} color={"#C3C5C3"} /><Text style={{ color: "#C3C5C3", fontWeight: "bold", marginLeft: 10 }}>Log uit</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    }
    return (
      <View>
      </View>
    );
  };
}

const styles = StyleSheet.create({
  navButtonText: {
    color: "#878787",
    fontWeight: "bold",
    marginLeft: 10,
    fontSize: 16
  },
  navButton: {
    flexDirection: "row",
    height: 60,
    borderRadius: 7,
    alignItems: "center"
  },
  profileImage: {
    alignSelf: 'center',
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,
    backgroundColor: "#BEBEBE",
    height: 100,
    width: 100,
    borderRadius: 1000,
    marginBottom: 20,
    position: "relative",
  },
  ViewImage: {
    alignSelf: 'center',
    height: 100,
    width: 100,
    borderRadius: 1000,
  },
  filterText: {
    color: 'white',
    margin: 10,
    marginRight: 30,
    fontWeight: 'bold',
    fontSize: 20,
  }
})