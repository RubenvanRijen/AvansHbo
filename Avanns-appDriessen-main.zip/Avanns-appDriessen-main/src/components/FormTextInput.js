import React from 'react';
import {Image, StyleSheet, TextInput, View} from 'react-native';

export default class FormTextInput extends React.Component {

    render() {
        return (
            <View style={styles.rootView}>
                <Image source={this.props.icon}
                       style={this.props.icon ? styles.iconImage : [styles.iconImage, styles.gone]}/>
                <TextInput style={styles.textInput} {...this.props}/>
            </View>
        );
    }

}

const styles = StyleSheet.create({
    rootView: {
        backgroundColor: 'white',
        borderRadius: 20,
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        minHeight: 60,
        marginHorizontal: 40,
        marginVertical: 10,
        paddingHorizontal: 15,
        paddingVertical: 15
    },
    iconImage: {
        marginRight: 15
    },
    textInput: {
        flex: 1,
        fontSize: 16
    },
    gone: {
        display: 'none'
    }
});
