import React from 'react';
import {View} from 'react-native';

export default class HorizontalLine extends React.Component {

    render() {
        return (
            <View style={{
                height: 5,
                backgroundColor: 'white',
                borderColor: 'white',
                borderWidth: 1,
                borderRadius: 5,
                marginHorizontal: 20,
                marginVertical: 30,
                alignSelf: 'stretch'
            }}/>
        );
    }

}
