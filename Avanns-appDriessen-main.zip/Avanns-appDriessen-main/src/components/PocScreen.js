import React from 'react';
import {Dimensions, SafeAreaView, StyleSheet, Text, View} from "react-native";
import {MapShapeType, WebViewLeaflet, WebViewLeafletEvents} from "react-native-webview-leaflet";
import * as Permissions from "expo-permissions";
import * as TaskManager from "expo-task-manager";
import * as Location from "expo-location";
import {EventEmitter} from "fbemitter";

const LOCATION_TRACKER = 'background-task-location';
const eventEmitter = new EventEmitter();

const {width} = Dimensions.get("window");

TaskManager.defineTask(LOCATION_TRACKER, ({data, error}) => {
    if (error) {
        console.log(error);
        // Error occurred - check `error.message` for more details.
        return;
    }
    if (data) {
        const {locations} = data;
        eventEmitter.emit(LOCATION_TRACKER, data);
    }
});

export default class PocScreen extends React.Component {

    state = {
        location: null,
        errorMessage: null,
        isDriving: false,
        drivingTimer: null,
        markers: null,
        mapShapes: null,
        distance: null,
    };

    locations = [];
    recentRides = [];

    constructor(props) {
        // console.log(Routing);
        super(props);
        this.state = {location: {}};

        this.state = {
            mapCenterPosition: {}
        };
    }

    onMessageReceived(message) {
        switch (message.event) {
            case WebViewLeafletEvents.ON_MAP_MARKER_CLICKED:
                // On marker click
                break;
            case WebViewLeafletEvents.ON_MAP_TOUCHED:
                // On map toutch
                break;
            default:
            // console.log("App received", message);
        }
    }

    componentDidMount() {
        this._getLocationAsync();
        this.eventSubscription = eventEmitter.addListener(LOCATION_TRACKER, data => {
            if (data.locations != null) {
                var location = data.locations[data.locations.length - 1];
                if (this.state.location == null) {
                    this.setState({location});

                    var mapCenterPosition = {lat: location.coords.latitude, lng: location.coords.longitude};
                    this.setState({mapCenterPosition});

                    var markers = this.state.markers || [];
                    markers.push({id: markers.length + 1, position: mapCenterPosition, size: [24, 24], icon: "🚗",});
                    this.setState({markers});
                }

                if (location.coords.speed >= 10) {
                    var drivingTimer = 300;
                    this.setState({drivingTimer});
                    if (this.state.isDriving == null || !this.state.isDriving) {
                        console.log("started driving!");
                        var isDriving = true;
                        this.setState({isDriving});
                        this.setCountdownTimer(this);
                    }

                    var mapCenterPosition = {lat: location.coords.latitude, lng: location.coords.longitude};
                    this.setState({mapCenterPosition});
                    var markers = this.state.markers;
                    // markers[0] = { id: markers.length + 1, position: mapCenterPosition, size: [24, 24], icon: "🚗", };
                    // markers.push({ id: markers.length + 1, position: mapCenterPosition, size: [24, 24], icon: "🚗", });
                    // this.setState({ markers });


                    this.setState({location});
                    this.locations.push(location.coords);

                    console.log("Speed: " + location.coords.speed);
                    // console.log("locations: " + this.locations);
                }
            }
        });
    }

    finishedDriving() {
        clearInterval(this.myInterval);
        // BackgroundTimer.stopBackgroundTimer()

        // clearInterval(this.myInterval);
        var isDriving = false;
        this.setState({isDriving});
        console.log("Stopped driving!");
        console.log("Number of location points: " + this.locations.length);
        if (this.locations.length > 2) {
            console.log("First position: ", this.locations[0]);
            console.log("Last position: ", this.locations[this.locations.length - 1]);
            this.recentRides.push(this.locations);

            coordinatesString = "";
            var size = 24;
            var locationsSize = this.locations.length - 1;
            if (locationsSize <= 24) {
                size = locationsSize;
            }

            this.locations.slice(0, size).map(i => {

                coordinatesString += i.longitude + "," + i.latitude + ";";
            });
            coordinatesString += this.locations[locationsSize].longitude + "," + this.locations[locationsSize].latitude;
            console.log(coordinatesString);
            fetch('https://api.mapbox.com/directions/v5/mapbox/driving/' + coordinatesString + '?alternatives=false&geometries=geojson&steps=false&access_token=pk.eyJ1IjoicnViZW53ZXN0IiwiYSI6ImNrNnVucmd6eDBheGUzbGszM29ueDY3dzUifQ.0tOgZAEanZ5_iDMUQy1XmQ').then((response) => response.json())
                .then((responseJson) => {

                    routes = responseJson["routes"];
                    //TODO: Get shortest

                    this.setState({distance: routes[0]["distance"]});

                    coordinates = routes[0]["geometry"]["coordinates"];
                    positions = [];
                    coordinates.map((coordinate, i) => {
                        positions.push({lat: coordinate[1], lng: coordinate[0]});
                    });
                    this.setState({
                        mapShapes: {
                            shapeType: MapShapeType.POLYLINE,
                            color: "orange",
                            id: "5",
                            positions,
                        }
                    });
                }).catch((error) => {
                console.error(error);
            });

            this.locations = [];
            console.log("Current number of rides: " + this.recentRides.length);
        } else {
            console.log("Probably not a actual ride!")
        }
    }

    setCountdownTimer = async () => {
        //  try{
        //   BackgroundTimer.runBackgroundTimer(() => {
        //     this.setState(({ drivingTimer }) => ({
        //       drivingTimer: drivingTimer - 1
        //     }));

        //     console.log("time: " + this.state.drivingTimer);

        //     if (this.state.drivingTimer <= 0) {
        //       this.finishedDriving();
        //     }
        //   },
        //   1000);
        // }catch(e){
        //   console.log(e);
        // }

        this.myInterval = setInterval(() => {
            this.setState(({drivingTimer}) => ({
                drivingTimer: drivingTimer - 1
            }));

            console.log("time: " + this.state.drivingTimer);

            if (this.state.drivingTimer <= 0) {
                this.finishedDriving();
            }

        }, 1000);
    };

    _getLocationAsync = async () => {

        let {status} = await Permissions.askAsync(Permissions.LOCATION);
        if (status !== 'granted') {
            this.setState({
                errorMessage: 'Permission to access location was denied',
            });
        }

        let isRegistered = await TaskManager.isTaskRegisteredAsync(LOCATION_TRACKER);

        if (!isRegistered) await Location.startLocationUpdatesAsync(LOCATION_TRACKER, {
            accuracy: Location.Accuracy.BestForNavigation,
            /* after edit */
            timeInterval: 1000,
            distanceInterval: 500,
            foregroundService: {notificationTitle: "test", notificationBody: "test"},
            pausesUpdatesAutomatically: false,
        });


        var location = await Location.getCurrentPositionAsync({});
        console.log(location);
        if (location != null && this.state.location == null) {
            this.setState({location});

            var mapCenterPosition = {lat: location.coords.latitude, lng: location.coords.longitude};
            this.setState({mapCenterPosition});

            var markers = this.state.markers || [];
            markers.push({id: markers.length + 1, position: mapCenterPosition, size: [24, 24], icon: "🚗",});
            this.setState({markers});
        }
    };

    render() {
        let text = 'Waiting..';
        let text2 = 'Waiting..';
        let text3 = 'Waiting..';
        let text4 = 'Waiting..';
        let text5 = 'Waiting..';
        let text6 = 'Waiting..';
        let mapMarkers = [];
        let ownPositionMarker = {};
        let zoom = 16;
        if (this.state.errorMessage) {
            text = this.state.errorMessage;
        } else if (this.state.location) {
            text = JSON.stringify(this.state.location);
            if (this.state.isDriving == null) {
                text2 = JSON.stringify(this.state.isDriving);
            }
            mapMarkers = this.state.markers || [];
            ownPositionMarker = mapMarkers[mapMarkers.length - 1];
            text3 = JSON.stringify(this.recentRides.length);
            text4 = JSON.stringify(mapMarkers.length);
            if (this.state.drivingTimer) {
                text5 = JSON.stringify(this.state.drivingTimer);
            }
            if (this.state.distance) {
                text6 = JSON.stringify(this.state.distance);
            }
        }
        let mapShapes = this.state.mapShapes || {};
        let mapCenterPosition = this.state.mapCenterPosition;

        return (
            <SafeAreaView style={styles.container}>
                <View style={{flex: 8}}>
                    <WebViewLeaflet style={styles.map}
                                    ref={(component) => (this.webViewLeaflet = component)}
                                    onLoad={this.onLoad}
                                    eventReceiver={this} // the component that will receive map events
                                    onMessageReceived={this.onMessageReceived}
                                    mapCenterPosition={mapCenterPosition}
                                    mapShapes={[
                                        mapShapes
                                    ]}
                                    mapLayers={[
                                        {
                                            attribution: '&amp;copy <a href="http://osm.org/copyright">OpenStreetMap</a> contributors',
                                            baseLayerIsChecked: true,
                                            baseLayerName: "OpenStreetMap.Mapnik",
                                            // url: "https://api.mapbox.com/styles/v1/mapbox/streets-v11/tiles/256/{z}/{x}/{y}?access_token=pk.eyJ1IjoicnViZW53ZXN0IiwiYSI6ImNrNnVucmd6eDBheGUzbGszM29ueDY3dzUifQ.0tOgZAEanZ5_iDMUQy1XmQ"
                                            // pk.eyJ1IjoicnViZW53ZXN0IiwiYSI6ImNrNnVucmd6eDBheGUzbGszM29ueDY3dzUifQ.0tOgZAEanZ5_iDMUQy1XmQ
                                            url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                        }
                                    ]}
                                    ownPositionMarker={ownPositionMarker}
                        // mapMarkers={mapMarkers}
                                    zoom={zoom}
                        // mapLayers={this.mapLayers}
                    />
                </View>

                <View style={{flex: 2}}>
                    <Text style={styles.paragraph}>Current location: {text}</Text>
                    <Text>Currently riding: {text2}</Text>
                    <Text>Number of rides: {text3}</Text>
                    <Text>Number of markers: {text4}</Text>
                    <Text>Time till end of ride: {text5}</Text>
                    <Text>Ride distance: {text6}</Text>
                </View>
            </SafeAreaView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#fff"
    },
    item: {
        paddingLeft: 15,
        marginTop: 10,
        width: width / 2,
        fontSize: 20
    },
    flexRow: {
        flex: 1,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-around",
        margin: 5
    },
    fontsize20: {
        fontSize: 20
    }
});