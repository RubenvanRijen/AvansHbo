import React from 'react';
import {StyleSheet, Text, Touchable, TouchableNativeFeedback, TouchableOpacity, View} from 'react-native';

import invariant from 'invariant';

export default class FormButton extends React.Component {

    render() {
        const {
            accessibilityLabel,
            color,
            onPress,
            textColor,
            touchSoundDisabled,
            title,
            hasTVPreferredFocus,
            nextFocusDown,
            nextFocusForward,
            nextFocusLeft,
            nextFocusRight,
            nextFocusUp,
            disabled,
            testID,
        } = this.props;

        const buttonStyles = [styles.button];
        const textStyles = [styles.text];

        if (color) {
            buttonStyles.push({backgroundColor: color});
        }

        if (textColor) {
            textStyles.push({color: textColor})
        }

        const accessibilityStates = [];
        if (disabled) {
            buttonStyles.push(styles.buttonDisabled);
            textStyles.push(styles.textDisabled);
            accessibilityStates.push('disabled');
        }

        invariant(
            typeof title === 'string',
            'The title prop of a Button must be a string'
        );

        const Touchable = Platform.OS === 'android' ? TouchableNativeFeedback : TouchableOpacity;

        return (
            <Touchable
                accessibilityLabel={accessibilityLabel}
                accessibilityRole="button"
                accessibilityStates={accessibilityStates}
                hasTVPreferredFocus={hasTVPreferredFocus}
                nextFocusDown={nextFocusDown}
                nextFocusForward={nextFocusForward}
                nextFocusLeft={nextFocusLeft}
                nextFocusRight={nextFocusRight}
                nextFocusUp={nextFocusUp}
                testID={testID}
                disabled={disabled}
                onPress={onPress}
                touchSoundDisabled={touchSoundDisabled}>
                <View style={buttonStyles}>
                    <Text style={textStyles} disabled={disabled}>
                        {title}
                    </Text>
                </View>
            </Touchable>
        );
    }

}

const styles = StyleSheet.create({
    button: {
        backgroundColor: 'white',
        borderRadius: 20,
        height: 60,
        justifyContent: 'center',
        marginHorizontal: 40,
        marginVertical: 10,
        ...Platform.select({
            ios: {},
            android: {
                elevation: 4
            }
        })
    },
    text: {
        color: 'black',
        fontSize: 24,
        padding: 8,
        textAlign: 'center',
        ...Platform.select({
            ios: {},
            android: {
                fontWeight: '500'
            }
        })
    },
    buttonDisabled: Platform.select({
        ios: {},
        android: {
            elevation: 0,
            backgroundColor: '#dfdfdf',
        }
    }),
    textDisabled: Platform.select({
        ios: {
            color: '#cdcdcd',
        },
        android: {
            color: '#a1a1a1',
        }
    })
});
