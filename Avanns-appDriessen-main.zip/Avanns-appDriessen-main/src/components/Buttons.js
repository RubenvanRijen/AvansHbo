import styled from 'styled-components'

export const AcceptButton = styled.Button({
    width: "150px",
    height: "30px",
    backgroundColor: "#50BE64",
    border: "none",
    borderRadius: "12px",
    color: "#FFFFFF",
    fontWeight: "bold",
    boxShadow: "0px 3px 5px 0px rgba(50, 50, 40, 0.5)",
    transition: "background-color 0.3s",
    ":hover": {
        transition: "background-color 500ms",
        backgroundColor: "rgba(80,190,100,0.8)",
        cursor: "pointer",
    },
    ":focus": {
        outline: "0",
        backgroundColor: "#48ab5a"
    }
});