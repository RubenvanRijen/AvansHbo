import React from 'react';
import { Keyboard, TouchableOpacity, Image, Picker, Button, SafeAreaView, StyleSheet, Text, View, NativeSyntheticEvent, TextInputEndEditingEventData } from 'react-native';
import { DrawerNavigationProp } from '@react-navigation/drawer';
import IconFA from 'react-native-vector-icons/FontAwesome5';
import { OutlinedTextField } from 'react-native-material-textfield';
import storage from '../../Storage'
import { User } from '../../models/IUser';

import * as ImagePicker from 'expo-image-picker';
import Constants from 'expo-constants';
import * as Permissions from 'expo-permissions';

import UserService from '../../services/UserService';

type RootStackParamList = {
}
type ProfileScreenNavigationProp = DrawerNavigationProp<RootStackParamList>;

interface Props {
    navigation: ProfileScreenNavigationProp;
    route: { params: Params };
}
interface State {
    user: User | undefined,
    firstName: string,
    lastName: string,
    email: string,
    image: any,
}
interface Params {
    user: User
    jwtToken: string;
    jwt: any;
}


export default class LoginScreen extends React.Component<Props, State>  {
    jwtToken: string;
    jwt: any;
    params: Params;
    userService: UserService;

    constructor(props: Props) {
        super(props);
        this.params = props.route.params;
        let user = this.params.user;
        this.jwtToken = this.params.jwtToken;
        this.jwt = this.params.jwt;

        this.userService = new UserService(props.navigation);

        this.state = {
            user,
            firstName: user.firstName,
            lastName: user.lastName,
            email: user.email,
            image: user.image
        }
        this.setState({});
    }

    componentDidMount() {
        this.getPermissionAsync();
    }

    getPermissionAsync = async () => {
        if (Constants.platform?.ios) {
            const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
            if (status !== 'granted') {
                alert('Sorry, we hebben rechten voor camerarollen nodig om dit te laten werken!');
            }
        }
    };

    _pickImage = async () => {
        try {
            let result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.Images,
                allowsEditing: true,
                aspect: [1, 1],
                quality: 0.5,
                base64: true,
            });
            if (!result.cancelled) {
                this.setState({ image: "data:image/png;base64," + result.base64 });
            }
        } catch (E) {
        }
    };

    saveUserProfile = () => {
        this.userService.update(this.jwt.sub,{
            firstName: this.state.firstName,
            lastName: this.state.lastName,
            email: this.state.email,
            image: this.state.image,
            roleName: this.state.user?.roleName,
        }).then((responseJson) => {
                if (responseJson) {
                    let user: User = responseJson;
                    storage.setItem("user", JSON.stringify(user)).then(() => { storage.setItem("userLoggedIn", "true");  this.props.navigation.openDrawer(); });
                    this.setState({ user, firstName: user.firstName, lastName: user.lastName, email: user.email, image: user.image });
                }
            }).catch(err => {
                err.text().then((errorMessage: any) => {

                })
            });
    }

    render() {
        let image = this.state.image;
        var firstName = this.state.firstName;
        var lastName = this.state.lastName;
        var email = this.state.email;
        if (this.state.user) {
            return (
                <SafeAreaView>
                    <View style={styles.item}>

                        <View style={styles.ViewImageBackground}>
                            <TouchableOpacity
                                style={styles.ViewImageEditButton}
                                onPress={this._pickImage}>
                                <IconFA name={"camera"} size={30} color="white" />
                            </TouchableOpacity>
                            <Image source={{ uri: image }} style={styles.ViewImage} />
                        </View>

                        <OutlinedTextField
                            characterRestriction={200}
                            lineType='none'
                            contentInset={{ top: 0, input: 8, label: 0 }}
                            inputContainerStyle={[styles.inputButton,]}
                            // @ts-ignore
                            labelOffset={{ y1: 2 }} // Werkt wel, word alleen niet herkent door typescript
                            onEndEditing={(text: NativeSyntheticEvent<TextInputEndEditingEventData>) => { this.setState({ firstName: text.nativeEvent.text }) }}
                            value={firstName}
                            label='Voornaam' />

                        <OutlinedTextField
                            characterRestriction={200}
                            lineType='none'
                            contentInset={{ top: 0, input: 8, label: 0 }}
                            inputContainerStyle={[styles.inputButton,]}
                            // @ts-ignore
                            labelOffset={{ y1: 2 }} // Werkt wel, word alleen niet herkent door typescript
                            onEndEditing={(text: NativeSyntheticEvent<TextInputEndEditingEventData>) => { this.setState({ lastName: text.nativeEvent.text }) }}
                            value={lastName}
                            label='Achternaam' />

                        <OutlinedTextField
                            characterRestriction={100}
                            lineType='none'
                            contentInset={{ top: 0, input: 8, label: 0 }}
                            inputContainerStyle={[styles.inputButton,]}
                            // @ts-ignore
                            labelOffset={{ y1: 2 }} // Werkt wel, word alleen niet herkent door typescript
                            onEndEditing={(text: NativeSyntheticEvent<TextInputEndEditingEventData>) => { this.setState({ email: text.nativeEvent.text }) }}
                            value={email}
                            label='Email' />

                        <View style={{ borderRadius: 20 }}>
                            <Button
                                title="Update"
                                onPress={() => this.saveUserProfile()}
                                color={"#E71234"}
                            />
                        </View>
                    </View>
                </SafeAreaView>
            );
        } else {
            return (
                <SafeAreaView>
                    <View style={styles.item}>
                    </View>
                </SafeAreaView>
            );
        }
    }

}

const styles = StyleSheet.create({
    ViewImageEditButton: {
        borderWidth: 1,
        alignSelf: 'flex-end',
        right: 0,
        borderColor: 'rgba(0,0,0,0.2)',
        alignItems: 'center',
        justifyContent: 'center',
        width: 50,
        height: 50,
        backgroundColor: '#E71234',
        borderRadius: 50,
        position: "absolute",
        zIndex: 50
    },
    ViewImageBackground: {
        alignSelf: 'center',
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 6,
        },
        shadowOpacity: 0.37,
        shadowRadius: 7.49,
        elevation: 12,
        backgroundColor: "#BEBEBE",
        height: 150,
        width: 150,
        borderRadius: 1000,
        marginBottom: 40,
        marginTop: 40,
        position: "relative",
    },
    ViewImage: {
        alignSelf: 'center',
        height: 150,
        width: 150,
        borderRadius: 1000,
    },
    inputButton: {
        borderColor: 'gray',
        backgroundColor: 'white',
        borderBottomRightRadius: 7,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 6,
        width: '100%',
        padding: 10,
    },
    item: {
        margin: 30,
        marginBottom: 0
    },
});