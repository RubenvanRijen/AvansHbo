import React from 'react';
import { Picker, TouchableOpacity, ScrollView, StyleSheet, Text, View, NativeSyntheticEvent, TextInputEndEditingEventData } from 'react-native';
import { Col, Row, Grid } from "react-native-easy-grid";
import { Route } from '../../models/IRoute';
import { KilometerAllowance } from '../../models/IKilometerAllowance';
import { Placement } from '../../models/IPlacement';
import { Company } from '../../models/ICompany';

import Icon from 'react-native-vector-icons/Ionicons';
import IconFA from 'react-native-vector-icons/FontAwesome';
import IconMCI from 'react-native-vector-icons/MaterialCommunityIcons';

import DateTimePickerModal from "react-native-modal-datetime-picker";

import {
    OutlinedTextField,
} from 'react-native-material-textfield';
import { StackNavigationProp } from '@react-navigation/stack';

import PlacementService from '../../services/PlacementService';
import KilometerAllowanceService from '../../services/KilometerAllowanceService';
import RouteService from '../../services/RouteService';

// @ts-ignore // Works just fine, typescript just doesn't like it
import { MAPBOX_API_KEY } from 'react-native-dotenv';

type RootStackParamList = {
    Dashboard: undefined,
    Details: { item: Route, companyData: Array<Company>, doChange: () => void, userId: string, jwtToken: string },
    Create: { companyData: Array<Company>, doChange: () => void, userId: string, jwtToken: string },
};

type ProfileScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Create'>;

interface Props {
    navigation: ProfileScreenNavigationProp;
    route: { params: Params };
}

interface State {
    date1: Date | undefined;
    date2: Date | undefined;
    time1: Date | undefined;
    time2: Date | undefined;
    dateTimeError: string | undefined;
    postcode1Error: string | undefined;
    postcode2Error: string | undefined;
    huisnr1Error: string | undefined;
    huisnr2Error: string | undefined;
    datePicker: number;
    selectedValue: string;
    isTimePickerVisible: boolean;
    isDatePickerVisible: boolean;
    allowanceTypeName: string;
}

interface Params {
    doChange(): () => void;
    item: Route;
    companyData: Array<Company>;
    userId: string;
    jwtToken: string;
}

export default class LoginScreen extends React.Component<Props, State>  {
    months = ['januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december'];

    postcode1: string | undefined;
    postcode2: string | undefined;
    huisnr1: string | undefined;
    huisnr2: string | undefined;
    loc1: string | undefined;
    loc2: string | undefined;
    creatingNewRoute: boolean | undefined;

    POSTCODE_VALIDATION_ERROR = "Postcode onjuist";
    POSTCODE_NOT_FOUND_ERROR = "Bestaat niet";
    HUISNUMMER_VALIDATION_ERROR = "Onjuist";
    DATETIME_VALIDATION_ERROR = "Niet alle data is ingevuld";
    DATETIME_BEFORE_VALIDATION_ERROR = "Begin datum moet voor eind datum zijn";

    params: Params;
    placementService: PlacementService;
    kilometerAllowanceService: KilometerAllowanceService;
    routeService: RouteService;

    constructor(props: Props) {
        super(props);

        this.params = this.props.route.params;

        this.placementService = new PlacementService(props.navigation);
        this.kilometerAllowanceService = new KilometerAllowanceService(props.navigation);
        this.routeService = new RouteService(props.navigation);

        this.state = {
            selectedValue: props.route.params.companyData[0].name,
            isDatePickerVisible: false,
            isTimePickerVisible: false,
            datePicker: 1,
            postcode1Error: undefined,
            postcode2Error: undefined,
            huisnr1Error: undefined,
            huisnr2Error: undefined,
            dateTimeError: undefined,
            date1: undefined,
            date2: undefined,
            time1: undefined,
            time2: undefined,
            allowanceTypeName: "WORK",
        };
    }

    async getPlacement(): Promise<Placement | undefined> {
        return await this.placementService.getPlacementByUser().then(responseJson => {
            var currentPlacement;
            responseJson.forEach((element: Placement) => {
                if (element.companyName === this.state.selectedValue) {
                    currentPlacement = element;
                }
            });
            return currentPlacement;
        })
    }

    async getKilometerAllowanceId(): Promise<KilometerAllowance | undefined> {
        return await this.kilometerAllowanceService.getKilometerAllowanceByUser()
            .then((responseJson) => {
                var currentKilometerAllowance;
                responseJson.forEach((element: KilometerAllowance) => {
                    if (element.companyName === this.state.selectedValue && element.allowanceTypeName === this.state.allowanceTypeName) {
                        currentKilometerAllowance = element;
                    }
                });

                return currentKilometerAllowance;
            });
    }

    async createNewRoute() {
        if (!this.creatingNewRoute) {
            this.creatingNewRoute = true;

            if (this.postcode1 && this.postcode2 && this.huisnr1 && this.huisnr2 && this.state.date1 && this.state.date2 && this.state.time1 && this.state.time2) {
                var date1 = this.state.date1;
                var date2 = this.state.date2;
                var time1 = this.state.time1;
                var time2 = this.state.time2;

                var startTime = new Date(date1.getFullYear(), date1.getMonth(), date1.getDate(),
                    time1.getHours(), time1.getMinutes(), 0, 0);

                var endTime = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate(),
                    time2.getHours(), time2.getMinutes(), 0, 0);
                if (endTime <= startTime) {
                    this.creatingNewRoute = false;
                    return this.setState({ dateTimeError: this.DATETIME_BEFORE_VALIDATION_ERROR });
                }
                else if (this.state.dateTimeError)
                    this.setState({ dateTimeError: undefined });

                if (!(/^[1-9][0-9]{3} ?[A-Z]{2}$/.test(this.postcode1))) {
                    this.creatingNewRoute = false;
                    return this.setState({ postcode1Error: this.POSTCODE_VALIDATION_ERROR });
                }
                if (!(/^[1-9][0-9]{3} ?[A-Z]{2}$/.test(this.postcode2))) {
                    this.creatingNewRoute = false;
                    return this.setState({ postcode2Error: this.POSTCODE_VALIDATION_ERROR });
                }
                if (!(/^[1-9]\d{0,3}$/.test(this.huisnr1))) {
                    this.creatingNewRoute = false;
                    return this.setState({ huisnr1Error: this.HUISNUMMER_VALIDATION_ERROR });
                }
                if (!(/^[1-9]\d{0,3}$/.test(this.huisnr2))) {
                    this.creatingNewRoute = false;
                    return this.setState({ huisnr2Error: this.HUISNUMMER_VALIDATION_ERROR });
                }

                await fetch('https://api.mapbox.com/geocoding/v5/mapbox.places/' + this.huisnr1 + ' ' + this.postcode1 + '.json?country=NL&access_token=' + MAPBOX_API_KEY)
                    .then((response) => {
                        return response.json()
                    })
                    .then((responseJson) => {
                        if (responseJson.features.length > 0) { this.loc1 = responseJson.features[0].center } else {
                            this.setState({ postcode1Error: this.POSTCODE_NOT_FOUND_ERROR, huisnr1Error: this.HUISNUMMER_VALIDATION_ERROR });
                        }
                    });
                await fetch('https://api.mapbox.com/geocoding/v5/mapbox.places/' + this.huisnr2 + ' ' + this.postcode2 + '.json?country=NL&access_token=' + MAPBOX_API_KEY)
                    .then((response) => {
                        return response.json()
                    })
                    .then((responseJson) => {
                        if (responseJson.features.length > 0) { this.loc2 = responseJson.features[0].center } else {
                            this.setState({ postcode2Error: this.POSTCODE_NOT_FOUND_ERROR, huisnr2Error: this.HUISNUMMER_VALIDATION_ERROR });
                        }
                    });

                if (!this.loc1 || !this.loc2) {
                    this.creatingNewRoute = false;
                    return;
                }

                let selectedPlacement = await this.getPlacement();
                let kilometerAllowanceId = await this.getKilometerAllowanceId();

                if (selectedPlacement && kilometerAllowanceId) {
                    this.routeService.create({
                        companyName: this.state.selectedValue,
                        statusName: 'PENDING_BY_EMPLOYER',
                        startTime: startTime,
                        endTime: endTime,
                        userId: this.props.route.params.userId,
                        allowanceTypeName: this.state.allowanceTypeName,
                        placementId: selectedPlacement.id,
                        kilometerAllowanceId: kilometerAllowanceId.id,
                        serializedRoute: "[{\"longitude\":\"" + this.loc1[0] + "\",\"latitude\":\"" + this.loc1[1] + "\"},{\"longitude\":\"" + this.loc2[0] + "\",\"latitude\":\"" + this.loc2[1] + "\"}]",
                    }).then((responseJson) => {
                        if (responseJson) {
                            this.props.route.params.doChange();
                            this.props.navigation.goBack();
                        } else {
                            this.creatingNewRoute = false;
                            console.log(responseJson)
                        }
                    });
                } else {
                    return;
                }

            } else {
                if (!(/^[1-9][0-9]{3} ?[A-Z]{2}$/.test(this.postcode1 ? this.postcode1 : "")))
                    this.setState({ postcode1Error: this.POSTCODE_VALIDATION_ERROR });
                if (!(/^[1-9][0-9]{3} ?[A-Z]{2}$/.test(this.postcode2 ? this.postcode2 : "")))
                    this.setState({ postcode2Error: this.POSTCODE_VALIDATION_ERROR });
                if (!(/^[1-9]\d{0,3}$/.test(this.huisnr1 ? this.huisnr1 : "")))
                    this.setState({ huisnr1Error: this.HUISNUMMER_VALIDATION_ERROR });
                if (!(/^[1-9]\d{0,3}$/.test(this.huisnr2 ? this.huisnr2 : "")))
                    this.setState({ huisnr2Error: this.HUISNUMMER_VALIDATION_ERROR });

                var date1 = this.state.date1;
                var date2 = this.state.date2;
                var time1 = this.state.time1;
                var time2 = this.state.time2;

                if (!date1 || !date2 || !time1 || !time2)
                    this.setState({ dateTimeError: this.DATETIME_VALIDATION_ERROR });
                this.creatingNewRoute = false;
            }
        }
    }

    handleConfirmTime(date: Date): void {
        if (this.state.datePicker == 1) {
            this.setState({ time1: date, isTimePickerVisible: false })
        } else if (this.state.datePicker == 2) {
            this.setState({ time2: date, isTimePickerVisible: false })
        }
    };

    handleConfirmDay(date: Date): void {
        if (this.state.datePicker == 1) {
            this.setState({ date1: date, isDatePickerVisible: false })
        } else if (this.state.datePicker == 2) {
            this.setState({ date2: date, isDatePickerVisible: false })
        }
    };

    hideDatePicker() {
        this.setState({ isDatePickerVisible: false, isTimePickerVisible: false });
    };

    getCompanyView(companyData: Array<Company>) {
        var selectedValue = this.state.selectedValue;
        var companyViews = companyData.map((item: Company, i: number) => {
            return (
                <Picker.Item label={item.name} value={item.name} key={item.name} />
            )
        });

        return (
            <Picker selectedValue={selectedValue} style={styles.input} mode='dropdown' onValueChange={(itemValue, itemIndex) => this.setState({ selectedValue: itemValue })
            } >
                {
                    companyViews
                }
            </Picker >
        );
    }

    render() {
        var isDatePickerVisible = this.state.isDatePickerVisible;
        var isTimePickerVisible = this.state.isTimePickerVisible;
        var dateTimeError = this.state.dateTimeError;

        let date1Day = "Dag";
        let date1Month = "";
        if (this.state.date1) {
            date1Day = this.state.date1.getDate().toString();
            date1Month = this.months[this.state.date1.getMonth()];
        }
        let date2Day = "Dag";
        let date2Month = "";
        if (this.state.date2) {
            date2Day = this.state.date2.getDate().toString();
            date2Month = this.months[this.state.date2.getMonth()];
        }
        if (this.state.time1)
            var time1 = this.state.time1.getHours() + ":" + (this.state.time1.getMinutes() < 10 ? '0' : '') + this.state.time1.getMinutes();
        else
            var time1 = "Tijd";
        if (this.state.time2)
            var time2 = this.state.time2.getHours() + ":" + (this.state.time2.getMinutes() < 10 ? '0' : '') + this.state.time2.getMinutes();
        else
            var time2 = "Tijd";

        var companyData = this.props.route.params.companyData;

        let currentAllowanceTypeName = "";
        let homeToWorkButtonColor = "#707070";
        let workButtonColor = "#707070";

        switch (this.state.allowanceTypeName) {
            case "HOME_TO_WORK":
                currentAllowanceTypeName = "Woon- werkverkeer";
                homeToWorkButtonColor = "#FF3719";
                break;
            case "WORK":
                currentAllowanceTypeName = "Dienstreizen";
                workButtonColor = "#FF3719";
                break;
        }
        return (
            <ScrollView style={{ padding: 15 }}>
                <DateTimePickerModal
                    isVisible={isDatePickerVisible}
                    mode="date"
                    onConfirm={this.handleConfirmDay.bind(this)}
                    onCancel={this.hideDatePicker.bind(this)}
                    locale="nl_NL"
                    cancelTextIOS="Annuleren"
                    confirmTextIOS="Ok"
                    headerTextIOS="Kies een datum"
                />
                <DateTimePickerModal
                    isVisible={isTimePickerVisible}
                    mode="time"
                    onConfirm={this.handleConfirmTime.bind(this)}
                    onCancel={this.hideDatePicker.bind(this)}
                    is24Hour={true}
                    locale="nl_NL"
                    cancelTextIOS="Annuleren"
                    confirmTextIOS="Ok"
                    headerTextIOS="Kies een tijd"
                />
                <View style={{ height: 330 }}>
                    <Text style={styles.header}>Locatie</Text>
                    <View style={{ flex: 1 }}>
                        <Grid style={{ flex: 1, justifyContent: 'center', alignItems: 'center', marginBottom: 10 }}>
                            <Row style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                <Col size={10} style={{ alignItems: 'center' }}>
                                    <Icon name="md-home" style={{ fontSize: 40, }} />
                                </Col>
                                <Col size={10}>
                                    <Text style={{ fontSize: 16, fontWeight: 'bold' }}>Van</Text>
                                </Col>
                                <Col size={30} style={styles.inputCol}>
                                    <OutlinedTextField
                                        characterRestriction={7}
                                        lineType='none'
                                        contentInset={{ top: 0, input: 8, label: 0 }}
                                        inputContainerStyle={[styles.inputButton,]}
                                        // @ts-ignore
                                        labelOffset={{ y1: 2 }} // Werkt wel, word alleen niet herkent door typescript
                                        onEndEditing={(text: NativeSyntheticEvent<TextInputEndEditingEventData>) => { this.setState({ postcode1Error: undefined }), this.postcode1 = text.nativeEvent.text }}
                                        error={this.state.postcode1Error}
                                        label='Postcode' />
                                </Col>
                                <Col size={20} style={{ marginRight: 15 }}>
                                    <OutlinedTextField
                                        characterRestriction={4}
                                        lineType='none'
                                        contentInset={{ top: 0, input: 8, label: 0 }}
                                        inputContainerStyle={[styles.inputButton, styles.inputHouseNumberButton]}
                                        // @ts-ignore
                                        labelOffset={{ y1: 2 }} // Werkt wel, word alleen niet herkent door typescript
                                        onEndEditing={(text: NativeSyntheticEvent<TextInputEndEditingEventData>) => { this.setState({ huisnr1Error: undefined }), this.huisnr1 = text.nativeEvent.text }}
                                        error={this.state.huisnr1Error}
                                        label='Huis nr.' />
                                </Col>
                            </Row>
                            <Row size={1} style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                <Col size={10} style={{ alignItems: 'center' }}>
                                    <IconFA name="map-marker" style={{ fontSize: 40, }} />
                                </Col>
                                <Col size={10}>
                                    <Text style={{ fontSize: 16, fontWeight: 'bold' }}>Naar</Text>
                                </Col>
                                <Col size={30} style={styles.inputCol}>
                                    <OutlinedTextField
                                        characterRestriction={7}
                                        lineType='none'
                                        contentInset={{ top: 0, input: 8, label: 0 }}
                                        inputContainerStyle={[styles.inputButton,]}
                                        // @ts-ignore
                                        labelOffset={{ y1: 2 }} // Werkt wel, word alleen niet herkent door typescript
                                        onEndEditing={(text: NativeSyntheticEvent<TextInputEndEditingEventData>) => { this.setState({ postcode2Error: undefined }), this.postcode2 = text.nativeEvent.text }}
                                        error={this.state.postcode2Error}
                                        label='Postcode' />
                                </Col>
                                <Col size={20} style={{ marginRight: 15 }}>
                                    <OutlinedTextField
                                        characterRestriction={4}
                                        lineType='none'
                                        contentInset={{ top: 0, input: 8, label: 0 }}
                                        inputContainerStyle={[styles.inputButton, styles.inputHouseNumberButton]}
                                        // @ts-ignore
                                        labelOffset={{ y1: 2 }} // Werkt wel, word alleen niet herkent door typescript
                                        onEndEditing={(text: NativeSyntheticEvent<TextInputEndEditingEventData>) => { this.setState({ huisnr2Error: undefined }), this.huisnr2 = text.nativeEvent.text }}
                                        error={this.state.huisnr2Error}
                                        label='Huis nr.' />
                                </Col>
                            </Row>
                        </Grid>
                        <View style={{ alignItems: "center" }}>
                            <Row style={styles.typeRoutes}>
                                <TouchableOpacity style={styles.typeRoutesButton} onPress={() => { this.setState({ allowanceTypeName: "HOME_TO_WORK" }) }}>
                                    <IconFA name="home" size={50} color={homeToWorkButtonColor} />
                                    <Text style={{ fontSize: 13, color: homeToWorkButtonColor }}>woon- werkverkeer</Text>
                                </TouchableOpacity>
                                <Text style={{ borderColor: "#CFCFCF", borderWidth: 1, height: "80%", }}></Text>
                                <TouchableOpacity style={styles.typeRoutesButton} onPress={() => { this.setState({ allowanceTypeName: "WORK" }) }}>
                                    <IconMCI name="briefcase" size={50} color={workButtonColor} />
                                    <Text style={{ fontSize: 13, color: workButtonColor }}>dienstreizen</Text>
                                </TouchableOpacity>
                            </Row>
                        </View>
                    </View>

                </View>
                <View style={{ height: 175 }}>
                    <Text style={styles.header}>Vanaf</Text>
                    <Col style={{ alignItems: "center" }}>

                        <Row style={styles.typeRoutes}>
                            <TouchableOpacity style={styles.typeRoutesButton} onPress={() => { this.setState({ datePicker: 1, isDatePickerVisible: true }) }}>
                                <Text style={{ fontSize: 35, fontWeight: "bold", color: "#536171" }}>{date1Day}</Text>
                                <Text style={{ fontSize: 16, color: "#A1AAB2", fontWeight: "bold" }}>{date1Month}</Text>
                            </TouchableOpacity>
                            <Text style={{ borderColor: "#CFCFCF", borderWidth: 1, height: "80%", }}></Text>
                            <TouchableOpacity style={styles.typeRoutesButton} onPress={() => { this.setState({ datePicker: 1, isTimePickerVisible: true }) }}>
                                <Text style={{ fontSize: 35, fontWeight: "bold", color: "#536171" }}>{time1}</Text>
                                <Text style={{ fontSize: 16, color: "#A1AAB2", fontWeight: "bold" }}></Text>
                            </TouchableOpacity>
                        </Row>
                        <Row style={{ height: 10 }}>
                            <Col size={20}>
                            </Col>
                            <Col size={50} style={styles.inputCol}>
                                <Text style={styles.errorMessage}>{dateTimeError}</Text>
                            </Col>
                        </Row>
                    </Col>
                </View>
                <View style={{ height: 175 }}>
                    <Text style={styles.header}>Tot</Text>
                    <Col style={{ alignItems: "center" }}>

                        <Row style={styles.typeRoutes}>
                            <TouchableOpacity style={styles.typeRoutesButton} onPress={() => { this.setState({ datePicker: 2, isDatePickerVisible: true }) }}>
                                <Text style={{ fontSize: 35, fontWeight: "bold", color: "#536171" }}>{date2Day}</Text>
                                <Text style={{ fontSize: 16, color: "#A1AAB2", fontWeight: "bold" }}>{date2Month}</Text>
                            </TouchableOpacity>
                            <Text style={{ borderColor: "#CFCFCF", borderWidth: 1, height: "80%", }}></Text>
                            <TouchableOpacity style={styles.typeRoutesButton} onPress={() => { this.setState({ datePicker: 2, isTimePickerVisible: true }) }}>
                                <Text style={{ fontSize: 35, fontWeight: "bold", color: "#536171" }}>{time2}</Text>
                                <Text style={{ fontSize: 16, color: "#A1AAB2", fontWeight: "bold" }}></Text>
                            </TouchableOpacity>
                        </Row>
                        <Row style={{ height: 10 }}>
                            <Col size={20}>
                            </Col>
                            <Col size={50} style={styles.inputCol}>
                                <Text style={styles.errorMessage}>{dateTimeError}</Text>
                            </Col>
                        </Row>
                    </Col>

                </View>
                <View style={{ height: 125 }}>
                    <Text style={styles.header}>Werkgever</Text>
                    <View style={{ flex: 1 }}>
                        <Grid style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                            <Row size={1} style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                <Col size={20} style={{ alignItems: 'center' }}>
                                    <IconFA name="user" style={{ fontSize: 40, }} />
                                </Col>
                                <Col size={50} style={{ marginRight: 15 }}>
                                    {
                                        this.getCompanyView(companyData)
                                    }
                                </Col>
                            </Row>

                        </Grid>
                    </View>
                </View>
                <View style={{ height: 125 }}>
                    <TouchableOpacity style={{ width: "80%", marginTop: 20, alignSelf: "center", height: 40, backgroundColor: "#E71234", borderRadius: 10, alignItems: "center", justifyContent: "center" }} onPress={() => { this.createNewRoute() }}>
                        <Text style={{ color: "white" }}>OK</Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>

        );
    }
}

const styles = StyleSheet.create({
    typeRoutes: {
        height: 100,
        alignItems: "center",
        borderRadius: 10,
        backgroundColor: "white",
        overflow: "hidden",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3,
        marginBottom: 10
    },
    typeRoutesButton: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "white",
        height: "100%",
        width: "40%",
    },
    header: {
        borderBottomWidth: 1,
        paddingLeft: 10,
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 15,
    },
    input: {
        height: 50,
        backgroundColor: 'white',
        shadowOffset: {
            width: 0,
            height: 1,
        },
        width: '100%',
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 6,
        borderRadius: 40,
    },
    inputCol: {
        marginRight: 15,
        marginLeft: 10,
    },
    inputButton: {
        borderColor: 'gray',
        backgroundColor: 'white',
        borderBottomRightRadius: 7,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 6,
        width: '100%',
        padding: 10,
    },
    inputHouseNumberButton: {
        width: '100%',
    },
    errorMessage: {
        color: 'red',
    }

});
