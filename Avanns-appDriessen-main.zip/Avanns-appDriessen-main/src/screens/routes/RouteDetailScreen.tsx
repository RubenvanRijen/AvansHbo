// Native
import React, { Component } from 'react';
import { Image, TouchableOpacity, SafeAreaView, Dimensions, StyleSheet, Text, View } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';

// Grid
import { Col, Row, Grid } from "react-native-easy-grid";

// Icons
import Icon from 'react-native-vector-icons/Ionicons';
import IconFA from 'react-native-vector-icons/FontAwesome5';
import IconMCI from 'react-native-vector-icons/MaterialCommunityIcons';

// Models
import { Route } from '../../models/IRoute';
import { Company } from '../../models/ICompany';
import { KilometerAllowance } from '../../models/IKilometerAllowance';
import { Placement } from '../../models/IPlacement';

// Map
import {
    WebViewLeaflet, WebViewLeafletEvents, MapShapeType,
    WebviewLeafletMessage
} from 'react-native-webview-leaflet';
import { MapShape, LatLng } from 'react-native-webview-leaflet/models';

// Services
import PlacementService from '../../services/PlacementService';
import KilometerAllowanceService from '../../services/KilometerAllowanceService';
import RouteService from '../../services/RouteService';

let { width, height } = Dimensions.get("window");

type RootStackParamList = {
    Dashboard: undefined,
    Details: { item: Route, companyData: Array<Company>, doChange: () => void, userId: string, jwtToken: string },
    Create: { companyData: Array<Company>, doChange: () => void, userId: string, jwtToken: string },
};

type ProfileScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Details'>;

interface Props {
    navigation: ProfileScreenNavigationProp;
    route: { params: Params };
}

interface State {
    showCompany: boolean;
    mapCenterPosition: LatLng;
    currentCompanyImage: string;
    currentCompanyName: string;
    zoom: number;
    mapShapes: Array<MapShape> | undefined;
    allowanceTypeName: string;
}

interface Coord {
    lat: number;
    lng: number;
}

interface Params {
    doChange(): () => void;
    item: Route;
    companyData: Array<Company>;
    userId: string;
    jwtToken: string;
}

export default class DetailScreen extends React.Component<Props, State>  {
    params: Params;
    navigation: ProfileScreenNavigationProp;
    companyViewCache: any;
    placementService: PlacementService;
    kilometerAllowanceService: KilometerAllowanceService;
    routeService: RouteService;

    constructor(props: Props) {
        super(props);

        this.navigation = props.navigation
        this.params = props.route.params;

        this.placementService = new PlacementService(props.navigation);
        this.kilometerAllowanceService = new KilometerAllowanceService(props.navigation);
        this.routeService = new RouteService(props.navigation);

        this.state = {
            zoom: 0,
            mapShapes: [],
            mapCenterPosition: {},
            showCompany: false,
            currentCompanyImage: this.params.companyData[0].image,
            currentCompanyName: this.params.companyData[0].name,
            allowanceTypeName: this.params.item.allowanceTypeName || "WORK"
        };
    }

    componentDidMount() {
        var mapShapes = this.state.mapShapes || [];
        var positions = JSON.parse(this.params.item.serializedMapRoute);

        var mapCenterPosition = this.averageGeolocation(positions);

        var firstItem = positions[0];
        var lastItem = positions[positions.length - 1];
        var distance = this.distance(firstItem.lat, firstItem.lng, lastItem.lat, lastItem.lng);

        if (distance < 1) {
            var zoom = 16;
        } else if (distance < 3) {
            var zoom = 14;
        } else if (distance < 8) {
            var zoom = 12;
        } else if (distance < 22) {
            var zoom = 11;
        } else {
            var zoom = 10;
        }

        mapShapes.push({
            shapeType: MapShapeType.POLYLINE,
            color: "blue",
            id: "1",
            positions,
        });

        this.setState({ zoom, mapCenterPosition, mapShapes });
    }
    onMessageReceived(message: WebviewLeafletMessage): void {
        switch (message.event) {
            case WebViewLeafletEvents.ON_MAP_MARKER_CLICKED:
                // On marker click
                break;
            case WebViewLeafletEvents.ON_MAP_TOUCHED:
                // On map toutch
                break;
            default:
        }
    }

    distance(lat1: number, lon1: number, lat2: number, lon2: number): number {
        if ((lat1 == lat2) && (lon1 == lon2)) {
            return 0;
        }
        else {
            var radlat1 = Math.PI * lat1 / 180;
            var radlat2 = Math.PI * lat2 / 180;
            var theta = lon1 - lon2;
            var radtheta = Math.PI * theta / 180;
            var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
            if (dist > 1) {
                dist = 1;
            }
            dist = Math.acos(dist);
            dist = dist * 180 / Math.PI;
            dist = dist * 60 * 1.1515;
            dist = dist * 1.609344
            return dist;
        }
    }

    averageGeolocation(coords: Array<Coord>) {
        if (coords.length === 1) {
            return coords[0];
        }

        let x = 0.0;
        let y = 0.0;
        let z = 0.0;

        for (let Coord of coords) {
            let latitude = Coord.lat * Math.PI / 180;
            let longitude = Coord.lng * Math.PI / 180;

            x += Math.cos(latitude) * Math.cos(longitude);
            y += Math.cos(latitude) * Math.sin(longitude);
            z += Math.sin(latitude);
        }

        let total = coords.length;

        x = x / total;
        y = y / total;
        z = z / total;

        let centralLongitude = Math.atan2(y, x);
        let centralSquareRoot = Math.sqrt(x * x + y * y);
        let centralLatitude = Math.atan2(z, centralSquareRoot);

        return {
            lat: centralLatitude * 180 / Math.PI,
            lng: centralLongitude * 180 / Math.PI
        };
    }

    deleteRoute() {
        this.routeService.delete(this.params.item.id)
            .then(() => { this.params.doChange(), this.props.navigation.goBack() });
    }

    async getPlacement(): Promise<Placement | undefined> {
        return await this.placementService.getPlacementByUser()
            .then((responseJson) => {
                var currentPlacement;
                responseJson.forEach((element: Placement) => {
                    if (element.companyName === this.state.currentCompanyName) {
                        currentPlacement = element;
                    }
                });

                return currentPlacement;
            });
    }

    async getKilometerAllowanceId(): Promise<KilometerAllowance | undefined> {
        return await this.kilometerAllowanceService.getKilometerAllowanceByUser()
            .then((responseJson) => {
                var currentKilometerAllowance;
                responseJson.forEach((element: KilometerAllowance) => {
                    if (element.companyName === this.state.currentCompanyName && element.allowanceTypeName === this.state.allowanceTypeName) {
                        currentKilometerAllowance = element;
                    }
                });

                return currentKilometerAllowance;
            });
    }

    async addRoute() {
        let selectedPlacement = await this.getPlacement();
        let kilometerAllowanceId = await this.getKilometerAllowanceId();

        if (selectedPlacement && kilometerAllowanceId) {
            this.routeService.update(this.params.item.id, {
                companyName: this.state.currentCompanyName,
                statusName: 'PENDING_BY_EMPLOYER',
                userId: this.params.userId,
                serializedMapRoute: this.params.item.serializedMapRoute,
                serializedRoute: this.params.item.serializedRoute,
                allowanceTypeName: this.state.allowanceTypeName,
                placementId: selectedPlacement.id,
                kilometerAllowanceId: kilometerAllowanceId.id,
                id: this.params.item.id,
                distance: this.params.item.distance,
            }).then((responseJson) => {
                if (responseJson) {
                    this.props.route.params.doChange();
                    this.props.navigation.goBack();
                }
            });
        }
    }

    changeCompany() {
        if (this.state.showCompany) {
            this.setState({ showCompany: false });
        } else {
            this.setState({ showCompany: true });
        }
    }

    changeSelectedCompany(name: string, image: string) {
        this.setState({ showCompany: false, currentCompanyImage: image, currentCompanyName: name, });
    }

    getStatusView(status: string, amount: number) {
        switch (status) {
            case "PENDING_BY_EMPLOYEE":
                return (
                    <View style={{ height: 35, backgroundColor: "#FFB33E", alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' }}>
                        <Text style={[styles.statusText]}><Icon name="md-alert" style={styles.actionButtonIcon} /> Route gedetecteerd, klopt deze route?</Text>
                        <Text style={[styles.statusText]}>{'\u20AC'} {amount}</Text>
                    </View>
                );
            case "PENDING_BY_EMPLOYER":
                return (
                    <View style={{ height: 35, backgroundColor: "#707070", alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' }}>
                        <Text style={[styles.statusText, { marginRight: 0 }]}><Icon name="md-checkmark-circle-outline" style={styles.actionButtonIcon} /> In afwachting van goedkeuring werkgever</Text>
                        <Text style={[styles.statusText]}>{'\u20AC'} {amount}</Text>
                    </View>
                );
            case "APPROVED":
                return (
                    <View style={{ height: 35, backgroundColor: "#50BE64", alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' }}>
                        <Text style={styles.statusText}><Icon name="md-checkmark-circle-outline" style={styles.actionButtonIcon} /> Goedgekeurd</Text>
                        <Text style={[styles.statusText]}>{'\u20AC'} {amount}</Text>
                    </View>
                );
            case "REJECTED":
                return (
                    <View style={{ height: 35, backgroundColor: "#E71234", alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' }}>
                        <Text style={styles.statusText}><Icon name="md-close-circle-outline" style={styles.actionButtonIcon} /> Afgekeurd</Text>
                        <Text style={[styles.statusText, styles.statusTextRejected]}>{'\u20AC'} {amount}</Text>
                    </View>
                );
            default:
                return null;
        }
    }

    getCompanySelectView() {
        if (this.state.showCompany && this.params.companyData) {
            let companyData = this.params.companyData;
            let companyViews = companyData.map((item: Company, i: number) => {

                let backgroundColor = "white";
                if (item.name == this.state.currentCompanyName) {
                    backgroundColor = "rgba(255, 0, 0, 0.2)";
                }
                let borderColor = "#CFCFCF";
                if (companyData.length - 1 == i) {
                    borderColor = "white";
                }
                return (
                    <Row style={{ height: 45, borderColor: borderColor, borderBottomWidth: 1, padding: 4 }} key={item.name}>
                        <TouchableOpacity activeOpacity={0.9} style={[styles.companyButton, { backgroundColor: backgroundColor }]} onPress={this.changeSelectedCompany.bind(this, item.name, item.image)}>
                            <Image style={{
                                width: 30, height: 30,
                                marginRight: 10, resizeMode: 'contain'
                            }} source={{ uri: item.image }} />
                            <Text>{item.name}</Text>
                        </TouchableOpacity>
                    </Row>
                )
            });
            this.companyViewCache = (
                <View style={styles.companyPopup}>
                    <Grid style={{ flex: 1, justifyContent: 'center', alignItems: 'center', }}>
                        {companyViews}
                    </Grid>
                </View>

            );
            return this.companyViewCache;
        } else {
            return null;
        }
    }

    getCompanyView = () => {
        let company;
        let companyImage;

        if (this.params.item.companyName) {
            company = this.params.item.companyName;
            companyImage = this.params.companyData.find((company: Company) => { return company.name === this.params.item.companyName })?.image;
        } else if (this.state.currentCompanyName) {
            company = this.state.currentCompanyName;
            companyImage = this.state.currentCompanyImage
        }

        if (this.params.item.statusName === 'PENDING_BY_EMPLOYEE') {
            return (
                <View>
                    <Text style={{ fontSize: 13 }}>{company}</Text>
                    <Row>
                        <Col style={{ paddingRight: 10, height: 40 }}>
                            <TouchableOpacity style={[styles.pendingButton, { backgroundColor: "white", width: 70 }]} onPress={this.changeCompany.bind(this)}>
                                <Text style={[styles.pendingButtonText, { height: 40, color: 'white' }]}><Image style={{ width: 25, height: 25, }} source={{ uri: this.state.currentCompanyImage }} /> <IconFA name="chevron-up" color="gray" style={styles.actionButtonIcon} /></Text>
                            </TouchableOpacity>
                        </Col>
                    </Row>
                </View>);
        } else {
            return (
                <View>
                    <Text style={{ fontSize: 13 }}>{company}</Text>
                    <Row>
                        <Col style={{ height: 40, marginTop: 5 }}>
                            <Image style={{ width: 30, height: 30, resizeMode: 'contain' }} source={{ uri: companyImage }} />
                        </Col>

                    </Row>
                </View>
            );
        }
    }

    getNewRouteView(status: string) {
        if (status === 'PENDING_BY_EMPLOYEE') {
            return (
                <Grid style={{ flex: 1, justifyContent: 'center', alignItems: 'center', }}>
                    <Col style={{ height: 30 }}>
                        <TouchableOpacity style={[styles.pendingButton, { backgroundColor: "#F4F0ED" }]} onPress={this.deleteRoute.bind(this)}>
                            <Text style={styles.pendingButtonText}>Nee, verwijderen</Text>
                        </TouchableOpacity>
                    </Col>


                    <Col style={{ height: 30, alignItems: "flex-end" }}>
                        <TouchableOpacity style={styles.pendingButton} onPress={this.addRoute.bind(this)}>
                            <Text style={[styles.pendingButtonText, { color: 'white' }]}>Ja, toevoegen</Text>
                        </TouchableOpacity>
                    </Col>
                </Grid>
            );
        }
    }
    render() {
        let zoom = this.state.zoom || 12;
        let mapShapes = this.state.mapShapes || [];
        let mapCenterPosition = this.state.mapCenterPosition;
        let distance = (this.params.item.distance / 1000).toFixed(0);
        let startTime = this.params.item.startTime;
        let endTime = this.params.item.endTime;
        let totalTime = this.params.item.duration;
        let date = this.params.item.date;

        let startLocation = this.params.item.startLocation;
        let endLocation = this.params.item.endLocation;

        let currentAllowanceTypeName = "";
        let homeToWorkButtonColor = "#707070";
        let workButtonColor = "#707070";

        switch (this.state.allowanceTypeName) {
            case "HOME_TO_WORK":
                currentAllowanceTypeName = "Woon- werkverkeer";
                homeToWorkButtonColor = "#FF3719";
                break;
            case "WORK":
                currentAllowanceTypeName = "Dienstreizen";
                workButtonColor = "#FF3719";
                break;
        }
        let buttonsDisabled = true;

        if (this.params.item.statusName === 'PENDING_BY_EMPLOYEE') {
            buttonsDisabled = false;
        }

        return (
            <SafeAreaView style={styles.container}>
                <TouchableOpacity style={[styles.goBackButton]} activeOpacity={0.9} onPress={this.props.navigation.goBack}>
                    <IconFA name="arrow-left" size={35} color="#707070" />
                </TouchableOpacity>
                <View style={{ flex: 10 }}>

                    <WebViewLeaflet
                        onMessageReceived={this.onMessageReceived}
                        mapCenterPosition={mapCenterPosition}
                        mapShapes={
                            mapShapes
                        }
                        mapLayers={[
                            {
                                attribution: '&amp;copy <a href="http://osm.org/copyright">OpenStreetMap</a> contributors',
                                baseLayerIsChecked: true,
                                baseLayerName: "OpenStreetMap.Mapnik",
                                url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                            }
                        ]}
                        zoom={zoom}
                    />
                </View>
                {
                    this.getStatusView(this.params.item.statusName, this.params.item.amount)
                }
                <View style={{ flex: 3, justifyContent: 'center', margin: 20, marginBottom: 10 }}>
                    <Grid style={{ paddingLeft: 10 }}>
                        {
                            this.getCompanySelectView()
                        }
                        <Col>
                            {
                                this.getCompanyView()
                            }

                        </Col>

                        <Col style={{ alignItems: "center" }}>
                            <Text style={{ fontSize: 13 }}>{currentAllowanceTypeName}</Text>
                            <Row style={styles.typeRoutes}>
                                <TouchableOpacity disabled={buttonsDisabled} style={styles.typeRoutesButton} onPress={() => { this.setState({ allowanceTypeName: "HOME_TO_WORK" }) }}>
                                    <IconFA name="home" size={25} color={homeToWorkButtonColor} />
                                </TouchableOpacity>
                                <Text style={{ borderColor: "#CFCFCF", borderWidth: 1, height: "80%", }}></Text>
                                <TouchableOpacity disabled={buttonsDisabled} style={styles.typeRoutesButton} onPress={() => { this.setState({ allowanceTypeName: "WORK" }) }}>
                                    <IconMCI name="briefcase" size={25} color={workButtonColor} />
                                </TouchableOpacity>
                            </Row>
                        </Col>
                        <Col style={{ justifyContent: 'center', alignItems: 'center' }}>
                            <Text style={{ fontWeight: "bold" }}>{date}</Text>
                        </Col>
                    </Grid>

                    <Grid style={{ paddingTop: 10, paddingLeft: 10 }}>
                        <Row >
                            <Col size={22} style={styles.routeCol} >
                                <Text numberOfLines={1}>{startLocation} </Text>
                            </Col>
                            <Col size={40} style={[styles.routeCol, { alignItems: "center" }]}>
                                <Text><IconFA name="road" style={styles.actionButtonIcon} /> {distance} km</Text>
                            </Col>
                            <Col size={22} style={styles.routeCol}>
                                <Text numberOfLines={1}>{endLocation}</Text>
                            </Col>
                        </Row>
                        <Image source={require("../../../assets/route_arrow.png")} style={styles.arrowImage} />
                        <Row>
                            <Col size={22} style={styles.routeCol}>
                                <Text>{startTime}</Text>
                            </Col>
                            <Col size={40} style={[styles.routeCol, { alignItems: "center" }]}>
                                <Text><Icon name="ios-timer" style={styles.actionButtonIcon} /> {totalTime}</Text>
                            </Col>
                            <Col size={22} style={styles.routeCol}>
                                <Text>{endTime}</Text>
                            </Col>
                        </Row>
                    </Grid>
                </View>
                <View style={{ flex: 1, alignItems: 'center', margin: 10 }}>
                    {
                        this.getNewRouteView(this.params.item.statusName)
                    }
                </View>
            </SafeAreaView>
        );
    }
}
const styles = StyleSheet.create({
    goBackButton: {
        backgroundColor: "white",
        width: 60,
        height: 60,
        position: "absolute",
        top: 0,
        right: 0,
        zIndex: 10,
        marginRight: 15,
        marginTop: 35,
        borderRadius: 1000,
        alignItems: "center",
        justifyContent: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3
    },
    container: {
        flex: 1,
        backgroundColor: "#EFECEA"
    },
    item: {
        paddingLeft: 15,
        marginTop: 10,
        width: width / 2,
        fontSize: 20
    },
    flexRow: {
        flex: 1,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-around",
        margin: 5
    },
    routeCol: {
        justifyContent: 'center',
    },
    fontsize20: {
        fontSize: 20
    },
    arrowImage: {
        width: "100%",
    },
    routeViewImage: {
        alignSelf: "center",
        height: 35,
        resizeMode: 'contain',
    },
    statusText: {
        marginLeft: 30,
        marginRight: 30,
        fontSize: 15,
        color: 'white',
    },
    statusTextRejected: {
        textDecorationLine: "line-through",
    },
    actionButtonIcon: {
        fontSize: 16,
    },
    typeRoutes: {
        height: 40,
        alignItems: "center",
        borderRadius: 10,
        backgroundColor: "white",
        overflow: "hidden",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3
    },
    typeRoutesButton: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "white",
        height: "100%",
        width: 50,
    },
    companyPopup: {
        position: 'absolute',
        left: 0,
        bottom: 0,
        marginBottom: 70,
        // borderWidth: 1,
        // borderColor: 'gray',
        borderRadius: 10,
        overflow: "hidden",
        width: '55%',
        backgroundColor: 'white',
        zIndex: 2,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3
    },
    companyButton: {
        backgroundColor: 'white',
        // alignItems: 'baseline',
        width: '100%',
        borderWidth: 0,
        borderRadius: 5,
        padding: 5,
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center'
    },
    pendingButton: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        height: 30,
        backgroundColor: "#50BE64",
        borderWidth: 0,
        borderColor: '#fff',
        borderRadius: 12,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3,
        width: "70%"
    },
    pendingButtonText: {
        fontWeight: "bold",
    }
});