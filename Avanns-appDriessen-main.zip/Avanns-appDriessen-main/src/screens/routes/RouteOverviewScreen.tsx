// Native
import * as React from 'react';
import { Image, Picker, TouchableWithoutFeedback, SafeAreaView, StyleSheet, Text, View, Platform, StatusBar } from 'react-native';

// Grid
import { Col, Grid } from "react-native-easy-grid";

// Models
import { Route } from '../../models/IRoute';
import { Company } from '../../models/ICompany';
import { KilometerAllowance } from '../../models/IKilometerAllowance';
import { User } from '../../models/IUser';

// Tracker
import Tracker from '../../controller/tracker';

// Default company base 64 image
import defaultCompanyImage from '../../../assets/default_company_image.json';

// Icons
import ActionButton from 'react-native-action-button';
import Icon from 'react-native-vector-icons/Ionicons';
import IconMI from 'react-native-vector-icons/MaterialIcons';

// Services
import CompanyService from '../../services/CompanyService';
import PlacementService from '../../services/PlacementService';
import KilometerAllowanceService from '../../services/KilometerAllowanceService';
import RouteService from '../../services/RouteService';

// Other
import { ScrollView } from 'react-native-gesture-handler';
import Dash from 'react-native-dash';
import { StackNavigationProp } from '@react-navigation/stack';
import { YellowBox } from 'react-native';

YellowBox.ignoreWarnings([
    'Non-serializable values were found in the navigation state',
]);

type RootStackParamList = {
    WorkHours: undefined,
    Dashboard: any,
    Details: { item: Route, companyData: Array<Company>, doChange: () => void, userId: string, jwtToken: string },
    Create: { companyData: Array<Company>, doChange: () => void, userId: string, jwtToken: string },
    Login: undefined,
    RouteFilter: undefined
};

type ProfileScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Dashboard'>;

interface Props {
    navigation: ProfileScreenNavigationProp;
    route: { params: Params };
    Dashboard:
    {
        screen: string,
        params: { user: User, jwt: Jwt, jwtToken: string }
    };
}

interface State {
    baseRoutesArray: Array<Route> | undefined,
    initialRoutesArray: Array<Route> | undefined,
    companyData: Array<Company> | undefined,
    companyDataFromUser: Array<Company> | undefined,
    isAllowedToTrack: boolean,
    isDriving: boolean,
    filter: string,
    user: User | undefined,
    isLoading: boolean,
}

interface Jwt {
    email: string,
    sub: string,
    nbf: string,
    exp: string,
    iat: string
}

interface Params {
    user: User
    jwtToken: string;
    jwt: any;
    filterString: string | undefined;
    sortName: string | undefined;
    sortDirection: string | undefined;
}

export default class OverviewScreen extends React.Component<Props, State>  {  
    navigation: ProfileScreenNavigationProp;
    jwtToken: string | undefined;
    jwt: any;
    params: Params;
    tracker: Tracker | undefined;
    kilometerAllowances: KilometerAllowance[] | undefined;
    companyService: CompanyService;
    placementService: PlacementService;
    kilometerAllowanceService: KilometerAllowanceService;
    routeService: RouteService;

    constructor(props: Props) {
        super(props);
        this.params = props.route.params;

        this.jwtToken = this.params.jwtToken;
        this.jwt = this.params.jwt;
        this.navigation = props.navigation;

        let user = this.params.user;

        // Init services
        this.companyService = new CompanyService(props.navigation);
        this.placementService = new PlacementService(props.navigation);
        this.kilometerAllowanceService = new KilometerAllowanceService(props.navigation);
        this.routeService = new RouteService(props.navigation);

        this.state = {
            baseRoutesArray: [],
            initialRoutesArray: [],
            companyData: [],
            companyDataFromUser: [],
            isAllowedToTrack: false,
            isDriving: false,
            isLoading: true,
            filter: "NONE",
            user
        };

        this.init();
    }

    init = async () => {
        await this.getRouteData();
        if (this.jwt && this.jwtToken) {
            this.tracker = new Tracker(this.jwt.sub, this.getRouteData, this.jwtToken, this);
        }
    }

    componentDidMount() {
        console.disableYellowBox = true;
    }

    getRouteData = async () => {
        if (this.jwt) {
            this.setState({ isLoading: true });
            let kilometerAllowances = await this.kilometerAllowanceService.getKilometerAllowanceByUser();

            if (kilometerAllowances) {
                let fetchUri = "";
                if (this.params.filterString != null) fetchUri = this.params.filterString
                
                await this.routeService.getRoutesByUser(fetchUri)
                    .then((responseJson) => {
                        if (responseJson) {
                            let routesData: Array<Route> = responseJson.map(function (obj: Route): Route {
                                let startDT = new Date(obj.startTime);
                                let endDT = new Date(obj.endTime);
                                let duration = new Date((endDT as any) - (startDT as any));
                                let diffHours = (((duration.getUTCDate() - 1) * 24) + duration.getUTCHours());

                                // Calculate route price
                                let amount = 0;
                                kilometerAllowances?.forEach(element => {
                                    if (element.companyName === obj.companyName && element.allowanceTypeName === obj.allowanceTypeName && element.minDistance <= (obj.distance / 1000)) {
                                        amount = +((obj.distance / 1000) * element.price).toFixed(2);
                                    }
                                });

                                return {
                                    statusName: obj.statusName,
                                    date: startDT.getDate() + "-" + (startDT.getMonth() + 1) + "-" + startDT.getFullYear(),
                                    startTime: startDT.getHours() + ":" + (startDT.getMinutes() < 10 ? '0' : '') + startDT.getMinutes(),
                                    endTime: endDT.getHours() + ":" + (endDT.getMinutes() < 10 ? '0' : '') + endDT.getMinutes(),
                                    duration: diffHours + ":" + (duration.getMinutes() < 10 ? '0' : '') + duration.getMinutes(),
                                    amount,
                                    companyName: obj.companyName,
                                    id: obj.id,
                                    serializedMapRoute: obj.serializedMapRoute,
                                    serializedRoute: obj.serializedRoute,
                                    distance: obj.distance,
                                    startLocation: obj.startLocation,
                                    endLocation: obj.endLocation,
                                    allowanceTypeName: obj.allowanceTypeName
                                }
                            });
                            if (this.params.sortName != "NONE") {
                                var tempRoutes: Array<Route> = routesData;
                                tempRoutes = this.sortRoutes(routesData);
                                this.setState({ initialRoutesArray: tempRoutes });
                            } else {
                                this.setState({ initialRoutesArray: routesData });
                            }
                        }
                    }).catch((error) => {
                        console.error(error);
                    });

                // TODO: Use services instead of own functions
                Promise.all([this.companyService.getAll(), this.companyService.getCompanyByUser()]).then((values) => {
                    if (values[0])
                        this.setState({ companyData: values[0] });
                    if (values[1])
                        this.setState({ companyDataFromUser: values[1] });
                    this.setState({ isLoading: false });
                });
            }
            else
                this.setState({ isLoading: false });
        }
    }

    sortRoutes = (routes: Route[]) => {
        let sortString = this.params.sortName;
        let sortDirection = this.params.sortDirection;
        routes.sort(function (a: Route, b: Route) {
            switch (sortString) {
                case "distance":
                    if (sortDirection == "1") {
                        if (a.distance > b.distance) return 1;
                        if (a.distance < b.distance) return -1;
                    } else if (sortDirection == "2") {
                        if (a.distance > b.distance) return 1;
                        if (a.distance < b.distance) return -1;
                    }
                    return 0;
                case "company":
                    if (sortDirection == "1") {
                        if (a.companyName > b.companyName) return 1;
                        if (a.companyName < b.companyName) return -1;
                    } else if (sortDirection == "2") {
                        if (a.companyName > b.companyName) return 1;
                        if (a.companyName < b.companyName) return -1;
                    }
                    return 0;
                case "date":
                    let dateA = a.date;
                    let yearA = dateA.split('-')[2];
                    let monthA = dateA.split('-')[1];
                    if (monthA.length == 1) monthA = "0" + monthA;
                    let dayA = dateA.split('-')[0];
                    if (dayA.length == 1) dayA = "0" + dayA;
                    let dateAParsed = Date.parse(yearA + "-" + monthA + "-" + dayA + "T00:00:00.000Z");

                    let dateB = b.date;
                    let yearB = dateB.split('-')[2];
                    let monthB = dateB.split('-')[1];
                    if (monthB.length == 1) monthB = "0" + monthB;
                    let dayB = dateB.split('-')[0];
                    if (dayB.length == 1) dayB = "0" + dayB;
                    let dateBParsed = Date.parse(yearB + "-" + monthB + "-" + dayB + "T00:00:00.000Z");

                    if (sortDirection == "1") {
                        if (dateAParsed < dateBParsed) return 1;
                        if (dateAParsed < dateBParsed) return -1;
                    } else if (sortDirection == "2") {
                        if (dateAParsed < dateBParsed) return 1;
                        if (dateAParsed < dateBParsed) return -1;
                    }
                    return 0;
                case 'type':
                    let numberA;
                    a.allowanceTypeName === "WORK" ? numberA = 1 : numberA = 0;

                    let numberB;
                    b.allowanceTypeName === "WORK" ? numberB = 1 : numberB = 0;

                    if (sortDirection == "1") {
                        if (numberA < numberB) return 1;
                        if (numberA < numberB) return -1;
                    } else if (sortDirection == "2") {
                        if (numberA < numberB) return 1;
                        if (numberA < numberB) return -1;
                    }
                    return 0;
                default:
                    return 0;
            }

        });

        return routes;
    }

    getStatusColor(status: string) {
        switch (status) {
            case "PENDING_BY_EMPLOYEE":
                return '#FFB33E';
            case "PENDING_BY_EMPLOYER":
                return '#707070';
            case "APPROVED":
                return '#50BE64';
            case "REJECTED":
                return '#E71234';
            default:
                return '#FF0F1B';
        }
    }

    getRouteImage(item: Route, companyData: Array<Company>) {
        const currentCompany = companyData.find((company: Company) => { return company.name === item.companyName });
        if (currentCompany) {
            return currentCompany.image;
        } else {
            return defaultCompanyImage.imageString;
        }
    }

    renderRoutes(routes: Array<Route>, companyData: Array<Company>, companyDataFromUser: Array<Company>, navigation: ProfileScreenNavigationProp, userId: string, jwtToken: string) {
        const rowLen = routes.length;

        return routes.map((item: Route, i: number) => {
            if (rowLen === i + 1) {
                return (
                    <View key={item.id}>
                        <View style={[styles.routeView, { borderLeftColor: this.getStatusColor(item.statusName) }]}>
                            <TouchableWithoutFeedback onPress={() => navigation.push('Details', { item: item, companyData: companyDataFromUser, doChange: this.getRouteData, userId, jwtToken })}>
                                <Grid>
                                    <Col size={20} style={styles.routeCol}>
                                        <Image source={{ uri: this.getRouteImage(item, companyData) }} style={styles.routeViewImage} />
                                    </Col>

                                    <Col size={60} style={styles.routeCol}>
                                        <Text style={styles.routeViewInformation}>{item.date}</Text>
                                        <Text style={styles.routeViewInformation2}>{item.startTime} - {item.endTime}</Text>
                                    </Col>
                                    <Col size={20} style={styles.routeCol}>
                                        <Text>{'\u20AC'} {item.amount}</Text>
                                    </Col>
                                </Grid>
                            </TouchableWithoutFeedback>
                        </View>
                    </View>
                );
            } else {
                return (
                    <View key={item.id}>
                        <View style={[styles.routeView, { borderLeftColor: this.getStatusColor(item.statusName) }]}>
                            <TouchableWithoutFeedback onPress={() => navigation.push('Details', { item: item, companyData: companyDataFromUser, doChange: this.getRouteData, userId, jwtToken })}>
                                <Grid>
                                    <Col size={20} style={styles.routeCol}>
                                        <Image source={{ uri: this.getRouteImage(item, companyData) }} style={styles.routeViewImage} />
                                    </Col>

                                    <Col size={60} style={styles.routeCol}>
                                        <Text style={styles.routeViewInformation}>{item.date}</Text>
                                        <Text style={styles.routeViewInformation2}>{item.startTime} - {item.endTime}</Text>
                                    </Col>
                                    <Col size={20} style={styles.routeCol}>
                                        <Text>{'\u20AC'} {item.amount}</Text>
                                    </Col>
                                </Grid>
                            </TouchableWithoutFeedback>
                        </View>

                        <Dash dashGap={10} dashThickness={1} dashLength={10} dashColor={'#D0CECC'} style={{
                            height: 1, marginBottom: 10, padding: 0, marginLeft: 20,
                            marginRight: 20,
                        }} />
                    </View>
                );
            }
        });

    }

    renderButtons(navigation: ProfileScreenNavigationProp, companyData: Array<Company>, companyDataFromUser: Array<Company>, userId: string, jwtToken: string, isTracking: boolean, isAllowedToTrack: boolean) {
        var trackingButton: any;
        if (isAllowedToTrack) {
            trackingButton = (
                !isTracking ? (
                    <ActionButton.Item buttonColor='#E71234' title="Start tracking" onPress={() => this.tracker?.drivingButton()}>
                        <IconMI name="gps-fixed" style={styles.actionButtonIcon} />
                    </ActionButton.Item>
                ) : <ActionButton.Item buttonColor='#50BE64' title="End tracking" onPress={() => this.tracker?.drivingButton()}>
                        <IconMI name="gps-fixed" style={styles.actionButtonIcon} />
                    </ActionButton.Item>
            );
        } else {
            trackingButton = (
                <ActionButton.Item buttonColor='#E71234' title="Cannot track" onPress={() => null}>
                    <IconMI name="gps-fixed" style={styles.actionButtonIcon} />
                </ActionButton.Item>
            );
        }
        return (
            <ActionButton buttonColor="#E71234" size={60} style={{ elevation: 4, }} shadowStyle={{ shadowColor: "#000", shadowOffset: { width: 0, height: 1, }, shadowOpacity: 0.22, shadowRadius: 2.22, }}>
                {trackingButton}
                <ActionButton.Item buttonColor='#E71234' title="Route" style={{ elevation: 10 }} onPress={() => navigation.push('Create', { companyData: companyDataFromUser, doChange: this.getRouteData, userId, jwtToken })}>
                    <Icon name="md-create" style={styles.actionButtonIcon} />
                </ActionButton.Item>
            </ActionButton >
        );
    }

    render() {
        let navigation = this.navigation;
        var userId: string | undefined;
        var jwtToken: string | undefined;
        if (this.jwt) {
            userId = this.jwt.sub;
            jwtToken = this.jwtToken;
        }

        if (this.state.initialRoutesArray?.length && this.state.companyData?.length && this.state.companyDataFromUser?.length && userId && jwtToken) {
            var companyData = this.state.companyData;
            var companyDataFromUser = this.state.companyDataFromUser;
            var routes = this.state.initialRoutesArray;
            return (
                <SafeAreaView style={styles.safeAreaView}>
                    <ScrollView style={{ overflow: 'scroll', }}>
                        {
                            this.renderRoutes(routes, companyData, companyDataFromUser, navigation, userId, jwtToken)
                        }
                    </ScrollView>
                    {
                        this.renderButtons(navigation, companyData, companyDataFromUser, userId, jwtToken, this.state.isDriving, this.state.isAllowedToTrack)
                    }
                </SafeAreaView>
            );
        } else if (this.state.isLoading) {
            return (
                <SafeAreaView style={styles.safeAreaView}>
                    <View>
                        <Icon style={{ textAlign: 'center' }} name={'md-information-circle-outline'} size={60} />
                        <Text style={{ textAlign: 'center', margin: 8, fontSize: 32 }}>Aan het laden</Text>
                        <Text style={{ textAlign: 'center', margin: 20 }}>
                            Nog geen route informatie gevonden.
                        </Text>
                    </View>
                </SafeAreaView>
            );
        } else if (this.state.companyData?.length && this.state.companyDataFromUser?.length && userId && jwtToken) {
            var companyData = this.state.companyData;
            var companyDataFromUser = this.state.companyDataFromUser;
            return (
                <SafeAreaView style={styles.safeAreaView}>
                    <View>
                        <Icon style={{ textAlign: 'center' }} name={'md-information-circle-outline'} size={60} />
                        <Text style={{ textAlign: 'center', margin: 8, fontSize: 32 }}>Geen route informatie gevonden.</Text>
                        <Text style={{ textAlign: 'center', margin: 20 }}>
                            Er is geen route informatie gevonden.
                            Mist u data? Probeer opnieuw aan te melden of stuur een bericht naar de administrator.
                    </Text>
                    </View>
                </SafeAreaView>
            );
        }
        else {
            return (
                <SafeAreaView style={styles.safeAreaView}>
                    <View>
                        <Icon style={{ textAlign: 'center' }} name={'md-information-circle-outline'} size={60} />
                        <Text style={{ textAlign: 'center', margin: 8, fontSize: 32 }}>Geen route informatie gevonden.</Text>
                        <Text style={{ textAlign: 'center', margin: 20 }}>
                            Er is geen route informatie voor deze gebruiker gevonden.
                            Mist u data? Probeer opnieuw aan te melden of stuur een bericht naar de administrator.
                        </Text>
                    </View>
                </SafeAreaView>
            );
        }
    }
}

const styles = StyleSheet.create({
    safeAreaView: {
        backgroundColor: '#EFECEA',
        flex: 1,
        paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0
    },
    routeViewPending: {
        borderLeftColor: '#00D54E',
    },
    routeView: {
        borderLeftWidth: 5,
        height: 60,
        color: 'white',
        textAlign: 'center',
        backgroundColor: 'white',
        padding: 10,
        marginLeft: 20,
        marginRight: 20,
        borderRadius: 10,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3,
        marginBottom: 15,
    },
    routeViewImage: {
        alignSelf: 'center',
        height: 35,
        width: 35,
        resizeMode: 'contain',
    },
    routeViewInformation: {
        marginLeft: 35,
        fontWeight: 'bold'
    },
    routeViewInformation2: {
        marginLeft: 35
    },
    routeCol: {
        justifyContent: 'center',
    },
    actionButtonIcon: {
        fontSize: 20,
        height: 22,
        color: 'white',
        elevation: 4,
    },
    input: {
        height: 50,
        backgroundColor: 'white',
        shadowOffset: {
            width: 0,
            height: 1,
        },
        width: '100%',
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 6, borderRadius: 40,
    },
    filter: {
        marginTop: 10,
        fontSize: 20
    },
    filterView: {
        flex: 0,
        flexDirection: 'row',
        marginTop: -10,
        marginBottom: 20,
        marginLeft: 10,
        width: '90%'
    },
    noRouteText: {
        textAlign: 'center',
        fontSize: 20,
        fontWeight: 'bold',
        marginTop: 20,
    }
});
