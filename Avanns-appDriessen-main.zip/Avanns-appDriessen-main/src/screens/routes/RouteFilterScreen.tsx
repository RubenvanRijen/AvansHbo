import React from 'react';
import { Image, Text, View, Keyboard, StyleSheet } from 'react-native';
import { TouchableOpacity, TouchableWithoutFeedback, TextInput, ScrollView, Switch, TouchableHighlight } from 'react-native-gesture-handler';
import { Col, Row, Grid } from "react-native-easy-grid";

import Icon from 'react-native-vector-icons/FontAwesome';
import IconFA from 'react-native-vector-icons/FontAwesome';
import IconMCI from 'react-native-vector-icons/MaterialCommunityIcons';

import { StackNavigationProp } from '@react-navigation/stack';
import MultiSlider from '@ptomasroos/react-native-multi-slider';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { Company } from '../../models/ICompany';
import { Route } from '../../models/IRoute';
import { User } from '../../models/IUser';
import storage from '../../Storage';

import CompanyService from '../../services/CompanyService';
import UserService from '../../services/UserService';
import RouteService from '../../services/RouteService';

type RootStackParamList = {
    filter: undefined,
    Dashboard: any,
};

type RootStackNavigationProp = StackNavigationProp<RootStackParamList, 'filter'>;

interface State {
    distanceMin: number;
    distanceMax: number;
    distanceValues: number[];
    isDatePickerVisible: boolean,
    isTimePickerVisible: boolean,
    datePicker: number,
    timePicker: number,
    date1: string,
    date2: string,
    time1: string,
    time2: string,
    companyDataBase: Array<Company>,
    companyData: Array<Company>,
    routesArray: Array<Route>,
    routesFilteredArray: Array<Route>,
    dateEnabled: boolean,
}

interface Jwt {
    email: string,
    sub: string,
    nbf: string,
    exp: string,
    iat: string
}

interface Params {
    user: User
    jwtToken: string;
    jwt: any;
}

interface Props {
    navigation: RootStackNavigationProp;
    route: { params: Params };
}

export default class DetailScreen extends React.Component<Props, State, Params> {
    navigation: RootStackNavigationProp;
    jwtToken: string | undefined;
    jwt: any;
    params: Params;

    scrollViewEnabled: boolean = true;
    isUpdating: boolean = false;
    isUpdatingMulti: boolean = false;
    tempVar: number = 0;

    arrowState: number = 0;
    sortButtonState: number = 0;
    sortNames: string[] = ["none", "distance", "company", "date", "type"];

    distanceShow: boolean = false;
    employerShow: boolean = false;
    dateShow: boolean = false;
    typeShow: boolean = true;

    distanceMin: number = 0;
    distanceMax: number = 100;

    employerSearchText: string = '';
    selectedCompany: Company | undefined;

    routeType: string = "NONE";
    companyService: CompanyService;
    userService: UserService;
    routeService: RouteService;

    constructor(props: Props) {
        super(props);
        this.params = props.route.params;

        this.navigation = props.navigation;

        this.companyService = new CompanyService(props.navigation);
        this.userService = new UserService(props.navigation);
        this.routeService = new RouteService(props.navigation);

        this.navigation.setOptions({
            headerRight: () => {
                return <Text style={{ color: "white", fontSize: 16, marginRight: 20, fontWeight: 'bold' }}
                    onPress={() => { this.resetFilters() }}
                >Wis filters</Text>
            }
        })

        let curDate = new Date(Date.now()).toISOString();
        let date = curDate.substr(8, 2) + "-" + curDate.substr(5, 2) + "-" + curDate.substr(0, 4);
        let prevDate = new Date(Date.parse(curDate) - 30 * 24 * 60 * 60 * 1000).toISOString();
        prevDate = prevDate.substr(8, 2) + "-" + prevDate.substr(5, 2) + "-" + prevDate.substr(0, 4);

        this.state = {
            distanceMin: 0,
            distanceMax: 100,
            distanceValues: [0, 100],
            isDatePickerVisible: false,
            isTimePickerVisible: false,
            datePicker: 1,
            timePicker: 1,
            date1: prevDate,
            date2: date,
            time1: '09:00',
            time2: '17:00',
            companyDataBase: [],
            companyData: [],
            routesArray: [],
            routesFilteredArray: [],
            dateEnabled: false,
        }

        this.getRouteData();
    }

    async getCompanyInfo(): Promise<Array<Company> | undefined> {
        return this.companyService.getAll();
    }

    // TODO: Move to a service
    async getRouteInfo(): Promise<Array<Route> | undefined> {
        return this.routeService.getRoutesByUser()
            .then((responseJson) => {
                if (responseJson) {
                    let routesData: Array<Route> = responseJson.map(function (obj: Route): Route {
                        let startDT = new Date(obj.startTime);
                        let endDT = new Date(obj.endTime);
                        let duration = new Date((endDT as any) - (startDT as any));
                        let diffHours = (((duration.getDate() - 1) * 24) + duration.getUTCHours());

                        return {
                            statusName: obj.statusName,
                            date: startDT.getDate() + "-" + (startDT.getMonth() + 1) + "-" + startDT.getFullYear(),
                            startTime: startDT.getHours() + ":" + (startDT.getMinutes() < 10 ? '0' : '') + startDT.getMinutes(),
                            endTime: endDT.getHours() + ":" + (endDT.getMinutes() < 10 ? '0' : '') + endDT.getMinutes(),
                            duration: diffHours + ":" + (duration.getMinutes() < 10 ? '0' : '') + duration.getMinutes(),
                            amount: Number.parseFloat(((obj.distance / 1000) * 0.19).toFixed(2)),
                            companyName: obj.companyName,
                            id: obj.id,
                            serializedMapRoute: obj.serializedMapRoute,
                            serializedRoute: obj.serializedRoute,
                            distance: obj.distance,
                            startLocation: obj.startLocation,
                            endLocation: obj.endLocation,
                            allowanceTypeName: obj.allowanceTypeName
                        }
                    });
                    return routesData;
                }
            })
    }

    getRouteData = async () => {
        await storage.getItem(storage.jwtKey)
            .then(jwt => {
                if (jwt) {
                    this.jwtToken = jwt;
                    let base64Url = jwt.split('.')[1];
                    let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
                    let jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c: string) {
                        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
                    }).join(''));
                    this.jwt = JSON.parse(jsonPayload);
                }
            })
            .catch(error => console.error(error));

        if (this.jwt) {
            // TODO: Use services instead of own functions
            Promise.all([this.getCompanyInfo(), this.getRouteInfo()]).then((values) => {
                if (values[0] && values[1]) {
                    this.setFilterData(values[0], values[1]);
                }
            });
        }
    }

    setFilterData = async (companyData: Array<Company>, routeData: Array<Route>) => {
        let companies: Company[] = []
        let tempDistanceMin = this.distanceMin;
        let tempDistanceMax = this.distanceMax;
   
        routeData.forEach(route => {
            if (route.distance < tempDistanceMin) tempDistanceMin = route.distance;
            if (route.distance > tempDistanceMax) tempDistanceMax = route.distance;
            companyData.forEach(company => {
                if (route.companyName == company.name) {
                    if (companies.indexOf(company) == -1) {
                        companies.push(company)
                    }
                }
            });
        });

        this.distanceMin = Math.ceil((tempDistanceMin / 1000));
        this.distanceMax = Math.ceil((tempDistanceMax / 1000));

        await this.setState({
            routesArray: routeData,
            distanceValues: [this.distanceMin, this.distanceMax], distanceMin: this.distanceMin, distanceMax: this.distanceMax,
            companyDataBase: companies, companyData: companies
        })

        this.forceUpdate();

    }

    resetFilters() {
        this.scrollViewEnabled = true;
        this.isUpdating = false;
        this.isUpdatingMulti = false;
        this.tempVar = 0;
        this.arrowState = 0;
        this.sortButtonState = 0;
        this.distanceShow = false;
        this.employerShow = false;
        this.dateShow = false;
        this.typeShow = true;
        this.distanceMin = 0;
        this.distanceMax = 100;
        this.employerSearchText = '';
        this.selectedCompany = undefined;
        this.routeType = "NONE";

        let curDate = new Date(Date.now()).toISOString();
        let date = curDate.substr(8, 2) + "-" + curDate.substr(5, 2) + "-" + curDate.substr(0, 4);

        this.setState({
            distanceMin: 0,
            distanceMax: 100,
            distanceValues: [0, 100],
            isDatePickerVisible: false,
            isTimePickerVisible: false,
            datePicker: 1,
            timePicker: 1,
            date1: date,
            date2: date,
            time1: '09:00',
            time2: '17:00',
            companyDataBase: [],
            companyData: [],
            routesArray: [],
            dateEnabled: false,
            routesFilteredArray: []
        })

        this.getRouteData();
    }

    enableScroll = (type: string) => {
        this.scrollViewEnabled = true;
        switch (type) {
            case 'distance':
                this.setState({ distanceMin: this.state.distanceValues[0], distanceMax: this.state.distanceValues[1] })
                break;
            case 'employer':
                break;
            case 'date':
                break;
            case 'type':
                break;
            default:
                break;
        }
        this.forceUpdate();
    }

    disableScroll = () => {
        this.scrollViewEnabled = false;
    }

    changeSort(type: number) {
        if (this.sortButtonState != type) {
            this.arrowState = 1;
        } else {
            if (this.arrowState == 1) {
                this.arrowState = 2;
            } else if (this.arrowState == 2) {
                this.arrowState = 0;
                this.sortButtonState = 0;
                this.forceUpdate();
                return;
            } else {
                this.arrowState = 1;
            }
        }
        this.sortButtonState = type;
        this.forceUpdate();
    }

    changeVisibility(type: string) {
        switch (type) {
            case 'distance':
                this.distanceShow ? this.distanceShow = false : this.distanceShow = true;
                break;
            case 'employer':
                this.employerShow ? this.employerShow = false : this.employerShow = true;
                break;
            case 'date':
                this.dateShow ? this.dateShow = false : this.dateShow = true;
                break;
            case 'type':
                this.typeShow ? this.typeShow = false : this.typeShow = true;
                break;
            default:
                break;
        }
        this.forceUpdate();
    }

    renderTypeSort() {
        return (
            <View style={styles.flexColumn}>
                <View style={styles.sortBox}>
                    <View style={[styles.flexRow, styles.typeHeader]}>
                        <Text style={styles.filterTypeTitle}>Sorteer op</Text>
                    </View>
                    <View style={styles.flexRow}>
                        <TouchableWithoutFeedback style={[styles.sortButton, styles.flexRow, this.sortButtonState == 1 ? styles.sortPressed : null]} onPress={() => this.changeSort(1)}>
                            <Text style={[styles.sortText, this.sortButtonState == 1 ? styles.sortPressedText : null]}>Afstand</Text>
                            <Icon name="long-arrow-down" style={[styles.arrowIcon, this.sortButtonState == 1 && this.arrowState == 1 ? null : styles.invisible]} />
                            <Icon name="long-arrow-up" style={[styles.arrowIcon, this.sortButtonState == 1 && this.arrowState == 2 ? null : styles.invisible]} />
                        </TouchableWithoutFeedback>
                        <TouchableWithoutFeedback style={[styles.sortButton, styles.flexRow, this.sortButtonState == 2 ? styles.sortPressed : null]} onPress={() => this.changeSort(2)}>
                            <Text style={[styles.sortText, this.sortButtonState == 2 ? styles.sortPressedText : null]}>Werkgever</Text>
                            <Icon name="long-arrow-down" style={[styles.arrowIcon, this.sortButtonState == 2 && this.arrowState == 1 ? null : styles.invisible]} />
                            <Icon name="long-arrow-up" style={[styles.arrowIcon, this.sortButtonState == 2 && this.arrowState == 2 ? null : styles.invisible]} />
                        </TouchableWithoutFeedback>
                        <TouchableWithoutFeedback style={[styles.sortButton, styles.flexRow, this.sortButtonState == 3 ? styles.sortPressed : null]} onPress={() => this.changeSort(3)}>
                            <Text style={[styles.sortText, this.sortButtonState == 3 ? styles.sortPressedText : null]}>Datum</Text>
                            <Icon name="long-arrow-down" style={[styles.arrowIcon, this.sortButtonState == 3 && this.arrowState == 1 ? null : styles.invisible]} />
                            <Icon name="long-arrow-up" style={[styles.arrowIcon, this.sortButtonState == 3 && this.arrowState == 2 ? null : styles.invisible]} />
                        </TouchableWithoutFeedback>
                        <TouchableWithoutFeedback style={[styles.sortButton, styles.flexRow, this.sortButtonState == 4 ? styles.sortPressed : null]} onPress={() => this.changeSort(4)}>
                            <Text style={[styles.sortText, this.sortButtonState == 4 ? styles.sortPressedText : null]}>Route Type</Text>
                            <Icon name="long-arrow-down" style={[styles.arrowIcon, this.sortButtonState == 4 && this.arrowState == 1 ? null : styles.invisible]} />
                            <Icon name="long-arrow-up" style={[styles.arrowIcon, this.sortButtonState == 4 && this.arrowState == 2 ? null : styles.invisible]} />
                        </TouchableWithoutFeedback>
                    </View>
                </View>
            </View>
        )
    }

    renderDistance() {
        return (
            <View style={styles.flexColumn}>
                <View style={[styles.flexRow, styles.headerBox]}>
                    <Text style={styles.headerText}>Afstand</Text>
                    <TouchableWithoutFeedback onPress={() => this.changeVisibility('distance')}>
                        <Icon name="chevron-up" style={[styles.headerIcon, this.distanceShow ? null : styles.invisible]} />
                        <Icon name="chevron-down" style={[styles.headerIcon, this.distanceShow ? styles.invisible : null]} />
                    </TouchableWithoutFeedback>
                </View>
                <View style={[styles.flexRow, this.distanceShow ? null : styles.invisible]}>
                    <View style={[styles.flexColumn, styles.inputNumberBox]}>
                        <Text style={styles.inputNumberText}>Km</Text>
                        <TextInput
                            style={styles.inputNumber}
                            keyboardType="numeric"
                            onChangeText={value => this.changeDistanceValue(value, 'min')}
                            value={this.state.distanceMin.toString()}
                        />
                    </View>

                    <View style={styles.sliderBox}>
                        <MultiSlider
                            allowOverlap={false}
                            min={this.distanceMin}
                            max={this.distanceMax}
                            onValuesChangeStart={this.disableScroll}
                            onValuesChangeFinish={() => this.enableScroll('distance')}
                            onValuesChange={(values: number[]) => this.setState({ distanceValues: values })}
                            enabledOne={true}
                            enabledTwo={true}
                            sliderLength={200}
                            isMarkersSeparated={true}
                            values={this.state.distanceValues}
                            markerStyle={{ backgroundColor: '#E71234', height: 20, width: 20, marginTop: 5 }}
                            selectedStyle={{ backgroundColor: '#E71234' }}
                            unselectedStyle={{ backgroundColor: '#f8a0af' }}
                            trackStyle={{ height: 7, borderRadius: 5 }}
                        />
                    </View>

                    <View style={[styles.flexColumn, styles.inputNumberBox]}>
                        <Text style={styles.inputNumberText}>Km</Text>
                        <TextInput
                            style={styles.inputNumber}
                            keyboardType="numeric"
                            onChangeText={(value) => this.changeDistanceValue(value, 'max')}
                            value={this.state.distanceMax.toString()}
                        />
                    </View>
                </View>
            </View>
        )
    }

    changeDistanceValue(value: string, type: string) {
        this.tempVar = Number.parseInt(value.replace(/[- #*;,.<>\{\}\[\]\\\/]/gi, ''));
        if (this.tempVar.toString() == "NaN") this.tempVar = 0;
        if (type == 'min') {
            if (this.tempVar < this.distanceMin) this.tempVar = this.distanceMin;
            if (this.tempVar >= this.state.distanceMax) this.tempVar = (this.state.distanceMax - 1);
            this.setState({ distanceMin: this.tempVar, distanceValues: [this.tempVar, this.state.distanceValues[1]] })
            this.forceUpdate();
        } else if (type == 'max') {
            if (this.tempVar > this.distanceMax) this.tempVar = this.distanceMax;
            if (this.tempVar <= this.state.distanceMin) this.tempVar = (this.state.distanceMin + 1);
            this.setState({ distanceMax: this.tempVar, distanceValues: [this.state.distanceValues[0], this.tempVar] })
            this.forceUpdate();
        }
    }

    renderCompanies() {
        return (
            <View style={styles.flexColumn}>
                <View style={[styles.flexRow, styles.headerBox]}>
                    <Text style={styles.headerText}>Werkgevers</Text>
                    <TouchableWithoutFeedback onPress={() => this.changeVisibility('employer')}>
                        <Icon name="chevron-up" style={[styles.headerIcon, this.employerShow ? null : styles.invisible]} />
                        <Icon name="chevron-down" style={[styles.headerIcon, this.employerShow ? styles.invisible : null]} />
                    </TouchableWithoutFeedback>
                </View>
                <View style={[styles.flexColumn, this.employerShow ? null : styles.invisible]}>
                    <View style={styles.employerBase}>
                        <View style={[styles.flexRow, styles.employerBox]}>
                            <Icon name="search" style={styles.employerIcon} />
                            <TextInput placeholder="Zoek naar werkgevers" onChangeText={(value) => this.employerSearchText = value} onEndEditing={() => this.filterCompanies()} />
                        </View>
                    </View>
                    {
                        this.renderCompany()
                    }
                </View>
            </View>
        )
    }

    renderCompany() {
        return this.state.companyData.map((company: Company) => {
            let bool: boolean = this.selectedCompany == company;
            return (
                <View style={[styles.flexRow, styles.companyBox, bool ? null : styles.companyOff]}>
                    <Grid style={{ display: "flex", alignItems: "center" }}>
                        <Col size={1} >
                            <Image source={{ uri: company.image }} style={styles.companyImage} />
                        </Col>
                        <Col size={3} >
                            <Text style={styles.companyName}>{company.name}</Text>
                        </Col>
                        <Col size={1} >
                            <Switch
                                trackColor={{ false: "#767577", true: "#5ed4a7" }}
                                thumbColor={bool ? "#00b300" : "#f4f3f4"}
                                ios_backgroundColor="#3e3e3e"
                                onValueChange={(value) => this.changeCompany(company, value)}
                                value={bool}
                            />
                        </Col>
                    </Grid>
                </View>
            )
        });
    }

    changeCompany(company: Company, value: boolean) {
        if (!value) {
            this.selectedCompany = undefined
        } else {
            this.selectedCompany = company;
        }
        this.forceUpdate();
    }

    filterCompanies = async () => {
        let tempCompanies: Company[] = []
        this.state.companyDataBase.forEach(company => {
            if (company.name.toLocaleLowerCase().includes(this.employerSearchText.toLocaleLowerCase())) {
                tempCompanies.push(company)
            }
        });
        await this.setState({ companyData: tempCompanies });
        this.forceUpdate();
    }

    renderDate() {
        return (
            <View style={styles.flexColumn}>
                <View style={[styles.flexRow, styles.headerBox]}>
                    <Text style={styles.headerText}>Datum</Text>
                    <TouchableWithoutFeedback onPress={() => this.changeVisibility('date')}>
                        <Icon name="chevron-up" style={[styles.headerIcon, this.dateShow ? null : styles.invisible]} />
                        <Icon name="chevron-down" style={[styles.headerIcon, this.dateShow ? styles.invisible : null]} />
                    </TouchableWithoutFeedback>
                </View>

                <View style={this.dateShow ? null : styles.invisible}>
                    <View style={[styles.flexRow, styles.disableDate]}>
                        <Text style={styles.disableDateText}>Filter op datum</Text>
                        <Switch
                            trackColor={{ false: "#767577", true: "#5ed4a7" }}
                            thumbColor={this.state.dateEnabled ? "#00b300" : "#f4f3f4"}
                            ios_backgroundColor="#3e3e3e"
                            onValueChange={(value) => this.setState({ dateEnabled: value })}
                            value={this.state.dateEnabled}
                        />
                    </View>
                    <DateTimePickerModal
                        isVisible={this.state.isDatePickerVisible}
                        mode="date"
                        date={new Date()}
                        locale="nl_NL"
                        cancelTextIOS="Annuleren"
                        confirmTextIOS="Ok"
                        headerTextIOS="Kies een datum"
                        onConfirm={this.handleConfirmDay.bind(this)}
                        onCancel={this.hideDatePicker.bind(this)}
                    />
                    <DateTimePickerModal
                        isVisible={this.state.isTimePickerVisible}
                        mode="time"
                        is24Hour={true}
                        locale="nl_NL"
                        cancelTextIOS="Annuleren"
                        confirmTextIOS="Ok"
                        headerTextIOS="Kies een tijd"
                        onConfirm={this.handleConfirmTime.bind(this)}
                        onCancel={this.hideTimePicker.bind(this)}
                    />
                    <View style={[styles.flexColumn, this.state.dateEnabled ? null : styles.invisible]}>
                        <Text style={styles.dateTitle}>Vanaf</Text>
                        <View style={styles.inputDateBox}>
                            <TextInput placeholder="Start Datum" style={[styles.textInput, styles.borderRightNone]} value={this.state.date1}
                                onFocus={() => { Keyboard.dismiss(), this.setState({ datePicker: 1, isDatePickerVisible: true }) }} />
                            <View style={styles.dashBack}>
                                <View style={styles.dash}></View>
                            </View>
                            <TextInput placeholder="Start Tijd" style={[styles.textInput, styles.borderLeftNone]} value={this.state.time1}
                                onFocus={() => { Keyboard.dismiss(), this.setState({ timePicker: 1, isTimePickerVisible: true }) }} />
                        </View>
                        <Text style={styles.dateTitle}>Tot</Text>
                        <View style={styles.inputDateBox}>
                            <TextInput placeholder="Eind Datum" style={[styles.textInput, styles.borderRightNone]} value={this.state.date2}
                                onFocus={() => { Keyboard.dismiss(), this.setState({ datePicker: 2, isDatePickerVisible: true }) }} />
                            <View style={styles.dashBack}>
                                <View style={styles.dash}></View>
                            </View>
                            <TextInput placeholder="Eind Tijd" style={[styles.textInput, styles.borderLeftNone]} value={this.state.time2}
                                onFocus={() => { Keyboard.dismiss(), this.setState({ timePicker: 2, isTimePickerVisible: true }) }} />
                        </View>
                    </View>
                </View>
            </View>
        )
    }

    handleConfirmTime(date: Date) {
        let hours = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
        let minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
        if (this.state.timePicker == 1) {
            this.setState({ time1: hours + ":" + minutes, isTimePickerVisible: false })
        } else if (this.state.timePicker == 2) {
            this.setState({ time2: hours + ":" + minutes, isTimePickerVisible: false })
        }
    };

    handleConfirmDay(date: Date) {
        if (this.state.datePicker == 1) {
            this.setState({ date1: date.getDate() + "-" + (date.getMonth() + 1) + "-" + date.getFullYear(), isDatePickerVisible: false })
        } else if (this.state.datePicker == 2) {
            this.setState({ date2: date.getDate() + "-" + (date.getMonth() + 1) + "-" + date.getFullYear(), isDatePickerVisible: false })
        }
    };

    hideDatePicker() {
        this.setState({ isDatePickerVisible: false });
    };

    hideTimePicker() {
        this.setState({ isTimePickerVisible: false });
    };

    renderType() {
        let homeToWorkButtonColor = "#707070";
        let workButtonColor = "#707070";
        let noneButtonColor = "#707070";

        switch (this.routeType) {
            case "HOME_TO_WORK":
                homeToWorkButtonColor = "#FF3719";
                break;
            case "WORK":
                workButtonColor = "#FF3719";
                break;
            default: noneButtonColor = "#FF3719";
                break;
        }
        return (
            <View style={styles.flexColumn}>
                <View style={[styles.flexRow, styles.headerBox]}>
                    <Text style={styles.headerText}>Route Type</Text>
                    <TouchableWithoutFeedback onPress={() => this.changeVisibility('type')}>
                        <Icon name="chevron-up" style={[styles.headerIcon, this.typeShow ? null : styles.invisible]} />
                        <Icon name="chevron-down" style={[styles.headerIcon, this.typeShow ? styles.invisible : null]} />
                    </TouchableWithoutFeedback>
                </View>

                <View style={this.typeShow ? null : styles.invisible}>
                    <View style={{ alignItems: "center", marginTop: 20 }}>
                        <Row style={styles.typeRoutes}>
                            <Col size={1}>
                                <TouchableOpacity style={styles.typeRoutesButton} onPress={() => { this.selectType('HOME_TO_WORK') }}>
                                    <IconFA name="home" size={50} color={homeToWorkButtonColor} />
                                    <Text style={{ fontSize: 13, textAlign: "center", color: homeToWorkButtonColor }}>woon- werkverkeer</Text>
                                </TouchableOpacity>
                            </Col>
                            <Text style={{ borderColor: "#CFCFCF", borderWidth: 1, height: "80%", }}></Text>
                            <Col size={1}>
                                <TouchableOpacity style={styles.typeRoutesButton} onPress={() => { this.selectType('NONE') }}>
                                    <Icon name="plus" size={50} color={noneButtonColor} />
                                    <Text style={{ fontSize: 13, textAlign: "center", color: noneButtonColor }}>beide</Text>
                                </TouchableOpacity>
                            </Col>
                            <Text style={{ borderColor: "#CFCFCF", borderWidth: 1, height: "80%", }}></Text>
                            <Col size={1}>
                                <TouchableOpacity style={styles.typeRoutesButton} onPress={() => { this.selectType('WORK') }}>
                                    <IconMCI name="briefcase" size={50} color={workButtonColor} />
                                    <Text style={{ fontSize: 13, textAlign: "center", color: workButtonColor }}>dienstreizen</Text>
                                </TouchableOpacity>
                            </Col>
                        </Row>
                    </View>
                </View>
            </View>
        )
    }

    selectType(type: string) {
        this.routeType = type;
        this.forceUpdate();
    }

    filterRoutes = async () => {
        // TODO: Change to env
        let filters: string[] = []

        let minDistance = "MinDistance=" + (this.state.distanceMin * 1000).toString();
        filters.push(minDistance);

        let maxDistance = "MaxDistance=" + (this.state.distanceMax * 1000).toString();
        filters.push(maxDistance);

        if (this.selectedCompany != undefined) {
            let company = "Company=" + this.selectedCompany.name;
            filters.push(company);
        }

        if (this.state.dateEnabled) {
            let startDate = this.state.date1
            let startDay = startDate.split('-')[0];
            if (startDay.length == 1) startDay = "0" + startDay
            let startMonth = startDate.split('-')[1];
            if (startMonth.length == 1) startMonth = "0" + startMonth
            let startTime = this.state.time1
            if (startTime.length == 4) startTime = "0" + startTime;
            startDate = "StartDate=" + startDate.split("-")[2] + "-" + startMonth + "-" + startDay + "T" + startTime + ":00.000000"
            filters.push(startDate);

            let endDate = this.state.date2

            let endDay = endDate.split('-')[0];
            if (endDay.length == 1) endDay = "0" + endDay
            let endMonth = endDate.split('-')[1];
            if (endMonth.length == 1) endMonth = "0" + endMonth
            let endTime = this.state.time2
            if (endTime.length == 4) endTime = "0" + endTime;
            endDate = "EndDate=" + endDate.split("-")[2] + "-" + endMonth + "-" + endDay + "T" + endTime + ":00.000000"
            filters.push(endDate);
        }

        if (this.routeType != "NONE") {
            let routeType = "RouteType=" + this.routeType;
            filters.push(routeType);
        }

        let fetchUri = "";

        filters.forEach(value => {
            if (value.startsWith("MinDistance")) {
                fetchUri += value
            } else {
                fetchUri += "&" + value
            }
        });

        let responseJson = await this.userService.get(this.jwt?.sub);        

        this.props.navigation.push("Dashboard", { screen: "Routes", params: { screen: "Routes", params: { jwt: this.jwt, jwtToken: this.jwtToken, sortName: this.sortNames[this.sortButtonState], sortDirection: this.arrowState.toString(), filterString: fetchUri, user: responseJson } } });
    }

    render() {
        return (
            <ScrollView style={styles.flexColumn} enabled={this.scrollViewEnabled}>
                {
                    this.renderTypeSort()
                }
                <View style={[styles.flexRow, styles.typeHeader]}>
                    <Text style={styles.filterTypeTitle}>Filter op</Text>
                </View>
                {
                    this.renderDistance()
                }
                {
                    this.renderCompanies()
                }
                {
                    this.renderDate()
                }
                {
                    this.renderType()
                }
                <View style={styles.buttonBox}>
                    <TouchableOpacity onPress={() => this.filterRoutes()}>
                        <Text style={styles.button} >Filter</Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>)
    }
}

const styles = StyleSheet.create({
    typeRoutes: {
        width: "80%",
        height: 100,
        alignItems: "center",
        borderRadius: 10,
        backgroundColor: "white",
        overflow: "hidden",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3,
        marginBottom: 10,
    },
    typeRoutesButton: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "white",
        height: "100%",
        marginHorizontal: 10
    },
    flexRow: {
        display: 'flex',
        flexDirection: 'row'
    },
    flexColumn: {
        display: 'flex',
        flexDirection: 'column'
    },
    invisible: {
        display: 'none',
    },
    typeHeader: {
        marginTop: -10,
        justifyContent: "center"
    },
    // resetBox: {
    //     padding: 10,
    //     backgroundColor: '#E71234',
    //     margin: 5,
    //     marginTop: -10,
    //     marginRight: -22,
    //     borderBottomLeftRadius: 5,
    // },
    // resetText: {
    //     color: 'white',
    //     fontSize: 15,
    //     fontWeight: 'bold'
    // },
    arrowIcon: {
        fontSize: 20,
        marginTop: 3,
        marginRight: 5,
        color: 'white'
    },
    filterTypeTitle: {
        color: '#666',
        fontWeight: 'bold',
        padding: 5,
        margin: 5,
        fontSize: 15,
    },
    sortText: {
        margin: 5,
        fontSize: 15,
    },
    sortButton: {
        borderColor: '#ccc',
        backgroundColor: 'white',
        borderWidth: 1,
        height: 50,
        alignItems: 'center',
    },
    sortBox: {
        alignItems: 'center',
        margin: 20,
    },
    sortPressed: {
        backgroundColor: '#E71234',
    },
    sortPressedText: {
        color: 'white',
    },
    headerBox: {
        margin: 20,
        borderBottomWidth: 2,
        borderBottomColor: '#999',
        marginBottom: 5,
    },
    headerText: {
        fontSize: 15,
        color: 'gray',
        width: '25%',
    },
    headerIcon: {
        justifyContent: 'flex-end',
        marginLeft: 260,
        fontSize: 20,
        color: '#999'
    },
    inputNumber: {
        fontSize: 20,
        padding: 10,
        borderColor: '#ccc',
        elevation: 2,
        backgroundColor: 'white',
        color: '#999',
        fontWeight: 'bold',
        width: 65,
        textAlign: 'center'
    },
    inputNumberText: {
        color: '#999',
    },
    inputNumberBox: {
        marginLeft: 20,
        alignItems: 'center',
    },
    sliderBox: {
        marginLeft: 20,
        marginRight: 0,
        marginTop: 15
    },
    textInput: {
        borderColor: 'gray',
        backgroundColor: 'white',
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 6,
        width: 175,
        height: 100,
        padding: 20,
        fontSize: 25,
        borderRadius: 10,
        textAlign: 'center',
    },
    dateTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        borderBottomColor: '#555',
        borderBottomWidth: 1,
        margin: 15,
        marginLeft: 40,
        marginRight: 45,
    },
    inputDateBox: {
        flexDirection: 'row',
        margin: 10,
        marginLeft: 40,
    },
    borderLeftNone: {
        borderTopLeftRadius: 0,
        borderBottomLeftRadius: 0,
        borderLeftColor: 'white',
    },
    borderRightNone: {
        borderTopRightRadius: 0,
        borderBottomRightRadius: 0,
        borderRightColor: 'white',
    },
    dash: {
        width: 2,
        height: 80,
        backgroundColor: '#ccc',
        marginTop: 10,
    },
    dashBack: {
        width: 2,
        height: 100,
        backgroundColor: 'white',
        elevation: 6,
    },
    disableDate: {
        borderRadius: 10,
        backgroundColor: 'white',
        elevation: 6,
        margin: 10,
        marginLeft: 30,
        marginRight: 30,
    },
    disableDateText: {
        margin: 15,
        fontSize: 20,
        width: '75%',
    },

    // employer/companies
    employerBox: {
        backgroundColor: 'white',
        width: '95%',
        height: 40,
        fontSize: 20,
        textAlign: 'center',
        borderBottomColor: 'gray',
        borderBottomWidth: 2,
        padding: 10,
        margin: 10,
    },
    employerBase: {
        backgroundColor: 'white',
        width: '90%',
        height: 60,
        margin: 10,
        marginLeft: 20,
        elevation: 6,
        borderRadius: 5,
    },
    employerIcon: {
        color: '#999',
        fontSize: 25,
        marginRight: 10,
        marginTop: -7
    },
    companyBox: {
        backgroundColor: 'white',
        width: '90%',
        height: 60,
        margin: 5,
        marginLeft: 20,
        elevation: 6,
        borderRadius: 5,
    },
    companyImage: {
        alignSelf: 'center',
        height: 35,
        width: 35,
        resizeMode: 'contain',
        margin: 5,
        marginLeft: 15,
    },
    companyName: {
        color: '#999',
        margin: 15,
        fontSize: 20,
    },
    companyOff: {
        backgroundColor: 'gray'
    },
    button: {
        backgroundColor: '#E71234',
        width: 300,
        height: 40,
        textAlign: "center",
        color: 'white',
        borderRadius: 10,
        justifyContent: 'center',
        padding: 10,
    },
    buttonBox: {
        margin: 10,
        alignItems: 'center',
        marginTop: 30,
    }
});
