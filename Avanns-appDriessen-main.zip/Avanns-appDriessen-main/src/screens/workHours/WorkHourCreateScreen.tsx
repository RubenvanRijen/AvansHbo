import React from 'react';
import { Button, Text, TextInput, Keyboard, View, SafeAreaView, StyleSheet } from 'react-native';

import DateTimePickerModal from "react-native-modal-datetime-picker";
import { StackNavigationProp } from '@react-navigation/stack';
import { WorkHour } from '../../models/IWorkHour';
import IconI from 'react-native-vector-icons/Ionicons';
import uuid from 'react-native-uuid';

import { Holiday } from '../../models/IHoliday';
import { TouchableWithoutFeedback, TouchableOpacity, Switch } from 'react-native-gesture-handler';

import WorkHourService from '../../services/WorkHourService';
import HolidayService from '../../services/HolidayService';

type RootStackParamList = {
    WorkHours: undefined,
    WorkHoursDetail: { item: WorkHour, doChange: () => void },
    WorkHoursCreate: { doChange: () => void },
};

type RootStackNavigationProp = StackNavigationProp<RootStackParamList, 'WorkHoursDetail'>;

interface Params {
    doChange(): () => void;
    hour: WorkHour;
    holiday: Holiday;
    userId: string;
    jwtToken: string;
}

interface Props {
    navigation: RootStackNavigationProp;
    route: {
        params: {
            doChange(): () => void
            hour: WorkHour;
            holiday: Holiday;
            userId: string;
            jwtToken: string;
        }
    }
}

interface State {
    isDatePickerVisible: boolean,
    isTimePickerVisible: boolean,
    params: Params,
    datePicker: number,
    timePicker: number,
    date1: string,
    date2: string,
    time1: string,
    time2: string,
    dateError: string,
    timeError: string,
    fieldError: string,
}

export default class WorkHoursDetailScreen extends React.Component<Props, State, Params>  {
    // jwt: Jwt | undefined;
    // rawJwt: string = "";
    error: boolean = false;
    isRepeat: boolean = false;
    touchedFree: boolean = false;
    touchedWork: boolean = true;
    monthsEN: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    ENDDATE_BEFORE_STARTDATE_VALIDATION_ERROR = "Eind datum na begin datum";
    ENDTIME_BEFORE_STARTTIME_VALIDATION_ERROR = "Eind tijd na begin tijd";
    ENDTIME_EQUALS_STARTTIME_VALIDATION_ERROR = "Eind tijd is hetzelfde als begin tijd";
    NOT_ALL_FIELDS_FILLED = "Vul alle velden!";
    workHourService: WorkHourService;
    holidayService: HolidayService;

    constructor(props: Props) {
        super(props);

        this.workHourService = new WorkHourService(props.navigation);
        this.holidayService = new HolidayService(props.navigation);

        this.state = {
            isDatePickerVisible: false,
            isTimePickerVisible: false,
            params: props.route.params,
            datePicker: 1,
            timePicker: 1,
            date1: "",
            date2: "",
            time1: '08:30',
            time2: '17:00',
            dateError: "",
            timeError: "",
            fieldError: "",
        };
    }

    handleConfirmTime(date: Date) {
        let hours = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
        let minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
        if (this.state.timePicker == 1) {
            this.setState({ time1: hours + ":" + minutes, isTimePickerVisible: false })
        } else if (this.state.timePicker == 2) {
            this.setState({ time2: hours + ":" + minutes, isTimePickerVisible: false })
        }
    };

    handleConfirmDay(date: Date) {
        if (this.state.datePicker == 1) {
            if (this.touchedWork) {
                this.setState({ date1: date.getDate() + "-" + (date.getMonth() + 1) + "-" + date.getFullYear(), isDatePickerVisible: false })
            } else {
                this.setState({ date1: date.getDate() + "-" + (date.getMonth() + 1) + "-" + date.getFullYear(), date2: date.getDate() + "-" + (date.getMonth() + 1) + "-" + date.getFullYear(), isDatePickerVisible: false })
            }
        } else if (this.state.datePicker == 2) {
            this.setState({ date2: date.getDate() + "-" + (date.getMonth() + 1) + "-" + date.getFullYear(), isDatePickerVisible: false })
        }
    };

    hideDatePicker() {
        this.setState({ isDatePickerVisible: false });
    };

    hideTimePicker() {
        this.setState({ isTimePickerVisible: false });
    };

    saveDate = () => {
        this.setState({ fieldError: "" });
        this.error = false;
        if (this.touchedWork) {
            if (this.state.date1 == '' || this.state.date2 == '' || this.state.time1 == '' || this.state.time2 == '') {
                this.error = true;
                this.setState({ fieldError: this.NOT_ALL_FIELDS_FILLED })
                return;
            }
            this.setState({ fieldError: "" });

            let startYear = this.state.date1.split('-')[2];
            let startMonth = this.state.date1.split('-')[1];
            if (startMonth.length == 1) startMonth = "0" + startMonth;
            let startDay = this.state.date1.split('-')[0];
            if (startDay.length == 1) startDay = "0" + startDay;
            let startDate = Date.parse(startYear + "-" + startMonth + "-" + startDay);
            let startDateTime = Date.parse(startYear + "-" + startMonth + "-" + startDay + "T" + this.state.time1 + ":00");
            let startDT = startYear + "-" + startMonth + "-" + startDay + "T" + this.state.time1 + ":00.000Z";

            let endYear = this.state.date2.split('-')[2];
            let endMonth = this.state.date2.split('-')[1];
            if (endMonth.length == 1) endMonth = "0" + endMonth;
            let endDay = this.state.date2.split('-')[0];
            if (endDay.length == 1) endDay = "0" + endDay;
            let endDate = Date.parse(endYear + "-" + endMonth + "-" + endDay);
            let endDateTime = Date.parse(startYear + "-" + startMonth + "-" + startDay + "T" + this.state.time2 + ":00");
            let endDT = endYear + "-" + endMonth + "-" + endDay + "T" + this.state.time2 + ":00.000Z";


            if (endDate < startDate) {
                this.error = true;
                this.setState({ dateError: this.ENDDATE_BEFORE_STARTDATE_VALIDATION_ERROR })
            } else if (this.state.dateError == this.ENDDATE_BEFORE_STARTDATE_VALIDATION_ERROR) { this.setState({ dateError: "" }) }

            if (endDateTime < startDateTime) {
                this.error = true;
                this.setState({ timeError: this.ENDTIME_BEFORE_STARTTIME_VALIDATION_ERROR })
            } else if (this.state.timeError == this.ENDTIME_BEFORE_STARTTIME_VALIDATION_ERROR) { this.setState({ timeError: "" }) }

            if (endDateTime == startDateTime) {
                this.error = true;
                this.setState({ timeError: this.ENDTIME_EQUALS_STARTTIME_VALIDATION_ERROR })
            } else if (this.state.timeError == this.ENDTIME_EQUALS_STARTTIME_VALIDATION_ERROR) { this.setState({ timeError: "" }) }

            if (this.error) {
                return;
            } else {
                if (startDate != endDate) {
                    if (this.isRepeat) {
                        let tempDateStart = new Date(startDT);
                        let tempDateEnd = new Date(startYear + "-" + startMonth + "-" + startDay + "T" + this.state.time2 + ":00");
                        let tempEndDate = new Date(endDT);
                        while (Date.parse(tempDateStart.toString()) < Date.parse(tempEndDate.toString())) {
                            this.workHourService.create({
                                userId: this.state.params.userId,
                                startDateTime: tempDateStart,
                                endDateTime: tempDateEnd,
                                id: uuid.v1(),
                            });

                            tempDateStart = new Date(Date.parse(tempDateStart.toString()) + 24 * 60 * 60 * 1000);
                            tempDateEnd = new Date(Date.parse(tempDateEnd.toString()) + 24 * 60 * 60 * 1000);
                        }
                        this.state.params.doChange();
                        this.props.navigation.goBack()
                    } else {
                        let startDateRepeat = new Date(startDT);
                        let startDateZero = new Date(startYear + "-" + startMonth + "-" + startDay + "T00:00:00");
                        let endDateZero = new Date(startYear + "-" + startMonth + "-" + startDay + "T23:59:00");
                        let endDateRepeat = new Date(endDT);

                        this.workHourService.create({
                            userId: this.state.params.userId,
                            startDateTime: startDateRepeat,
                            endDateTime: endDateZero,
                            id: uuid.v1(),
                        });

                        startDateZero = new Date(Date.parse(startDateZero.toString()) + 24 * 60 * 60 * 1000);
                        endDateZero = new Date(Date.parse(endDateZero.toString()) + 24 * 60 * 60 * 1000);

                        while (Date.parse(endDateZero.toString()) < Date.parse(endDateRepeat.toString())) {
                            this.workHourService.create({
                                userId: this.state.params.userId,
                                startDateTime: startDateZero,
                                endDateTime: endDateZero,
                                id: uuid.v1(),
                            });

                            startDateZero = new Date(Date.parse(startDateZero.toString()) + 24 * 60 * 60 * 1000);
                            endDateZero = new Date(Date.parse(endDateZero.toString()) + 24 * 60 * 60 * 1000);
                        }

                        this.workHourService.create({
                            userId: this.state.params.userId,
                            startDateTime: startDateZero,
                            endDateTime: endDateRepeat,
                            id: uuid.v1(),
                        }).then(() => { this.state.params.doChange(), this.props.navigation.goBack() });
                    }

                } else {
                    this.workHourService.create({
                        userId: this.state.params.userId,
                        startDateTime: startDT,
                        endDateTime: endDT,
                        id: uuid.v1(),
                    }).then(() => { this.state.params.doChange(), this.props.navigation.goBack() });
                }
            }
        } else if (this.touchedFree) {
            if (this.state.date1 == '' || this.state.date2 == '') {
                this.error = true;
                this.setState({ fieldError: this.NOT_ALL_FIELDS_FILLED })
                return;
            }
            this.setState({ fieldError: "" });

            let startYear = this.state.date1.split('-')[2];
            let startMonth = this.state.date1.split('-')[1];
            if (startMonth.length == 1) startMonth = "0" + startMonth;
            let startDay = this.state.date1.split('-')[0];
            if (startDay.length == 1) startDay = "0" + startDay;
            let startDate = Date.parse(startYear + "-" + startMonth + "-" + startDay);
            let startDT = startYear + "-" + startMonth + "-" + startDay + "T00:00:00";

            let endYear = this.state.date2.split('-')[2];
            let endMonth = this.state.date2.split('-')[1];
            if (endMonth.length == 1) endMonth = "0" + endMonth;
            let endDay = this.state.date2.split('-')[0];
            if (endDay.length == 1) endDay = "0" + endDay;
            let endDate = Date.parse(endYear + "-" + endMonth + "-" + endDay);

            if (endDate < startDate) {
                this.error = true;
                this.setState({ timeError: this.ENDTIME_BEFORE_STARTTIME_VALIDATION_ERROR })
            } else if (this.state.timeError == this.ENDTIME_BEFORE_STARTTIME_VALIDATION_ERROR) { this.setState({ timeError: "" }) }

            if (this.error) {
                return;
            } else {
                if (startDate != endDate) {
                    let tempDate = new Date(startDT);
                    let tempEndDate = new Date(endDate);
                    while (Date.parse(tempDate.toString()) < Date.parse(tempEndDate.toString())) {
                        this.holidayService.create({
                            userId: this.state.params.userId,
                            date: tempDate,
                            id: uuid.v1(),
                        }).then(() => { this.state.params.doChange() });

                        tempDate = new Date(Date.parse(tempDate.toString()) + 24 * 60 * 60 * 1000);
                    }

                    this.holidayService.create({
                        userId: this.state.params.userId,
                        date: tempDate,
                        id: uuid.v1(),
                    }).then(() => { this.state.params.doChange(), this.props.navigation.goBack() });

                } else {
                    this.holidayService.create({
                        userId: this.state.params.userId,
                        date: startDT,
                        id: uuid.v1(),
                    }).then(() => { this.state.params.doChange(), this.props.navigation.goBack() });
                }
            }
        }
    };

    setTouched(type: string) {
        if (type === 'work') {
            this.touchedFree = false;
            this.touchedWork = true;
        } else if (type == 'free') {
            this.touchedFree = true;
            this.touchedWork = false;
            this.isRepeat = false;
            this.setState({ time1: '00:00', time2: '00:00', date2: this.state.date1 })
        }
        this.forceUpdate();
    }

    toggleSwitch() {
        this.isRepeat = !this.isRepeat;
        this.forceUpdate();
    }

    render() {
        let isDatePickerVisible = this.state.isDatePickerVisible;
        let isTimePickerVisible = this.state.isTimePickerVisible;
        return (
            <SafeAreaView style={styles.safeAreaView}>
                <DateTimePickerModal
                    isVisible={isDatePickerVisible}
                    mode="date"
                    date={new Date()}
                    locale="nl_NL"
                    cancelTextIOS="Annuleren"
                    confirmTextIOS="Ok"
                    headerTextIOS="Kies een datum"
                    onConfirm={this.handleConfirmDay.bind(this)}
                    onCancel={this.hideDatePicker.bind(this)}
                />
                <DateTimePickerModal
                    isVisible={isTimePickerVisible}
                    mode="time"
                    is24Hour={true}
                    locale="nl_NL"
                    cancelTextIOS="Annuleren"
                    confirmTextIOS="Ok"
                    headerTextIOS="Kies een tijd"
                    onConfirm={this.handleConfirmTime.bind(this)}
                    onCancel={this.hideTimePicker.bind(this)}
                />
                <Text style={styles.title}>Vanaf</Text>
                <View style={styles.inputBox1}>
                    <TextInput placeholder="Start Datum" style={[styles.textInput, styles.borderRightNone]} value={this.state.date1}
                        onFocus={() => { Keyboard.dismiss(), this.setState({ datePicker: 1, isDatePickerVisible: true }) }} />
                    <View style={styles.dashBack}>
                        <View style={styles.dash}></View>
                    </View>
                    <TextInput placeholder="Start Tijd" style={[styles.textInput, styles.borderLeftNone, this.touchedFree ? styles.grayOut : null]} value={this.state.time1} editable={this.touchedWork}
                        onFocus={() => { Keyboard.dismiss(), this.setState({ timePicker: 1, isTimePickerVisible: true }) }} />
                </View>
                <Text style={styles.title}>Tot</Text>
                <View style={styles.inputBox2}>
                    <TextInput placeholder="Eind Datum" style={[styles.textInput, styles.borderRightNone, this.touchedFree ? styles.grayOut : null]} value={this.state.date2} editable={this.touchedWork}
                        onFocus={() => { Keyboard.dismiss(), this.setState({ datePicker: 2, isDatePickerVisible: true }) }} />
                    <View style={styles.dashBack}>
                        <View style={styles.dash}></View>
                    </View>
                    <TextInput placeholder="Eind Tijd" style={[styles.textInput, styles.borderLeftNone, this.touchedFree ? styles.grayOut : null]} value={this.state.time2} editable={this.touchedWork}
                        onFocus={() => { Keyboard.dismiss(), this.setState({ timePicker: 2, isTimePickerVisible: true }) }} />
                </View>

                <View style={{ flex: 1, flexDirection: 'row' }}>
                    <View style={styles.toggleBox}>
                        <TouchableWithoutFeedback style={[styles.toggle, styles.flexRow, this.touchedFree ? styles.touchedFree : null]} onPress={() => this.setTouched('free')}>
                            <View style={[styles.colorFree, this.touchedFree ? styles.touchedFreeBack : null]}></View>
                            <Text style={styles.toggleText}>Vrije Dag</Text>
                        </TouchableWithoutFeedback>
                        <TouchableWithoutFeedback style={[styles.toggle, styles.flexRow, this.touchedWork ? styles.touchedWork : null]} onPress={() => this.setTouched('work')}>
                            <View style={[styles.colorWork, this.touchedWork ? styles.touchedWorkBack : null]}></View>
                            <Text style={styles.toggleText}>Werkdag</Text>
                        </TouchableWithoutFeedback>
                    </View>
                </View>

                <View style={styles.errorBox}>
                    <Text style={[styles.error, this.state.fieldError == "" ? styles.invisible : null]}>{this.state.fieldError}</Text>
                    <Text style={[styles.error, this.state.dateError == "" ? styles.invisible : null]}>{this.state.dateError}</Text>
                    <Text style={[styles.error, this.state.timeError == "" ? styles.invisible : null]}>{this.state.timeError}</Text>
                </View>

                <View style={styles.flexColumn}>
                    <View style={[styles.flexRow, styles.repeatBox, this.touchedFree ? styles.grayOut : null]} >
                        <Text style={styles.repeatTitle}>Herhaal uren</Text>
                        <Switch
                            trackColor={{ false: "#767577", true: "#5ed4a7" }}
                            thumbColor={this.isRepeat ? "#00b300" : "#f4f3f4"}
                            ios_backgroundColor="#3e3e3e"
                            onValueChange={() => this.toggleSwitch()}
                            value={this.isRepeat}
                            style={styles.switch}
                            disabled={this.touchedFree}
                        />
                    </View>
                    <View style={[styles.flexRow, styles.infoBox]}>
                        <IconI name="ios-information-circle-outline" style={styles.infoIcon} />
                        <Text style={styles.infoText}>
                            Aan = De uren worden herhaalt voor elke geselecteerde datum.{"\n"}
                            Uit = De tijd wordt als 1 periode gezien.
                        </Text>
                    </View>
                </View>

                <View style={styles.bottomDiv}>
                    <View style={styles.buttonDiv}>
                        <TouchableOpacity onPress={this.saveDate} >
                            <Text style={styles.button} >Ok</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </SafeAreaView>
        );
    }
}

const styles = StyleSheet.create({
    flexColumn: {
        display: 'flex',
        flexDirection: 'column',
    },
    flexRow: {
        display: 'flex',
        flexDirection: 'row',
    },
    safeAreaView: {
        backgroundColor: '#EFECEA',
        flex: 1,
        paddingTop: 10,
    },
    textInput: {
        borderColor: 'gray',
        backgroundColor: 'white',
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 6,
        width: 175,
        height: 100,
        padding: 20,
        fontSize: 25,
        borderRadius: 10,
        textAlign: 'center',
    },
    label: {
        marginLeft: 15,
    },
    bottomDiv: {
        flex: 0,
        flexDirection: 'row',
        justifyContent: 'center',
        margin: 5,
    },
    buttonDiv: {
        padding: 10,
        width: '80%',
    },
    error: {
        paddingLeft: 10,
        color: 'red',
        fontSize: 15,
    },
    errorBox: {
        display: "flex",
        flex: 2,
        flexDirection: 'column',
        marginLeft: 20,
        marginTop: 5,
    },
    title: {
        fontSize: 25,
        fontWeight: 'bold',
        borderBottomColor: '#555',
        borderBottomWidth: 1,
        margin: 10,
        paddingLeft: 10,
    },
    inputBox1: {
        flex: 0,
        flexDirection: 'row',
        margin: 10,
        paddingLeft: 20,
    },
    inputBox2: {
        flex: 0,
        flexDirection: 'row',
        margin: 10,
        paddingLeft: 20,
    },
    borderLeftNone: {
        borderTopLeftRadius: 0,
        borderBottomLeftRadius: 0,
        borderLeftColor: 'white',
    },
    borderRightNone: {
        borderTopRightRadius: 0,
        borderBottomRightRadius: 0,
        borderRightColor: 'white',
    },
    dash: {
        width: 2,
        height: 80,
        backgroundColor: '#ccc',
        marginTop: 10,
    },
    dashBack: {
        width: 3,
        height: 100,
        backgroundColor: 'white',
        elevation: 6,
    },
    colorFree: {
        backgroundColor: '#53C1F2',
        minWidth: 20,
        minHeight: 50,
        borderRadius: 10,
        borderRightColor: 'white',
        borderRightWidth: 10,
    },
    colorWork: {
        backgroundColor: '#4CD19F',
        minWidth: 20,
        minHeight: 50,
        borderRadius: 10,
        borderRightColor: 'white',
        borderRightWidth: 10,
    },
    toggleText: {
        padding: 15,
        paddingLeft: 30,
    },
    toggle: {
        backgroundColor: 'white',
        width: 160,
        borderRadius: 20,
        margin: 10,
        marginLeft: 30,
        marginRight: 0,
    },
    toggleBox: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 70,
        margin: 10,
        marginLeft: 0
    },
    touchedFree: {
        backgroundColor: '#b8e6fa',
    },
    touchedWork: {
        backgroundColor: '#c2efde',
    },
    touchedFreeBack: {
        borderRightColor: '#b8e6fa',
    },
    touchedWorkBack: {
        borderRightColor: '#c2efde',
    },
    button: {
        backgroundColor: '#E71234',
        width: 300,
        height: 40,
        textAlign: "center",
        color: 'white',
        borderRadius: 10,
        justifyContent: 'center',
        padding: 10,
    },
    grayOut: {
        backgroundColor: '#bbb'
    },
    invisible: {
        display: "none",
    },
    repeatBox: {
        backgroundColor: 'white',
        borderRadius: 10,
        margin: 20,
        marginBottom: 5,
    },
    switch: {
        flex: 1,
        margin: 10,
    },
    repeatTitle: {
        margin: 10,
        textAlign: 'center',
        fontSize: 12,
        marginTop: 15,
        marginLeft: 15,
    },
    infoBox: {
        marginLeft: 25,
    },
    infoText: {
        color: 'grey',
        fontSize: 12,
        marginTop: 2,
    },
    infoIcon: {
        fontSize: 20,
        marginRight: 5,
        color: 'grey'
    }
});