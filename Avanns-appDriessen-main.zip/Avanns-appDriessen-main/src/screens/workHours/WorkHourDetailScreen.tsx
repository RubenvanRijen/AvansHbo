import React from 'react';
import { Button, Text, TextInput, Keyboard, View, SafeAreaView, StyleSheet } from 'react-native';
import { Col, Grid } from "react-native-easy-grid";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { StackNavigationProp } from '@react-navigation/stack';
import { WorkHour } from '../../models/IWorkHour';

import storage from '../../Storage';
import { Jwt } from '../../models/IJwt';
import { Holiday } from '../../models/IHoliday';
import { TouchableWithoutFeedback, TouchableOpacity } from 'react-native-gesture-handler';

import WorkHourService from '../../services/WorkHourService';
import HolidayService from '../../services/HolidayService';

type RootStackParamList = {
    WorkHours: undefined,
    WorkHoursDetail: { item: WorkHour, doChange: () => void },
    WorkHoursCreate: { doChange: () => void },
};

type RootStackNavigationProp = StackNavigationProp<RootStackParamList, 'WorkHoursDetail'>;

interface Params {
    doChange(): () => void;
    hour: WorkHour;
    holiday: Holiday;
    userId: string;
    jwtToken: string;
}

interface Props {
    navigation: RootStackNavigationProp;
    route: {
        params: {
            doChange(): () => void
            hour: WorkHour;
            holiday: Holiday;
            userId: string;
            jwtToken: string;
        }
    }
}

interface State {
    isDatePickerVisible: boolean,
    isTimePickerVisible: boolean,
    params: Params,
    datePicker: number,
    timePicker: number,
    date1: string,
    date2: string,
    time1: string,
    time2: string,
    dateError: string,
    timeError: string,
}

export default class WorkHourDetailScreen extends React.Component<Props, State, Params>  {
    error: boolean = false;
    touchedFree: boolean = false;
    touchedWork: boolean = false;
    monthsEN: string[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    ENDDATE_BEFORE_STARTDATE_VALIDATION_ERROR = "Eind datum niet hetzelfde als begin datum";
    ENDTIME_BEFORE_STARTTIME_VALIDATION_ERROR = "Eind tijd na begin tijd";
    ENDTIME_EQUALS_STARTTIME_VALIDATION_ERROR = "Eind tijd is hetzelfde als begin tijd";
    workHourService: WorkHourService;
    holidayService: HolidayService;

    constructor(props: Props) {
        super(props);

        let params = props.route.params;
        let startDate = "";
        let endDate = "";
        let startTime = "";
        let endTime = "";

        this.workHourService = new WorkHourService(props.navigation);
        this.holidayService = new HolidayService(props.navigation);

        if (params.hour != null) {
            this.touchedWork = true;
            let startD = params.hour.startDateTime.toString();
            let startDay = startD.split(' ')[2]
            if (startDay.length == 1) startDay = "0" + startDay;
            let startMonth = (this.monthsEN.indexOf(startD.split(' ')[1]) + 1).toString();
            if (startMonth.length == 1) startMonth = "0" + startMonth;
            let startYear = startD.split(' ')[3];
            startDate = startDay + "-" + startMonth + "-" + startYear;
            startTime = startD.split(' ')[4].substr(0, 5);

            let endD = params.hour.endDateTime.toString();
            let endDay = endD.split(' ')[2]
            if (endDay.length == 1) endDay = "0" + endDay;
            let endMonth = (this.monthsEN.indexOf(endD.split(' ')[1]) + 1).toString();
            if (endMonth.length == 1) endMonth = "0" + endMonth;
            let endYear = endD.split(' ')[3];
            endDate = endDay + "-" + endMonth + "-" + endYear;
            endTime = endD.split(' ')[4].substr(0, 5);
        } else if (params.holiday != null) {
            this.touchedFree = true;
            let startD = params.holiday.date.toString();
            let startDay = startD.split(' ')[2]
            if (startDay.length == 1) startDay = "0" + startDay;
            let startMonth = (this.monthsEN.indexOf(startD.split(' ')[1]) + 1).toString();
            if (startMonth.length == 1) startMonth = "0" + startMonth;
            let startYear = startD.split(' ')[3];
            startDate = startDay + "-" + startMonth + "-" + startYear;
            startTime = "00:00";
            endDate = startDate;
            endTime = "00:00";
        }

        this.state = {
            isDatePickerVisible: false,
            isTimePickerVisible: false,
            params: params,
            datePicker: 1,
            timePicker: 1,
            date1: startDate,
            date2: endDate,
            time1: startTime,
            time2: endTime,
            dateError: "",
            timeError: "",
        };

    }

    handleConfirmTime(date: Date) {
        let hours = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
        let minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
        if (this.state.timePicker == 1) {
            this.setState({ time1: hours + ":" + minutes, isTimePickerVisible: false })
        } else if (this.state.timePicker == 2) {
            this.setState({ time2: hours + ":" + minutes, isTimePickerVisible: false })
        }
    };

    handleConfirmDay(date: Date) {
        if (this.state.datePicker == 1) {
            if (this.touchedWork) {
                this.setState({ date1: date.getDate() + "-" + (date.getMonth() + 1) + "-" + date.getFullYear(), isDatePickerVisible: false })
            } else {
                this.setState({ date1: date.getDate() + "-" + (date.getMonth() + 1) + "-" + date.getFullYear(), date2: date.getDate() + "-" + (date.getMonth() + 1) + "-" + date.getFullYear(), isDatePickerVisible: false })
            }
        } else if (this.state.datePicker == 2) {
            this.setState({ date2: date.getDate() + "-" + (date.getMonth() + 1) + "-" + date.getFullYear(), isDatePickerVisible: false })
        }
    };

    hideDatePicker() {
        this.setState({ isDatePickerVisible: false });
    };

    hideTimePicker() {
        this.setState({ isTimePickerVisible: false });
    };

    saveDate = () => {
        this.error = false;
        let startYear = this.state.date1.split('-')[2];
        let startMonth = this.state.date1.split('-')[1];
        if (startMonth.length == 1) startMonth = "0" + startMonth;
        let startDay = this.state.date1.split('-')[0];
        if (startDay.length == 1) startDay = "0" + startDay;
        let startDate = Date.parse(startYear + "-" + startMonth + "-" + startDay);
        let startDateTime = Date.parse(startYear + "-" + startMonth + "-" + startDay + "T" + this.state.time1 + ":00");
        let startDT = startYear + "-" + startMonth + "-" + startDay + "T" + this.state.time1 + ":00";

        let endYear = this.state.date2.split('-')[2];
        let endMonth = this.state.date2.split('-')[1];
        if (endMonth.length == 1) endMonth = "0" + endMonth;
        let endDay = this.state.date2.split('-')[0];
        if (endDay.length == 1) endDay = "0" + endDay;
        let endDate = Date.parse(endYear + "-" + endMonth + "-" + endDay);
        let endDateTime = Date.parse(startYear + "-" + startMonth + "-" + startDay + "T" + this.state.time2 + ":00");
        let endDT = endYear + "-" + endMonth + "-" + endDay + "T" + this.state.time2 + ":00";

        if (endDate != startDate) {
            this.error = true;
            this.setState({ dateError: this.ENDDATE_BEFORE_STARTDATE_VALIDATION_ERROR })
        } else if (this.state.dateError == this.ENDDATE_BEFORE_STARTDATE_VALIDATION_ERROR) { this.setState({ dateError: "" }) }

        if (endDateTime < startDateTime) {
            this.error = true;
            this.setState({ timeError: this.ENDTIME_BEFORE_STARTTIME_VALIDATION_ERROR })
        } else if (this.state.timeError == this.ENDTIME_BEFORE_STARTTIME_VALIDATION_ERROR) { this.setState({ timeError: "" }) }

        if (this.touchedWork) {
            if (endDateTime == startDateTime) {
                this.error = true;
                this.setState({ timeError: this.ENDTIME_EQUALS_STARTTIME_VALIDATION_ERROR })
            } else if (this.state.timeError == this.ENDTIME_EQUALS_STARTTIME_VALIDATION_ERROR) { this.setState({ timeError: "" }) }
        }

        if (this.error) {
            return;
        } else {
            if (this.touchedWork) {
                setTimeout(() => {
                    this.workHourService.update(this.state.params.hour.id, {
                        userId: this.state.params.hour.userID,
                        startDateTime: startDT,
                        endDateTime: endDT,
                        id: this.state.params.userId,
                    }).then(() => { this.state.params.doChange(), this.props.navigation.goBack() });
                }, 500);

            } else if (this.touchedFree) {
                let holidayYear = this.state.date1.split('-')[2];
                let holidayMonth = this.state.date1.split('-')[1];
                if (holidayMonth.length == 1) holidayMonth = "0" + holidayMonth;
                let holidayDay = this.state.date1.split('-')[0];
                if (holidayDay.length == 1) holidayDay = "0" + holidayDay;
                let HolidayDT = holidayYear + "-" + holidayMonth + "-" + holidayDay + "T00:00:00.000Z";

                this.holidayService.update("", {
                    userId: this.state.params.userId,
                    date: HolidayDT,
                    id: this.state.params.holiday.id,
                }).then(() => { this.state.params.doChange(), this.props.navigation.goBack() });

            }
        }
    };

    delete = async () => {
        if (this.touchedWork) {
            this.workHourService.delete(this.state.params.hour.id);
            this.props.navigation.goBack();
        } else if (this.touchedFree) {
            this.holidayService.delete(this.state.params.holiday.id)
            this.props.navigation.goBack();
        }
    };

    render() {
        let isDatePickerVisible = this.state.isDatePickerVisible;
        let isTimePickerVisible = this.state.isTimePickerVisible;
        return (
            <SafeAreaView style={styles.safeAreaView}>
                <DateTimePickerModal
                    isVisible={isDatePickerVisible}
                    mode="date"
                    date={new Date()}
                    locale="nl_NL"
                    cancelTextIOS="Annuleren"
                    confirmTextIOS="Ok"
                    headerTextIOS="Kies een datum"
                    onConfirm={this.handleConfirmDay.bind(this)}
                    onCancel={this.hideDatePicker.bind(this)}
                />
                <DateTimePickerModal
                    isVisible={isTimePickerVisible}
                    mode="time"
                    is24Hour={true}
                    locale="nl_NL"
                    cancelTextIOS="Annuleren"
                    confirmTextIOS="Ok"
                    headerTextIOS="Kies een tijd"
                    onConfirm={this.handleConfirmTime.bind(this)}
                    onCancel={this.hideTimePicker.bind(this)}
                />
                <Text style={styles.title}>Vanaf</Text>
                <View style={styles.inputBox1}>
                    <TextInput placeholder="Start Datum" style={[styles.textInput, styles.borderRightNone]} value={this.state.date1}
                        onFocus={() => { Keyboard.dismiss(), this.setState({ datePicker: 1, isDatePickerVisible: true }) }} />
                    <View style={styles.dashBack}>
                        <View style={styles.dash}></View>
                    </View>
                    <TextInput placeholder="Start Tijd" style={[styles.textInput, styles.borderLeftNone, this.touchedFree ? styles.grayOut : null]} value={this.state.time1} editable={this.touchedWork}
                        onFocus={() => { Keyboard.dismiss(), this.setState({ timePicker: 1, isTimePickerVisible: true }) }} />
                </View>
                <Text style={styles.title}>Tot</Text>
                <View style={styles.inputBox2}>
                    <TextInput placeholder="Eind Datum" style={[styles.textInput, styles.borderRightNone, this.touchedFree ? styles.grayOut : null]} value={this.state.date2} editable={this.touchedWork}
                        onFocus={() => { Keyboard.dismiss(), this.setState({ datePicker: 2, isDatePickerVisible: true }) }} />
                    <View style={styles.dashBack}>
                        <View style={styles.dash}></View>
                    </View>
                    <TextInput placeholder="Eind Tijd" style={[styles.textInput, styles.borderLeftNone, this.touchedFree ? styles.grayOut : null]} value={this.state.time2} editable={this.touchedWork}
                        onFocus={() => { Keyboard.dismiss(), this.setState({ timePicker: 2, isTimePickerVisible: true }) }} />
                </View>

                <View style={{ flex: 1, flexDirection: 'row' }}>
                    <TouchableWithoutFeedback style={[styles.toggle, styles.flexRow, this.touchedFree ? styles.touchedFree : styles.invisible]}>
                        <View style={[styles.colorFree, this.touchedFree ? styles.touchedFreeBack : null]}></View>
                        <Text style={styles.toggleText}>Vrije Dag</Text>
                    </TouchableWithoutFeedback>
                    <TouchableWithoutFeedback style={[styles.toggle, styles.flexRow, this.touchedWork ? styles.touchedWork : styles.invisible]}>
                        <View style={[styles.colorWork, this.touchedWork ? styles.touchedWorkBack : null]}></View>
                        <Text style={styles.toggleText}>Werkdag</Text>
                    </TouchableWithoutFeedback>
                </View>

                <View style={styles.errorBox}>
                    <Text style={[styles.error, this.state.dateError == "" ? styles.invisible : null]}>{this.state.dateError}</Text>
                    <Text style={[styles.error, this.state.timeError == "" ? styles.invisible : null]}>{this.state.timeError}</Text>
                </View>

                <View style={styles.bottomDiv}>
                    <View style={styles.buttonDiv}>
                        <TouchableOpacity onPress={this.delete} >
                            <Text style={styles.button} >Verwijderen</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.buttonDiv}>
                        <TouchableOpacity onPress={this.saveDate} >
                            <Text style={styles.button} >Ok</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </SafeAreaView>
        );
    }
}

const styles = StyleSheet.create({
    flexColumn: {
        display: 'flex',
        flexDirection: 'column',
    },
    flexRow: {
        display: 'flex',
        flexDirection: 'row',
    },
    safeAreaView: {
        backgroundColor: '#EFECEA',
        flex: 1,
        paddingTop: 10,
    },
    textInput: {
        borderColor: 'gray',
        backgroundColor: 'white',
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 6,
        width: 175,
        height: 100,
        padding: 20,
        fontSize: 25,
        borderRadius: 10,
        textAlign: 'center',
    },
    label: {
        marginLeft: 15,
    },
    bottomDiv: {
        flex: 0,
        flexDirection: 'row',
        justifyContent: 'center',
        margin: 5,
    },
    buttonDiv: {
        padding: 10,
        width: '40%',
    },
    error: {
        paddingLeft: 10,
        color: 'red',
        fontSize: 15,
    },
    errorBox: {
        display: "flex",
        flex: 3,
        flexDirection: 'column',
        marginLeft: 20
    },
    title: {
        fontSize: 25,
        fontWeight: 'bold',
        borderBottomColor: '#555',
        borderBottomWidth: 1,
        margin: 10,
        paddingLeft: 10,
    },
    inputBox1: {
        flex: 0,
        flexDirection: 'row',
        margin: 10,
        paddingLeft: 20,
    },
    inputBox2: {
        flex: 0,
        flexDirection: 'row',
        margin: 10,
        paddingLeft: 20,
    },
    borderLeftNone: {
        borderTopLeftRadius: 0,
        borderBottomLeftRadius: 0,
        borderLeftColor: 'white',
    },
    borderRightNone: {
        borderTopRightRadius: 0,
        borderBottomRightRadius: 0,
        borderRightColor: 'white',
    },
    dash: {
        width: 2,
        height: 80,
        backgroundColor: '#ccc',
        marginTop: 10,
    },
    dashBack: {
        width: 3,
        height: 100,
        backgroundColor: 'white',
        elevation: 6,
    },
    colorFree: {
        backgroundColor: '#53C1F2',
        minWidth: 20,
        minHeight: 50,
        borderRadius: 10,
        borderRightColor: 'white',
        borderRightWidth: 10,
    },
    colorWork: {
        backgroundColor: '#4CD19F',
        minWidth: 20,
        minHeight: 50,
        borderRadius: 10,
        borderRightColor: 'white',
        borderRightWidth: 10,
    },
    toggleText: {
        padding: 15,
        paddingLeft: 30,
    },
    toggle: {
        backgroundColor: 'white',
        width: 160,
        borderRadius: 20,
        margin: 10,
        marginLeft: 30,
        marginRight: 0,
    },
    touchedFree: {
        backgroundColor: '#b8e6fa',
    },
    touchedWork: {
        backgroundColor: '#c2efde',
    },
    touchedFreeBack: {
        borderRightColor: '#b8e6fa',
    },
    touchedWorkBack: {
        borderRightColor: '#c2efde',
    },
    button: {
        backgroundColor: '#E71234',
        width: 150,
        height: 40,
        textAlign: "center",
        color: 'white',
        borderRadius: 10,
        justifyContent: 'center',
        padding: 10,
    },
    grayOut: {
        backgroundColor: '#bbb'
    },
    invisible: {
        display: "none",
    }
});