import React, { Component } from 'react';
import { Modal, TouchableWithoutFeedback, TouchableHighlight, SafeAreaView, ScrollView, StyleSheet, Text, View, Keyboard } from 'react-native';
import { Col, Grid } from "react-native-easy-grid";
import ActionButton from 'react-native-action-button';
import Icon from 'react-native-vector-icons/FontAwesome';
import IconI from 'react-native-vector-icons/Ionicons';
import { StackNavigationProp } from '@react-navigation/stack';
import { WorkHour } from '../../models/IWorkHour';

import storage from '../../Storage';
import { Jwt } from '../../models/IJwt';
import { Holiday } from '../../models/IHoliday';
import { TextInput } from 'react-native-gesture-handler';
import uuid from 'react-native-uuid';

import WorkHourService from '../../services/WorkHourService';
import HolidayService from '../../services/HolidayService';

const currentWeekNumber = require('current-week-number');

type RootStackParamList = {
    Dashboard: undefined,
    WorkHours: undefined,
    WorkHoursDetail: { hour: WorkHour | null, holiday: Holiday | null, doChange: () => void, userId: string, jwtToken: string },
    WorkHoursCreate: { doChange: () => void, userId: string, jwtToken: string },
    Holidays: undefined,
};

type RootStackNavigationProp = StackNavigationProp<RootStackParamList, 'WorkHours'>;

interface Props {
    navigation: RootStackNavigationProp;
}

interface State {
    daysAbrev: string[],
    months: string[],
    weekDays: Date[],
    weekNumber: number,
    monthNumber: number,
    year: number,
    dayType: string[],
    holidayArray: Holiday[],
    hourArray: WorkHour[],
    repeatNumber: string,
}

export default class WorkHourOverviewScreen extends React.Component<Props, State> {
    jwt!: Jwt;
    rawJwt: string = "";
    modalVisible = false;
    weekChangeAmount: number;
    workHourService: WorkHourService;
    holidayService: HolidayService;

    constructor(props: Props) {
        super(props);

        props.navigation.addListener('focus', () => { this.getUserData(); });

        this.workHourService = new WorkHourService(props.navigation);
        this.holidayService = new HolidayService(props.navigation);

        this.weekChangeAmount = 0;
        this.state = {
            daysAbrev: ['Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag', 'Zondag'],
            months: ['Januari', 'Februari', 'Maart', 'April', 'Mei', 'Juni', 'Juli', 'Augustus', 'September', 'Oktober', 'November', 'December'],
            weekDays: [],
            weekNumber: 0,
            monthNumber: 0,
            year: 0,
            dayType: [],
            holidayArray: [],
            hourArray: [],
            repeatNumber: "1",
        };

        this.getUserData();
    }
    componentDidMount() { console.disableYellowBox = true; }

    getUserData = async () => {
        //jwt
        await storage.getItem(storage.jwtKey)
            .then(jwt => {
                if (jwt) {
                    this.rawJwt = jwt;
                    let base64Url = jwt.split('.')[1];
                    let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
                    let jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c: string) {
                        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
                    }).join(''));
                    this.jwt = JSON.parse(jsonPayload);
                }
            })
            .catch(error => console.error(error));
        this.getWorkHourData();
    }

    getWorkHourData = async () => {
        if (this.jwt) {
            // Get current date
            let curDate = new Date(Date.now());
            // Change current date to corresponding date in week x
            curDate = new Date(Date.parse(curDate.toString()) + (this.weekChangeAmount * 7 * 24 * 60 * 60 * 1000));
            curDate.setHours(0);
            curDate.setMinutes(0);
            curDate.setSeconds(0);
            curDate.setMilliseconds(0);

            // Get weekday of current selected week
            let dayOfWeek = curDate.getDay();

            // Get number of days that needs to be substracted from curDate to get monday from the same week
            dayOfWeek = dayOfWeek == 0 ? 6 : dayOfWeek - 1;

            // Get correct date for monday of current selected week
            let dateIntBeginCurWeek = Date.parse(curDate.toString()) - (dayOfWeek * 24 * 60 * 60 * 1000);
            curDate = new Date(dateIntBeginCurWeek);

            let monthNr = curDate.getMonth();

            // List of all days in current selected day
            let weekDayList: Date[] = [];
            for (let index = 0; index < 7; index++) {
                weekDayList.push(new Date(Date.parse(curDate.toString()) + (index * 24 * 60 * 60 * 1000)));
            }

            // workhours
            let startDate = weekDayList[0].toJSON();
            let endDate = weekDayList[weekDayList.length - 1].toJSON();

            let workHourData: WorkHour[] = await this.workHourService.getWorkHoursByUser(`?StartDate=${startDate}&EndDate=${endDate}&PageSize=100`)
                .then((responseJson) => {
                    if (responseJson) {
                        let workHourData = responseJson.map(function (obj: WorkHour): WorkHour {
                            let startDT = new Date(Date.parse(new Date(obj.startDateTime).toString()) + (new Date(obj.startDateTime).getTimezoneOffset() * 60 * 1000));

                            let endDT = new Date(Date.parse(new Date(obj.endDateTime).toString()) + (new Date(obj.endDateTime).getTimezoneOffset() * 60 * 1000));

                            return {
                                userID: obj.userID,
                                startDateTime: startDT,
                                endDateTime: endDT,
                                id: obj.id,
                            }
                        });

                        workHourData = this.sortWorkHours(workHourData);
                        return workHourData;
                    }
                }).catch((error) => {
                    console.error(error);
                }) || [];

            //holidays
            let holidayData: Holiday[] = await this.holidayService.getHolidayByUser('?StartDate=${startDate}&EndDate=${endDate}&PageSize=100')
                .then((responseJson) => {
                    if (responseJson) {
                        let holidayData = responseJson.map(function (obj: Holiday): Holiday {
                            let date = new Date(Date.parse(new Date(obj.date).toString()) + (new Date(obj.date).getTimezoneOffset() * 60 * 1000));
                            date.setHours(0);
                            date.setMinutes(0);
                            date.setSeconds(0);
                            date.setMilliseconds(0);

                            return {
                                userId: obj.userId,
                                date: date,
                                id: obj.id,
                            }
                        });
                        holidayData = this.sortHolidays(holidayData);
                        return holidayData;
                    }
                }).catch((error) => {
                    console.error(error);
                }) || [];

            // Get current weekNr from curDate
            let weekNr = currentWeekNumber(curDate);
            let dayTypeList: string[] = [];
            for (let a = 0; a < weekDayList.length; a++) {
                let day = new Date(Date.parse(weekDayList[a].toString()));
                let endDay = new Date(Date.parse(weekDayList[a].toString()) + 24 * 60 * 60 * 1000);
                workHourData.forEach(workHour => {
                    if (new Date(workHour.startDateTime) >= day && new Date(workHour.endDateTime) < endDay) {
                        dayTypeList[a] = 'work'
                    } else if (dayTypeList[a] != 'work') {
                        dayTypeList[a] = 'null'
                    }
                });
                holidayData.forEach(holiday => {
                    if (new Date(holiday.date) >= day && new Date(holiday.date) < endDay && dayTypeList[a] != 'work') {
                        dayTypeList[a] = 'holiday'
                    }
                });
            };

            this.setState({ weekDays: weekDayList, weekNumber: weekNr, monthNumber: monthNr, year: curDate.getFullYear(), dayType: dayTypeList, hourArray: workHourData, holidayArray: holidayData });
        }

    }

    changeWeek(bool: Boolean) {
        if (bool) {
            this.weekChangeAmount += 1;
        } else {
            this.weekChangeAmount -= 1;
        }
        this.getWorkHourData();
    }

    showRepeat() {
        this.modalVisible = !this.modalVisible;
        this.forceUpdate();
    }

    changeRepeat(number: string) {
        number = number.replace(/[- #*;,.<>\{\}\[\]\\\/]/gi, '');
        if (Number.parseInt(number) > 52) number = "52";
        this.setState({ repeatNumber: number });
    }

    repeatWeeks() {
        let startDate = this.state.weekDays[0];
        let endDate = new Date(Date.parse(startDate.toString()) + (7 * 24 * 60 * 60 * 1000));
        let workhourArray: WorkHour[] = [];
        let holidayArray: Holiday[] = [];
        this.state.hourArray.forEach(workHour => {
            if (new Date(workHour.startDateTime) >= startDate && new Date(workHour.endDateTime) < endDate) {
                workhourArray.push(workHour)
            }
        });
        this.state.holidayArray.forEach(holiday => {
            if (new Date(holiday.date) >= startDate && new Date(holiday.date) < endDate) {
                holidayArray.push(holiday)
            }
        });
        for (let index = 0; index < Number.parseInt(this.state.repeatNumber); index++) {
            workhourArray.forEach(workHour => {
                let tempStartDate = new Date(workHour.startDateTime.getTime() + ((index + 1) * 7 * 24 * 60 * 60 * 1000) - (new Date(workHour.startDateTime).getTimezoneOffset() * 60 * 1000));
                let tempEndDate = new Date(workHour.startDateTime.getTime() + ((index + 1) * 7 * 24 * 60 * 60 * 1000) - (new Date(workHour.startDateTime).getTimezoneOffset() * 60 * 1000));
                this.workHourService.create({
                    userId: this.jwt?.sub,
                    startDateTime: tempStartDate,
                    endDateTime: tempEndDate,
                    id: uuid.v1(),
                });
            });
            holidayArray.forEach(holiday => {
                let tempDate = new Date(holiday.date.getTime() + ((index + 1) * 7 * 24 * 60 * 60 * 1000) - (new Date(holiday.date).getTimezoneOffset() * 60 * 1000))
                this.holidayService.create({
                    userId: this.jwt?.sub,
                    date: tempDate,
                    id: uuid.v1(),
                });
            });
        }
        this.setState({ repeatNumber: "1" });
        this.showRepeat();
    }

    modal() {
        return (
            <Modal
                animationType="slide"
                transparent={true}
                visible={this.modalVisible}
                onRequestClose={() => {
                }}
            >
                <View style={styles.centeredView}>
                    <View style={styles.modalView}>
                        <View style={[styles.flexRow, styles.modalHeader]}>
                            <Text style={styles.modalHeaderText}>Herhaling instellen</Text>
                            <TouchableWithoutFeedback onPress={() => this.showRepeat()}>
                                <Icon style={styles.cross} name="close" />
                            </TouchableWithoutFeedback>
                        </View>
                        <View>
                            <Text style={styles.modalText}>
                                Voor hoeveel weken wilt u deze planning herhalen?
                    </Text>

                            <View style={styles.inputBox}>
                                <TextInput
                                    style={styles.input}
                                    keyboardType="numeric"
                                    onChangeText={value => this.changeRepeat(value)}
                                    value={this.state.repeatNumber}
                                />
                                <Text style={styles.weekText}>{this.state.repeatNumber == "1" ? "Week" : "Weken"}</Text>
                            </View>

                            <TouchableHighlight
                                style={styles.button}
                                onPress={() => {
                                    this.repeatWeeks();
                                }}
                            >
                                <Text style={styles.textStyle}>OK</Text>
                            </TouchableHighlight>
                        </View>
                    </View>
                </View>
            </Modal>
        )
    }

    renderWeek() {
        return (
            <View style={[styles.weekNrBase, styles.flexColumn]}>
                <Text style={styles.year}>{this.state.year}</Text>
                <View style={styles.weekNrBase2}>
                    <TouchableWithoutFeedback onPress={() => this.changeWeek(false)}>
                        <Icon name="caret-left" style={styles.weekButton} />
                    </TouchableWithoutFeedback>
                    <Text style={styles.weekNr}>Week: {this.state.weekNumber}</Text>
                    <TouchableWithoutFeedback onPress={() => this.changeWeek(true)}>
                        <Icon name="caret-right" style={styles.weekButton} />
                    </TouchableWithoutFeedback>
                    <View style={styles.repeatWeek}>
                        <TouchableWithoutFeedback onPress={() => this.showRepeat()}>
                            <Icon name="retweet" style={styles.weekButton} />
                        </TouchableWithoutFeedback>
                    </View>
                </View>
            </View>
        )
    }

    renderWeekDay() {
        return this.state.weekDays.map((number: Date, i: number) => {
            if (this.state.dayType[i] == 'work') {
                return (
                    <View style={styles.weekDay} key={i}>
                        <Text style={[styles.day, styles.work]}>{this.state.daysAbrev[this.state.weekDays.indexOf(number)].substr(0, 2)}</Text>
                        <Text style={[styles.day, styles.work]}>{number.toString().substr(8, 2)}</Text>
                    </View>
                )
            } else if (this.state.dayType[i] == 'holiday') {
                return (
                    <View style={styles.weekDay} key={i}>
                        <Text style={[styles.day, styles.holiday]}>{this.state.daysAbrev[this.state.weekDays.indexOf(number)].substr(0, 2)}</Text>
                        <Text style={[styles.day, styles.holiday]}>{number.toString().substr(8, 2)}</Text>
                    </View>
                )
            } else {
                return (
                    <View style={styles.weekDay} key={i}>
                        <Text style={styles.day}>{this.state.daysAbrev[this.state.weekDays.indexOf(number)].substr(0, 2)}</Text>
                        <Text style={styles.day}>{number.toString().substr(8, 2)}</Text>
                    </View>
                )
            }
        })
    }

    renderWeekHours(navigation: RootStackNavigationProp) {
        return this.state.weekDays.map((day: Date, i: number) => {
            let workhourArray: WorkHour[] = [];
            let holidayArray: Holiday[] = [];
            let endDay = new Date(Date.parse(day.toString()) + 24 * 60 * 60 * 1000);

            this.state.hourArray.forEach(workHour => {
                if (new Date(workHour.startDateTime) >= day && new Date(workHour.endDateTime) < endDay) {
                    workhourArray.push(workHour)
                }
            });
            this.state.holidayArray.forEach(holiday => {
                if (new Date(holiday.date) >= day && new Date(holiday.date) < endDay) {
                    holidayArray.push(holiday)
                }
            });
            return (
                <View key={i}>
                    <Text style={styles.weekDayList}>{this.state.daysAbrev[i] + " " + day.toString().substr(8, 2) + " " + this.state.months[day.getMonth()]}</Text>
                    {
                        this.renderHolidayHours(holidayArray, navigation)
                    }
                    {
                        this.renderWorkHours(workhourArray, navigation)
                    }
                </View>
            )
        });
    }

    renderHolidayHours(holidays: Holiday[], navigation: RootStackNavigationProp) {
        if (holidays.length != 0) {
            return holidays.map((holiday: Holiday) => {

                let holidayDay = holiday.date.toString().substr(8, 2);
                if (holidayDay.length == 1) holidayDay = "0" + holidayDay;
                let holidayMonth = (new Date(holiday.date).getMonth() + 1).toString();
                if (holidayMonth.length == 1) holidayMonth = "0" + holidayMonth;
                let holidayYear = new Date(holiday.date).getFullYear().toString();
                return (
                    <View key={holiday.id}>
                        <View style={[styles.workHourView, styles.flexRow]} onTouchEnd={() => navigation.navigate('WorkHoursDetail', { hour: null, holiday: holiday, doChange: this.getWorkHourData, userId: this.jwt.sub, jwtToken: this.rawJwt })}>
                            <View style={styles.colorFree}></View>
                            <View style={[styles.workHourView2, styles.flexColumn]}>
                                <Grid style={styles.hourGrid}>
                                    <Text style={[styles.workHourViewInformation, styles.bold]}>{holidayDay + "-" + holidayMonth + "-" + holidayYear}</Text>
                                </Grid>
                            </View>
                        </View>
                    </View>
                );
            });
        }
    }

    renderWorkHours(workhours: WorkHour[], navigation: RootStackNavigationProp) {
        if (workhours.length != 0) {
            return workhours.map((workHour: WorkHour) => {
                let day = workHour.startDateTime.toString().substr(8, 2);
                if (day.length == 1) day = "0" + day;
                let month = (new Date(workHour.startDateTime).getMonth() + 1).toString();
                if (month.length == 1) month = "0" + month;
                let year = new Date(workHour.startDateTime).getFullYear().toString();
                let startTime = workHour.startDateTime.toString().split(' ')[4].substr(0, 5);
                let endTime = workHour.endDateTime.toString().split(' ')[4].substr(0, 5);

                return (
                    <View key={workHour.id}>
                        <View style={[styles.workHourView, styles.flexRow]} onTouchEnd={() => navigation.navigate('WorkHoursDetail', { hour: workHour, holiday: null, doChange: this.getWorkHourData, userId: this.jwt.sub, jwtToken: this.rawJwt })}>
                            <View style={styles.colorWork}></View>
                            <View style={[styles.workHourView2, styles.flexColumn]}>
                                <Grid style={styles.hourGrid}>
                                    <Text style={[styles.workHourViewInformation, styles.bold]}>{day + "-" + month + "-" + year}</Text>
                                    <Text style={styles.workHourViewInformation}>{startTime + " - " + endTime}</Text>
                                </Grid>
                            </View>
                        </View>
                    </View>
                );
            }
            );
        }
    }

    renderButtons(navigation: RootStackNavigationProp) {
        return (
            <ActionButton buttonColor="#E71234" size={60} style={{ elevation: 4, }} shadowStyle={{ shadowColor: "#000", shadowOffset: { width: 0, height: 1, }, shadowOpacity: 0.22, shadowRadius: 2.22, }} onPress={() => navigation.navigate('WorkHoursCreate', { doChange: this.getWorkHourData, userId: this.jwt.sub, jwtToken: this.rawJwt })}>
            </ActionButton>
        );
    }

    sortWorkHours(workHourData: WorkHour[]) {
        workHourData.sort(function (a: WorkHour, b: WorkHour) {
            let parsedTimeA = a.startDateTime;
            let parsedTimeB = b.startDateTime;

            if (parsedTimeA < parsedTimeB) { return -1; }
            if (parsedTimeA > parsedTimeB) { return 1; }
            return 0;
        });
        return workHourData;
    }

    sortHolidays(holidayData: Holiday[]) {
        holidayData.sort(function (a: Holiday, b: Holiday) {
            let parsedTimeA = a.date;
            let parsedTimeB = b.date;

            if (parsedTimeA < parsedTimeB) { return -1; }
            if (parsedTimeA > parsedTimeB) { return 1; }
            return 0;
        });
        return holidayData;
    }

    render() {
        let navigation = this.props.navigation;

        if (this.state.hourArray.length != null && this.state.holidayArray.length != null) {
            return (
                <SafeAreaView style={styles.safeAreaView}>
                    {
                        this.modal()
                    }
                    {
                        this.renderWeek()
                    }
                    <View style={styles.weekDays}>
                        {
                            this.renderWeekDay()
                        }
                    </View>
                    <ScrollView>
                        {
                            this.renderWeekHours(navigation)
                        }
                    </ScrollView>
                    {
                        this.renderButtons(navigation)
                    }
                </SafeAreaView>
            );
        } else {
            return (
                <SafeAreaView style={[styles.safeAreaView]}>
                    <View style={{ flex: 1, position: 'absolute' }}>
                        {
                            this.renderButtons(navigation)
                        }
                    </View>
                </SafeAreaView>
            );
        }
    }
}

const styles = StyleSheet.create({
    flexRow: {
        display: 'flex',
        flexDirection: 'row'
    },
    flexColumn: {
        display: 'flex',
        flexDirection: 'column'
    },
    bold: {
        fontWeight: 'bold'
    },
    safeAreaView: {
        backgroundColor: '#EFECEA',
        flex: 1,
        paddingTop: 10,
    },
    workHourView: {
        textAlign: 'center',
        backgroundColor: 'white',
        marginLeft: 20,
        marginRight: 30,
        marginBottom: 10,
        borderRadius: 10,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3,
    },
    workHourView2: {
        padding: 10,
    },
    workHourViewInformation: {
        display: 'flex',
        marginLeft: 10,
    },
    workHourCol: {
        justifyContent: 'center',
    },
    actionButtonIcon: {
        fontSize: 20,
        height: 22,
        color: 'white',
        elevation: 4,
    },
    weekNrBase: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: "#CCC",
        padding: 5,
        marginTop: -10,
        borderBottomColor: "#AAA",
        borderBottomWidth: 1,
    },
    weekNrBase2: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: "#CCC",
        padding: 5,
        marginLeft: 120,
    },
    weekNr: {
        fontSize: 20,
        color: "white",
        marginLeft: 10,
        marginRight: 10,
    },
    weekButton: {
        color: "white",
        fontSize: 30

    },
    weekDays: {
        display: 'flex',
        flexDirection: 'row',
        backgroundColor: '#DDD',
        paddingBottom: 0,
        marginBottom: 0,
        paddingLeft: 20,
        justifyContent: 'center',
    },
    weekDay: {
        display: 'flex',
        flexDirection: 'column',
        padding: 15,
        paddingLeft: 15,
        paddingRight: 15,
    },
    day: {
        color: "#AAA",
        fontSize: 15,
    },
    weekDayList: {
        padding: 0,
        borderBottomColor: '#aaa',
        borderBottomWidth: 2,
        margin: 20,
        marginTop: 10,
        marginBottom: 5,
    },
    hourGrid: {
        display: 'flex',
        flexDirection: 'column',
    },
    colorWork: {
        backgroundColor: '#4CD19F',
        minWidth: 20,
        minHeight: 40,
        borderRadius: 10,
        borderRightColor: 'white',
        borderRightWidth: 10,
    },
    colorFree: {
        backgroundColor: '#53C1F2',
        minWidth: 20,
        minHeight: 40,
        borderRadius: 10,
        borderRightColor: 'white',
        borderRightWidth: 10,
    },
    holiday: {
        color: "#53C1F2"
    },
    work: {
        color: "#4CD19F"
    },
    year: {
        textAlign: "center",
        fontSize: 20,
        color: "white",
        marginLeft: 10,
        marginRight: 10,
        marginBottom: -5,
    },
    repeatWeek: {
        marginLeft: 100,
    },
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 22
    },
    modalView: {
        margin: 10,
        backgroundColor: "white",
        borderRadius: 20,
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5
    },
    openButton: {
        backgroundColor: "#F194FF",
        borderRadius: 20,
        padding: 10,
        elevation: 2
    },
    textStyle: {
        color: "white",
        fontWeight: "bold",
        textAlign: "center"
    },
    modalHeader: {
        padding: 10,
        textAlign: "center",
        backgroundColor: '#E71234',
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        marginBottom: 10,
    },
    modalHeaderText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 20,
        marginLeft: 10,
    },
    cross: {
        color: 'white',
        fontSize: 30,
        marginLeft: 190,
        marginRight: 10,
    },
    modalText: {
        borderBottomWidth: 3,
        borderBottomColor: '#aaa',
        fontSize: 25,
        fontWeight: 'bold',
        margin: 10,
        marginLeft: 40,
        marginRight: 40,
        textAlign: 'center',
        color: '#444'
    },
    button: {
        backgroundColor: '#E71234',
        width: 360,
        height: 40,
        borderRadius: 10,
        justifyContent: 'center',
        padding: 10,
        margin: 15,
        marginLeft: 30,
    },
    weekText: {
        margin: 5,
        fontSize: 20,
        padding: 5,
    },
    inputBox: {
        justifyContent: 'center',
        display: 'flex',
        flexDirection: 'row',
    },
    input: {
        margin: 5,
        fontSize: 20,
        padding: 5,
        paddingLeft: 15,
        borderColor: '#ccc',
        elevation: 2,
    }
});