import React from 'react';
import { Keyboard, Picker, TextInput, SafeAreaView, StyleSheet, Text, View, NativeSyntheticEvent, TextInputEndEditingEventData, Platform, StatusBar } from 'react-native';
import { DrawerNavigationProp } from '@react-navigation/drawer';
import { Col, Row, Grid } from "react-native-easy-grid";
type RootStackParamList = {
}
type ProfileScreenNavigationProp = DrawerNavigationProp<RootStackParamList>;

interface Props {
    navigation: ProfileScreenNavigationProp;
}
interface State {

}
export default class HelpScreen extends React.Component<Props, State>  {
    constructor(props: Props) {
        super(props);
    }
    getStatusColor(status: string) {
        switch (status) {
            case "PENDING_BY_EMPLOYEE":
                return '#FFB33E';
            case "PENDING_BY_EMPLOYER":
                return '#707070';
            case "APPROVED":
                return '#50BE64';
            case "REJECTED":
                return '#E71234';
            default:
                return '#FF0F1B';
        }
    }
    render() {
        return (
            <SafeAreaView>
                <View style={styles.item}>
                    <Text style={styles.headerText}>Planning</Text>
                    <View style={styles.subItem}>
                        <View style={[styles.subItemStripe, { borderColor: '#4CD19F' }]} />
                        <Text style={{ fontSize: 16 }}>Werkuren</Text>
                    </View>
                    <View style={styles.subItem}>
                    <View style={[styles.subItemStripe, { borderColor: '#53C1F2' }]} />
                        <Text style={{ fontSize: 16 }}>Vrije dag</Text>
                    </View>
                </View>
                <View style={styles.item}>
                    <Text style={styles.headerText}>Routes</Text>
                    <View style={styles.subItem}>
                        <View style={[styles.subItemStripe, { borderColor: '#FFB33E' }]} />
                        <Text style={{ fontSize: 16 }}>Actie vereist</Text>
                    </View>
                    <View style={styles.subItem}>
                        <View style={[styles.subItemStripe, { borderColor: '#707070' }]} />
                        <Text style={{ fontSize: 16 }}>In afwachting van opdrachtgever</Text>
                    </View>
                    <View style={styles.subItem}>
                        <View style={[styles.subItemStripe, { borderColor: '#50BE64' }]} />
                        <Text style={{ fontSize: 16 }}>Goedgekeurd</Text>
                    </View>
                    <View style={styles.subItem}>
                        <View style={[styles.subItemStripe, { borderColor: '#E71234' }]} />
                        <Text style={{ fontSize: 16 }}>Afgekeurd</Text>
                    </View>
                </View>


                <View style={styles.item}>
                    <Text style={styles.headerText}>Uitbetaling</Text>
                    <View style={styles.subItem}>
                        <View style={[styles.subItemStripe, { borderColor: '#50BE64' }]} />
                        <Text style={{ fontSize: 16 }}>Uitbetaling</Text>
                    </View>
                    <View style={styles.subItem}>
                        <View style={[styles.subItemStripe, { borderColor: '#707070' }]} />
                        <Text style={{ fontSize: 16 }}>Uitbetaling preview</Text>
                    </View>
                </View>
            </SafeAreaView>
        );
    }
}
const styles = StyleSheet.create({
    subItemStripe: {
        borderWidth: 3,
        width: 3,
        borderRadius: 1,
        height: 35,
        marginRight: 10,
    },
    subItem: {
        margin: 10,
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
    },
    item: {
        margin: 20,
        marginBottom: 0
    },
    headerText: {
        borderBottomColor: 'black',
        borderBottomWidth: 1,
        fontSize: 22,
        fontWeight: 'bold',
    },
    routeView: {
        borderLeftWidth: 5,
        height: 60,
        color: 'white',
        textAlign: 'center',
        backgroundColor: 'white',
        padding: 10,
        marginLeft: 20,
        marginRight: 20,
        borderRadius: 10,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        width: 0,
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3,
        marginBottom: 15,
    }
});
