import React from 'react';
import Dash from 'react-native-dash';
import storage from '../../Storage'

import { Jwt } from '../../models/IJwt';
import { Route } from '../../models/IRoute';
import { Company } from '../../models/ICompany';

import { Col, Grid } from "react-native-easy-grid";
import { Image, SafeAreaView, StyleSheet, Text, View, Platform, StatusBar, TouchableWithoutFeedback, Easing } from 'react-native';
import { YellowBox } from 'react-native';

import { StackNavigationProp } from '@react-navigation/stack';
import Icon from 'react-native-vector-icons/Ionicons';

import { ScrollView } from 'react-native-gesture-handler';
import Collapsible from 'react-native-collapsible';
import Spinner from 'react-native-loading-spinner-overlay';

import CompanyService from '../../services/CompanyService';
import RouteService from '../../services/RouteService';
import ExpectedDeclarationService from '../../services/ExpectedDeclarations';

import defaultCompanyImage from '../../../assets/default_company_image.json';

YellowBox.ignoreWarnings([
    'Non-serializable values were found in the navigation state',
]);

type ProfileScreenNavigationProp = StackNavigationProp<{ WorkHours: undefined }, 'WorkHours'>;

//#region Interfaces
/** 
 * Minimal data needed for the payment component, this is an abstraction of the Route interface
 */
interface IPaymentData {
    date: string;
    duration: string;
    amount: number;
    companyName: string;
    distance: number;
    allowanceTypeName: "HOME_TO_WORK" | "WORK";
}

interface IExpectedDeclaration{
    distance: number;
    payout: number;
}

interface IMonthlyPayment {
    totalAmount: number
    totalDistance: number

    companies: Array<ICompanyPayment>
    date: ISimpleDate
}

interface ICompanyPayment extends Company {
    homeToWorkDistance: number
    workDistance: number
    amount: number;
}

interface ISimpleDate {
    year: number,
    month: number,
    lastDay: number,
}
//#endregion

//#region Class interfaces
interface Props {
    navigation: ProfileScreenNavigationProp;
}

interface State {
    paymentsArray: Array<IPaymentData> | undefined,
    companyData: Array<Company> | undefined,
    monthHidden: Array<boolean>,
    spinner: boolean
}
//#endregion

export default class PaymentsOverviewScreen extends React.Component<Props, State>  {
    navigation: ProfileScreenNavigationProp;
    jwt?: Jwt;
    jwtToken?: string;
    companyService: CompanyService;
    routeService: RouteService;
    expectedDeclarationService: ExpectedDeclarationService;

    constructor(props: Props) {
        super(props);

        this.navigation = props.navigation;

        this.routeService = new RouteService(props.navigation);
        this.companyService = new CompanyService(props.navigation);
        this.expectedDeclarationService = new ExpectedDeclarationService(props.navigation);

        this.state = { paymentsArray: [], companyData: [], monthHidden: [], spinner: true };
        this.fetchData = this.fetchData.bind(this);
        this.fetchData();
    }

    async fetchData() {
        // cache
        if (this.state.companyData?.length && this.state.paymentsArray?.length)
            return;

        try {

            const companies = await this.fetchCompanies();
            if (companies)
                this.setState({ companyData: companies });

            const routes = await this.fetchUserRoutes();
            const preview = await this.fetchPreviewPayments()
            const paymentData: Array<IPaymentData> = [
                ...(preview ?? []),
                ...(routes ?? [])
            ];

            if (paymentData)
                this.setState({ paymentsArray: paymentData });
            this.setState({ spinner: false });
        } catch (err) {
            console.log(err);
        };
    }

    //#region Payments
    // TODO: Werkuren preview fetch
    async fetchPreviewPayments(): Promise<Array<IPaymentData>> {
        var currentDate = new Date();
        // Get next month
        var currentMonth = currentDate.getMonth() + 2;

        let previewData = await this.expectedDeclarationService.getExpectedDeclarationsFromUser();

        return [
            {
                date: "1-" + currentMonth + "-2020",
                duration: "0",
                amount: previewData.payout,
                companyName: "Preview",
                distance: previewData.distance,
                allowanceTypeName: "WORK"
            }
        ];
    }
    //#endregion

    //#region Companies
    async fetchCompanies(): Promise<Array<Company>> {
        const response = await this.companyService.getAll();

        const companyData: Array<Company> = response || [];

        return companyData;
    }

    findCompany(companyName: string): Company | undefined {
        return this.state.companyData?.find((company: Company) => company.name === companyName);
    }
    //#endregion

    //#region Routes
    async fetchUserRoutes(): Promise<Array<Route>> {

        const response = await this.routeService.getRoutesByUser();

        const routesData = response || [];
        const routes: Array<Route> = routesData.map((route: any) => this.parseRoute(route))

        return routes;
    }

    parseRoute(route: any): Route {
        var startDT = new Date(route.startTime);
        var endDT = new Date(route.endTime);
        var duration = new Date((endDT as any) - (startDT as any));
        var diffHours = (((duration.getDate() - 1) * 24) + duration.getUTCHours());

        return {
            statusName: route.statusName,
            date: startDT.getDate() + "-" + (startDT.getMonth() + 1) + "-" + startDT.getFullYear(),
            startTime: startDT.getHours() + ":" + (startDT.getMinutes() < 10 ? '0' : '') + startDT.getMinutes(),
            endTime: endDT.getHours() + ":" + (endDT.getMinutes() < 10 ? '0' : '') + endDT.getMinutes(),
            duration: diffHours + ":" + (duration.getMinutes() < 10 ? '0' : '') + duration.getMinutes(),
            amount: +((route.distance / 1000) * 0.19).toFixed(2),
            companyName: route.companyName,
            id: route.id,
            serializedMapRoute: route.serializedMapRoute,
            serializedRoute: route.serializedRoute,
            distance: route.distance,
            startLocation: route.startLocation,
            endLocation: route.endLocation,
            allowanceTypeName: route.allowanceTypeName
        }
    }
    //#endregion

    //#region Groupings
    groupPayments(payments: Array<IPaymentData>): Array<IMonthlyPayment> {
        const monthlyRouteData: Array<IMonthlyPayment> = [];
        const byDate = this.groupByDate(payments);

        for (let _date in byDate) {
            // date as keyof typeof currentRoute simulates k being what you would have expected it to be
            // As for now the statement above blows up when date is not equal to a route, so be aware of this problem
            const paymentDates = byDate[_date as keyof typeof byDate];
            const [year, month] = _date.split(',').map(s => parseInt(s));
            const lastDay = this.lastDayOfMonth(year, month)
            const date: ISimpleDate = { year, month, lastDay, }

            let totalAmount: number = 0, totalDistance: number = 0;

            const companies: Array<ICompanyPayment> = [];
            const byCompany = this.groupByCompany(paymentDates);

            for (let companyName in byCompany) {
                const routes = byCompany[companyName as keyof typeof byCompany];

                let company = this.findCompany(companyName);

                if (!company)
                    if (companyName != "null")
                        company = { image: defaultCompanyImage.imageString, name: "Preview" }
                    else
                        continue;

                const companyData: ICompanyPayment = {
                    ...company,
                    ...routes
                        .map(({ amount, distance, allowanceTypeName }) => ({
                            amount,
                            homeToWorkDistance: distance * (allowanceTypeName === 'HOME_TO_WORK' ? 1 : 0),
                            workDistance: distance * (allowanceTypeName === 'WORK' ? 1 : 0)
                        }))
                        .reduce((acc, route) => ({
                            amount: acc.amount + route.amount,
                            homeToWorkDistance: acc.homeToWorkDistance + route.homeToWorkDistance,
                            workDistance: acc.workDistance + route.workDistance,
                        }))
                }

                totalAmount += companyData.amount
                totalDistance += (companyData.homeToWorkDistance + companyData.workDistance)
                companies.push(companyData)
            }

            monthlyRouteData.push({ totalDistance, totalAmount, companies, date });
        }

        const sortedRouteData = this.sortRouteByDate(monthlyRouteData);

        return sortedRouteData;
    }

    groupByDate<T extends { date: string /*day-year-month*/ }>(entities: Array<T>): Record</*year,month*/string, Array<T>> {
        const dates: Record</*year,month*/string, Array<T>> = {};
        entities.forEach(entity => {
            const [_, month, year] = entity.date.split('-');
            dates[`${year},${month}`] = [
                ...dates[`${year},${month}`] ?? [],
                entity
            ]
        });

        return dates;
    }

    groupByCompany<T extends { companyName: string }>(entities: Array<T>): Record</*company:*/string, Array<T>> {
        const companies: Record</*company:*/string, Array<T>> = {};
        entities.forEach(entity => companies[entity.companyName] = [
            ...companies[entity.companyName] ?? [],
            entity
        ]);

        return companies;
    }
    //#endregion

    //#region sort
    sortRouteByDate(route: Array<IMonthlyPayment>): Array<IMonthlyPayment> {
        return route.sort((a, b) => {
            return (b.date.year * 12 + b.date.month) - (a.date.year * 12 + a.date.month)
        });
    }
    //#endregion

    //#region Dates
    formatYearMonth(year: number, month: number) {
        const monthNames = ["januari", "februari", "maart", "april", "mei", "juni", "juli", "augustus", "september", "oktober", "november", "december"]
        const format = `${monthNames[month - 1]} ${year}`
        const upper = format.charAt(0).toUpperCase() + format.slice(1)

        return upper;
    }

    lastDayOfMonth(year: number, month: number): number {
        return new Date(year, month, 0).getDate();
    }

    lastTwelveMonths(): Array<{ year: number, month: number }> {
        const date = new Date();
        const year = date.getFullYear();
        const months = date.getMonth();
        const prevMonths = 12 - months;

        const thisYearMonths = Array.from({ length: months }, (_, i) => ({ year: year, month: i + 1 }));
        const prevYearMonths = Array.from({ length: prevMonths }, (_, i) => ({ year: year, month: 12 - i }))

        return thisYearMonths.concat(prevYearMonths);
    }
    //#endregion

    //#region Components
    renderPaymentCard(company: ICompanyPayment, navigation: ProfileScreenNavigationProp, date: any) {
        const givenDate = new Date(`${date.date.year}-${date.date.month - 1}-${date.date.lastDay}`);
        const currentDate = new Date();
        const isPreview = company.name === "Preview";
        return (
            <View key={company.name}>
                <View style={[styles.routeView, { borderLeftColor: isPreview ? '#707070' : '#50BE64' }]}>
                    <Grid>
                        <Col size={20} style={styles.routeCol}>
                            <Image source={{ uri: company.image }} style={styles.routeViewImage} />
                        </Col>
                        {isPreview ?
                            <Col size={60} style={styles.routeCol}>
                                <Text style={styles.routeViewInformation}>{this.formatYearMonth(date.date.year, date.date.month)} (preview)</Text>
                                <Text style={styles.routeViewInformation2}>
                                    <Icon name={'md-car'} size={18} style={{ color: '#333' }} /> {((company.homeToWorkDistance + company.workDistance) * 0.001).toFixed()} km 	&nbsp;
                                </Text>
                            </Col>
                            :
                            <Col size={60} style={styles.routeCol}>
                                <Text style={styles.routeViewInformation}>{date.date.lastDay}-{date.date.month}-{date.date.year}</Text>
                                <Text style={styles.routeViewInformation2}>
                                    <Icon name={'md-home'} size={18} style={{ color: '#333' }} /> {(company.homeToWorkDistance * 0.001).toFixed()} km 	&nbsp;
                                    <Icon name={'md-briefcase'} size={16} style={{ color: '#333' }} /> {(company.workDistance * 0.001).toFixed()} km
                                </Text>
                            </Col>
                        }
                        <Col size={20} style={styles.routeCol}>
                            <Text>{'\u20AC'} {
                                (company.amount).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
                            }</Text>
                        </Col>
                    </Grid>
                </View>

            </View>
        );
    };

    toggleHiddenMonth(index: number) {
        const state = this.state.monthHidden;
        const currentMonthState = this.state.monthHidden[index];
        state[index] = !currentMonthState;

        this.setState({ monthHidden: state })
    }
    //#endregion

    render() {
        return (
            <SafeAreaView style={styles.safeAreaView}>
                <ScrollView style={{ overflow: 'scroll' }}>
                    <Spinner
                        visible={this.state.spinner}
                        textContent={'Loading...'}
                        textStyle={styles.spinnerTextStyle}
                    />
                    {
                        (this.state.paymentsArray?.length && this.state.companyData?.length) ?
                            this.groupPayments(this.state.paymentsArray).map((payment, i) => (
                                <View key={i} style={{ marginBottom: 20 }}>
                                    {/* Info bar */}
                                    <View key={i} style={{ flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                                        <View style={{ alignItems: 'center', width: '92%', flex: 1, flexDirection: 'row', justifyContent: 'space-between', borderBottomColor: 'black', borderBottomWidth: 1, marginBottom: 8, }}>
                                            <Text style={{ flex: 0.2 }}>{this.formatYearMonth(payment.date.year, payment.date.month)}</Text>
                                            <Text style={{ flex: 0.3, textAlign: 'right' }}>{(payment.totalDistance * 0.001).toFixed()} km</Text>
                                            <Text style={{ flex: 0.3, textAlign: 'right' }}>{'\u20AC'} {
                                                (payment.totalAmount).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
                                            }</Text>
                                            <TouchableWithoutFeedback onPress={() => this.toggleHiddenMonth(i)}>
                                                <Icon name={this.state.monthHidden[i] ? 'md-arrow-dropdown' : 'md-arrow-dropup'} size={40} style={{ textAlign: 'center', marginRight: 2 }} />
                                            </TouchableWithoutFeedback>
                                        </View>
                                    </View>

                                    <Collapsible duration={100} easing={Easing.ease} collapsed={this.state.monthHidden[i] ?? false}>
                                        {/* Cards */}
                                        {payment.companies.map((company, j) => (
                                            <View key={j}>
                                                {/* Card */}
                                                {this.renderPaymentCard(company, this.navigation, payment)}

                                                {/* Dashed line */}
                                                {(payment.companies.length - 1 > j) ?
                                                    <Dash dashGap={10} dashThickness={1} dashLength={10} dashColor={'#D0CECC'} style={{
                                                        height: 1, marginTop: 10, marginBottom: 10, padding: 0, marginLeft: 20, marginRight: 20,
                                                    }} /> : <View></View>
                                                }
                                            </View>
                                        ))}
                                    </Collapsible>

                                </View>
                            ))
                            : this.state.spinner ?
                                <View>
                                    <Icon style={{ textAlign: 'center' }} name={'md-information-circle-outline'} size={60} />
                                    <Text style={{ textAlign: 'center', margin: 8, fontSize: 32 }}>Aan het zoeken naar uitbetalings informatie.</Text></View>
                                :
                                <View>
                                    <Icon style={{ textAlign: 'center' }} name={'md-information-circle-outline'} size={60} />
                                    <Text style={{ textAlign: 'center', margin: 8, fontSize: 32 }}>Geen uitbetalings informatie gevonden.</Text>
                                    <Text style={{ textAlign: 'center', margin: 20 }}>
                                        Er is geen uitbetalings informatie voor deze gebruiker gevonden.
                                        Mist u data? Probeer opnieuw aan te melden of stuur een bericht naar de administrator.
                                    </Text>
                                </View>
                    }
                </ScrollView>
                <View style={{ paddingBottom: 20 }}></View>
            </SafeAreaView>
        );
    }
}

//#region Styles
const styles = StyleSheet.create({
    spinnerTextStyle: {
        color: '#FFF'
    },
    safeAreaView: {
        backgroundColor: '#EFECEA',
        flex: 1,
        paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0
    },
    routeViewPending: {
        borderLeftColor: '#00D54E',
    },
    routeView: {
        borderLeftWidth: 5,
        height: 60,
        color: 'white',
        textAlign: 'center',
        backgroundColor: 'white',
        padding: 10,
        marginLeft: 20,
        marginRight: 20,
        borderRadius: 10,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 3,
    },
    routeViewImage: {
        alignSelf: 'center',
        height: 35,
        width: 35,
        resizeMode: 'contain',
    },
    routeViewInformation: {
        marginLeft: 35,
        fontWeight: 'bold'
    },
    routeViewInformation2: {
        marginLeft: 35
    },
    routeCol: {
        justifyContent: 'center',
    },
    actionButtonIcon: {
        fontSize: 20,
        height: 22,
        color: 'white',
        elevation: 4,
    },
    input: {
        height: 50,
        backgroundColor: 'white',
        shadowOffset: {
            width: 0,
            height: 1,
        },
        width: '100%',
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
        elevation: 6, borderRadius: 40,
    },
    filter: {
        marginTop: 10,
        fontSize: 20
    },
    filterView: {
        flex: 0,
        flexDirection: 'row',
        marginTop: -10,
        marginBottom: 20,
        marginLeft: 10,
        width: '90%'
    }
});
//#endregion

