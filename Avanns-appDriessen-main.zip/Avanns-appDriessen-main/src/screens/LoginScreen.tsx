import React from 'react';
import { Image, Platform, SafeAreaView, StatusBar, StyleSheet, Text, View, KeyboardAvoidingView } from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';


import storage from '../Storage'

import logo from "../../assets/icon.png";
import lock from '../../assets/lock.png'
import user from '../../assets/user.png'

import FormTextInput from "../components/FormTextInput";
import FormButton from "../components/FormButton";
import HorizontalLine from "../components/HorizontalLine";
import { StackNavigationProp } from '@react-navigation/stack';
import { User } from '../models/IUser';
import UserService from '../services/UserService';


type RootStackParamList = {
    LoginScreen: undefined,
    Dashboard: any,
};

type RootStackNavigationProp = StackNavigationProp<RootStackParamList, 'LoginScreen'>;

interface Props {
    navigation: RootStackNavigationProp;
}

interface State {
    username: string;
    password: string;
    spinner: boolean;
    errorMessage: string | undefined;
}
interface Jwt {
    email: string,
    sub: string,
    nbf: string,
    exp: number,
    iat: string
}

export default class LoginScreen extends React.Component<Props, State> {
    jwt: Jwt | undefined;
    jwtToken: string | undefined;
    userService: UserService;

    constructor(props: Props) {
        super(props);

        this.userService = new UserService(props.navigation);

        this.state = {
            username: "",
            password: "",
            spinner: false,
            errorMessage: undefined,
        };
        storage.getItem(storage.jwtKey)
            .then((element) => {
                if (element) {
                    this.setState({ spinner: true });
                    this.jwtToken = element;
                    var base64Url = element.split('.')[1];
                    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
                    var jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
                        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
                    }).join(''));
                    this.jwt = JSON.parse(jsonPayload);
                    if (this.jwt) {
                        let expDate = new Date(this.jwt.exp * 1000);
                        let currDate = new Date();
                        if (currDate < expDate) {
                            this.setUserData();
                        } else {
                            storage.removeItem("jwt");
                            this.setState({ spinner: false });
                        }
                    }

                }
            })
            .catch(error => console.error(error));
    }
    setUserData = async () => {
        if (this.jwtToken) {
            if (!this.jwt) {
                var base64Url = this.jwtToken.split('.')[1];
                var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
                var jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
                    return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
                }).join(''));
                this.jwt = JSON.parse(jsonPayload);
            }
            if (this.jwt?.sub) {
                let responseJson: User = await this.userService.get(this.jwt.sub)

                if (!responseJson.image) {
                    responseJson.image = "data:image/jpeg;base64,/9j/4QBsRXhpZgAASUkqAAgAAAADADEBAgAHAAAAMgAAABICAwACAAAAAQABAGmHBAABAAAAOgAAAAAAAABQaWNhc2EAAAMAAJAHAAQAAAAwMjIwAqAEAAEAAACfAQAAA6AEAAEAAACfAQAAAAAAAP/uAA5BZG9iZQBkwAAAAAH/2wCEAAYEBAQFBAYFBQYJBgUGCQsIBgYICwwKCgsKCgwQDAwMDAwMEAwODxAPDgwTExQUExMcGxsbHB8fHx8fHx8fHx8BBwcHDQwNGBAQGBoVERUaHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fH//AABEIAZ8BnwMBEQACEQEDEQH/xACFAAEAAgMBAQEAAAAAAAAAAAAABgcDBAUIAgEBAQAAAAAAAAAAAAAAAAAAAAAQAQABAwICBQgFCQcCBwAAAAABAgMEEQUxBiFBURIHYXGBoSIyExSRsUJiI8HRUnKCkqKyFeHCQ1NzJBczk2ODwzRUJVURAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/APRgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMGXmYeHa+Ll37ePb/Tu1RRE+bXiCLbj4qco4czTZu3M2uOqxTPd/eq0gEdzPGm/MzGFtlNMdVd+5Mz+7TGnrByL/AIt823J9j5axHV3LMzP8VUg1f+T+dP8A5lP/AGrf5gfseKHOcTE/N0T5JtW9PVANvH8XOarcx8SjGvU9fet1Uz9NNX5AdjC8aZ1iM7a+jrqsXNZ/driPrBJdt8TeUc2YpqyqsS5P2cimaY17O9GsAk1i/YyLUXbF2i9anhct1RVT9MagyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5W/cz7LsVn4m4ZEUVzGtFin2r1XmojpBWu++Lm7ZXetbVajBsz0Rdr0rvTH8tPrBCMzOzs69N7Mv3Mi7PGu7VNU+sGsAAAAAAADd27d9z227F3AybmNXHXbqmInzxwkE72Hxgy7U02t7x4v2+E5NiIpuR5aqPdn0aAsjZ992nd8f4+3ZNF+j7VMdFdPkqpnpgG+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4u3bVm1Xdu1027VuJqruVTpTTEdczIKy5s8WKpmvE2DojpirPqjp/wDKpn+aQVtkZF/IvV38i5VevVzrXcrmaqpme2ZBhAAAAAAAAAAABs4O4Zu35NOThXq8e/R7ty3Ok/2gtLlLxVx8qqjD3zu4+ROlNGZTGlqqfvx9ifLw8wLEiYmImJiYmNYmOmJiewAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGnum7YG1YNzNzrsWMe3xqnjM9VNMdcz2ApTnHnncuYr02omcfbKJ/CxYn3tOFV3TjPk4QCLgAAAAAAAAAAAAAAAmnJHiJl7JVRhZ81ZG0zOkRxrs69dHbT936AXLh5WNl41vKxrlN7HvUxVbuUzrExIMwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANXc9yw9twbudmXItY9mNa6p9URHXM9QKI5t5szuY8/416Zt4lqZjFxYn2aI7Z7ap65BwQAAAAAAAAAAAAAAAAASvkfnfI5ey/hXpqu7Ten8azrr3J/zKI7e2OsF34+RYyrFvIx64u2LtMV27lM6xVTPCYBlAAAAAAAAAAAAAAAAAAAAAAAAAAAAB+VVU0UzXXMU0UxM1VT0RER0zMgo7xA5yub/uHwMeqY2rFqmLFP+ZVwm7V/d8gIkAAAAAAAAAAAAAAAAAAACe+GfOk7blU7RnXP/r8ir8Cuqeizdn+7V9YLiAAAAAAAAAAAAAAAAAAAAAAAAAAAABXXixzXONjxsWJXpfyKYrzaon3bU8KP2+vyAqUAAAAAAAAAAAAAAAAAAAAAF2eGfNc7vtXyOVX3twwYimZnjctcKavPHCQTMAAAAAAAAAAAAAAAAAAAAAAAAAAGnu26Y+1bbk7hkf8ASxqJrmOuZ4U0x556Aedtxz8ncc+/nZNXev5Fc3K57NeER5IjogGqAAAAAAAAAAAAAAAAAAAAADqct71e2TecbcLWulqrS9RH2rVXRXT9HrB6HsX7WRYt37NUV2btMV2644TTVGsSDIAAAAAAAAAAAAAAAAAAAAAAAAACs/GLfZpoxdktVdNX+4yojs4W6Z9cgqwAAAAAAAAAAAAAAAAAAAAAAAFyeEm+zmbHc227Vre2+r8PXjNm5Osfu1awCdgAAAAAAAAAAAAAAAAAAAAAAAAaxHTM6RHTM+QHnfmrdat15izs6Z1ouXppteS3R7NOnojUHIAAAAAAAAAAAAAAAAAAAAAAABKfDfdv6dzbi96dLOXrjXez2/dn97QF7AAAAAAAAAAAAAAAAAAAAAAAAA4/OG4zt3LO45dM6V0Waqbc9ldfsU+uoHniI0jTsAAAAAAAAAAAAAAAAAAAAAAAABkt3Llq5Rdtzpct1RXRPZVTOsT9IPSW3ZlGbt+Nm0e7kWqLsft0xINkAAAAAAAAAAAAAAAAAAAAAAAEG8XcubXLFuxE9OTkUUzH3aImqfXEApkAAAAAAAAAAAAAAAAAAAAAAAAAF8+G2ZOVydt8zOtVnv2av2K50/hmASYAAAAAAAAAAAAAAAAAAAAAAAFZeNV6fhbTZjrqvVz9FEQCrQAAAAAAAAAAAAAAAAAAAAAAAAAXJ4PXpr5byLUzr8LKqmPNVRT+YE7AAAAAAAAAAAAAAAAAAAAAAABVXjT/AO72v/TufzQCtQAAAAAAAAAAAAAAAAAAAAAAAAAW34MVzO07jT1U36Jj00T+YFiAAAAAAAAAAAAAAAAAAAAAAAAq3xqtz8babnVNN2n6Jpn8oKyAAAAAAAAAAAAAAAAAAAAAAAAABb/g3b02HOr09/IiNe3u0f2gsAAAAAAAAAAAAAAAAAAAAAAAAFeeM2PNW07fkadFq/XRM/6lGv8A6YKjAAAAAAAAAAAAAAAAAAAAAAAAABdvhPj/AAuUaK9P+vfu3InyRpR/cBMgAAAAAAAAAAAAAAAAAAAAAAARXxMwvmuT8uYjWrHmi/T+xVpVP7syCigAAAAAAAAAAAAAAAAAAAAAAAAAeh+UMKcHljbcaY0qpsU1Vx2VV+3V66gdgAAAAAAAAAAAAAAAAAAAAAAAGDNw7eZhX8S5GtvIt1Wqo8lcTAPNuRj3cbIu412NLtiuq3X56J0n6gYQAAAAAAAAAAAAAAAAAAAAAAAdHl/batz3vCwIjWMi9TTXH3InWv8AhiQejoiKYimOEdEeaAAAAAAAAAAAAAAAAAAAAAAAAAAUp4qbNO38zVZdFOljcaYvRPV8SPZrj8oIWAAAAAAAAAAAAAAAAAAAAAAACxfB3Zpu7jlbtdp/DxaPgWZ/8S5730UwC2gAAAAAAAAAAAAAAAAAAAAAAAAARbxG2Cd45buzap72XgzN+xEcZ0j26Y89PriAUSAAAAAAAAAAAAAAAAAAAAAAD7ooruV026KZqrrmKaKY4zMzpEQD0LylsVOx7BjYOkfHiPiZVUdd6vpq+jh6AdcAAAAAAAAAAAAAAAAAAAAAAAAAAFGeIvLE7Jv1dyzTpgZszdxp6qapn27fonh5ARMAAAAAAAAAAAAAAAAAAAAAE98KuWJ3DdZ3fIo1w8GfwdeFd/q/cjpBcQAAAAAAAAAAAAAAAAAAAAAAAAAAAORzRy9i7/s93AvaU1z7ePd/QuR7s+bqkFAZ2FlYObew8qibeRYqmi5RPVMfknqBrAAAAAAAAAAAAAAAAAAAA6OxbLm7zulnb8SnW5dn2q+qiiPerq8kA9A7PtWJtW22NvxadLNinSJ66p+1VV5apBugAAAAAAAAAAAAAAAAAAAAAAAAAAAAhniJyPG94nz2FTEbtj06RTHR8aiPsT96Ps/QClqqaqappqiaaqZmKqZ6JiY4xMA+AAAAAAAAAAAAAAAAAAZsbGyMrIt4+Pbqu37tUU27dMazVM9UAvTkfk+xy7t+lelzcciInKvR0xHZbpn9Gn1gkoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIH4geHlO6xXum1URRuURresR0RfiOuPv/WCoLlu5buVW7lM0XKJmmuiqNJiY4xMSDGAAAAAAAAAAAAAAADPh4mTmZNvGxbVV7Iuz3bduiNZmZBdXIvIdjYLMZWTpf3W7TpXXHTTaieNFH5ZBLgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARTnLw/wN/pqybMxi7pEezf09m5p1XIj+biCmt22fctozasTcLFVm9Hu69NNUdtNXCqAaAAAAAAAAAAAAAAOry/y3uu+5fy+Ba70RP4t+rot247aqvycQXRynyXtXL1jW1Hx86uNL2XXHtT92iPs0gkQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANLddm23dsScXcLFN+zPDve9TPbTVHTTPmBVvMnhNuWJNd/ZapzseOn5erSL1MeTqr+sEEvWbtm7VavUVWrtPRVbriaao9EgxAAAAAAAAAA2MTDy8y/Tj4lmvIv1dFNu3TNVX0QCwuWvCO/cmjI3+58Kjj8nanWuf1646I80As3B2/C2/GoxcKzRj49Hu27caR5/LINgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHO3jl7Zt4t9zccSi/PCm5MaXKfNXHSCCbv4N25ma9ozZo7LGTGseiunp+mJBD9x8P+bsCZm7t9d63H+JY0u06dvs9MemAcG7ZvWappu26rdUdExXTNP1gxaxPAAACZiOMgzWMbJyK4osWa7tVXCKKZq1+gEi27w45uzpiYwpxrc/4mTMW9P2Z1r9QJjs/g5g25pubtl1ZE9dix+HR5pqn2p9QJztez7VtVn4O34tvGt8J7kaTP61XGQboAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOZmcy7Dh5VvEydxs2sm5VFNNqao1iZ4d7T3fSDpgAAAAAAAxX8fHyI0yLNu9HZcopr/AJokHMv8n8q351vbVjVfsd3+WYBq/wDHvJX/AOXa+mr84EeHvJUTE/0q1OnVM1TH1g3MflPlfFmJsbXjUTHD2Iq/m1B1LNqzZp7tm3Rap/Rt0xRH0UxAPoAAAAAAH5XXRRRVXXVFNFMa1VTOkREdcyDBh52Fm2YvYV+3kWp+3aqiuPUDYAAAAAAAAAAAAAAAAAAAAAAAAABH+ZeeNj2GmaMi58bM01pxLWk1+TvTwojzgq3mHxJ5i3aarVq58hhz0RZsTMVTH3rnvT6AROemZmemZ6ZkE15P8Stw2eKMPcO9mbbHRTMzrdtR92Z96PuyC3dr3bbt2xYysC/TfszxmnjTPZVHGmfODcAAAAAAAAAAAAAAAAABzd85h2nY8b5jcL8W4nX4dqOm5XMdVNPWCneb/EDdeYKqsejXE2yJ9nGpnpr8t2rr83AEe2/c9w2+/F/ByLmNej7duqY188cJ9ILD5c8XrlM0Y+/2e/Tw+dsxpVHlrt9foBZO37lg7hjU5OFfoyLFXCuidY809k+SQbIAAAAAAAAAAAAAAAAAAAAAMV+/Yx7Nd+/cptWbcTVcuVzpTTEdczIKs5v8Vb9+a8LYJmzY92vOmNLlX+nE+7Hl4gruuuu5VNddU1V1TrVVVMzMzPXMyD4AABvbXvG5bTlRk7fkV49+OM0z7NUdlVPCqPOCz+WfFzAyu5j77b+Uvz0fNURM2ap+9HvUesE+x8jHyLVN7HuU37FfTTct1RVTPmmAZAAAAAAAAAAAAAAa+dnYWBYqyMy/Rj2KeNy5MUx/aCu+ZfF23TFWPsNrv1cJzb0aUx+pR1+eQVrm52Zn5NeTmXq8jIr965cnWfN5I8kA1gAAdHZd/wB22bKjJ26/Var+3RxoriOqunhILi5Q8QNt3+Kce7pibnp048z7NfbNuqePm4glgAAAAAAAAAAAAAAAAAAANPdd3wNqwrmbnXYtWLfXPGqeqmmOuZBSPN/O+4cxX5onXH26idbOJE8eyq5p71X1AjQAAAAAAOjtO/bxtF34m3ZVePMzrVRE60VfrUTrTIJ/svjLMd23vOHr25eN9c26vySCb7Vzfy1usR8nn26rk/4Nc/Duebu1aa+gHYAAAAAAAAAnojWeEcZBwt2545X2uJjIz6K7sf4Nj8av+Hoj0yCC714xZt2KrWzYlOPTPRGRf9uv0UR7MekED3Hddy3K/wDHz8m5k3eqa51iP1Y4R6AaYAAAAAPumqqiqK6KpprpnWmqmdJiY4TEwC1OQ/EuMibe1b9ciL86UYudV0RXPCKbnZV94FkAAAAAAAAAAAAAAAAAA0t33bB2nAu5+dc+Hj2o6f0qp6qaY65kFFc1815/MWfN+/8Ah41uZjGxon2aKe2e2qeuQcIAAAAAAAAAAHW23mnmPboiMPcL1qinhbmrv0R+xX3qfUCSYPi9zNZ0jIs4+VTHbTNuqfTTMx6gdrG8acedPmtqriev4NyJ/miAdG14wcs1R+JZybU9ncir6pBn/wCWuTf8zJ/7E/nA/wCWuTf08n/sT+cGve8YuWqI/Cx8m7PZ3aaPrkHNyvGqjSflNqmZ6vj3Yj+SJBw83xa5qvxMWIsYlM8Joo79UemuZj1Aje4cw75uOsZ2fev0zxoqrmKP3I0p9QOaAAAAAAAAAACzvDrxAmKrezbxe1pnSnCy656YnqtV1T/DILRAAAAAAAAAAAAAAABjysnHxce5k5FyLVixTNd25V0RFMcZBRHOvN+RzHuHejW3t9iZjEsT2fp1feq9QI2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC3fDXnic6inZdzua5tuNMS9VPTdoj7EzP249cAsIAAAAAAAAAAAAAAFP+J/OU5+VVs2Fc/2OPV/ua6Z6Lt2nq/Vo+sEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABktXbtm7Res1zbu26oqt10zpNNUdMTAL25F5tt8xbVFVyYp3HG0oy7cdc9VymOyr6wSUAAAAAAAAAAAAEO8SebP6JtXyuLXpuOdE025jjbt8Krnn6oBSIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOry1v2VsW7Wc+xrNNM92/a6q7c+9TP5PKD0Fg5uNnYNnMxa/iY+RRFduqOye3yx1g2AAAAAAAAAAAYM3Nx8LEvZmTV3LFiiblyqeqIB565i3rI3vd7+4X+ibs6WqP0Lce5THmgHMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABZPhLzR8G/VsGTX+FembmFM9VzjXR+1xgFrAAAAAAAAAAArLxe5jmmmzsGPX72l/N07P8OifrBVoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMti/ex79u/Zqmi/aqiu3XHGKqZ1iQeheWN9tb5seNuNGkV3I7t+iPs3aeiuPp6QdUAAAAAAAAGtuWfY2/AyM2/OlnHt1XK/L3Y4R5Z4QDzrum45G5bjkZ+ROt7Jrmurya8KY8kR0A0wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAT7wl5hnD3a5tN6r/AG+f02teFN6iP71PQC4QAAAAAAAAVx4wb78HCxtmtVe3kz8bJ0/y6J9iPTV0+gFTgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzY9+7j37d+zVNF2xVTXbqjjFVM6xP0g9FbFutrddoxNxt6aZFuKqqY+zXwrp9FQN8AAAAAADojpnhHEHnnm7eJ3jmHMzYq1tTX8PH/0rfs06efiDjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtTwb3rvWczZrlXTbn5nFieyroriPTpILLAAAAAABH+fN3nbOVs2/TV3b92n5ezPCe/e6OjzU6yCgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdrk7d/wClczYObNXdtRci3f7Ph3PZq182uvoB6FAAAAAABVvjNumtzbtqpnopirIux5Z9miJ+iZBWQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPQ/KG6f1Plnb8uZ71yq1FF2evv2/Yq18+moOwAAAAACguf8Acf6hzduFyJ1t2q4sW/1bUafXqCOgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtzwb3D4m0ZuBVPTjXou0R927Gk+ukFhgAAAAxZN+jHx7t+udKbVFVdU9kUxqDzVfv1379y/X796uq5V565mqfrBiAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOPCLN+BzPXjzOlOXj1U+eqiYqp/KC5wAAAAcbnK5et8rbpVZpqqu/L10xFETM+1HdmejsjpB55AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABIOQ7t21zftddqmqv8AG0qppiZnu1UzTM6R1RxBf4AAP//Z";
                }
                await storage.setItem("user", JSON.stringify(responseJson));
                await storage.setItem("userLoggedIn", "true");


                this.setState({
                    password: "",
                    errorMessage: ""
                });

                this.props.navigation.push("Dashboard", { screen: "Routes", params: { screen: "Routes", params: { user: responseJson, jwt: this.jwt, jwtToken: this.jwtToken } } });
            }
        }

        this.setState({ spinner: false });
    }

    async onLogIn() {
        this.setState({ spinner: true });
        try {
            const response = await this.userService.authenticate({
                email: this.state.username,
                password: this.state.password
            });

            if (response.status !== 200) {
                let responseBody = await response.json();
                let errorMessage = "";
                if (responseBody.errors) {
                    if (responseBody.errors.Email) {
                        errorMessage = responseBody.errors.Email[0];
                    } else if (responseBody.errors.Password) {
                        errorMessage = responseBody.errors.Password[0];
                    } else {
                        errorMessage = "Er is iets fout gegaan. Probeer later opnieuw!"
                    }
                } else if (response.status == 401) {
                    errorMessage = "De gebruikersnaam of het wachtwoord wat je invoerde is niet correct."
                }

                await storage.removeItem(storage.jwtKey);
                this.setState({
                    password: "",
                    errorMessage
                });
                this.setState({ spinner: false });
                return;
            }

            const responseBody = await response.json();
            const jwt = responseBody.jwt;

            await storage.setItem(storage.jwtKey, jwt);
            this.jwtToken = jwt;
            this.jwt = undefined;
            this.setUserData();
        } catch (error) {
            console.error(error);
            this.setState({ spinner: false });
        }
    }

    render() {
        return (
            <KeyboardAvoidingView style={styles.safeAreaView}>
                <SafeAreaView style={styles.safeAreaView}>
                    <Spinner
                        visible={this.state.spinner}
                        textContent={'Loading...'}
                        textStyle={styles.spinnerTextStyle}
                    />

                    <Image source={logo} style={styles.logo} />

                    <View>
                        <View style={{ width: "80%", alignSelf: "center", }}>
                            <Text style={{ color: "white", fontSize: 16, }}>{this.state.errorMessage || ""}</Text>
                        </View>
                        <FormTextInput placeholder="Email" autoCapitalize="none" autoCompleteType="email"
                            textContentType="emailAddress" value={this.state.username}
                            keyboardType="email-address" icon={user}
                            onChangeText={(value: string) => this.setState({ username: value })} />
                        <FormTextInput placeholder="Wachtwoord" secureTextEntry={true} value={this.state.password}
                            autoCompleteType="password" textContentType="password" icon={lock}
                            onChangeText={(value: string) => this.setState({ password: value })} />

                        <HorizontalLine />
                        <FormButton title="Log in" onPress={this.onLogIn.bind(this)} />
                    </View>

                    <View style={styles.bottomTextContainer}>
                        <Text style={styles.bottomText}>Reiskosten tracker &copy; 2020</Text>
                        <Text style={styles.bottomText}>Powered by Driessen</Text>
                    </View>
                </SafeAreaView>
            </KeyboardAvoidingView>

        );
    }

}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: "center"
    },
    horizontal: {
        flexDirection: "row",
        justifyContent: "space-around",
        padding: 10
    },
    safeAreaView: {
        backgroundColor: '#D7152D',
        flex: 1,
        paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0
    },
    logo: {
        alignSelf: 'center',
        marginVertical: 40
    },
    bottomTextContainer: {
        flex: 1,
        justifyContent: 'flex-end',
        marginBottom: 20
    },
    bottomText: {
        color: 'white',
        textAlign: 'center'
    },
    spinnerTextStyle: {
        color: '#FFF'
    },
});
