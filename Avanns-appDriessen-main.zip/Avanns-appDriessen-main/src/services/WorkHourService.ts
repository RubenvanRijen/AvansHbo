import { AbstractService } from "./AbstractService";
import { WorkHour } from "../models/IWorkHour";

export default class WorkHourService extends AbstractService<WorkHour, any>  {
    constructor(navigation: any) { super("WorkHours/", navigation) }

    async getWorkHoursByUser(params: string = ""): Promise<Array<WorkHour>> {
        if (await this.jwtService.isJwtExpired())
            this.navigation.navigate('Login')

        const jwt = await this.jwtService.getJwt();
        if (!jwt)
            throw new Error("No JWT found");

        const userId = (await this.jwtService.getJwtPayload())?.sub;
        const headers = {
            'Accept': 'application/json',
            'Authorization': `Bearer ${jwt}`,
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
        };
        const url = `${this.hostURL}${this.path}User/${userId}?${params}`;

        return await fetch(url, { headers })
            .then((response) => { if (response.ok) { return response.json() } else { return null } })
            .then((responseJson) => {
                return responseJson;
            });
    }
}