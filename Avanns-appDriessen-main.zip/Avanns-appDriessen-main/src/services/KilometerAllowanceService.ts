import { AbstractService } from "./AbstractService";
import { KilometerAllowance } from "../models/IKilometerAllowance";

interface Input {
    email: string,
    firstName: string,
    lastName: string,
    accountNumber: string
}

export default class KilometerAllowanceService extends AbstractService<KilometerAllowance, Input>  {
    constructor(navigation: any) { super("KilometerAllowances/", navigation) }

    async getKilometerAllowanceByUser(): Promise<Array<KilometerAllowance>> {
        if (await this.jwtService.isJwtExpired())
            this.navigation.navigate('Login')

        const jwt = await this.jwtService.getJwt();
        if (!jwt)
            throw new Error("No JWT found");

        const userId = (await this.jwtService.getJwtPayload())?.sub;
        const headers = {
            'Accept': 'application/json',
            'Authorization': `Bearer ${jwt}`,
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
        };
        const url = `${this.hostURL}${this.path}Users/${userId}`;

        return await fetch(url, { headers })
            .then((response) => { if (response.ok) { return response.json() } else { return null } })
            .then((responseJson) => {
                   return responseJson;
            });
    }
}