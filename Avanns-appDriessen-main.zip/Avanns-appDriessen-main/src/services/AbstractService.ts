import JwtService from "./JwtService";

// @ts-ignore // Works just fine, typescript just doesn't like it
import { API_URL } from 'react-native-dotenv';
import { StackNavigationProp } from "@react-navigation/stack";

type RootStackParamList = {
    Login: {},
};
type NavigationProp = StackNavigationProp<RootStackParamList>;

export abstract class AbstractService<Model, Input> {
    hostURL = `${API_URL}/api/`;
    jwtService = new JwtService();

    constructor(public path: string, public navigation: NavigationProp) { }

    create = async (data: Input): Promise<Model> => this.genericFetch("POST", { data })
    get = async (id: string): Promise<Model> => this.genericFetch("GET", { id })
    getAll = async (): Promise<Array<Model>> => this.genericFetch("GET")
    update = async (id: string, data: Input): Promise<Model> => this.genericFetch("PUT", { id, data })
    delete = async (id: string): Promise<Model | null| undefined> => this.genericFetch("DELETE", { id })

    protected rmvBackSlash = (str: string) => str.replace(/\/$/, "");

    protected async genericFetch(method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE', options: { id?: string, data?: {}, params?: {} } = {}) {
        if (await this.jwtService.isJwtExpired())
            this.navigation.navigate('Login')

        const jwt = await this.jwtService.getJwt();

        if (!jwt)
            throw new Error("No JWT found");

        const { id, data, params } = options;
        const _url = this.hostURL
        const _path = this.rmvBackSlash(this.path)
        const _id = id ? '/' + id : ''
        const _param = Object.entries(params || {}).reduce((acc, [key, value]) => `${key}=${value}&`, "?").slice(1, -1)
        const _body = data ? { body: JSON.stringify(data) } : {}

        const url = `${_url}${_path}${_id}${_param}`
        const headers = {
            'Accept': 'application/json',
            'Authorization': `Bearer ${jwt}`,
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
        };

        const content = { method, headers, ..._body };
        try {
            return fetch(url, content).then((response) => { if (response.ok) { return response.json() } else { return null } });
        } catch (err) {
            return null;
        }
    }
}