import { AbstractService } from "./AbstractService";
import { User } from "../models/IUser";

export default class UserService extends AbstractService<User, any>  {
    constructor(navigation: any) { super("Users/", navigation) }
    async authenticate(data: {}) {
        const headers = {
            'Accept': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
        };
        const url = `${this.hostURL}authentication`;
        const _body = data ? { body: JSON.stringify(data) } : {}
        const method = "POST"
        const content = { method, headers, ..._body };

        return await fetch(url, content);
    }
}