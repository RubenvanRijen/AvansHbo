import { AbstractService } from "./AbstractService";
import { Holiday } from "../models/IHoliday";

export default class HolidayService extends AbstractService<Holiday, any>  {
    constructor(navigation: any) { super("Holidays/", navigation) }

    async getHolidayByUser(params: string = ""): Promise<Array<Holiday>> {
        if (await this.jwtService.isJwtExpired())
            this.navigation.navigate('Login')

        const jwt = await this.jwtService.getJwt();
        if (!jwt)
            throw new Error("No JWT found");

        const userId = (await this.jwtService.getJwtPayload())?.sub;
        const headers = {
            'Accept': 'application/json',
            'Authorization': `Bearer ${jwt}`,
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
        };
        const url = `${this.hostURL}${this.path}/${userId}/Users?${params}`;

        return await fetch(url, { headers })
            .then((response) => { if (response.ok) { return response.json() } else { return null } })
            .then((responseJson) => {
                return responseJson;
            });
    }
}