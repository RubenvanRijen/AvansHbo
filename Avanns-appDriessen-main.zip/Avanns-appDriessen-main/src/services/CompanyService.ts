import { AbstractService } from "./AbstractService";
import { Company } from "../models/ICompany";
import { StackNavigationProp } from "@react-navigation/stack";

interface Input {
    email: string,
    firstName: string,
    lastName: string,
    accountNumber: string
}

export default class CompanyService extends AbstractService<Company, Input>  {
    constructor(navigation: any) { super("Companies/", navigation) }

    async getCompanyByUser(): Promise<Array<Company> | undefined> {
        if (await this.jwtService.isJwtExpired())
            this.navigation.navigate('Login')

        const jwt = await this.jwtService.getJwt();
        if (!jwt)
            throw new Error("No JWT found");

        const userId = (await this.jwtService.getJwtPayload())?.sub;
        const headers = {
            'Accept': 'application/json',
            'Authorization': `Bearer ${jwt}`,
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
        };
        const url = `${this.hostURL}${this.path}Users/${userId}`;

        return await fetch(url, { headers })
            .then((response) => { if (response.ok) { return response.json() } else { return null } })
            .then((responseJson) => {
                if (responseJson) {
                    var companyData: Array<Company> = responseJson.map(function (obj: Company): Company {
                        return {
                            name: obj.name,
                            image: obj.image
                        }
                    });
                    return companyData;
                }
            });
    }
}