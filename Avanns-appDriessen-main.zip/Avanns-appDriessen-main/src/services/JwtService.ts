import { Jwt } from '../models/IJwt';

import storage from '../Storage';

// @ts-ignore // Works just fine, typescript just doesn't like it
import { API_URL } from 'react-native-dotenv';

export default class JwtService {
    hostUrl = `${API_URL}/api`;
    path = "/authentication"

    public async authorize(username: string, password: string) {
        const response = await fetch(this.hostUrl + this.path, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Accept: 'application/json',
            },
            body: JSON.stringify({
                email: username,
                password: password,
            }),
        })

        if (response.status !== 200) {
            this.removeJwt();
            throw Error("Invalid password or username.")
        }

        const responseBody = await response.json()
        const jwt = responseBody.jwt

        this.setJwt(jwt);
        return jwt;
    }

    public async getJwt(): Promise<string | null | undefined> {
        return await storage.getItem(storage.jwtKey);
    }

    public async isJwtExpired(): Promise<boolean> {
        const jwt = await this.getJwtPayload();
        if (jwt) {
            let expDate = new Date(jwt.exp * 1000);
            let currDate = new Date();
            if (currDate < expDate) {
                return false;
            } else {
                this.removeJwt();
                return true;
            }
        }
        return true;
    }

    public async getJwtPayload(): Promise<Jwt | null> {
        const jwt = await this.getJwt();
        if (jwt)
            return await this.parseJwt(jwt);
        return null;
    }

    public setJwt(jwt: string) {
        return sessionStorage.setItem('jwt', jwt);
    }

    public removeJwt() {
        storage.removeItem("jwt");
    }

    private parseJwt(jwt: string | null): Jwt | null {
        if (!jwt) return null;

        const jwtBody = atob(jwt.split('.')[1]);
        return JSON.parse(jwtBody);
    }
}