import { AbstractService } from "./AbstractService";
import { Route } from "../models/IRoute";

export default class RouteService extends AbstractService<Route, any>  {
    constructor(navigation: any) { super("Routes/", navigation) }

    async getRoutesByUser(params: string = ""): Promise<Array<Route>> {
        if (await this.jwtService.isJwtExpired())
            this.navigation.navigate('Login')

        const jwt = await this.jwtService.getJwt();
        if (!jwt)
            throw new Error("No JWT found");

        const userId = (await this.jwtService.getJwtPayload())?.sub;
        const headers = {
            'Accept': 'application/json',
            'Authorization': `Bearer ${jwt}`,
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
        };
        const url = `${this.hostURL}${this.path}User/${userId}?${params}`;

        return await fetch(url, { headers })
            .then((response) => { if (response.ok) { return response.json() } else { return null } })
            .then((responseJson) => {
                return responseJson;
            });
    }
}