export interface Route {
    statusName: string;
    date: string;
    startTime: string;
    endTime: string;
    duration: string;
    amount: number;
    startLocation: string;
    endLocation: string;
    companyName: string;
    id: string;
    serializedMapRoute: string;
    serializedRoute: string;
    distance: number;
    allowanceTypeName: "HOME_TO_WORK" | "WORK";
}