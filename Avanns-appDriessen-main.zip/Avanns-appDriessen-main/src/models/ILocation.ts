export interface ILocation {
    timestamp: number;
    coords: {
        accuracy: number;
        altitude: number;
        heading: number;
        latitude: number;
        longitude: number;
        speed: number;
    };
}