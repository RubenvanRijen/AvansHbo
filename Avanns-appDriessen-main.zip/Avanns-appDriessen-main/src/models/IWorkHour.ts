export interface WorkHour {
    userID: string,
    startDateTime: Date,
    endDateTime: Date,
    id: string,
}