export interface User {
    firstName: string,
    lastName: string,
    image: string,
    email:string,
    accountNumber: string,
    password: string,
    roleName: string,
}