export interface Jwt {
    email: string,
    sub: string,
    nbf: string,
    exp: number,
    iat: string
}