export interface Placement {
    companyName: string;
    id: string;
}