export interface Company {
    name: string;
    image: string;
}