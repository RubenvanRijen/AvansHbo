export interface Holiday {
    userId: string,
    date: Date,
    id: string,
}