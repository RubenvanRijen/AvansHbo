export interface KilometerAllowance {
    allowanceTypeName: "HOME_TO_WORK" | "WORK",
    companyName: string,
    id: string,
    minDistance: number,
    price: number
}