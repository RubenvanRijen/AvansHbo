import * as TaskManager from 'expo-task-manager';

import { Notifications, Constants } from 'expo';
import * as Location from 'expo-location';
import * as Permissions from 'expo-permissions';
import { EventEmitter } from 'fbemitter';
import OverviewScreen from '../screens/routes/RouteOverviewScreen';

import { ILocation } from '../models/ILocation';
import { Route } from '../models/IRoute';

import { Platform, Vibration } from 'react-native';

// @ts-ignore // Works just fine, typescript just doesn't like it
import { API_URL } from 'react-native-dotenv';

const VIBRATION_DURATION = 500;

const LOCATION_TRACKER = 'background-task-location';
const eventEmitter = new EventEmitter();

const isInDebugMode = true;
const disableObjectsInDebugMode = true;

TaskManager.defineTask(LOCATION_TRACKER, ({ data, error }) => {
    if (error) {
        console.log(error);
        return;
    }
    if (data) {
        eventEmitter.emit(LOCATION_TRACKER, data);
    }
});

interface WorkHour {
    startDateTime: Date;
    endDateTime: Date;
}
interface Location {
    longitude: number;
    latitude: number;
}

export default class Tracker {
    location: ILocation | undefined;
    isDriving: boolean;
    drivingTimer: number;
    manualMode: boolean;
    isCarRide: boolean;
    trackerTimer: number | undefined;
    userId: string;
    jwtToken: string;
    distanceInterval: number;
    isAllowedToTrack: boolean | undefined;
    overview: OverviewScreen;
    eventEmitterInit: boolean;
    locations: Array<Location> | undefined;
    startTime: Date | undefined;

    reloadRouteData: () => void;
    trackingTimeout: number | undefined;
    _notificationSubscription: any;

    constructor(userId: string, reload: () => void, jwt: string, overviewState: OverviewScreen) {
        console.ignoredYellowBox = [
            'Setting a timer'
        ];
        this.isDriving = false;
        this.manualMode = false;
        this.isCarRide = false;
        this.overview = overviewState;
        this.userId = userId;
        this.jwtToken = jwt;
        this.distanceInterval = 500;
        this.drivingTimer = 0;
        this.eventEmitterInit = false;
        this.reloadRouteData = reload;
        this.registerForPushNotificationsAsync();
        this._notificationSubscription = Notifications.addListener(this._handleNotification);
        this.init();
    }

    registerForPushNotificationsAsync = async () => {
        let { status } = await Permissions.askAsync(Permissions.LOCATION);

        if (status !== 'granted') {
            alert('Failed to get push token for push notification!');
            return;
        }

        if (Platform.OS === 'android') {
            Notifications.createChannelAndroidAsync('default', {
                name: 'default',
                sound: true,
                priority: 'max',
                vibrate: [0, 250, 250, 250],
            });
        }
    };

    _handleNotification = async (notification: any) => {
        if (notification.origin == "received")
            Vibration.vibrate(VIBRATION_DURATION);
        if (notification.origin == "selected") {
            const userId = this.userId;
            const jwtToken = this.jwtToken;
            const item = notification.data;

            this.overview.navigation.push('Details', { item: item, companyData: this.overview.state.companyData, doChange: this.overview.getRouteData, userId, jwtToken })
        }
    };

    public init = async () => {
        debug("Route init, check if tracker is allowed to track");
        if (this.trackingTimeout) {
            clearTimeout(this.trackingTimeout)
        }
        var workhourData = await fetch(`${API_URL}/api/WorkHours/User/` + this.userId, {
            headers: {
                'Authorization': 'Bearer ' + this.jwtToken,
            }
        }).then((response) => response.json())
            .then((responseJson) => {
                var workhourData: Array<WorkHour> = responseJson.map(function (obj: WorkHour): WorkHour {
                    return {
                        startDateTime: obj.startDateTime,
                        endDateTime: obj.endDateTime
                    }
                });
                return workhourData;
            });

        let isWithinWorkHours = false;
        let closestDate: Date | undefined;

        workhourData.forEach(workHour => {
            const startDateTime = new Date(workHour["startDateTime"]);
            const endDateTime = new Date(workHour["endDateTime"]);
            const currentDateTime = new Date(Date.now() + (120 * 60 * 1000));

            if (startDateTime <= currentDateTime && endDateTime > currentDateTime) {
                isWithinWorkHours = true;
            } else if (!closestDate && endDateTime > currentDateTime) {
                closestDate = startDateTime;
            } else if (closestDate && startDateTime < closestDate && endDateTime > currentDateTime) {
                closestDate = startDateTime;
            }

        });

        await this._getLocationAsync();

        if (isWithinWorkHours) {
            debug("User is within work hours, tracker start tracking");
            this.startTracking();
        } else {

            if (closestDate) {
                var duration = new Date((closestDate as any) - (new Date(Date.now() + (120 * 60 * 1000)) as any));
                var diffHours = (((duration.getDate() - 1) * 24) + duration.getUTCHours());
                var diffMin = duration.getMinutes();
                var difSec = duration.getSeconds();
                debug("User is not within work hours, nearest workhour is in: " + diffHours + " hours and " + diffMin + " minutes");
                if (diffHours > 1 || diffMin > 15) {
                    this.trackingTimeout = setTimeout(() => {
                        this.init();
                    }, (15 * 60 * 1000));
                } else {
                    var miliSeconds = ((3600 * diffHours) + (diffMin * 60) + difSec) * 1000;
                    this.trackingTimeout = setTimeout(() => {
                        this.init();
                    }, miliSeconds);
                }
            }
        }
    }


    drivingButton() {
        if (this.isDriving) {
            debug("Stop tracking");
            if (this.manualMode) {
                Location.stopLocationUpdatesAsync(LOCATION_TRACKER);
            }
            this.finishedDriving();

        } else {
            if (this.isAllowedToTrack) {
                debug("Start manualy tracking");
                if (this.trackingTimeout) {
                    debug("Remove wait for tracking timeout");
                    clearTimeout(this.trackingTimeout)
                }
                this.isDriving = true;
                this.manualMode = true;
                this.isCarRide = true;
                this.startTime = new Date();

                this.startTracking();
                this.overview.setState({ isDriving: true });
            } else {
                alert("App is not allowed to track!")
            }
        }
    }


    startTracking = async () => {
        if (this.isAllowedToTrack) {
            let isRegistered = await TaskManager.isTaskRegisteredAsync(LOCATION_TRACKER);

            debug("Start background location update async");
            await Location.startLocationUpdatesAsync(LOCATION_TRACKER, {
                accuracy: Location.Accuracy.BestForNavigation,
                // timeInterval: 1000,
                distanceInterval: this.distanceInterval,
                foregroundService: { notificationTitle: "Reiskosten tracker", notificationBody: "De reiskosten tracker is actief!" },
                showsBackgroundLocationIndicator: true,
                // pausesUpdatesAutomatically: false,
            })
            Location.hasStartedLocationUpdatesAsync(LOCATION_TRACKER).then(res => debug("Registered location upates successfully: " + res));

            var location = await Location.getCurrentPositionAsync({});
            debug("Current location: ", location);
            if (location != null && this.location == null)
                this.location = location;

            this.locations = [];
            if (this.manualMode)
                this.locations.push({ "latitude": location.coords.latitude, "longitude": location.coords.longitude });

            this.eventEmitterInit = true;

            debug("Register event emitter");
            eventEmitter.addListener(LOCATION_TRACKER, (data: { locations: Array<ILocation>; }) => {
                debug("New location data found!");
                if (data.locations != null) {
                    var location = data.locations[data.locations.length - 1];

                    if (this.location && !this.manualMode) {
                        var duration = new Date((location.timestamp as any) - (new Date(this.location.timestamp) as any));
                        var diffHours = (((duration.getDate() - 1) * 24) + duration.getUTCHours());
                        var diffMin = duration.getMinutes();

                        if (diffHours >= 1 || diffMin >= 5) {
                            this.finishedDriving();
                        }
                    }

                    if (location.coords.speed >= 9) { //Speed is in meters per second
                        this.isCarRide = true;
                    }
                    debug("Current speed: " + location.coords.speed);

                    if (location.coords.speed > 1 || this.manualMode) {
                        this.location = location;
                        if (!this.manualMode) {
                            this.drivingTimer = 300;
                        }
                        if (this.isDriving == null || !this.isDriving) {
                            this.isDriving = true;
                            this.overview.setState({ isDriving: true });
                            if (!this.manualMode) {
                                this.setCountdownTimer();
                                this.startTime = new Date();
                            }
                        }
                        if (!this.locations)
                            this.locations = [];

                        if (location.coords.speed > 1) {
                            debug("Added new location: ", location);
                            this.locations.push({ "latitude": location.coords.latitude, "longitude": location.coords.longitude });
                        }
                    } else {
                        if (!this.isCarRide) {
                            this.locations = [];
                            this.location = location;
                            this.locations.push({ "latitude": location.coords.latitude, "longitude": location.coords.longitude });
                            debug("Reset first location: ", location);
                        }
                    }

                }
            });
        }
        debug("Number of event listeners: " + eventEmitter.listeners.length);
    }

    _getLocationAsync = async () => {
        let { status } = await Permissions.askAsync(Permissions.LOCATION);
        if (status !== 'granted') {
            this.isAllowedToTrack = false;
            this.overview.setState({ isAllowedToTrack: false });
        } else {
            this.overview.setState({ isAllowedToTrack: true });
            this.isAllowedToTrack = true;
        }
    };

    componentWillUnmount() {
        console.log("unmount");
    }

    finishedDriving() {
        debug("Finish tracking!");
        clearInterval(this.trackerTimer);
        this.isDriving = false;
        debug("Remove event emitter");
        eventEmitter.removeAllListeners();
        this.overview.setState({ isDriving: false });

        if (this.locations) {
            debug("Tracker has locations");

            if (this.locations.length > 2 && this.isCarRide) {
                debug("Current ride is actually a car ride");

                fetch(`${API_URL}/api/Routes?isGPSData=true`, {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + this.jwtToken,
                    },
                    body: JSON.stringify({
                        'statusName': "PENDING_BY_EMPLOYEE",
                        'userId': this.userId,
                        'startTime': this.startTime,
                        'endTime': new Date(),
                        'serializedRoute': JSON.stringify(this.locations)
                    })
                }).then((response) => { if (response.ok) { return response.json() } else { return null } })
                    .then((responseJson: Route) => {
                        if (responseJson) {
                            debug("Route created");
                            this.reloadRouteData();
                            let startDT = new Date(responseJson.startTime);
                            let endDT = new Date(responseJson.endTime);
                            let duration = new Date((endDT as any) - (startDT as any));
                            let diffHours = (((duration.getUTCDate() - 1) * 24) + duration.getUTCHours());
                            responseJson.duration = diffHours + ":" + (duration.getMinutes() < 10 ? '0' : '') + duration.getMinutes();
                            responseJson.date = startDT.getDate() + "-" + (startDT.getMonth() + 1) + "-" + startDT.getFullYear();
                            responseJson.startTime = startDT.getHours() + ":" + (startDT.getMinutes() < 10 ? '0' : '') + startDT.getMinutes();
                            responseJson.endTime = endDT.getHours() + ":" + (endDT.getMinutes() < 10 ? '0' : '') + endDT.getMinutes();
                            const item = responseJson;
                            Notifications.presentLocalNotificationAsync({ title: "Route gedetecteerd", body: `Van: ${item.startLocation}, naar: ${item.endLocation}. Aantal kilometer: ${(item.distance / 1000).toFixed(1)}km`, data: item }).then(res => console.log(res));
                        }
                    }).catch((error) => {
                        console.error(error);
                    });
            }
        }
        this.locations = [];
        this.location = undefined;
        this.isCarRide = false;
        this.manualMode = false;
        this.drivingTimer = 0;
        if (this.trackerTimer) {
            debug("Clear timeout tracker");
            clearTimeout(this.trackerTimer)
        }
        this.init();
    }

    setCountdownTimer = async () => {
        this.trackerTimer = setInterval(() => {
            this.drivingTimer = this.drivingTimer - 1;
            if (this.drivingTimer <= 0) {
                this.finishedDriving();
            }
        }, 1000);
    }
}

function debug(text: String, object: any = "") {
    if (isInDebugMode)
        console.log(text, disableObjectsInDebugMode ? "" : object)
}