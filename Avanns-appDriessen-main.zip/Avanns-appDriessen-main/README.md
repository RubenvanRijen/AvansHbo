# appDriessen
Instructie om de app lokaal te draaien
1. typ 'npm install' in je terminal
2. typ 'npm start' om de app lokaal te starten
3. installeer Expo op je mobiel: https://play.google.com/store/apps/details?id=host.exp.exponent&hl=nl
4. scan de qrcode met de expo app op het scherm dat opent in de browser

Instructie om de app te builden naar APK
1. typ 'expo build:(android of ios)' in je terminal
2. log in met een expo account
3. de app word nu bij expo gebuild, via de link is de progress te volgen en kan de app gedownload worden
