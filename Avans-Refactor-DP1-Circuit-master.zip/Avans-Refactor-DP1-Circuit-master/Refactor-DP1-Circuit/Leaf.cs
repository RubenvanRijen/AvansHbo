﻿namespace Refactor_DP1_Circuit
{
    public class Leaf : NodeComponent
    {
        public override void Accept(Interface.IVisitor visitor)
        {
            visitor.Visit(this);
        }

        public override NodeComponent Clone()
        {
            return new Leaf()
            {
                Node = this.Node, Name = this.Name, OutputValue = this.OutputValue,
                AmountOfInputs = this.AmountOfInputs, InputType = this.InputType
            };
        }

        public override void Operation()
        {
        }
    }
}