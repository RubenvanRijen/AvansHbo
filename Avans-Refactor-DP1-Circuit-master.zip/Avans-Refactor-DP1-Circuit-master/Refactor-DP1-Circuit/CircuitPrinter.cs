﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Refactor_DP1_Circuit
{
    public class CircuitPrinter
    {
        private float _timePassed;

        public void PrintCircuit(IEnumerable<NodeComponent> nodeComponents)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(
                "Press 1 through the amount of inputs to change the values");
            Console.WriteLine(
                "Type; 'reset' to reload the circuit. Type 'change' to change circuit. Type 'stop' to stop the circuit");
            Console.WriteLine("Name\t|     Input 1\t|Input 2|Output\t|Children");

            foreach (var node in nodeComponents)
            {
                if (node.IsInput()) Console.ForegroundColor = ConsoleColor.Yellow;
                else if (node is Composite) Console.ForegroundColor = ConsoleColor.Green;
                else Console.ForegroundColor = ConsoleColor.Gray;

                Console.Write(node.Name + "\t|");

                if (node.AmountOfInputs.Equals(1)) Console.Write("\t\t|" + node.InputValues.Values.First());
                else if (node.AmountOfInputs > 1)
                    Console.Write("\t" + node.InputValues.Values.First() + "\t|" +
                                  node.InputValues.Values.Last());
                else Console.Write("\t\t|");

                Console.Write("\t|" + node.OutputValue + "\t|");

                if (node is Composite composite)
                {
                    foreach (var child in composite.Children)
                    {
                        Console.Write(child.Name + " ");
                    }
                }

                Console.WriteLine();
            }

            Console.WriteLine("time passed: " + ((_timePassed * 15) / 1000000) + "MS");
        }

        public void SetTimePassed(IEnumerable<NodeComponent> nodeComponents)
        {
            foreach (var nodeComponent in nodeComponents)
            {
                _timePassed += nodeComponent.TimesPassed;
            }
        }
    }
}