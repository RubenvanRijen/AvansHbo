﻿using System.Linq;
using Refactor_DP1_Circuit.Interface;

namespace Refactor_DP1_Circuit.Nodes
{
    public class XorNode : INode
    {
        public void SetNode(NodeComponent nodeComponent)
        {
            nodeComponent.OutputValue = 0;
            if (nodeComponent.InputValues.Values.First() != nodeComponent.InputValues.Values.Last())
            {
                nodeComponent.OutputValue = 1;
            }
            nodeComponent.TimesPassed++;
        }
    }
}