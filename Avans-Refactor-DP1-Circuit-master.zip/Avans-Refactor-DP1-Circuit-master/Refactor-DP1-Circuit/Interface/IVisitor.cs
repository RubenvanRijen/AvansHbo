﻿namespace Refactor_DP1_Circuit.Interface
{
    public abstract class IVisitor
    {
        public abstract void Visit(Leaf leaf);
        public abstract void Visit(Composite composite);
    }
}
