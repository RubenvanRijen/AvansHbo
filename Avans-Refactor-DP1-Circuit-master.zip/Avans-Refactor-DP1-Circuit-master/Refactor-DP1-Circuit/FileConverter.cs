﻿using Refactor_DP1_Circuit.Factories;
using System;
using System.Collections.Generic;
using System.Linq;
using Refactor_DP1_Circuit.Visitor;

namespace Refactor_DP1_Circuit
{
    public class FileConverter
    {
        private readonly List<NodeComponent> _nodeComponents;
        private static readonly char[] EndingChars = {':', ';', ','};
        private static readonly char[] NewLineChars = {' ', '\t'};
        private readonly AbstractFactory _nodeFactory;
        private IEnumerable<string> FileLines { get; set; }

        public FileConverter()
        {
            _nodeComponents = new List<NodeComponent>();
            _nodeFactory = new NodeFactory();
            _nodeFactory.CreateNodes();
        }

        private void SetFileLines(string filename)
        {
            var path = System.IO.Path.Combine(Environment.CurrentDirectory, @"..\..\..\Circuits\", filename);
            FileLines = System.IO.File.ReadLines(path);
        }

        public List<NodeComponent> ConvertFile(string filename)
        {
            _nodeComponents.Clear();
            SetFileLines(filename);
            var indicator = 0;

            foreach (var line in FileLines)
            {
                if (line.Length == 0)
                {
                    indicator++;
                }

                if (line.Length > 0 && line[0] != '#')
                {
                    var chars = line.Split(EndingChars).Select(s => s.Trim(NewLineChars)).ToArray();
                    switch (indicator)
                    {
                        case 0:
                            _nodeComponents.Add(CreateNewComponent(chars));
                            break;
                        case 1:
                            AddChildrenToComposite(chars);
                            break;
                    }
                }
            }

            CreateStartNode();
            return _nodeComponents;
        }


        private void AddChildrenToComposite(IReadOnlyList<string> args)
        {
            var source =
                (Composite) _nodeComponents.First(item => item.Name == args[0]);
            var arguments = args.Skip(1).ToList();
            arguments.RemoveAll(item => item == "");
            foreach (var identifier in arguments)
            {
                source.Accept(
                    new AddChildrenToNodeVisitor(_nodeComponents.First(component =>
                        component.Name == identifier)));
            }
        }

        private void CreateStartNode()
        {
            var root = _nodeFactory.CreateComponent("Start", "START");

            foreach (var bar in _nodeComponents.Where(c => c.IsInput()))
            {
                root.Accept(new AddChildrenToNodeVisitor(bar));
            }

            _nodeComponents.Insert(0, root);
        }

        private NodeComponent CreateNewComponent(IReadOnlyList<string> args)
        {
            return _nodeFactory.CreateComponent(args[0], args[1]);
        }
    }
}