﻿using Refactor_DP1_Circuit.Builder;
using Refactor_DP1_Circuit.Nodes;

namespace Refactor_DP1_Circuit.Factories
{
    public class NodeFactory : AbstractFactory
    {
        public override void CreateNodes()
        {
            RegisterComponent("START",
                new BuilderValues()
                    {node = new StartNode(), output = 0, builder = new CompositeBuilder(), amountOfInputs = 0});
            RegisterComponent("INPUT_HIGH",
                new BuilderValues()
                {
                    node = new InputNode(), output = 1, builder = new CompositeBuilder(), amountOfInputs = 0,
                    inputType = "INPUT_HIGH"
                });
            RegisterComponent("INPUT_LOW",
                new BuilderValues()
                {
                    node = new InputNode(), output = 0, builder = new CompositeBuilder(), amountOfInputs = 0,
                    inputType = "INPUT_LOW"
                });
            RegisterComponent("PROBE",
                new BuilderValues()
                    {node = new ProbeNode(), output = -1, builder = new LeafBuilder(), amountOfInputs = 1});
            RegisterComponent("OR",
                new BuilderValues()
                    {node = new OrNode(), output = -1, builder = new CompositeBuilder(), amountOfInputs = 2});
            RegisterComponent("AND",
                new BuilderValues()
                    {node = new AndNode(), output = -1, builder = new CompositeBuilder(), amountOfInputs = 2});
            RegisterComponent("NOT",
                new BuilderValues()
                    {node = new NotNode(), output = -1, builder = new CompositeBuilder(), amountOfInputs = 1});
            RegisterComponent("XOR",
                new BuilderValues()
                    {node = new XorNode(), output = -1, builder = new CompositeBuilder(), amountOfInputs = 2});
            RegisterComponent("NAND",
                new BuilderValues()
                    {node = new NandNode(), output = -1, builder = new CompositeBuilder(), amountOfInputs = 2});
            RegisterComponent("NOR",
                new BuilderValues()
                    {node = new NorNode(), output = -1, builder = new CompositeBuilder(), amountOfInputs = 2});
        }
    }
}