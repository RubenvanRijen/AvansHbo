﻿using Refactor_DP1_Circuit.Interface;

namespace Refactor_DP1_Circuit.State
{
    public class GateOpen : IState
    {
        public void Handle(NodeComponent nodeComponent, NodeComponent component)
        {
            nodeComponent.InputValues.Remove(component);
            nodeComponent.State = (new GateClosed());
            nodeComponent.State.Handle(nodeComponent, component);
        }
    }
}