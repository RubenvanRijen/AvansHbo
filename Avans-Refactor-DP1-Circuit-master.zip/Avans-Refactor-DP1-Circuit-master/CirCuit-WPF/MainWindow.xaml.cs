﻿using Microsoft.Win32;
using Refactor_DP1_Circuit;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

namespace CirCuit_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool _infinity = false;
        private readonly FileConverter _fileConverter;
        private List<NodeComponent> _nodeComponents;
        private bool _validCircuit = false;

        private static readonly string[] Files =
        {
            "Circuit1_FullAdder.txt", "Circuit2_Decoder.txt", "Circuit3_Encoder.txt", "Circuit4_InfiniteLoop.txt",
            "Circuit5_NotConnected.txt"
        };

        public MainWindow()
        {
            InitializeComponent();
            _fileConverter = new FileConverter();
        }

        //Open the file explorer to get a file
        private void BtnOpenFile_Click(object sender, RoutedEventArgs e)
        {
            _validCircuit = false;
            _infinity = false;
            var path = System.IO.Path.Combine(Environment.CurrentDirectory, @"..\..\..\Circuits\");
            var openFileDialog = new OpenFileDialog
            {
                InitialDirectory = System.IO.Path.GetFullPath(path)
            };

            if (openFileDialog.ShowDialog() != true) return;
            var filename = Path.GetFileName(openFileDialog.FileName);
            if (Files.Contains(filename))
            {
                _nodeComponents = _fileConverter.ConvertFile(filename);
                SetNodesValues(_nodeComponents);
                if (_validCircuit && !_infinity)
                {
                    var circuitWindow = new CircuitWindow(_nodeComponents);
                    circuitWindow.Show();
                }
            }
            else
            {
                TxtEditor.Text = "You have chosen a file which is not right";
            }
        }

        //set the values of all the nodes
        public void SetNodesValues(IEnumerable<NodeComponent> nodeComponents)
        {
            var start = nodeComponents.First(item => item.Name == "Start");
            start.SetNodeValues();
            IsCircuitInfinityLoop();
            if (!_infinity) _validCircuit = IsCircuitValid();
            else
            {
                TxtEditor.Text = "Infinity loop found";
            }
        }


        //check if circuit is valid
        public bool IsCircuitValid()
        {
            var valid = true;
            foreach (var nodeComponent in _nodeComponents
                .Where(nodeComponent => nodeComponent.AmountOfInputs == 1 || nodeComponent.AmountOfInputs > 1)
                .Where(nodeComponent => nodeComponent.InputValues.Count == 0))
            {
                valid = false;
                TxtEditor.Text = "Nodes not connected";
                break;
            }

            return valid;
        }

        //check if circuit is valid
        public void IsCircuitInfinityLoop()
        {
            foreach (var nodeComponent in _nodeComponents)
            {
                var nodesList = new List<NodeComponent> {nodeComponent};
                CheckInfinity(nodeComponent, nodesList);
            }
        }

        //check if circuit is valid
        public void CheckInfinity(NodeComponent nodeComponent, List<NodeComponent> nodeList)
        {
            if (!(nodeComponent is Composite composite)) return;
            foreach (var childNode in composite.Children)
            {
                if (nodeList.Contains(childNode))
                {
                    this._infinity = true;
                    break;
                }

                var newNodesList = nodeList.ToList();
                newNodesList.Add(childNode);
                CheckInfinity(childNode, newNodesList);
            }
        }

        public List<NodeComponent> NodeComponents
        {
            get => _nodeComponents;
            set => _nodeComponents = value;
        }

        public bool Infinity
        {
            get => _infinity;
            set => _infinity = value;
        }
    }
}