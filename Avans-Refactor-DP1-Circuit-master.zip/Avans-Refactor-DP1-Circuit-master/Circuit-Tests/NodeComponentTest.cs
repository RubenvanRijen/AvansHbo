﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Refactor_DP1_Circuit;
using Refactor_DP1_Circuit.Interface;
using Refactor_DP1_Circuit.Nodes;

namespace Circuit_Tests
{
    [TestClass]
    public class NodeComponentTest
    {
        private static NodeComponent NodeComponentOne(INode node)
        {
            var leaf = new Leaf {AmountOfInputs = 2, Node = node};
            var l1 = new Leaf();
            var l2 = new Leaf();
            l1.OutputValue = 0;
            l2.OutputValue = 0;
            leaf.AddInputValue(l1);
            leaf.AddInputValue(l2);
            return leaf;
        }

        private static NodeComponent NodeComponentTwo(INode node)
        {
            var leaf = new Leaf {AmountOfInputs = 2, Node = node};
            var l1 = new Leaf();
            var l2 = new Leaf();
            l1.OutputValue = 0;
            l2.OutputValue = 1;
            leaf.AddInputValue(l1);
            leaf.AddInputValue(l2);
            return leaf;
        }

        private static NodeComponent NodeComponentThree(INode node)
        {
            var leaf = new Leaf {AmountOfInputs = 2, Node = node};
            var l1 = new Leaf();
            var l2 = new Leaf();
            l1.OutputValue = 1;
            l2.OutputValue = 1;
            leaf.AddInputValue(l1);
            leaf.AddInputValue(l2);
            return leaf;
        }

        private static NodeComponent NodeComponentFour(INode node)
        {
            var leaf = new Leaf {AmountOfInputs = 2, Node = node};
            var l1 = new Leaf();
            var l2 = new Leaf();
            l1.OutputValue = 1;
            l2.OutputValue = 0;
            leaf.AddInputValue(l1);
            leaf.AddInputValue(l2);
            return leaf;
        }

        [TestMethod]
        public void AndTest()
        {
            var component = NodeComponentOne(new AndNode());
            component.SetNodeValues();
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentTwo(new AndNode());
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentThree(new AndNode());
            Assert.AreEqual(1, component.OutputValue);
            component = NodeComponentFour(new AndNode());
            Assert.AreEqual(0, component.OutputValue);
        }

        [TestMethod]
        public void NandTest()
        {
            var component = NodeComponentOne(new NandNode());
            component.SetNodeValues();
            Assert.AreEqual(1, component.OutputValue);
            component = NodeComponentTwo(new NandNode());
            Assert.AreEqual(1, component.OutputValue);
            component = NodeComponentThree(new NandNode());
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentFour(new NandNode());
            Assert.AreEqual(1, component.OutputValue);
        }

        [TestMethod]
        public void InputTest()
        {
            var component = NodeComponentOne(new InputNode());
            component.SetNodeValues();
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentTwo(new InputNode());
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentThree(new InputNode());
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentFour(new InputNode());
            Assert.AreEqual(0, component.OutputValue);
        }

        [TestMethod]
        public void NorTest()
        {
            var component = NodeComponentOne(new NorNode());
            component.SetNodeValues();
            Assert.AreEqual(1, component.OutputValue);
            component = NodeComponentTwo(new NorNode());
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentThree(new NorNode());
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentFour(new NorNode());
            Assert.AreEqual(0, component.OutputValue);
        }

        [TestMethod]
        public void NotTest()
        {
            var component = NodeComponentOne(new NotNode());
            component.SetNodeValues();
            Assert.AreEqual(1, component.OutputValue);
            component = NodeComponentThree(new NotNode());
            Assert.AreEqual(0, component.OutputValue);
        }

        [TestMethod]
        public void OrTest()
        {
            var component = NodeComponentOne(new OrNode());
            component.SetNodeValues();
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentTwo(new OrNode());
            Assert.AreEqual(1, component.OutputValue);
            component = NodeComponentThree(new OrNode());
            Assert.AreEqual(1, component.OutputValue);
            component = NodeComponentFour(new OrNode());
            Assert.AreEqual(1, component.OutputValue);
        }

        [TestMethod]
        public void ProbeTest()
        {
            var component = NodeComponentOne(new ProbeNode());
            component.SetNodeValues();
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentTwo(new ProbeNode());
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentThree(new ProbeNode());
            Assert.AreEqual(1, component.OutputValue);
            component = NodeComponentFour(new ProbeNode());
            Assert.AreEqual(1, component.OutputValue);
        }

        [TestMethod]
        public void StartTest()
        {
            var component = NodeComponentOne(new StartNode());
            component.SetNodeValues();
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentTwo(new StartNode());
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentThree(new StartNode());
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentFour(new StartNode());
            Assert.AreEqual(0, component.OutputValue);
        }

        [TestMethod]
        public void XorTest()
        {
            var component = NodeComponentOne(new XorNode());
            component.SetNodeValues();
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentTwo(new XorNode());
            Assert.AreEqual(1, component.OutputValue);
            component = NodeComponentThree(new XorNode());
            Assert.AreEqual(0, component.OutputValue);
            component = NodeComponentFour(new XorNode());
            Assert.AreEqual(1, component.OutputValue);
        }
    }
}