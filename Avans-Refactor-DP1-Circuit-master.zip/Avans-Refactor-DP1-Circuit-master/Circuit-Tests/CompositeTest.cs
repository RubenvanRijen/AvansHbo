﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Refactor_DP1_Circuit;
using Refactor_DP1_Circuit.Nodes;
using Refactor_DP1_Circuit.Visitor;
using Assert = NUnit.Framework.Assert;

namespace Circuit_Tests
{
    [TestClass]
    public class CompositeTest
    {
        [TestMethod]
        public void OperationCompositeTest()
        {
            var composite = new Composite {AmountOfInputs = 2, Node = new AndNode()};
            var l1 = new Leaf() {AmountOfInputs = 1};
            var l2 = new Leaf() {AmountOfInputs = 1};
            l1.Node = new AndNode();
            l2.Node = new AndNode();

            composite.OutputValue = 1;
            composite.Children.Add(l1);
            composite.Children.Add(l2);
            composite.Operation();
            Assert.AreEqual(1, composite.Children[0].OutputValue);
            Assert.AreEqual(1, composite.Children[1].OutputValue);
        }

        [TestMethod]
        [ExpectedException(typeof(NotSupportedException))]
        public void LeafAcceptCreateTest()
        {
            var leaf = new Leaf();
            leaf.Accept(new AddChildrenToNodeVisitor(null));
        }

        [TestMethod]
        [ExpectedException(typeof(NotSupportedException))]
        public void LeafAcceptDeleteTest()
        {
            var leaf = new Leaf();
            leaf.Accept(new RemoveChildrenFromNodeVisitor(null));
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void LeafAcceptNullTest()
        {
            var leaf = new Leaf();
            leaf.Accept(null);
        }
    }
}