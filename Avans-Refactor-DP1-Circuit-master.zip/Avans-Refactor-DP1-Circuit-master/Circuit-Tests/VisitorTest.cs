﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Refactor_DP1_Circuit;
using Refactor_DP1_Circuit.Visitor;

namespace Circuit_Tests
{
    [TestClass]
    public class VisitorTest
    {
        [TestMethod]
        public void CompositeCreateVisitorTest()
        {
            var obj = new Composite();
            Assert.AreEqual(obj.Children.Count, 0);
            NodeComponent child = new Leaf();
            obj.Accept(new AddChildrenToNodeVisitor(child));
            Assert.AreEqual(obj.Children.Count, 1);
            Assert.AreEqual(obj.Children[0], child);
        }

        [TestMethod]
        public void CompositeDeleteVisitorTest()
        {
            var obj = new Composite();
            Assert.AreEqual(obj.Children.Count, 0);
            NodeComponent child = new Leaf();
            obj.Accept(new AddChildrenToNodeVisitor(child));
            obj.Accept(new RemoveChildrenFromNodeVisitor(child));
            Assert.AreEqual(obj.Children.Count, 0);
        }

        [TestMethod]
        [ExpectedException(typeof(NotSupportedException))]
        public void LeafCreateVisitorTest()
        {
            var obj = new Leaf();
            obj.Accept(new AddChildrenToNodeVisitor(null));
        }

        [TestMethod]
        [ExpectedException(typeof(NotSupportedException))]
        public void LeafDeleteVisitorTest()
        {
            var obj = new Leaf();
            obj.Accept(new RemoveChildrenFromNodeVisitor(null));
        }
    }
}