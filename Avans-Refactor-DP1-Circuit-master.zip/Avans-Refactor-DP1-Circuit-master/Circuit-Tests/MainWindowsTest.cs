﻿using System.Threading;
using CirCuit_WPF;
using NUnit.Framework;
using Refactor_DP1_Circuit;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

namespace Circuit_Tests
{
    [TestFixture, Apartment(ApartmentState.STA)]
    public class MainWindowsTest
    {
        [Test, Apartment(ApartmentState.STA)]
        public void LoopCircuitSuccess()
        {
            var mainWindow = new MainWindow();
            var fileConverter = new FileConverter();
            var nodeComponents = fileConverter.ConvertFile("Circuit1_FullAdder.txt");
            mainWindow.NodeComponents = nodeComponents;
            mainWindow.SetNodesValues(mainWindow.NodeComponents);
            mainWindow.IsCircuitInfinityLoop();
            Assert.AreEqual(mainWindow.Infinity, false);
        }

        [Test, Apartment(ApartmentState.STA)]
        public void LoopCircuitFailure()
        {
            var mainWindow = new MainWindow();
            var fileConverter = new FileConverter();
            var nodeComponents = fileConverter.ConvertFile("Circuit4_InfiniteLoop.txt");
            mainWindow.NodeComponents = nodeComponents;
            mainWindow.SetNodesValues(mainWindow.NodeComponents);
            mainWindow.IsCircuitInfinityLoop();
            Assert.AreEqual(mainWindow.Infinity, true);
        }

        [Test, Apartment(ApartmentState.STA)]
        public void ValidCircuitSuccess()
        {
            var mainWindow = new MainWindow();
            var fileConverter = new FileConverter();
            var nodeComponents = fileConverter.ConvertFile("Circuit1_FullAdder.txt");
            mainWindow.NodeComponents = nodeComponents;
            mainWindow.SetNodesValues(mainWindow.NodeComponents);
            var valid = mainWindow.IsCircuitValid();
            Assert.AreEqual(valid, true);
        }

        [Test, Apartment(ApartmentState.STA)]
        public void ValidCircuitFailure()
        {
            var mainWindow = new MainWindow();
            var fileConverter = new FileConverter();
            var nodeComponents = fileConverter.ConvertFile("Circuit5_NotConnected.txt");
            mainWindow.NodeComponents = nodeComponents;
            mainWindow.SetNodesValues(mainWindow.NodeComponents);
            var valid = mainWindow.IsCircuitValid();
            Assert.AreEqual(valid, false);
        }
    }
}