<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\Pivot;

class ContactsGroups extends Pivot
{
    // let's use date mutator for a field
    // groups model
    public function groups(Model $parent, array $attributes, $table, $exists)
    {
        if ($parent instanceof Group) {
            return new CategoryUserPivot($parent, $attributes, $table, $exists);
        }

        return parent::newPivot($parent, $attributes, $table, $exists);
    }


    // contcts model
    public function contacts(Model $parent, array $attributes, $table, $exists)
    {
        if ($parent instanceof Contact) {
            return new CategoryUserPivot($parent, $attributes, $table, $exists);
        }

        return parent::newPivot($parent, $attributes, $table, $exists);
    }
}
