<?php

namespace App\Http\Controllers;

use App\BankAccount;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\View;
use PDF as PDF;
use Illuminate\Http\Response;


class BankAccountsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user_id = auth()->user()->id;
        $user = User::find($user_id);

        $bankaccounts = Bankaccount::latest()->paginate(5);

        return view('bankaccounts.index', compact('bankaccounts'))
            ->with('bankaccounts', $user->bankaccounts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('bankaccounts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'IBAN' => 'required|iban|unique:bank_accounts',
        ]);

        $bankaccount = new BankAccount();
        $bankaccount->IBAN = $request->input('IBAN');
        $bankaccount->user_id = auth()->user()->id;
        $bankaccount->save();

        return redirect()->to('/bankaccounts')->with('success', Lang::get('home.IBAN_C_Success'));
    }

    /**
     * Display the specified resource.
     *
     * @param \App\BankAccount $IBAN
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $bankaccount = BankAccount::find($id);
        $payments = $bankaccount->descriptions;

        return view('bankaccounts.show')->with('bankaccounts', $bankaccount)->with('descriptions', $payments);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\BankAccount $bankaccount
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $bankaccount = BankAccount::find($id);
        $bankaccount->delete();
        if (auth()->user()->id != $bankaccount->user_id) {
            return redirect('/contacts')->with('error', Lang::get('home.Page_Unauthorized'));
        }
        return redirect()->to('/bankaccounts')
            ->with('success', Lang::get('home.IBAN_D_Success'));
    }


}
