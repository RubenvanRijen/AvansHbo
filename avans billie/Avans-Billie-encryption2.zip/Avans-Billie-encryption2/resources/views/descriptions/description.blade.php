@extends('layouts.app')

@section('content')
    <div class="content ">
        <div class="creation-container">
            <div class="block block-rounded block-bordered block-fx-shadow">
                <div class="block-header block-header-default">
                    <h3 class="block-title text-center text-white font-weight-bolder m-4">
                        @lang('home.make_Description')
                    </h3>
                </div>
                <div class="block-content mb-4">
                    <form action="{{ route('description.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="exampleInputname">@lang('home.Name')</label>
                            <input type="name" class="form-control" name="name" id="name" aria-describedby="name"
                                   placeholder="Billie @lang('home.Name')">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">@lang('home.Description')</label>
                            <textarea class="form-control rounded-0" name="description" id="description"
                                      rows="10"></textarea>
                        </div>
                        <input type="hidden" class="form-control" name="id" id="id" value="{!!$id!!}" readonly>
                        <input type="hidden" class="form-control" name="ids" id="ids" value="{!!$ids!!}" readonly>

                        <button type="submit" class="btn btn-success">@lang('home.Submit')</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection