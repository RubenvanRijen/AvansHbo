@extends('layouts.app')

@section('content')
    <div class="h-100">
        <div class="card text-center  mt-5">
            <div class="card-header text">
                @lang('home.Bank_accounts')
            </div>
            <div class="card-body">
                <h5 class="card-title">{!! $bankaccounts->IBAN!!}</h5>
                <h5 class="card-text"><?php
                    $dt = $bankaccounts->balance;

                    if (app()->getLocale() == 'de') {
                        $new_dt = number_format($dt, 2, ',', ' ');
                    } else if (app()->getLocale() == 'nl') {
                        $new_dt = number_format($dt, 2, ',', ' ');
                    } else {
                        $new_dt = number_format($dt, 2, '.', ',');
                    }
                    ?>
                    {!!$new_dt!!} @lang('home.EURO')</h5>
                <a href="/bankaccounts" class="btn btn-success">@lang('home.Return')</a>
            </div>


        </div>
        <h2 class="text-center text-white mt-5">Transacties</h2>
        @foreach($descriptions as $payment)
            <div class="card text-center mt-5">
                <div class="card-header text">
                    Description
                </div>
                <div class="card-body">
                    <h5 class="card-text">Naam Persoon: {!! $payment->name !!}</h5>
                    <h5 class="card-text">Betaal soort: {!! $payment->typeofpayment !!}</h5>
                    <h5 class="card-text">Hoeveelheid geld: {!! $payment->amount !!} Euro</h5>
                    <h5 class="card-text">Date:  <?php
                        $dt = $payment->created_at;
                        if (app()->getLocale() == 'de') {
                            $new_dt = $dt->format('d-m-Y H:i');
                        } else if (app()->getLocale() == 'nl') {
                            $new_dt = $dt->format('d-m-Y H:i');
                        } else {
                            $new_dt = $dt->format('Y-m-d H:i');
                        }
                        ?>
                        {!!$new_dt!!}</h5>

                    <h5 class="card-text">Bericht: {!! $payment->note !!}</h5>


                </div>

            </div>
        @endforeach
    </div>
@endsection 