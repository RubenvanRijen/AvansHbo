<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User as User;

class BankAccount extends Model
{
    //public $primaryKey = 'IBAN';

    public function users() {
        return $this->belongsTo(User::class);
    }
}
