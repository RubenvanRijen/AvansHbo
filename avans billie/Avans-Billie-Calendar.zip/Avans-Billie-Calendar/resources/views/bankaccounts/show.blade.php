@extends('layouts.app')

@section('content')
<div class="h-100">
    <div class="card text-center  mt-5">
        <div class="card-header text">
            @lang('home.Bank_accounts')
        </div>
        <div class="card-body">
            <h5 class="card-title">{!! $bankaccounts->IBAN!!}</h5>
            <h5 class="card-text"><?php
                $dt = $bankaccounts->balance;

                if (app()->getLocale() == 'de') {
                    $new_dt = number_format($dt, 2, ',', ' ');
                } else if (app()->getLocale() == 'nl') {
                    $new_dt = number_format($dt, 2, ',', ' ');
                } else {
                    $new_dt = number_format($dt, 2, '.', ',');
                }
                ?>
                {!!$new_dt!!} @lang('home.EURO')</h5>
            <a href="/bankaccounts" class="btn btn-success">@lang('home.Return')</a>
        </div>

    </div>
</div>
@endsection 