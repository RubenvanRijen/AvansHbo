@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2 class="text-white text-center">@lang('home.Bank_accounts')</h2>
        </div>
        <div class="pull-right text-right">
            <a class="btn btn-success" href="/bankaccounts/create"> @lang('home.Add New Bankaccount')</a>
        </div>
    </div>
</div>

<table class="table table-striped table-light mr-2 ml-2">
    <tr>
        <th>IBAN</th>
        <th>@lang('home.Balance')</th>
        <th width="200px"></th>
    </tr>
    @foreach ($bankaccounts as $bankaccount)
    <tr>

        <td>{!! $bankaccount->IBAN !!}</td>
        <td>
            <?php
            $dt = $bankaccount->balance;

            if (app()->getLocale() == 'de') {
                $new_dt = number_format($dt, 2, ',', ' ');
            } else if (app()->getLocale() == 'nl') {
                $new_dt = number_format($dt, 2, ',', ' ');
            } else {
                $new_dt = number_format($dt, 2, '.', ',');
            }
            ?>
            {!!$new_dt!!} @lang('home.EURO')
        </td>

        <td>
            <div class="row">
                <a class="btn btn-info text-white" href="/bankaccounts/{!!$bankaccount->id !!}">@lang('home.Show')</a>
                <a class="btn btn-danger float-right" href='/bankaccounts/delete/{!!$bankaccount->id !!}'>@lang('home.Delete')</a>
            </div>
        </td>
    </tr>
    @endforeach
</table>



{{--/* {!! $bankaccounts->links() !!} */--}}

@endsection