@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2 class="text-white text-center">@lang('home.Groups')</h2>
        </div>
        <div class="pull-right text-right">
            <a class="btn btn-success" href="/groups/create"> @lang('home.Add New Group')</a>
        </div>
    </div>
</div>

<table class="table table-striped table-light mr-2 ml-2">
    <tr>
        <th>@lang('home.Name')</th>
        <th>@lang('home.Made on')</th>
        <th width="200px"></th>
    </tr>
    @foreach ($groups as $group)
    <tr>
        <td>{!! $group->name !!}</td>
        <td> {!! $group->created_at!!} </td>
        <td>
            <div class="row">
                <a class="btn btn-info text-white" href="/groups/{!! $group->id !!}">@lang('home.Show')</a>
                <a class="btn btn-danger float-right" href='/groups/delete/{!!$group->id !!}'>@lang('home.Delete')</a>
            </div>
        </td>
    </tr>
    @endforeach
</table>
@endsection 