@extends('layouts.app')

@section('content')
<div class="content ">
    <div class="creation-container">
        <div class="block block-rounded block-bordered block-fx-shadow">
            <div class="block-header block-header-default">
                <h3 class="block-title text-center text-white font-weight-bolder m-4">
                    @lang('home.Create Group')
                </h3>
            </div>
            <div class="block-content mb-4">
                <form action="{{ route('group.store') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="exampleInputname">@lang('home.Name')</label>
                        <input type="name" class="form-control" name="name" id="name" aria-describedby="name" placeholder="@lang('home.Groups')">
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlSelect1">@lang('home.Contacts')</label>
                        <select name="contacts[]" multiple class="custom-select">
                            @foreach($contacts as $contact)
                            <option value="{!!$contact->id !!}">{!!$contact->name!!}</option>
                            @endforeach
                        </select>


                    </div>
                    <button type="submit" class="btn btn-primary">@lang('home.Submit')</button>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection 