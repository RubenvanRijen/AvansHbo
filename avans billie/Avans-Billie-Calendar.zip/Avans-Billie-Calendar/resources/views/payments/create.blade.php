@extends('layouts.app')

@section('content')
<div class="content ">
    <div class="creation-container">
        <div class="block block-rounded block-bordered block-fx-shadow">
            <div class="block-header block-header-default">
                <h3 class="block-title text-center text-white font-weight-bolder m-4">
                    @lang('home.make_Billie')
                </h3>
            </div>
            <div class="block-content mb-4">
                <form action="{{ route('payment.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <label for="exampleInputname">@lang('home.Name')</label>
                        <input type="name" class="form-control" name="name" id="name" aria-describedby="name" placeholder="Billie @lang('home.Name')">
                    </div>
                    <div class="form-group">
                        <label for="IBAN">@lang('home.IBAN number')</label>
                        <select name="IBAN" class="custom-select">
                            @foreach($banks as $bank)
                            <option value="{!!$bank->IBAN!!}">{!!$bank->IBAN!!}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <div class="form-group">
                            <label for="exampleFormControlFile1">@lang('home.Img')</label>
                            <input type="file" accept="image/*" class="form-control-file" name="img" id="img">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="valuta">@lang('home.Currencies')</label>
                        <select name="valuta" class="custom-select">
                            <option value="EUR">@lang('home.EURO')</option>
                            <option value="GBP">@lang('home.Pound')</option>
                            <option value="USD">@lang('home.Dollars')</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputprice">@lang('home.Price')</label>
                        <input type="price" class="form-control" name="price" id="price" aria-describedby="price" placeholder="@lang('home.Price Tag')">
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlTextarea1">@lang('home.Description')</label>
                        <textarea class="form-control rounded-0" name="description" id="description" rows="10"></textarea>
                    </div>

                    <button type="submit" class="btn btn-success">@lang('home.Submit')</button>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection 