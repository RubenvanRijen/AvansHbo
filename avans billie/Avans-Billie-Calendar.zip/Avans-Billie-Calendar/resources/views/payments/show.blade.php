@extends('layouts.app')

@section('content')
    <div class="h-100">
        <div class="card text-center  mt-5">
            <div class="card-header text">
                Billie
            </div>
            <div class="card-body">
                <h5 class="card-title">@lang('home.Name'): {!! $payment->name!!}</h5>
                @if(!empty($payment->img))
                    <img style="width:20%" src="/storage/img/{!!$payment->img!!}">
                @endif
                <img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl={!!$payment->link!!}&choe=UTF-8"
                     title="Billie payment link"/>
                <p class="card-text">@lang('home.Price'): {!!$payment->price!!} @lang('home.EURO')</p>
                <p class="card-text">@lang('home.Description'): {!!$payment->description!!}</p>
                <p class="card-text">@lang('home.Amount_payed'): {!!$payment->amount!!}</p>
                <p class="card-text">Link: {!!$payment->link!!}</p>
                <small>You can only use this link once per person</small>


                <a href="/payments" class="btn float-left btn-success">@lang('home.Return')</a>

                <a href="/payments/share/{{$payment->id}}" class="btn float-right btn-success">@lang('home.Share')</a>
                <a href="/mollie/{{$payment->id}}" class="btn float-right btn-success">@lang('home.Link')</a>

            </div>
            <div class="card-footer text-muted">
                <?php
                $dt = $payment->created_at;
                if (app()->getLocale() == 'de') {
                    $new_dt = $dt->format('d-m-Y H:i');
                } else if (app()->getLocale() == 'nl') {
                    $new_dt = $dt->format('d-m-Y H:i');
                } else {
                    $new_dt = $dt->format('Y-m-d H:i');
                }
                ?>
                {!!$new_dt!!}
            </div>
        </div>
    </div>
@endsection 