<!DOCTYPE html>
<html lang="{{app()->getLocale() }}">

<head>
    @include('layouts.head')

</head>

<body>
    <header>
        @include('layouts.header')
    </header>

    @include('layouts.messages')
    @yield('content')

    @include('layouts.footer')

</body>

</html> 