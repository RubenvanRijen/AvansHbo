@extends('layouts.app')

@section('content')
<div class="h-100">
    <div class="card text-center  mt-5">
        <div class="card-header text">
            @lang('home.Groups')
        </div>
        <div class="card-body">
            <h5 class="card-title">@lang('home.Groups'): {!!$group->name!!}</h5>
            <hr>
            @foreach($groups as $group)
            <h5 class="card-text"> @lang('home.Member'): {!!$group->name!!} </h5>
            @endforeach

            <a href="/groups" class="btn btn-success">@lang('home.Return')</a>
        </div>
    </div>
</div>
@endsection 