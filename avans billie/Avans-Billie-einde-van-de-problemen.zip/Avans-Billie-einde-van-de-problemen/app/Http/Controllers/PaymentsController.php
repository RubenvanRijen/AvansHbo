<?php

namespace App\Http\Controllers;

use App\BankAccount;
use App\Group;
use App\Mail\PaymentRequest;
use Illuminate\Http\Request;
use App\Payment;
use App\User;
use DB;
use Illuminate\Support\Facades\Lang;


use Illuminate\Support\Facades\Mail;

class PaymentsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user_id = auth()->user()->id;
        $user = User::find($user_id);

        return view('payments.index')->with('payments', $user->payments);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $user_id = auth()->user()->id;
        $user = User::find($user_id);
        return view('payments.create')->with('banks', $user->bankaccounts)->with('groups', $user->groups);
    }

    public function share($id)
    {

        $payment = Payment::find($id);
        $user_id = auth()->user()->id;
        $user = User::find($user_id);
        return view('payments.share')->with('payments', $payment)->with('contacts', $user->contacts)
            ->with('groups', $user->groups);
    }

    public function mailContact(Request $request, $id)
    {
        $payment = Payment::find($id);
        Mail::to($request->email)->send(new PaymentRequest($payment));
        return redirect('/payments')->with('success', Lang::get('home.Billie_Sent'));
    }

    public function mailGroup($id, Request $request)
    {
        $payment = Payment::find($id);
        $group = $request->input('groups');
        $groups = Group::find($group);
        if (count($groups->contacts) <= 2) {
            foreach ($groups->contacts as $contact) {
                Mail::to($contact->email)->send(new PaymentRequest($payment));
            }
        } else {
            return redirect('/payments')->with('error', 'Om naar meer als 2 mensen tegelijk te sturen moet u betalen');

        }
        return redirect('/payments')->with('success', Lang::get('home.Billie_Sent'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|min:2|max:40|alpha_space',
            'description' => 'required|htmlclean|max:5000|alpha_space',
            'price' => 'required|max:7|regex:/^\d+\.\d\d$/',
            'img' => 'image|nullable|max:19999',
        ]);

        $fileNameToStore = null;
        // Handle File Upload
        if ($request->hasFile('img')) {
            // Get filename with the extension
            $filenameWithExt = $request->file('img')->getClientOriginalName();
            // Get just filename
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            // Get just ext
            $extension = $request->file('img')->getClientOriginalExtension();
            // Filename to store
            $fileNameToStore = $filename . '_' . time() . '.' . $extension;
            // Upload Image
            $path = $request->file('img')->storeAs('public/img', $fileNameToStore);
        }


        $payment = new Payment;
        $payment->name = $request->input('name');
        $payment->IBAN = $request->input('IBAN');
        //$payment->price = $request->input('price');
        $payment->valuta = $request->input('valuta');

        $course = 1;
        switch ($request->input('valuta')) {
            case 'USD':
                $course = 0.89;
                break;
            case 'GBP':
                $course = 1.16;
                break;
        }
        $change = $request->input('price') / $course;
        $payment->price = $change;

        if ($fileNameToStore != null) {
            $payment->img = $fileNameToStore;
        }else{
            $payment->img= 0;
        }
        $payment->description = $request->input('description');
        $payment->user_id = auth()->user()->id;
        $payment->email = auth()->user()->email;
        $payment->save();

        return redirect('/payments')->with('success', Lang::get('home.Billie_C_Success'));
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $payment = Payment::find($id);
        $payments = $payment->descriptions;
        //dd($payments);
        if (auth()->user()->id != $payment->user_id) {
            return redirect('/payments')->with('error',  Lang::get('home.Page_Unauthorized'));
        }

        return view('payments.show')->with('payment', $payment)->with('descriptions', $payments);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */


    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $payment = Payment::find($id);
        if (auth()->user()->id != $payment->user_id || $payment->paid == true) {
            return redirect('/payments')->with('error', Lang::get('home.Page_Unauthorized'));
        }
        $payment->delete();
        return redirect('/payments')->with('success', Lang::get('home.Billie_D_Succes'));
    }
}
