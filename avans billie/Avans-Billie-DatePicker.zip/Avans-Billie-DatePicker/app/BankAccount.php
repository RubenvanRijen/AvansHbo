<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Description;
use App\User as User;
use Illuminate\Support\Facades\Crypt;


class BankAccount extends Model
{
    public $primaryKey = 'IBAN';


    // public function getIBANAttribute($value) {
    //     return Crypt::decryptString($value);
    // }
  

    // public function setIBANAttribute($value) {
    //     $this->attributes['IBAN'] = Crypt::encryptString($value);
    // }

  


    public function users()
    {
        return $this->belongsTo(User::class);
    }

    public function descriptions()
    {
        return $this->Hasmany(Description::class);
    }



}
