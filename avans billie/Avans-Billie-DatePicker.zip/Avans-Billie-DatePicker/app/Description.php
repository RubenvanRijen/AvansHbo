<?php

namespace App;

use App\BankAccount;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class Description extends Model
{


    public function getnameAttribute($value) {
        return Crypt::decryptString($value);
    }

    public function setNameAttribute($value) {
        $this->attributes['name'] = Crypt::encryptString($value);
    }
    
    public function bankaccounts()
    {
        return $this->BelongsTo(BankAccount::class);
    }

    public function payments()
    {
        return $this->BelongsTo(Payment::class);

    }

}
