@extends('layouts.app')

@section('content')
<div class="HomeScreen">
    <img src="{{ asset('img/ducks.jpg') }}" class="align-top w-100" alt="">

</div>
@endsection 