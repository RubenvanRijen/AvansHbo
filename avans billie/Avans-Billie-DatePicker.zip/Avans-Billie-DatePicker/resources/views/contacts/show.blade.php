@extends('layouts.app')

@section('content')
<div class="h-100">
    <div class="card text-center  mt-5">
        <div class="card-header text">
            @lang('home.Contacts')
        </div>
        <div class="card-body">
            <h5 class="card-title">{!!$contacts->name!!}</h5>
            <p class="card-text">{!!$contacts->email!!}</p>
            <a href="/contacts" class="btn btn-success">@lang('home.Return')</a>
        </div>
    </div>
</div>
@endsection 