

<!DOCTYPE html>
<html dir="rtl" lang="he">
<head>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="styles.css">
<title>מערכת מעקב נוכחות - מרכז "בני ברוך" פתח תקוה</title>
<?php include("class_lib.php"); ?>
<script language="javascript" src="calendar/calendar.js"></script>
<link href="calendar/calendar.css" rel="stylesheet" type="text/css">
<script type="text/javascript"
        src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
        <script type="text/javascript"
        src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>
        <link rel="stylesheet" type="text/css"
        href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" />
<script type="text/javascript">
                $(document).ready(function(){
                    $("#gruppa_display_stat").autocomplete({
                        source:'get_data.php',
                        minLength:1
                    });
                });
        </script>
</head>
<body>

<?php
include 'top_menu.html';
$clear_surename=$_REQUEST['clear_surename'];
if($clear_surename)
{
	if(isset($_SESSION['surname']))
	unset($_SESSION['surname']);
	
	if(isset($_SESSION['gruppa_display_stat']))
		unset($_SESSION['gruppa_display_stat']);
}
$surname_filter=$_SESSION['surname'] ;
if (isset($_REQUEST['gruppa_display_stat']))
{
	$gruppa_display_stat=$_REQUEST['gruppa_display_stat'];
	$_SESSION['gruppa_display_stat']=$gruppa_display_stat;
	//echo "<p>gruppa_display_stat 1: ".$gruppa_display_stat."</p>";
}
elseif (isset($_SESSION['gruppa_display_stat']))
{
	$gruppa_display_stat=$_SESSION['gruppa_display_stat'];
}else{
	//echo "<p>gruppa_display_stat 2: ".$gruppa_display_stat."</p>";
	$gruppa_display_stat='';
}
?>
<p style="font-family:Arial, Helvetica, sans-serif">הזן כאן תאריכים בינהם תרצה לשלוף כמות חיסורים/איחורים</p>
<form id="form1" name="form1" method="post" action="statdisp.php">
<table border="0" cellspacing="0" cellpadding="2">
<tr>
<td>
מזהה:&nbsp;<input class="small" type="text" name="surname" value="<?php echo $surname_filter; ?>">
קבוצה:&nbsp;<input class="medium" type="text" id="gruppa_display_stat" name="gruppa_display_stat" autocomplete="off" value="<?php echo $gruppa_display_stat; ?>">
<input type="submit" name="Submit" value="שלח" />
</form>
<form id="form2" name="reset_surename" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" align="right">
	<input type="submit" name="clear_surename" value="נקה שדות" />
</form>
</td>
<td>
<?php	
	  $date3_default_not_formatted = mktime(0,0,0,date("m")-1,date("d"),date("Y"));
	  $date3_default = date("Y-m-d",$date3_default_not_formatted);
	  $date4_default = date("Y-m-d");
      
	  $myCalendar = new tc_calendar("date3", true, false);
	  $myCalendar->setIcon("calendar/images/iconCalendar.gif");
	  $myCalendar->setDate(date('d', strtotime($date3_default))
            , date('m', strtotime($date3_default))
            , date('Y', strtotime($date3_default)));
	  $myCalendar->setPath("calendar/");
	  $myCalendar->setYearInterval(2000, 2020);
	  $myCalendar->setAlignment('left', 'bottom');
	  $myCalendar->setDatePair('date3', 'date4', $date4_default);
	  $myCalendar->writeScript();	  
	  
	  $myCalendar = new tc_calendar("date4", true, false);
	  $myCalendar->setIcon("calendar/images/iconCalendar.gif");
	  $myCalendar->setDate(date('d', strtotime($date4_default))
           , date('m', strtotime($date4_default))
           , date('Y', strtotime($date4_default)));
	  $myCalendar->setPath("calendar/");
	  $myCalendar->setYearInterval(2000, 2020);
	  $myCalendar->setAlignment('left', 'bottom');
	  $myCalendar->setDatePair('date3', 'date4', $date3_default);
	  $myCalendar->writeScript();	  
	  ?>
</td>
<td><div class="arrow-right"></div></td>
</tr>
</table>
</body>
</html>