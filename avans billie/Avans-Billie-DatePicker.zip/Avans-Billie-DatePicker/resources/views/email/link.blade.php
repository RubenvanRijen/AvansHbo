<h2>@lang('home.MessageEmail') {{$payment->name}}</h2>
<hr>
@if($payment->link != null)
<h3>link:</h3>{{$payment->link}}
<img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl={!!$payment->link!!}&choe=UTF-8" title="Billie payment link" />
@endif
<hr>
<p>Team Billie</p> 