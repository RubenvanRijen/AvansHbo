@extends('layouts.app')

@section('content')
<div class="content ">
    <div class="creation-container">
        <div class="block block-rounded block-bordered block-fx-shadow">
            <div class="block-header block-header-default">
                <h3 class="block-title text-center text-white font-weight-bolder m-4">
                    @lang('home.Create a Bank Account')
                </h3>
            </div>
            <div class="block-content mb-4">
                <form action="{{ route('bankaccounts.store') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="exampleInputname">@lang('home.IBAN number')</label>
                        <input type="IBAN" class="form-control" name="IBAN" id="IBAN" aria-describedby="IBAN" placeholder="@lang('home.IBAN number')">
                    </div>
                    <button type="submit" class="btn float-right btn-primary">@lang('home.Submit')</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection 