@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2 class="text-white text-center">@lang('home.Contacts')</h2>
        </div>
        <div class="pull-right text-right">
            <a class="btn btn-success" href="/contacts/create"> @lang('home.Add New Contact')</a>
        </div>
    </div>
</div>

<table class="table table-striped table-light mr-2 ml-2">
    <tr>
        <th>@lang('home.Name')</th>
        <th>@lang('home.Email')</th>
        <th width="200px"></th>
    </tr>
    @foreach ($contacts as $contact)
    <tr>
        <td>{!!$contact->name!!}</td>
        <td>{!!$contact->email!!}</td>
        <td>
            <div class="row">
                <a class="btn btn-info text-white" href="/contacts/{!!$contact->id !!}}">@lang('home.Show')</a>
                <a class="btn btn-danger float-right" href='/contacts/delete/{!!$contact->id!!}}'>@lang('home.Delete')</a>
            </div>
        </td>
    </tr>
    @endforeach
</table>

{{--/* {!! $bankaccounts->links() !!} */--}}

@endsection 