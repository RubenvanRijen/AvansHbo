@extends('layouts.app')

@section('content')

    <div class="content ">
        <div class="creation-container">
            <div class="block block-rounded block-bordered block-fx-shadow">
                <div class="block-header block-header-default">
                    <h3 class="block-title text-center text-white font-weight-bolder m-4">
                        @lang('home.Price')
                    </h3>
                </div>
                <div class="block-content mb-4">
                    <form action="{{ route('donateamount') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="exampleInputname">@lang('home.donateamount')</label>
                            <input type="text" class="form-control" name="amount" id="amount" aria-describedby="name" placeholder=@lang('home.Price')
                        </div>
                        <input type="hidden" name="name" id="name" value="{{$id}}">
                        <button type="submit" class="donate mt-2 btn btn-success">Doneer vertrouwd</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection