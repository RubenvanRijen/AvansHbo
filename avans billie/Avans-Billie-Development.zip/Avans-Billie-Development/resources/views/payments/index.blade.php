@extends('layouts.app')

@section('content')

    <h1 class="text-white text-center">Billies</h1>
    @if(count($payments)>0)
        @foreach($payments as $payment)

            <div class="card mt-3 mb-4">
                <div class="card-header  text-center text">
                    Billie
                </div>
                <div class="card-body">
                    <a href="/payments/{!! $payment->id!!}" class="link-1">
                        <h5 class="card-title  text-center">{!! $payment->name!!}</h5>
                    </a>
                    <p class="card-text text-center">{!! $payment->price!!} Euro</p>

                    <p class="card-text text-center">{!! $payment->description!!}</p>
                    @if($payment->paid == false)
                        <hr>
                        <a class="btn btn-danger float-right"
                           href='/payments/delete/{!! $payment->id !!}'>@lang('home.Delete')</a>
                    @endif
                    {{--<a class="btn btn-success float-left" href="/payments/share/{{$payment->id}}">Share</a>--}}
                    <a href="mailto:" class="btn float-left btn-success">@lang('home.Mail')</a>

                </div>
                <div class="card-footer text-center text-muted">
                    <?php
                    $dt = $payment->created_at;
                    if (app()->getLocale() == 'de') {
                        $new_dt = $dt->format('d-m-Y H:i');
                    } else if (app()->getLocale() == 'nl') {
                        $new_dt = $dt->format('d-m-Y H:i');
                    } else {
                        $new_dt = $dt->format('Y-m-d H:i');
                    }
                    ?>
                    {!!$new_dt!!}
                </div>
            </div>
        @endforeach
        {{--{{$payments->links()}}--}}
    @else
        <p class="text-white text-center">@lang('home.Find_Billies')</p>
    @endif
@endsection 