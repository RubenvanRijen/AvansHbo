<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mollie\Laravel\Facades\Mollie;
use App\Payment;
use App\BankAccount;
use App\Mail\Link;
use Illuminate\Support\Facades\Lang;

class MollieController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }


    public function mail($contactEmail)
    {
        \Mail::to($contactEmail)->send(new Link);
    }


    public function preparePayment($id, Request $request)
    {
        $payment = Payment::find($id);

        $course = 1;
        switch ($payment->valuta) {
            case 'USD':
                $course = 0.89;
                break;
            case 'GBP':
                $course = 1.16;
                break;
        }
        $change = $payment->price * $course;
        $prices = number_format($change, 2);

        $number = number_format((float)$prices, 2, '.', '');

        $MollieTransaction = Mollie::api()->payments()->create(
            [
                'amount' => [
                    'currency' => "$payment->valuta",
                    'value' => "$number",
                ],
                'description' => $payment->name,
                'redirectUrl' => url('/mollie/' . $id . '/status'),

            ]
        );
        $MollieTransaction = Mollie::api()->payments()->get($MollieTransaction->id);
        \Cache::put($id, $MollieTransaction->id, 30);
        $payment->link = $MollieTransaction->getCheckoutUrl();
        $payment->save();
        return back();
    }


    public function paymentStatus($id)
    {
        $payment_id = \Cache::pull($id);
        if ($payment_id === 0 or $payment_id === null) {
            return redirect('/')->with('error', Lang::get('home.Payment_Error'));
        }
        $MollieTransaction = Mollie::api()->payments()->get($payment_id);

        if ($MollieTransaction->isPaid()) {
            $payment = Payment::find($id);
            $payment->paid = true;
            $payment->amount = $payment->amount + 1;
            $payment->password = $this->generateRandomString();
            $payment->save();
            $IBAN = BankAccount::where('IBAN', $payment->IBAN)->first();
            if ($IBAN == null) {
                return redirect('/')->with('error', Lang::get('home.Payment_Try_Again'));
            }
            $IBAN->payed = $IBAN->payed + 1;
            $IBAN->balance = $IBAN->balance + $payment->price;
            $IBAN->save();
            
            return redirect('description/showform/' . $payment->id . '/' . $IBAN->id. '/' .$payment->password);
        }
        return redirect('/')->with('error', Lang::get('home.Payment_Try_Again'));
    }

    function generateRandomString($length = 5) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    public function donate($id)
    {
        $payment = Payment::find($id);
        $payment->link = 'http://billie.local/mollie/donateView/' . $id;
        $payment->save();
        return back();
    }

    public function donateView($id)
    {
        $payment = Payment::find($id);
        if ($payment === null) {
            return redirect('/')->with('error', Lang::get('home.Payment_Error'));

        } else if ($payment->price != 0.00) {
            return redirect('/')->with('error', Lang::get('home.Payment_Error'));
        }
        return view('payments.donate')->with('id', $id);
    }

    public function donateAmount(Request $request)
    {
        $payment = Payment::find($request->name);
        $this->validate(
            request(), [
                'amount' => 'max:1000|numeric|between:0,1000000000.99',
            ]
        );


        $DonateAmount = sprintf("%.2f", $request->input('amount'));
        $paymentMollie = Mollie::api()->payments()->create(
            [
                'amount' => [
                    'currency' => "$payment->valuta",
                    'value' => $DonateAmount, // You must send the correct number of decimals, thus we enforce the use of strings
                ],
                'description' => "Doneren",
                'redirectUrl' => url('/mollie/' . $request->name . '/donateStatus/' . $DonateAmount),
            ]
        );
        \Cache::put($request->name, $paymentMollie->id, 30);
        $paymentMollie = Mollie::api()->payments()->get($paymentMollie->id);
        return redirect($paymentMollie->getCheckoutUrl(), 303);
    }

    public function donateStatus($id, $amount)
    {
        $payment_id = \Cache::pull($id);
        if ($payment_id === 0 or $payment_id === null) {
            return redirect('/')->with('error', Lang::get('home.Payment_Error'));
        }
        $MollieTransaction = Mollie::api()->payments()->get($payment_id);

        if ($MollieTransaction->isPaid()) {
            $payment = Payment::find($id);
            if ($payment === null) {
                return redirect('/')->with('error', Lang::get('home.Payment_Try_Again'));

            }
            $payment->paid = true;
            $payment->amount = $payment->amount + 1;

            $course = 1;
            switch ($payment->valuta) {
                case 'USD':
                    $course = 0.89;
                    break;
                case 'GBP':
                    $course = 1.16;
                    break;
            }
            $change = $amount * $course;
            $prices = number_format($change, 2);

            $number = number_format((float)$prices, 2, '.', '');

            $payment->password = $this->generateRandomString();
            $payment->donatedamount = $number;
            $payment->save();
            $IBAN = BankAccount::where('IBAN', $payment->IBAN)->first();
            if ($IBAN == null) {
                return redirect('/')->with('error', Lang::get('home.Payment_Try_Again'));
            }
            $IBAN->donated = $IBAN->donated + 1;
            $IBAN->balance = $IBAN->balance + $number;
            $IBAN->save();
            $IBANtel = BankAccount::where('IBAN', $payment->IBAN)->first();
            return redirect('description/showform/' . $payment->id . '/' . $IBANtel->id . '/' .$payment->password);
        }
        return redirect('/')->with('error', Lang::get('home.Payment_Try_Again'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
