<?php

namespace App\Http\Controllers;

use App\BankAccount;
use App\Payment;
use Illuminate\Http\Request;
use App\Description;
use Illuminate\Support\Facades\Lang;
use Illuminate\Contracts\View\View;

class DescriptionController extends Controller
{


    public function showform($id, $ids, $password)
    {
        $payment = Payment::find($id);
        if($password != $payment->password){
            return redirect('/')->with('error', 'Betaling is niet voltooid en je bericht is niet correct opgegeslagen/payment');
        }


        if ($payment->password != '0') {
            return view('descriptions.description')->with('id', $id)->with('ids', $ids);
        } else {
            return redirect('/')->with('error', 'Betaling is voltooid maar je bericht is niet correct opgegeslagen/payment');
        }
    }

    public function storeDescription(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|min:2|max:40|alpha_space',
            'description' => 'required|htmlclean|max:5000|alpha_space',
        ]);

        $description = new Description();
        $description->name = $request->input('name');
        $description->note = $request->input('description');

        $payment = Payment::find($request->input('id'));
        if ($payment != null) {
            $description->payment_id = $request->input('id');

            if ($payment->price != 0.00) {
                $description->amount = $payment->price;
            } else {
                $description->amount = $payment->donatedamount;
            }
            $description->valuta = $payment->valuta;
        } else {
            return redirect('/')->with('error', 'Betaling is voltooid maar je bericht is niet correct opgegeslagen/payment');
        }
        

        if ($payment->price != 0.00) {
            $description->typeofpayment = 'Normale Betaling';
        } else {
            $description->typeofpayment = 'Gedoneerd';
        }

        $bank = Bankaccount::find($request->input('ids'));
        if ($bank != null) {
            $description->bank_account_id = $request->input('ids');
        } else {
            return redirect('/')->with('error', 'Betaling is voltooid maar je bericht is niet correct opgegeslagen/iban');
        }
        $payment->password = '0';
        $payment->save();
        $description->save();
        return redirect('/')->with('success', Lang::get('home.Payment_Complete'));
    }
}
