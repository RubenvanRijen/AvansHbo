<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Description;
use App\User as User;

class BankAccount extends Model
{
    //public $primaryKey = 'IBAN';

    public function users()
    {
        return $this->belongsTo(User::class);
    }

    public function descriptions()
    {
        return $this->Hasmany(Description::class);
    }



}
