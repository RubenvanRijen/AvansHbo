<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Group extends Model
{



    public function users()
    {
        return $this->BelongsTo(User::class);
        //, 'groups_users', 'user_id', 'group_id'
    }

    public function contacts()
    {
        return $this->belongsToMany(Contact::class);
    }
}
