<?php

namespace App;

use App\BankAccount;
use Illuminate\Database\Eloquent\Model;

class Description extends Model
{

    public function bankaccounts()
    {
        return $this->BelongsTo(BankAccount::class);
    }

    public function payments()
    {
        return $this->BelongsTo(Payment::class);

    }

}
