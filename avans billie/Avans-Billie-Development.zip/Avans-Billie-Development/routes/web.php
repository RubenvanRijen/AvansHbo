<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/terms', function () {
    return view('terms');
});

Route::get('locale/{locale}', function ($locale) {
    Session::put('locale', $locale);
    return redirect()->back();
});

Route::get('/payments/locale/{locale}', function ($locale) {
    Session::put('locale', $locale);
    return redirect()->back();
});

Route::get('/bankaccounts/locale/{locale}', function ($locale) {
    Session::put('locale', $locale);
    return redirect()->back();
});

Route::get('/groups/locale/{locale}', function ($locale) {
    Session::put('locale', $locale);
    return redirect()->back();
});

Route::get('/contacts/locale/{locale}', function ($locale) {
    Session::put('locale', $locale);
    return redirect()->back();
});

Route::get('/description/locale/{locale}', function ($locale) {
    Session::put('locale', $locale);
    return redirect()->back();
});

Route::get('/mollie/locale/{locale}', function ($locale) {
    Session::put('locale', $locale);
    return redirect()->back();
});

Route::get('/mollie/donateView/locale/{locale}', function ($locale) {
    Session::put('locale', $locale);
    return redirect()->back();
});

Route::get('/description/showform/{id}/{ids}/locale/{locale}', function ($locale) {
    Session::put('locale', $locale);
    return redirect()->back();
});



Auth::routes();

Route::resource('payments', 'PaymentsController');
Route::get('/payments/delete/{id}', 'PaymentsController@destroy');
Route::post('/payments/store', 'PaymentsController@store')->name('payment.store');


Route::resource('bankaccounts', 'BankAccountsController');
Route::get('/bankaccounts/delete/{id}', 'BankAccountsController@destroy');
Route::get('/bankaccounts/{id}', 'BankAccountsController@show');
Route::post('/bankaccounts/store', 'BankAccountsController@store')->name('bankaccounts.store');


Route::resource('groups', 'GroupsController');
Route::get('/groups/delete/{id}', 'GroupsController@destroy');
Route::post('/groups/store', 'GroupsController@store')->name('group.store');

Route::resource('contacts', 'ContactsController');
Route::get('/contacts/delete/{id}', 'ContactsController@destroy');
Route::post('/contacts/store', 'ContactsController@store')->name('contacts.store');

//Route::resource('mollie', 'MollieController');

Route::get('mollie/{id}/status', 'MollieController@paymentStatus')->name('status');
Route::get('mollie/{id}', 'MollieController@preparePayment');
Route::get('mollie/donate/{id}', 'MollieController@donate');
Route::get('mollie/donateView/{id}', 'MollieController@donateView');
Route::post('mollie/donateAmount', 'MollieController@donateAmount')->name('donateamount');
Route::get('mollie/{id}/donateStatus/{amount}', 'MollieController@donateStatus');

Route::resource('description', 'DescriptionController');
Route::get('description/showform/{id}/{ids}/{password}', 'DescriptionController@showform');
Route::post('description/store', 'DescriptionController@storeDescription')->name('description.store');



Route::get('/payments/share/{id}', 'PaymentsController@share');
Route::post('/payments/mailContact/{id}', 'PaymentsController@mailContact')->name('mailContact');
Route::post('/payments/mailGroup/{id}', 'PaymentsController@mailGroup')->name('mailGroup');

