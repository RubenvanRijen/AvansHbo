<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);



        \App\Payment::create(['name' => 'etentje', 'description' => 'Bedankt voor het betalen van deze boete', 'IBAN' =>
        'NLRABO0987654321', 'valuta' => 'EUR', 'price' => '100.58', 'paid' => true, 'created_at' => '2019-03-25', 'img' => 'null' , 'user_id' => '2']);

        \App\Payment::create(['name' => 'team_uitje', 'description' => 'Bedankt voor het betalen van deze boete', 'IBAN' =>
            'NLRABO0987654321', 'valuta' => 'EUR', 'price' => '100.58', 'paid' => false , 'created_at' => '2019-03-26' , 'img' => 'null', 'user_id' => '1']);

        \App\Payment::create(['name' => 'team_uitje', 'description' => 'Bedankt voor het betalen van deze boete', 'IBAN' =>
            'NLRABO0987654321', 'valuta' => 'EUR', 'price' => '100.58', 'paid' => false , 'created_at' => '2019-03-26' , 'img' => 'null', 'user_id' => '3']);

        \App\User::create(['name' => 'Test', 'email' => 'test@gmail.com','password' => bcrypt('password')]);
        \App\User::create(['name' => 'Jim', 'email' => 'jim@gmail.com','password' => bcrypt('jim12345')]);
        \App\User::create(['name' => 'Ruben', 'email' => 'ruben@gmail.com', 'password' => bcrypt('ruben12345')]);

        \App\BankAccount::create(['IBAN' => 'DE89 3704 0044 0532 0130 00', 'user_id' => '1']);
        \App\BankAccount::create(['IBAN' => 'AL35202111090000000001234567', 'user_id' => '1']);
        \App\BankAccount::create(['IBAN' => 'NL02ABNA0123456789', 'user_id' => '2']);
        \App\BankAccount::create(['IBAN' => 'NO8330001234567', 'user_id' => '3']);

        \App\Contact::create(['name' => 'Jimmekeee', 'email' => 'jim@hotmail.com', 'user_id' => '3']);
        \App\Contact::create(['name' => 'Ruben De Boef', 'email' => 'rubem@hotmail.com', 'user_id' => '2']);

        \App\Group::create(['name' => 'Pipo Among Friends', 'user_id' => '2']);
        \App\Group::create(['name' => 'Dn Buufe Bende', 'user_id' => '3']);
    }
}
