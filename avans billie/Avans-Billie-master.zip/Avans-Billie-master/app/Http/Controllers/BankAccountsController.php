<?php

namespace App\Http\Controllers;

use App\BankAccount;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\View;
use PDF as PDF;
use Illuminate\Http\Response;


class BankAccountsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user_id = auth()->user()->id;
        $user = User::find($user_id);

        $bankaccounts = Bankaccount::latest()->paginate(5);

        return view('bankaccounts.index', compact('bankaccounts'))
            ->with('bankaccounts', $user->bankaccounts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('bankaccounts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'IBAN' => 'required|iban|unique:bank_accounts',
        ]);

        $bankaccount = new BankAccount();
        $bankaccount->IBAN = $request->input('IBAN');
        $bankaccount->user_id = auth()->user()->id;
        $bankaccount->save();

        return redirect()->to('/bankaccounts')->with('success', Lang::get('home.IBAN_C_Success'));
    }

    /**
     * Display the specified resource.
     *
     * @param \App\BankAccount $IBAN
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $bankaccount = BankAccount::find($id);
        return view('bankaccounts.show')->with('bankaccounts', $bankaccount);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\BankAccount $bankaccount
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $bankaccount = BankAccount::find($id);
        $bankaccount->delete();
        if (auth()->user()->id != $bankaccount->user_id) {
            return redirect('/contacts')->with('error', Lang::get('home.Page_Unauthorized'));
        }
        return redirect()->to('/bankaccounts')
            ->with('success', Lang::get('home.IBAN_D_Success'));
    }


    public function uploadToDropbox()
    {
        return View::make('dropbox');

    }

    public function uploadToDropboxFile(Request $RequestInput)
    {
        $file_src = $RequestInput->file("upload_file"); //file src
        if($file_src == null){
            return Redirect::back()->withErrors(['error' => 'file failed to uploaded on dropbox']);
        }
        $is_file_uploaded = Storage::disk('dropbox')->put('public-uploads', $file_src);

        if ($is_file_uploaded) {
            return Redirect::back()->withErrors(['success' => 'Succesfuly file uploaded to dropbox']);
        } else {
            return Redirect::back()->withErrors(['error' => 'file failed to uploaded on dropbox']);
        }
    }


    function pdf()
    {
        $pdf = \App::make('dompdf.wrapper');
        $pdf->loadHTML($this->convert_customer_data_to_html());
        return $pdf->stream();
    }

    function getData()
    {
        $user_id = auth()->user()->id;
        $user = User::find($user_id);
        $data = $user->bankaccounts;
        return $data;
    }

    function convert_customer_data_to_html()
    {
        $data = $this->getData();
        $output = '
     <h3 align="center">Customer Data</h3>
     <table width="100%" style="border-collapse: collapse; border: 0px;">
      <tr>
    <th style="border: 1px solid; padding:12px;" width="50%">IBAN</th>
    <th style="border: 1px solid; padding:12px;" width="50%">Balance</th>

   </tr>
     ';
        foreach ($data as $datas) {
            $output .= '
      <tr>
       <td style="border: 1px solid; padding:12px;">' . $datas->IBAN . '</td>
       <td style="border: 1px solid; padding:12px;">' . $datas->balance . '</td>
        </tr>
      ';
        }
        $output .= '</table>';
        return $output;
    }
}
