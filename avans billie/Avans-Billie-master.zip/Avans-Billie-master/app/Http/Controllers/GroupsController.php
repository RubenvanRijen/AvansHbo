<?php

namespace App\Http\Controllers;


use App\Contact;
use App\Group;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Lang;


class GroupsController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user_id = auth()->user()->id;
        $user = User::find($user_id);


        return view('groups.index')->with('groups', $user->groups);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $user_id = auth()->user()->id;
        $user = User::find($user_id);
        return view('groups.create')->with('contacts', $user->contacts);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|min:2|max:40|alpha_space',
            'contacts' => 'required',
        ]);

        $group = new Group();
        $group->name = $request->input('name');
        $group->user_id = auth()->user()->id;
        $group->save();
        foreach ($request->input('contacts') as $contact) {
            $groups = Group::find($group->id);
            $contact = Contact::find($contact);
            $contact->groups()->attach($groups);
        }
        return redirect('/groups')->with('success', Lang::get('home.Group_C_Success'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $group = Group::find($id);

        if (auth()->user()->id != $group->user_id) {
            return redirect('/groups')->with('error', Lang::get('home.Page_Unauthorized'));
        }
        return view('groups.show')->with('groups', $group->contacts)->with('group', $group);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $group = Group::find($id);
        if (auth()->user()->id != $group->user_id) {
            return redirect('/groups')->with('error', Lang::get('home.Page_Unauthorized'));
        }
        $group->delete();
        return redirect('/groups')->with('success', Lang::get('home.Group_D_Success'));
    }
}
