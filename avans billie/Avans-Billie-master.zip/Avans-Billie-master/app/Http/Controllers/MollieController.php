<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mollie\Laravel\Facades\Mollie;
use App\Payment;
use App\BankAccount;
use App\Mail\Link;
use Illuminate\Support\Facades\Lang;

class MollieController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }


    public function mail($contactEmail)
    {
        \Mail::to($contactEmail)->send(new Link);
    }


    public function preparePayment($id)
    {
        $payment = Payment::find($id);


        $MollieTransaction = Mollie::api()->payments()->create(
            [
                'amount' => [
                    'currency' => "$payment->valuta",
                    'value' => "$payment->price",
                ],
                'description' => $payment->name,
                'redirectUrl' => url('/mollie/' . $id . '/status'),

            ]
        );
        $MollieTransaction = Mollie::api()->payments()->get($MollieTransaction->id);
        \Cache::put($id, $MollieTransaction->id, 30);
        $payment->link = $MollieTransaction->getCheckoutUrl();
        $payment->save();
        return back();
    }

    public function paymentStatus($id)
    {
        $payment_id = \Cache::pull($id);
        if ($payment_id === 0 or $payment_id === null) {
            return redirect('/')->with('error', Lang::get('home.Payment_Error'));
        }
        $MollieTransaction = Mollie::api()->payments()->get($payment_id);

        if ($MollieTransaction->isPaid()) {
            $payment = Payment::find($id);
            $payment->paid = true;
            $payment->amount = $payment->amount + 1;
            $payment->save();
            $IBAN = BankAccount::where('IBAN', $payment->IBAN)->first();
            $IBAN->balance = $IBAN->balance + $payment->price;
            $IBAN->save();

            return redirect('/')->with('success', Lang::get('home.Payment_Complete'));
        }
        return redirect('/')->with('error', Lang::get('home.Payment_Try_Again'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
