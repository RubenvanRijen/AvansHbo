<footer class="footer-distributed position-static bg-dark">
    <div class="footer-right">

        <a href="https://www.facebook.com/"><i class="fab fa-facebook-square"></i></a>
        <a href="https://twitter.com/"><i class="fab fa-twitter-square"></i> </a>
        <a href="https://www.instagram.com/?hl=nl"><i class="fab fa-instagram"></i> </a>
        <a href="https://github.com/"><i class="fab fa-github-square"></i></a>

    </div>

    <div class="footer-left ">

        <h3 class="text-white">@guest @if (Route::has('register'))@lang('home.welcome') To Billie
            @endif
            @else @lang('home.welcome') {{ Auth::user()->name }} @endguest</h3>
        <div class="row">

            <a class="nav-link" href="locale/nl">
                <h4 class="text-white">@lang('home.language-dutch')</h4>
            </a>
            <a class="nav-link" href="locale/en">
                <h4 class="text-white">@lang('home.language-english')</h4>
            </a>
            <a class="nav-link" href="locale/de">
                <h4 class="text-white">@lang('home.language-german')</h4>
            </a>

        </div>
        <p>@lang('home.copyright')</p>

    </div>
</footer> 