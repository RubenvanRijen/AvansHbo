@extends('layouts.app')

@section('content')
<div class="m-3 h-75">
    <h1 class="text-white text-center">Share with contact</h1>
    <form action="/payments/mailContact/{{$payments->id}}" method="POST">
        @csrf
        <div class="form-group">
            <label for="exampleFormControlSelect1">@lang('home.Contacts')</label>
            <select name="email" class="custom-select">
                @foreach($contacts as $contact)
                <option value="{{ $contact->email }}">{{$contact->name}}</option>
                @endforeach
            </select>
        </div>
        <button type="submit" class="btn btn-primary float-right">Share with contact</button>
    </form>

    <hr class="mt-5">

    <h1 class="text-white text-center">Share with group</h1>
    <form action="/payments/mailGroup/{{$payments->id}}" method="POST">
        @csrf
        <div class="form-group">
            <label for="exampleFormControlSelect1">@lang('home.Groups')</label>
            <select name="groups" class="custom-select">
                @foreach($groups as $group)
                <option value="{{$group->id }}">{{$group->name}}</option>
                @endforeach
            </select>
        </div>
        <button type="submit" class="btn btn-primary float-right">Share with group</button>
    </form>
</div>
@endsection 