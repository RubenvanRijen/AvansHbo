﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    public class WareHouse : Track
    {


        public WareHouse()
        {

        }


    }
}
