﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    public class ShuntingTrack : Track
    {
        public ShuntingTrack()
        {
            this.Char = '═';
            this.Backup = Char;
        }
    }
}
