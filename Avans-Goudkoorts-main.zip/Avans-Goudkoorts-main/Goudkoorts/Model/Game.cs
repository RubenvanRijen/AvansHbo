﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    public class Game
    {
        public Ship ships;
        private List<Cart> _carts;
        private TileList _tileList;
        public int Time { get; set; }
        public TileList TileList { get { return _tileList; } }
        public int score;
        private int chanceOfOccurance;
        public bool CanWeGiveLoads;
        public Game(TileList tileList)
        {
            Time = 5000;
            ships = new Ship();
            _carts = new List<Cart>();
            this._tileList = tileList;
            _tileList.CreateTrackList();
            score = 0;
        }



        public void ChangeSwitches(int l)
        {
            _tileList.Change(l);
        }

        public bool MoveCarts()
        {
            foreach (Cart k in _carts)
            {
                if (!k.Move())
                {
                    return false;
                }
            }
            return true;
        }

        public int UpdateShipCounter()
        {
            var track = _tileList.FindDeliveryTrack().ToArray();
            if (track[0].Cart != null)
            {
                if (ships.counter == 7)
                {
                    score = score + 10;
                    if (Time != 1000)
                    {
                        Time = Time - 1000;
                    }
                }
                else
                {
                    score = score + 1;

                }
                chanceOfOccurance++;
                return ships.counter++;
            }
            return ships.counter;
        }
        public void SetFullCart()
        {
            var track = _tileList.FindDeliveryTrack().ToArray();
            if (ships.counter == 8)
            {
                track[0].switchChar = false;
            }
            else
            {
                track[0].switchChar = true;
            }
        }

        public void FirstCart()
        {
            Random generator = new Random();
            int whichWareHouse = generator.Next(0, 3);
            var warehousesList1 = TileList.FindWareHouses().ToArray();
            var track1 = (Track)warehousesList1[whichWareHouse].Next;
            var cart1 = new Cart(track1);
            warehousesList1[whichWareHouse].Next.SetCart(cart1);
            _carts.Add(cart1);

        }
        public void GenerateCart()
        {

            Random generator = new Random();
            if (chanceOfOccurance >= 98)
            {
                chanceOfOccurance = 98;
            }
            int canGenerate = generator.Next(1, 100 - chanceOfOccurance);
            int whichWareHouse = generator.Next(0, 3);
            if (canGenerate <= 20)
            {
                var warehousesList = TileList.FindWareHouses().ToArray();
                var track = (Track)warehousesList[whichWareHouse].Next;
                var cart = new Cart(track);
                warehousesList[whichWareHouse].Next.SetCart(cart);
                _carts.Add(cart);
            }
        }

        public String LevelToText()
        {
            String text = "";
            Tile temp = TileList.First;
            while (temp != TileList.Last)
            {
                int counter = 0;
                while (temp.Right != null)
                {
                    text = text.Insert(text.Length, temp.Char.ToString());
                    temp = temp.Right;
                    counter++;
                }
                text = text.Insert(text.Length, temp.Char.ToString());
                text = text.Insert(text.Length, "\r\n");
                if (temp != TileList.Last)
                {
                    for (int i = 0; i < counter; i++)
                    {
                        temp = temp.Left;
                    }
                    if (temp.Bottom != null)
                    {
                        temp = temp.Bottom;
                    }
                }
            }
            return text;
        }
    }
}