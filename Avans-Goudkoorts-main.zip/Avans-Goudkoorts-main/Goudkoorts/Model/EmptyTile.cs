﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    class EmptyTile : Tile
    {
    }
}
