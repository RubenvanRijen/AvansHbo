﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    public class SwitchTrack : Track
    {
        private Direction _direction;
        public Direction Direction { get { return _direction; } set { this._direction = value; } }

        public SwitchTrack(Direction direction)
        {
            this._direction = direction;
            this.SetCharacter();
            Backup = this.Char;
        }

        public void SetCharacter()
        {
            switch (_direction)
            {
                case Direction.From_Bottom:
                    this.Char = '╓';                    
                    this.Previous = (Track)Bottom;
                    break;

                case Direction.From_Top:
                    this.Char = '╙';
                    this.Previous = (Track)Top;
                    break;

                case Direction.To_Bottom:
                    this.Char = '╕';
                    this.Next = (Track)Bottom;
                    break;

                case Direction.To_Top:
                    this.Char = '╛';
                    this.Next = (Track)Top;
                    break;
            }
            Backup = this.Char;
        }

        public void SwitchTrackDirection()
        {
            if (this.Cart != null)
            {
                return;
            }
            if (_direction == Direction.From_Bottom)
            {
                _direction = Direction.From_Top;
            }
            else if (_direction == Direction.From_Top)
            {
                _direction = Direction.From_Bottom;
            }
            else if (_direction == Direction.To_Bottom)
            {
                _direction = Direction.To_Top;
            }
            else if (_direction == Direction.To_Top)
            {
                _direction = Direction.To_Bottom;
            }
            SetCharacter();
        }
    }
}
