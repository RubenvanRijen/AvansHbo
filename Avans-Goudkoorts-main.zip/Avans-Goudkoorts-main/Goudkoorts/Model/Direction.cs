﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    public enum Direction
    {
        From_Top,
        From_Bottom,
        To_Top,
        To_Bottom
    }
}
