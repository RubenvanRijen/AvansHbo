﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    public class Cart
    {
        private Track _currentTrack;
        private bool _isEmpty;
        public Track CurrentTrack { get { return _currentTrack; } set { _currentTrack = value; } }
        public bool IsEmpty { get { return _isEmpty; } set { _isEmpty = value; } }



        public Cart(Track startTrack)
        {
            _currentTrack = startTrack;
            _isEmpty = false;
        }

        public bool Move()
        {
            if (_currentTrack.Next == null)
            {
                if (_currentTrack is ShuntingTrack)
                {
                    return true;
                }
                else
                {
                    _currentTrack.RemoveCart();
                    return true;
                }
            } 
            if (_currentTrack.Next is SwitchTrack s)
            {
                if (s.Direction == Direction.From_Bottom && _currentTrack.Bottom == s)
                {
                    return true;
                }
                if (s.Direction == Direction.From_Top && _currentTrack.Top == s)
                {
                    return true;
                }
                ExecuteMove();
                return true;
            }
            if (_currentTrack.Next.Cart != null && !(_currentTrack.Next is ShuntingTrack))
            {
                return false;
            }
            if (_currentTrack.Next is ShuntingTrack e)
            {
                if (_currentTrack is ShuntingTrack)
                {
                    if (e.Cart != null)
                    {
                        return true;
                    }
                    ExecuteMove();
                    return true;
                }
                if (e.Cart != null)
                {
                    return false;
                }
            }
            if (_currentTrack.Next == null)
            {
                if (_currentTrack is ShuntingTrack)
                {
                    return true;
                }
                if (_isEmpty)
                {
                    _currentTrack.Cart = null;
                    return true;
                }
            }
            ExecuteMove();
            return true;
        }

        private void ExecuteMove()
        {
            _currentTrack.Next.SetCart(this);
            _currentTrack.Previous.RemoveCart();
        }
    }
}
