﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    public class Ship
    {
        public int counter;
        public Ship()
        {
            counter = 0;  
        }
    }
}
