﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    public enum TrackShape
    {
        Horizontal,
        Vertical,
        Left_Up,
        Down_Left,
        Down_Right,
        Up_Right

    }
}
