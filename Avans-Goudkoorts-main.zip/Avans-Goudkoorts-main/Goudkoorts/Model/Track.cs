﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    public abstract class Track : Tile
    {
        public Track Next { get; set; }
        public Track Previous { get; set; }
        public Cart Cart { get; set; }
        private Char backup;
        public Char Backup { get { return backup; } set { backup = value; } }

        public Track()
        {
            backup = this.Char;
        }

        public void RemoveCart()
        {
            this.Cart = null;
            this.Char = backup;
        }
        public virtual void SetCart(Cart cart)
        {
            this.Cart = cart;
            cart.CurrentTrack = this;
            if (Cart.IsEmpty)
            {
                backup = Char;
                this.Char = 'O';

            }
            else
            {
                this.Char = '#';
            }
        }
    }
}
