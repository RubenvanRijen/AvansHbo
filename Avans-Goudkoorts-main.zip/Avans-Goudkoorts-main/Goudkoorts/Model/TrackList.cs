﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    public class TrackList
    {
        private Track _originTrack;
        public Track First { get; set; }
        public Track Last { get; set; }

        public TrackList(Track originTrack)
        {
            this._originTrack = originTrack;
            this.First = originTrack;
            this.Last = originTrack;
        }

        public void AddTrack(Track track, bool bottomSplit)
        {
            if (bottomSplit)
            {
                SwitchTrack a = (SwitchTrack)_originTrack;
                track.Previous = _originTrack;
                First = track;
                Last = track;
                return;
            }
            if (track is SwitchTrack t && (t.Direction == Direction.From_Bottom || t.Direction == Direction.From_Top))
            {
                this.Last.Next = t;
                Last = t;
                return;
            }
            Last.Next = track;
            track.Previous = Last;
            Last = track;
            if (First == _originTrack)
            {
                First = track;
            }

        }

        public void ConnectToExistingSwitch(SwitchTrack track)
        {
            Last.Next = track;
            track.Bottom = Last;
        }
    }
}
