﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    public class DeliveryTrack : Track
    {
        public bool switchChar;
        public DeliveryTrack()
        {
            switchChar = true;
            this.Char = '╨';
            Backup = this.Char;
        }
        public override void SetCart(Cart cart)
        {
            cart.IsEmpty = switchChar;
            base.SetCart(cart);
        }
    }
}
