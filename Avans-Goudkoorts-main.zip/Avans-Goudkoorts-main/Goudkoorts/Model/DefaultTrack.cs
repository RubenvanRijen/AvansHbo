﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    class DefaultTrack : Track
    {
        private TrackShape _trackShape;
        public DefaultTrack(TrackShape trackShape)
        {
            this._trackShape = trackShape;
            this.SetCharacter();
            Backup = this.Char;
        }
        private void SetCharacter()
        {
            switch (_trackShape)
            {
                case TrackShape.Down_Left:
                    this.Char = '┐';
                    break;

                case TrackShape.Down_Right:
                    this.Char = '┌';
                    break;

                case TrackShape.Horizontal:
                    this.Char = '─';
                    break;

                case TrackShape.Left_Up:
                    this.Char = '┘';
                    break;

                case TrackShape.Up_Right:
                    this.Char = '└';
                    break;

                case TrackShape.Vertical:
                    this.Char = '│';
                    break;
            }
        }
    }
}
