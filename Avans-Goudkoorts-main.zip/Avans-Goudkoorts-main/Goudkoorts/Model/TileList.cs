﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Model
{
    public class TileList
    {
        public Tile First { get; set; }
        public Tile Last { get; set; }

        public void InsertToRight(Tile newTile)
        {
            if (First == null)
            {
                First = newTile;
                Last = newTile;
            }
            else
            {
                newTile.Left = Last;
                Last.Right = newTile;
                if (Last.Top != null && Last.Top.Right != null)
                {
                    newTile.Top = Last.Top.Right;
                    newTile.Top.Bottom = newTile;
                }
                Last = newTile;
            }

        }

        public void InsertNextLine(Tile newTile)
        {
            Tile temp = Last;
            while (temp.Left != null)
            {
                temp = temp.Left;
            }
            newTile.Top = temp;
            temp.Bottom = newTile;
            Last = newTile;
        }

        public List<DeliveryTrack> FindDeliveryTrack()
        {
            List<DeliveryTrack> delivery = new List<DeliveryTrack>();
            Tile current = First;
            while (current != Last)
            {
                while (current.Right != null)
                {
                    if (current is DeliveryTrack)
                    {
                        delivery.Add((DeliveryTrack)current);
                    }
                    current = current.Right;
                }
                if (current != Last)
                {
                    while (current.Left != null)
                    {
                        current = current.Left;
                    }
                    if (current.Bottom != null)
                    {
                        current = current.Bottom;
                    }
                }
            }
            return delivery;
        }

        public List<ShuntingTrack> FindShuntingTracks()
        {
            List<ShuntingTrack> shuntingTrack = new List<ShuntingTrack>();
            Tile current = First;
            while (current != Last)
            {
                while (current.Right != null)
                {
                    if (current is ShuntingTrack)
                    {
                        shuntingTrack.Add((ShuntingTrack)current);
                    }
                    current = current.Right;
                }
                if (current != Last)
                {
                    while (current.Left != null)
                    {
                        current = current.Left;
                    }
                    if (current.Bottom != null)
                    {
                        current = current.Bottom;
                    }
                }
            }
            return shuntingTrack;
        }

        public List<WareHouse> FindWareHouses()
        {
            List<WareHouse> wareHouses = new List<WareHouse>();
            Tile current = First;
            while (current != Last)
            {
                while (current.Right != null)
                {
                    if (current is WareHouse)
                    {
                        wareHouses.Add((WareHouse)current);
                    }
                    current = current.Right;
                }
                if (current != Last)
                {
                    while (current.Left != null)
                    {
                        current = current.Left;
                    }
                    if (current.Bottom != null)
                    {
                        current = current.Bottom;
                    }
                }
            }
            return wareHouses;
        }

        public List<SwitchTrack> FindSplits()
        {
            List<SwitchTrack> splits = new List<SwitchTrack>();
            Tile current = First;
            while (current != Last)
            {
                while (current.Right != null)
                {
                    if (current is SwitchTrack c && (c.Direction == Direction.To_Bottom || c.Direction == Direction.To_Top))
                    {
                        splits.Add(c);
                    }
                    current = current.Right;
                }
                if (current != Last)
                {
                    while (current.Left != null)
                    {
                        current = current.Left;
                    }
                    if (current.Bottom != null)
                    {
                        current = current.Bottom;
                    }
                }
            }
            return splits;
        }

        public List<SwitchTrack> FindSplitsAndMerges()
        {
            List<SwitchTrack> switchesTracks = new List<SwitchTrack>();

            Tile current = First;
            while (current != Last)
            {
                while (current.Right != null)
                {
                    if (current is SwitchTrack c)
                    {
                        switchesTracks.Add(c);
                    }
                    current = current.Right;
                }
                if (current != Last)
                {
                    while (current.Left != null)
                    {
                        current = current.Left;
                    }
                    if (current.Bottom != null)
                    {
                        current = current.Bottom;
                    }
                }
            }
            return switchesTracks;
        }

        public void Change(int l)
        {
            var switches = FindSplitsAndMerges();
            switches[l].SwitchTrackDirection();
        }

        public void CreateTrackList()
        {
            var splits = FindSplits();
            var wareHouses = FindWareHouses();
            foreach (WareHouse w in wareHouses)
            {
                bool shouldContinue = true;
                TrackList trackList = new TrackList(w);
                Track current = FindNextTrack(w, false);

                while (shouldContinue)
                {
                    if (current == null)
                    {
                        return;
                    }

                    foreach (SwitchTrack s in splits)
                    {
                        if (current == s)
                        {
                            shouldContinue = false;
                        }
                    }
                    if (current is SwitchTrack sp && shouldContinue)
                    {
                        trackList.AddTrack(current, false);
                    }
                    else
                    {
                        trackList.AddTrack(current, false);
                    }
                    current = FindNextTrack(current, false);
                }
            }
            foreach (SwitchTrack s in splits)
            {
                bool shouldContinue = true;
                TrackList trackList = new TrackList(s);
                Track current;
                bool bottomSplit = true;

                for (int i = 0; i < 2; i++)
                {
                    if (i == 1)
                    {
                        current = FindNextTrack(s, true);
                        if (i == 1 && bottomSplit)
                        {
                            trackList.AddTrack(current, true);
                            bottomSplit = false;
                        }
                        current = FindNextTrack(current, false);
                        shouldContinue = true;
                        while (shouldContinue)
                        {
                            if (current == null)
                            {
                                break;
                            }
                            foreach (SwitchTrack ct in splits)
                            {
                                if (current == ct || current.Left == null)
                                {
                                    shouldContinue = false;
                                }
                            }
                            if (current is SwitchTrack sp && shouldContinue)
                            {
                                trackList.Last.Next = current;
                                break;
                            }
                            if (current is ShuntingTrack && current.Left is EmptyTile)
                            {
                                trackList.AddTrack(current, false);
                                break;
                            }
                            else if (current != s)
                            {
                                trackList.AddTrack(current, false);
                            }
                            current = FindNextTrack(current, false);
                        }
                    }
                    else
                    {
                        current = FindNextTrack(s, false);
                        while (shouldContinue)
                        {
                            if (current == null)
                            {
                                break;
                            }
                            foreach (SwitchTrack ct in splits)
                            {
                                if (current == ct || current.Left == null)
                                {
                                    shouldContinue = false;
                                }
                            }
                            if (current is SwitchTrack sp && shouldContinue)
                            {
                                trackList.AddTrack(current, false);
                            }
                            else if (current != s)
                            {
                                trackList.AddTrack(current, false);
                            }
                            current = FindNextTrack(current, false);
                        }
                    }
                }
            }
            RefreshTiles();
        }

        private Track FindNextTrack(Track track, bool bottomOnly)
        {
            if (!bottomOnly)
            {
                if (track.Right is Track r && track.Right != track.Previous)
                {
                    return r;
                }
                if (track.Left is Track l && track.Left != track.Previous)
                {
                    return l;
                }
                if (track.Top is Track t && track.Top != track.Previous)
                {
                    return t;
                }
            }
            if (track.Bottom is Track b && track.Bottom != track.Previous)
            {
                return b;
            }
            return null;
        }

        private void RefreshTiles()
        {
            Tile current = First;
            while (current != Last)
            {
                while (current.Right != null)
                {
                    if (current is SwitchTrack s)
                    {
                        s.SwitchTrackDirection();
                        s.SwitchTrackDirection();
                    }
                    current = current.Right;
                }
                if (current != Last)
                {
                    while (current.Left != null)
                    {
                        current = current.Left;
                    }
                    if (current.Bottom != null)
                    {
                        current = current.Bottom;
                    }
                }
            }
        }
    }
}

