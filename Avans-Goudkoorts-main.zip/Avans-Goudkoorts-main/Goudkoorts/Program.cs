﻿using GoudKoorts.Controller;
using System;

namespace GoudKoorts
{
    class Program
    {
        static void Main(string[] args)
        {
            new GameController();
        }
    }
}
