﻿using GoudKoorts.Controller;
using GoudKoorts.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.View
{
    class InputView
    {

        private GameController controller;
        public string StringLevel { get; set; }
        public InputView(GameController controller)
        {
            this.controller = controller;
        }

        public void KeyPressed()
        {
            var ch = Console.ReadKey(false).Key;
            switch (ch)
            {
                case ConsoleKey.D1:
                    controller.Changeswitches(0);
                    break;
                case ConsoleKey.D2:
                    controller.Changeswitches(1);
                    break;
                case ConsoleKey.D3:
                    controller.Changeswitches(2);
                    break;
                case ConsoleKey.D4:
                    controller.Changeswitches(3);
                    break;
                case ConsoleKey.D5:
                    controller.Changeswitches(4);
                    break;
                default:
                    break;
            }
        }

        public void Standart()
        {
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}
