﻿using GoudKoorts.Controller;
using GoudKoorts.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.View
{
    class OutputView
    {
        private GameController controller;
        private String[] water1;

        public OutputView(GameController controller)
        {
            water1 = new String[35];
            this.controller = controller;
        }
        public void PrintBoat(int k)
        {
            int counter = 13 - k;
            for (int i = 0; i < 35; i++)
            {
                water1[i] = "~";
            }

            for (int i = 0; i < 13; i++)
            {
                Console.Write(water1[i]);
            }
            Console.WriteLine();
            for (int i = 0; i < counter; i++)
            {
                Console.Write(water1[i]);
            }
            Console.Write("<" + controller.UpdateShips() + ">");
            if (counter != 13)
            {
                for (int i = 0; i <= k - 4; i++)
                {
                    Console.Write(water1[i]);
                }
            }
        }

        public void PrintRailWay(String levelText, int k, int timeLeft)
        {
            Console.Clear();
            PrintBoat(k);
            Console.WriteLine();
            Console.WriteLine(levelText);
            PrintLogo();
            PrintTime(timeLeft);
        }

        public void Beginning()
        {
            Console.WriteLine("|----------------------------------------------|");
            Console.WriteLine("|------------ Welkom bij Goudkoorts -----------|");
            Console.WriteLine("|----------------------------------------------|");
            Console.WriteLine("|---- Ruben van Rijen & Maarten Mandigers -----|");
            Console.WriteLine("|----------------------------------------------|");
            Console.WriteLine();
            Console.WriteLine("|------------------ Toelichting----------------|");
            Console.WriteLine("|Gebruik de toetsen 1 t/m 5 om de trackswitches|");
            Console.WriteLine("|------- te verwisselen van directie-----------|");
            Console.WriteLine("|----------------------------------------------|");

            Console.WriteLine();
            Console.WriteLine("Druk op een toets om te beginnen.");
        }


        public void PrintGameOver()
        {
            Console.Clear();
            Console.WriteLine("|-----------------------------------------|");
            Console.WriteLine("|--------------- GAMEOVER ----------------|");
            Console.WriteLine("|-----------------------------------------|");


            Console.WriteLine("Je score was: " + controller.ScoreGame());
            Console.WriteLine();
            Console.WriteLine("Druk op een toets om te stoppen.");

        }
        public void PrintLogo()
        {
            Console.WriteLine("┌───────────┐");
            Console.WriteLine("|GoudsKoorts|        Score: " + controller.ScoreGame() + " ");
            Console.WriteLine("└───────────┘");
            Console.WriteLine();
        }
        public void PrintTime(double time)
        {

            Console.Write(time + " ");
        }
    }
}
