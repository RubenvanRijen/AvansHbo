﻿using GoudKoorts.Model;
using GoudKoorts.View;
using System;
using System.Collections.Generic;
using System.Text;
using System.Timers;

namespace GoudKoorts.Controller
{
    public class GameController
    {
        private bool CanWeContinue = true;
        public int k;
        private Timer aTimer;
        private Timer cartTimer;
        private Timer seconds;
        private OutputView outputView;
        private Game game;
        private InputView input;
        private Parser parser;
        public int shipCounter;
        private bool CanWecontinue;
        private int timeLeft;

        public GameController()
        {
            StartGame();
            GameFlow();
        }

        private void SecondsTimer()
        {
            seconds.Elapsed += Seconds_Elapsed;
        }

        private void Seconds_Elapsed(object sender, ElapsedEventArgs e)
        {
            timeLeft--;
            outputView.PrintTime(timeLeft);
        }

        private void StartGame()
        {
            cartTimer = new Timer();
            aTimer = new Timer();
            parser = new Parser();
            outputView = new OutputView(this);
            seconds = new Timer(1000);
            game = new Game(parser.MakeList(parser.ReadLevel()));
            seconds.Start();
            PrintRailway();
            input = new InputView(this);
            game.FirstCart();
            shipCounter = 0;
            k = 5;
            timeLeft = game.Time / 1000;
        }

        public void PrintRailway()
        {
            outputView.PrintRailWay(game.LevelToText(), k, timeLeft);
        }

        public void Changeswitches(int h)
        {
            game.ChangeSwitches(h);

            PrintRailway();

        }

        private void GenerateCarts()
        {
            game.GenerateCart();

            PrintRailway();

        }

        private bool MoveCarts()
        {
            timeLeft = game.Time / 1000;
            if (!game.MoveCarts())
            {
                return false;
            }

            game.SetFullCart();

            return true;
        }

        private void StopGame()
        {
            seconds.Enabled = false;
            cartTimer.Enabled = false;
            CanWecontinue = false;
            outputView.PrintGameOver();
            input.Standart();
        }

        private void TimerShip(Boolean makeItHapen)
        {
            aTimer.Elapsed += new ElapsedEventHandler(OnTimedEventShip);
            aTimer.Interval = 1000;
            aTimer.Enabled = makeItHapen;
        }

        private void OnTimedEventShip(object source, ElapsedEventArgs e)
        {


            k++;
            if (k == 15)
            {
                aTimer.Enabled = false;
                k = 5;
                game.ships.counter = 0;
                CanWecontinue = true;

            }
        }

        private void TimerMoveCarts(Boolean makeItHapen)
        {
            cartTimer.Elapsed += new ElapsedEventHandler(OnTimedEventCartsMove);
            cartTimer.Elapsed += new ElapsedEventHandler(OnTimedEventTGenerateCarts);
            cartTimer.Interval = game.Time;
            cartTimer.Enabled = makeItHapen;

            //iets erin zetten wanneer het moet stoppen
        }

        private void OnTimedEventCartsMove(object source, ElapsedEventArgs e)
        {
            CanWecontinue = true;
            if (!MoveCarts())
            {
                cartTimer.Enabled = false;
                this.StopGame();
                CanWecontinue = false;
            }
            if (UpdateShips() < 8)
            {
                UpdateShipCounter();
            }

            if (UpdateShips() == 8)
            {

                aTimer.Enabled = true;

            }
        }

        public int ScoreGame()
        {
            return game.score;
        }

        private void OnTimedEventTGenerateCarts(object source, ElapsedEventArgs e)
        {
            GenerateCarts();
            PrintRailway();
        }

        public void UpdateShipCounter()
        {
            game.UpdateShipCounter();

        }

        public int UpdateShips()
        {
            return game.ships.counter;
        }

        private void GameFlow()
        {
            SecondsTimer();
            TimerShip(true);
            aTimer.Enabled = false;
            TimerMoveCarts(true);
            while (CanWeContinue == true)
            {
                if (CanWecontinue == true)
                {
                    input.KeyPressed();
                }
            }
        }
    }
}