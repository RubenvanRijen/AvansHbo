﻿using GoudKoorts.Model;
using GoudKoorts.View;
using System;
using System.Collections.Generic;
using System.Text;

namespace GoudKoorts.Controller
{
    public class Parser
    {
        public static string stringLevel;
        public Game LoadLevel()
        {
            Game g = new Game(MakeList(ReadLevel()));
            return g;
        }
        public String ReadLevel()
        {
            string text = System.IO.File.ReadAllText("..\\..\\..\\Level\\level.txt");
            return text;

        }
        public TileList MakeList(String text)
        {
            TileList list = new TileList();
            char[] chars = text.ToCharArray();
            bool nextLine = false;
            foreach (char c in chars)
            {
                if (c == '\n' || c == '\r')
                {
                    nextLine = true;
                }
                else if (nextLine)
                {
                    nextLine = false;
                    list.InsertNextLine(ConvertGameObject(c));
                }
                else
                {
                    if (c == '\n' || c == '\r')
                    {
                        nextLine = true;
                    }
                    else
                    {
                        list.InsertToRight(ConvertGameObject(c));
                    }
                }
            }
            return list;
        }

        private Tile ConvertGameObject(Char c)
        {

            switch (c)
            {
                case '─':
                    DefaultTrack normalTrack = new DefaultTrack(TrackShape.Horizontal);
                    return normalTrack;
                case '╨':
                    DeliveryTrack dock = new DeliveryTrack();
                    return dock;
                case '│':
                    DefaultTrack RightLane = new DefaultTrack(TrackShape.Vertical);
                    return RightLane;
                case '┌':
                    SwitchTrack switchFromBottom = new SwitchTrack(Direction.From_Bottom);
                    return switchFromBottom;
                case '┐':
                    SwitchTrack switchToBottom = new SwitchTrack(Direction.To_Bottom);
                    return switchToBottom;
                case '┘':
                    SwitchTrack switchToTop = new SwitchTrack(Direction.To_Top);
                    return switchToTop;
                case '└':
                    SwitchTrack switchFromTop = new SwitchTrack(Direction.From_Top);
                    return switchFromTop;
                case '═':
                    ShuntingTrack shuntingTrack = new ShuntingTrack();
                    return shuntingTrack;
                case '╮':
                    DefaultTrack corner1 = new DefaultTrack(TrackShape.Down_Left);
                    return corner1;
                case '╯':
                    DefaultTrack corner2 = new DefaultTrack(TrackShape.Left_Up);
                    return corner2;
                case '╭':
                    DefaultTrack corner3 = new DefaultTrack(TrackShape.Down_Right);
                    return corner3;
                case '╰':
                    DefaultTrack corner4 = new DefaultTrack(TrackShape.Up_Right);
                    return corner4;
                case 'A':
                    WareHouse A = new WareHouse();
                    A.Char = 'A';
                    return A;
                case 'B':
                    WareHouse B = new WareHouse();
                    B.Char = 'B';
                    return B;
                case 'C':
                    WareHouse C = new WareHouse();
                    C.Char = 'C';
                    return C;
                case ' ':
                    return new EmptyTile();
                default: return null;
            }
        }
    }
}
