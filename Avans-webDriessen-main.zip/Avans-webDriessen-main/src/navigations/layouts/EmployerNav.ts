import { defaultDropdown } from './DefaultNav';
import { INavLayout } from "../../interfaces/INavLayout";

/**
* Employer key/value paired routes object.
*/
export const employerNav: INavLayout = {
   menu: [
       {name: "Declaraties",    href: "/declarations"},
       {name: "Acties",         href: "/employer/routes-overview"},
   ],
   dropdown: defaultDropdown,
   home: "/employer/routes-overview"
}
