import { defaultDropdown } from './DefaultNav';
import { INavLayout } from "../../interfaces/INavLayout";

/**
 * Admin key/value paired routes object.
 */
export const adminNav: INavLayout = {
    menu: [
        { name: "Organisaties", href: "/company-overview" },
        { name: "Werkgevers", href: "/employer-overview" },
        { name: "Werknemers", href: "/employee-overview" },
    ],
    dropdown: defaultDropdown.filter((_, i) => i !== 1),
    home: "/company-overview"
}


