import { defaultDropdown } from './DefaultNav';
import { INavLayout } from "../../interfaces/INavLayout";

/**
 * Employee key/value paired routes object.
 */
export const employeeNav: INavLayout = {
    menu: [
        {name: "Gereden routes",    href: "/employee/routes-overview"},
    ],
    dropdown: defaultDropdown.filter((_,i) => i !== 1),
    home: "/employee/routes-overview"
}
