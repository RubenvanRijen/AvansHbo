import JwtService from '../../services/JwtService';
import { INavDropdown } from '../../interfaces/INavLayout';

/**
 * Default dropdown navigation menu
 */
export const defaultDropdown: Array<INavDropdown> =  [
    { name: "Profiel",          href: "/profile",       icon: "user"},
    { name: "Organisatie",      href: "/organisation",  icon: "user-friends"},
    { name: "Logout",           href: logout,           icon: "sign-out-alt"},
]

/**
 * Logout the current user and redirect to login page.
 */
export function logout() {
    new JwtService().removeJwt()
    window.location.href = '/login'
}
