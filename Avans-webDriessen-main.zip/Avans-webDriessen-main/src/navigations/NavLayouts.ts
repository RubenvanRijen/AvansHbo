import { IRole } from '../interfaces/IRole';
import { INavLayout } from '../interfaces/INavLayout';
import JwtService from '../services/JwtService';

import { adminNav } from './layouts/AdminNav'
import { employeeNav } from './layouts/Employee';
import { employerNav } from './layouts/EmployerNav';

type navRolLayoutTypes = {[Key in IRole]: INavLayout;};
const navLayouts : navRolLayoutTypes = {
    Admin:      adminNav,
    Employee:   employeeNav,
    Employer:   employerNav
}

/**
 * Get the nav layout by the give role
 * @param role 
 */
export function getNavLayout(role: IRole): INavLayout | null {
    return navLayouts[role]
}

/**
 * Get nav layout based on the current logged in user
 */
export function getNavLayoutCurrentUser() {
    const service   = new JwtService()
    const jwt       = service.getJwt()
    const payload   = service.getJwtPayload()

    if (!jwt || !payload || !payload.role) 
        return null

    return getNavLayout(payload.role)
}