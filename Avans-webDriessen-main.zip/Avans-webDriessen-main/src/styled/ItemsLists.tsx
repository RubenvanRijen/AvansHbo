import styled from 'styled-components'
import * as Colors from '../global/Colors';

export const ItemsContainerSkeleton = styled.div({
  display: "flex",
  flexDirection: "column",
  alignItems: "center",

  minHeight: "100px",
  padding: "20px 20px",
  margin: "10px 0px",

  backgrounColor: 'transparent'
})

export const ItemsContainer = styled(ItemsContainerSkeleton)({
  backgroundColor: Colors.darkWhite,
  boxShadow: "0px 2px 5px 0px rgba(50, 50, 40, 0.2)",
  borderRadius: "4px"
})

export const ItemsList = styled.div({
  display: "flex",
  flexDirection: "column",
  alignItems: "center",

  minHeight: "100px",
  padding: "20px 20px",
  margin: "10px 0px",
  overflow: "hidden",

  boxShadow: "inset 0px 2px 5px 0px rgba(50, 50, 40, 0.2)",
  backgroundColor: Colors.darkWhite,
  borderRadius: "4px",
  overflowY: "scroll"
})

export const ItemPlate = styled.button ({
    border: "none",
    outline: "none",
    fontSize: "16px",
    fontWeight: "normal",
    boxShadow: "0px 1px 3px 0px rgba(40, 40, 40, 0.4)",
    borderRadius: "0px 15px 15px 0px",
    width: "650px",
    height: "70px",
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.white,
    transition: "all 200ms",
    margin: "4px 0px",
    padding: "0px 6px 0px 0px",
    ":hover": {
      transform: "scale(1.05)",
      boxShadow: "0px 2px 6px 0px rgba(40, 40, 40, 0.3)",
      transition: "all 300ms"
    },
    ":focus": {
      outline: 0
    }
});