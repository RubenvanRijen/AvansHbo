import styled from 'styled-components'

export const Container = styled.div ({
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-around",
});

export const ContainerCenter = styled(Container) ({
    justifyContent:'center', 
    alignItems:'center'
})

export const ContainerItem = styled.div ({
    flexGrow: 1,
    flexBasis: "40%",
    padding: "20px",
    margin: "40px 30px 0px 30px"
})

export const ContainerItemTight = styled.div ({
    flexGrow: 1,
    flexBasis: "30%",
    padding: "20px",
    margin: "20px 10px"
})