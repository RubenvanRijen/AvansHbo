import styled from "styled-components";

export const Fullscreen = (styledComponet: any) => styled(styledComponet) ({
    height: "100%",
    width: "100%"
});
