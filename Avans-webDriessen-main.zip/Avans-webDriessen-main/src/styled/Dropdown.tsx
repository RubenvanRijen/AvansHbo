import styled from 'styled-components';
import * as Colors from '../global/Colors';

export const Select = styled.select({
    width: "120px",
    height: "30px",
    backgroundColor: Colors.white,
    border: "none",
    borderRadius: "12px",
    color: Colors.black,
    fontWeight: "bold",
    boxShadow: "0px 3px 5px 0px rgba(50, 50, 40, 0.5)",
    margin: "0px 10px 0px 10px",
    ":focus": {
         outline: "0"
    }
});

export const Option = styled.option ({
    backgroundColor: Colors.white,
    color: Colors.black,
    borderRadius: "12px",
    outline: "0",
    ":hover": {
        backgroundColor: `${Colors.darkWhite}CC`,
    },
    ":focus": {
         outline: "0"
    }
});