import styled from 'styled-components'

export const HeadBar = styled.div ({
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    h2: {
        margin: 0
    }
})

export const HeadBarElement = styled.div ({
    display: "flex",
    flexDirection: "row"
})

export const HeadbarLable = styled.div ({
    display: "grid",
    gridTemplateColumns: "auto",
    gridTemplateAreas: "'. . . . . . hb-date . . hb-from . . . . . . hb-to . hb-money .'"
})

export const HeadbarLableItem = styled.div((props: {area: string}) => ({
    gridArea: props.area,
}));
