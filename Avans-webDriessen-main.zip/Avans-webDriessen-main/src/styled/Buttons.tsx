import styled from 'styled-components';
import * as Colors from '../global/Colors';

const Button = styled.button({
    width: "150px",
    height: "30px",
    backgroundColor: Colors.darkGray,
    border: "none",
    borderRadius: "12px",
    color: Colors.white,
    fontWeight: "bold",
    boxShadow: "0px 3px 5px 0px rgba(50, 50, 40, 0.5)",
    transition: "background-color 0.3s",
    ":hover": {
        transition: "background-color 500ms",
        backgroundColor: `${Colors.gray}CC`,
        cursor: "pointer",
    },
    ":active": {
        transition: "background-color 100ms",
        backgroundColor: Colors.black,
    },
    ":focus": {
        outline: "0"
    }
});

export const AcceptButton = styled(Button)({
    backgroundColor: Colors.green,
    width: '200px',
    color: Colors.white,
    ":hover": {
        backgroundColor: `${Colors.green}CC`,
    },
    ":active": {
        backgroundColor: Colors.darkGreen,
    }
});

export const CancelButton = styled(Button)({
    backgroundColor: Colors.darkWhite,
    color: Colors.black,
    ":hover": {
        backgroundColor: `${Colors.white}CC`,
    },
    ":active": {
        backgroundColor: Colors.gray,
    }
});

export const DeleteButton = styled(Button)({
    backgroundColor: Colors.darkWhite,
    marginLeft: 10,
    color: Colors.black,
    ":hover": {
        backgroundColor: `${Colors.brightRed}CC`,
        color: Colors.white
    },
    ":active": {
        backgroundColor: Colors.darkRed,
    }
});

export const RedButton = styled(Button)({
    backgroundColor: Colors.red,
    color: Colors.white,
    ":hover": {
        backgroundColor: `${Colors.brightRed}CC`,
    },
    ":active": {
        backgroundColor: Colors.darkRed,
    }
});