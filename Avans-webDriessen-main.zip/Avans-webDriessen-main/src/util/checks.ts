//#region existence
/**
* Check if a string exists, else return or
* If the string exists and is a single string add the before, before the string and after, after the string
* If the string is a series of strings insert a new element with before, before the string and a new element, after after the element
*/
export function stringExists(str?: String | String[], {before = "", after = "", or = ""} = {/*undefined will cause an error*/}) {
    if (!exists(str))
        return or
    
    if (!Array.isArray(str))
        return `${before}${str}${after}`

    return [
        ...before !== "" ? [before] : [],
        str,
        ...after !== "" ? [after] : []
    ]
}

/**
 * Check if all objects exists
 * If any is falsely return false
 */
export function allExists(...optionals: any) : boolean { 
    for(let optional of optionals){ 
        if (!exists(optional)) {

            return false
        }
    }

    return true; 
}

/**
 * Check if any objects exists
 * If any is truly return true
 */
export function anyExists(...optionals: any) : boolean {
    for(let optional of optionals){ 
        if (exists(optional)) {

            return true
        }
    } 

    return false; 
}

/**
 * Check if a single object exists
 */
export function exists(optional?: any) {
    return optional !== undefined
}
//#endregion