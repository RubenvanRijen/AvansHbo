import { Icon, Point } from "leaflet"
import { ICoordinate } from '../interfaces/ICoordinate';
import "./extentions/string.extentions"
import { anyExists, stringExists } from "./checks";

//#region Route helper
export class RouteHelper {

    BASE_URL:   String      = "https://api.mapbox.com/"
    API_KEY:    String      = "pk.eyJ1IjoibHJldCIsImEiOiJjazg2OHI5OGYwMGNuM2ZzOTF2ZHRsNW4yIn0.M8_X9hpNB7PR_VVAyQLGZg"

    RouteUrl = {
        BASE_URL: this.BASE_URL,
        URL_PATH: "geocoding/v5/mapbox.places/",
        QUERY:    "(query).json",
        PARAMS:   ["autocomplete=true", "country=NL", "cachebuster=1585040824134"],
        API_KEY:  this.API_KEY
    }

    DirectionUrl = {
        BASE_URL: this.BASE_URL,
        URL_PATH: "directions/v5/mapbox/driving/",
        PARAMS:   ["alternatives=true", "geometries=geojson", "steps=true"],
        API_KEY:  this.API_KEY
    }
  
    // async getAdress => getRoutes
    async getRoutes( // Adress
        query: string
    ) : Promise<Array<ICoordinate>> {
        let data : any = await http(this.createUrl(
            this.RouteUrl.BASE_URL,
            this.RouteUrl.URL_PATH.eBS() + this.RouteUrl.QUERY.replace("(query)", query),
            this.RouteUrl.PARAMS,
            this.RouteUrl.API_KEY
        )).catch(e => [])

        return this.unpackCoordinates(
            data?.parsedBody?.['features']?.map((f: any) => f['center'])
        )
    }

    async getDirections(
        from: ICoordinate,
        to: ICoordinate
    ) : Promise<Array<ICoordinate>> {
        let data : any =  await http(this.createUrl(
            this.DirectionUrl.BASE_URL,
            this.DirectionUrl.URL_PATH.eBS() + `${from.lng},${from.lat};${to.lng},${to.lat}`,
            this.DirectionUrl.PARAMS,
            this.DirectionUrl.API_KEY
        )).catch(e => [])
        return this.unpackCoordinates(
            data?.parsedBody?.['routes']?.[0]?.['geometry']?.['coordinates']
        ) 
    }

    unpackCoordinates( coordinates?: [[number, number]] ) : Array<ICoordinate> {
        if (coordinates == null)
            return []

        return coordinates.map( this.unpackCoordinate )
    }

    unpackCoordinate( coordinate: [number, number] ) : ICoordinate {
        return {lat: coordinate[1], lng: coordinate[0]}
    }

    createUrl(
        baseUrl: String = this.BASE_URL,
        urlPath: String,
        params?: String[],
        apiKey?: String,
    ): string { 
        return `${baseUrl.eBS()}${urlPath}${this.createParams(params, apiKey)}` 
    }

    createParams(
        params?: String | Array<String>,
        apiKey?: String
    ): string {
        if (!anyExists(params, apiKey))
            return ""

        let _params = stringExists(params) 
        let _apiKey = stringExists(apiKey, {before : "access_token="}) 

        return `?${this.flattenParams(_apiKey, _params)}`
    }

    flattenParams(...params: any) : String {
        let separator = "&"
        let _paramArray = [...params].flat(Infinity)
        return _paramArray.join(separator)
    }
}
//#endregion

//#region Marker helper
export const markerHelper = {
    makeMarker : (markerLocation: string, iconSize: number = 40) : Icon => new Icon({
        iconUrl: markerLocation,
        iconRetinaUrl: markerLocation,
        iconSize: new Point(iconSize, iconSize),
        popupAnchor: [0, -iconSize * 0.9],
        iconAnchor: [iconSize * 0.5, iconSize],
        className: 'leaflet-icon'
      }),
      
    iconRedMarker : () => markerHelper.makeMarker(process.env.PUBLIC_URL + '/assets/images/mapper_red.svg') ,
    iconBlueMarker : () => markerHelper.makeMarker(process.env.PUBLIC_URL + '/assets/images/mapper_blue.svg'),
    iconYellowMarker : () => markerHelper.makeMarker(process.env.PUBLIC_URL + '/assets/images/mapper_yellow.svg'),
}
//#endregion

//#region Map helper
export const MapHelper  = {
    marker: markerHelper
} 
//#endregion

//#region Http placeholder
interface HttpResponse<T> extends Response {
    parsedBody?: T;
  }

async function http<T>(
    request: RequestInfo
  ): Promise<HttpResponse<T>> {
    const response: HttpResponse<T> = await fetch(
      request
    );
  
    try {
      response.parsedBody = await response.json();
    } catch (ex) {}
  
    if (!response.ok) {
        throw new Error(response.statusText);
    }
    return response;
}
//#endregion