// @ts-ignore
//#region Global scope interface extension declarations
declare global { 
    interface String {
        dotToObjects(): Object
        dotToKeyValue(value: any): any
        ensureBackSlash(): String
        eBS(): String
    }
}
//#endregion

//#region Extensions assignments

// eslint-disable-next-line
String.prototype.dotToObjects = function(): any {
    return dotToObjects(this);
}
// eslint-disable-next-line
String.prototype.dotToKeyValue = function(value: any): any {
    return dotToKeyValue({[this.toString()]: value});
}
// eslint-disable-next-line
String.prototype.eBS = // Same but shortened
// eslint-disable-next-line
String.prototype.ensureBackSlash = function(): String {
    return ensureBackSlash(this)
}
//#endregion


//#region Concrete module functionalities (exported)
export function ensureBackSlash(str: String): String {
    let needed = str.substr(str.length - 1) !== "/"
    let newString = `${str}${needed ? "/" : ""}` // Tip: do not mutate return values directly, this can cause unexpected behavior. Instead return a new instance (for objects use the spread syntax newObj = {...oldObject} ) 
    return newString
}

export function dotToObjects(...paths: Array<String>): any {
    return paths.reduce(function (obj: any, path: String) {
        path.split('.').reduce((obj: any, key: string) => obj[key] = obj[key] || {}, obj);
        return obj;
    }, {});
}

export function dotToKeyValue(obj: any) {
    if (!obj) {
        return {};
    }
    
    const isPlainObject = (obj: any): any => !!obj && obj.constructor === {}.constructor;
    
    const getNestedObject = (obj: any): any => Object.entries(obj).reduce((result, [prop, val]) => {
        prop.split('.').reduce((nestedResult: any, prop, propIndex, propArray) => {
            const lastProp = propIndex === propArray.length - 1;
            if (lastProp) {
                nestedResult[prop] = isPlainObject(val) ? getNestedObject(val) : val;
            } else {
                nestedResult[prop] = nestedResult[prop] || {};
            }
            return nestedResult[prop];
        }, result);
        return result;
    }, {});
    
    return getNestedObject(obj);
}
//#endregion