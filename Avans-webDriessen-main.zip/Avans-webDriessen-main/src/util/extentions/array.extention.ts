// @ts-ignore
//#region Global scope interface extension declarations
declare global {
    interface Array<T> {
        isAny(test: (item: any) => boolean): boolean
        isAll(test: (item: any) => boolean): boolean
    }
}
//#endregion

//#region Extensions assignments
/**
 * Return true if all items are valid, 
 * else if any item is not valid return false
 */
// eslint-disable-next-line
Array.prototype.isAny = function(validation: (item: any) => boolean): boolean {
    return isAny(validation, this)
}

/**
 * Return true if any item is valid, 
 * else if no item are valid return false
 */
// eslint-disable-next-line
Array.prototype.isAll = function(validation: (item: any) => boolean): boolean {
    return isAll(validation, this)
}
//#endregion

//#region Concrete module functionalities (exported)
/**
 * Return true if all items are valid, 
 * else if any item is not valid return false
 */
export function isAll(validation: (item: any) => boolean, ...items: Array<any>): boolean {
    for( let i = 0; i < items?.length || 0; i++)
        if (!validation(items[i])) return false;
    return (items.length > 0);
}

/**
 * Return true if any item is valid, 
 * else if no item are valid return false
 */
export function isAny(validation: (item: any) => boolean, ...items: Array<any>): boolean {
    for( let i = 0; i < items?.length || 0; i++ )
        if (validation(items[i])) return true;
    return false;
}
//#endregion
