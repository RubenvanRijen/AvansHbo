import React, { FC, SVGProps } from "react";
 
export const Help: FC<SVGProps<SVGSVGElement>> = props => (
  <svg
    fillRule="evenodd"
    strokeLinejoin="round"
    strokeMiterlimit={1.4}
    clipRule="evenodd"
    viewBox="0 0 23 23"
    width="2.1em"
    fill="black"
    height="2.1em"
    {...props}
  >
    <g id="Group_22" data-name="Group 22" transform="translate(-345 -108)">
      <g id="Ellipse_1" data-name="Ellipse 1" transform="translate(345 108)" fill="#fff" stroke="#b1b1b1" strokeWidth="2">
        <circle cx="11.5" cy="11.5" r="11.5" stroke="none"/>
        <circle cx="11.5" cy="11.5" r="10.5" fill="none"/>
      </g>
      <path id="Path_42" data-name="Path 42" d="M13.635,12.7a3.225,3.225,0,0,1,3.595-2.158A3.282,3.282,0,0,1,19.915,13.8c0,2.2-3.232,3.3-3.232,3.3" transform="translate(339.232 103.199)" fill="none" stroke="#b1b1b1" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"/>
      <path id="Path_43" data-name="Path 43" d="M18,25.5h0" transform="translate(338 99)" fill="none" stroke="#b1b1b1" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"/>
    </g>
  </svg>
);