import React, { FC, SVGProps } from "react";
 
export const Clock: FC<SVGProps<SVGSVGElement>> = props => (
  <svg
    fillRule="evenodd"
    strokeLinejoin="round"
    strokeMiterlimit={1.4}
    transform="translate(1.001 -3.5)"
    clipRule="evenodd"
    viewBox="0 0 11.997 12"
    width="2.1em"
    fill="black"
    height="2.1em"
    {...props}
  >
    <g id="Group_11" data-name="Group 11">
        <path id="Path_10" data-name="Path 10" d="M9.937,15.938A6,6,0,0,1,5.773,5.617a.482.482,0,0,1,.669.693,5.035,5.035,0,1,0,3.975-1.386V6.8a.483.483,0,1,1-.966,0V4.42a.483.483,0,0,1,.483-.483,6,6,0,0,1,0,12Z" transform="translate(-3.938 -3.938)"/>
        <path id="Path_11" data-name="Path 11" d="M11.728,11.308l2.985,2.145a.9.9,0,1,1-1.05,1.47.872.872,0,0,1-.21-.21l-2.145-2.985a.3.3,0,0,1,.42-.42Z" transform="translate(-8.131 -8.131)"/>
    </g>
  </svg>
);