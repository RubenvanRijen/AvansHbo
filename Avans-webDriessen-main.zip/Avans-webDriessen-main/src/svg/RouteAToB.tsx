import React, { FC, SVGProps } from "react";
 
export const RouteAToB: FC<SVGProps<SVGSVGElement>> = props => (
  <svg
    fillRule="evenodd"
    strokeLinejoin="round"
    strokeMiterlimit={1.4}
    transform="translate(1.001 -3.5)"
    clipRule="evenodd"
    viewBox="0 0 36 36"
    width="2.1em"
    fill="black"
    height="2.1em"
    {...props}
  >
    <path id="Icon_awesome-route" data-name="Icon awesome-route" d="M29.25,22.5H22.5a2.25,2.25,0,0,1,0-4.5h6.75S36,10.477,36,6.75a6.75,6.75,0,0,0-13.5,0c0,1.793,1.561,4.458,3.185,6.75H22.5a6.75,6.75,0,0,0,0,13.5h6.75a2.25,2.25,0,0,1,0,4.5H13.043A48.544,48.544,0,0,1,9.717,36H29.25a6.75,6.75,0,0,0,0-13.5Zm0-18A2.25,2.25,0,1,1,27,6.75,2.248,2.248,0,0,1,29.25,4.5ZM6.75,18A6.752,6.752,0,0,0,0,24.75C0,28.477,6.75,36,6.75,36s6.75-7.523,6.75-11.25A6.752,6.752,0,0,0,6.75,18Zm0,9A2.25,2.25,0,1,1,9,24.75,2.248,2.248,0,0,1,6.75,27Z"/>
  </svg>
);