import React, { FC, SVGProps } from "react";
 
export const Check: FC<SVGProps<SVGSVGElement>> = props => (
  <svg
    fillRule="evenodd"
    strokeLinejoin="round"
    strokeMiterlimit={1.4}
    transform="translate(1.001 -3.5)"
    clipRule="evenodd"
    viewBox="0 0 32 32"
    width="2.1em"
    fill="black"
    height="2.1em"
    {...props}
  >
    <g id="Group_95" data-name="Group 95" transform="translate(-852.588 -109.063)">
      <path id="Icon_awesome-check-circle" data-name="Icon awesome-check-circle" d="M30.563,15.563a15,15,0,1,1-15-15A15,15,0,0,1,30.563,15.563ZM13.827,23.5,24.956,12.376a.968.968,0,0,0,0-1.369L23.588,9.639a.968.968,0,0,0-1.369,0l-9.076,9.076L8.906,14.477a.968.968,0,0,0-1.369,0L6.169,15.846a.968.968,0,0,0,0,1.369l6.29,6.29a.968.968,0,0,0,1.369,0Z" transform="translate(853.025 109.5)" fill="none" stroke="#50be64" strokeWidth="2"/>
      <path id="Icon_awesome-check" data-name="Icon awesome-check" d="M6.793,19.2l-6.5-6.5a1,1,0,0,1,0-1.414L1.707,9.87a1,1,0,0,1,1.414,0L7.5,14.249,16.879,4.87a1,1,0,0,1,1.414,0l1.414,1.414a1,1,0,0,1,0,1.414L8.207,19.2A1,1,0,0,1,6.793,19.2Z" transform="translate(859 113.423)" fill="#50be64"/>
    </g>
  </svg>
);