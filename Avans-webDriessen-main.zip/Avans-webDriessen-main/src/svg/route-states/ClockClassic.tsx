import React, { FC, SVGProps } from "react";
 
export const ClockClassic: FC<SVGProps<SVGSVGElement>> = props => (
  <svg
    fillRule="evenodd"
    strokeLinejoin="round"
    strokeMiterlimit={1.4}
    transform="translate(1.001 -3.5)"
    clipRule="evenodd"
    viewBox="0 0 33 33"
    width="2.1em"
    fill="black"
    height="2.1em"
    {...props}
  >
    <g id="Icon_feather-clock" data-name="Icon feather-clock" transform="translate(-1.5 -1.5)">
      <path id="Path_36" data-name="Path 36" d="M33,18A15,15,0,1,1,18,3,15,15,0,0,1,33,18Z" fill="none" stroke="#707070" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3"/>
      <path id="Path_37" data-name="Path 37" d="M18,9v9l6,3" fill="none" stroke="#707070" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3"/>
    </g>
  </svg>
);
