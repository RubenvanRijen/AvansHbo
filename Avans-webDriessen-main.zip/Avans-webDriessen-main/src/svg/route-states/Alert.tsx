import React, { FC, SVGProps } from "react";

export const Alert: FC<SVGProps<SVGSVGElement>> = props => (
  <svg
    fillRule="evenodd"
    strokeLinejoin="round"
    strokeMiterlimit={1.4}
    transform="translate(1.001 -3.5)"
    clipRule="evenodd"
    viewBox="0 0 36 36"
    width="2.1em"
    fill="none"
    height="2.1em"
    {...props}
  >
    <defs>
    <filter id="Path_30" x="0" y="0" width="36" height="36" filterUnits="userSpaceOnUse">
      <feOffset dy="1"/>
      <feGaussianBlur stdDeviation="0.5" result="blur"/>
      <feFlood floodOpacity="0.251"/>
      <feComposite operator="in" in2="blur"/>
      <feComposite in="SourceGraphic"/>
    </filter>
    </defs>
    <g id="Alert" transform="translate(3 2)">
        <g transform="matrix(1, 0, 0, 1, -3, -2)" filter="url(#Path_30)">
            <path id="Path_30-2" data-name="Path 30" d="M33,18A15,15,0,1,1,18,3,15,15,0,0,1,33,18Z" transform="translate(0 -1)" fill="#fbf3e7" stroke="#ffb33e" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3"/>
        </g>
        <path id="Path_31" data-name="Path 31" d="M18,12v6" transform="translate(-3 -3)" fill="#fbf3e7" stroke="#ffb33e" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3"/>
        <path id="Path_32" data-name="Path 32" d="M18,24h0" transform="translate(-3 -3)" fill="#fbf3e7" stroke="#ffb33e" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3"/>
    </g>
  </svg>
);
