import React, { FC, SVGProps } from "react";
 
export const Marker: FC<SVGProps<SVGSVGElement>> = props => (
  <svg
    fillRule="evenodd"
    strokeLinejoin="round"
    strokeMiterlimit={1.4}
    clipRule="evenodd"
    viewBox="0 0 23.365 30.487"
    width="2.1em"
    fill="black"
    height="2.1em"
    {...props}
  >
    <path id="Icon_awesome-map-marker-alt" data-name="Icon awesome-map-marker-alt" d="M9.585,27.912C1.5,16.193,0,14.99,0,10.683a10.683,10.683,0,0,1,21.365,0c0,4.307-1.5,5.51-9.585,17.23a1.336,1.336,0,0,1-2.2,0Zm1.1-12.779a4.451,4.451,0,1,0-4.451-4.451A4.451,4.451,0,0,0,10.683,15.134Z" transform="translate(1 1)" fill="none" stroke="#000" strokeWidth="2"/>
  </svg>
);