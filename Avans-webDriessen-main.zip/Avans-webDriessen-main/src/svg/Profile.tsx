import React, {FC, SVGProps} from "react";

export const Profile: FC<SVGProps<SVGSVGElement>> = props => (
    <svg
        fillRule="evenodd"
        strokeLinejoin="round"
        strokeMiterlimit={1.4}
        clipRule="evenodd"
        viewBox="0 0 32 32"
        width="2.1em"
        fill="black"
        height="2.1em"
        {...props}
    >
        <path id="Icon_ionic-md-contact" data-name="Icon ionic-md-contact"
              d="M19.375,3.375a16,16,0,1,0,16,16A16.047,16.047,0,0,0,19.375,3.375Zm0,4.8a4.8,4.8,0,1,1-4.8,4.8A4.816,4.816,0,0,1,19.375,8.175Zm0,23.108a11.656,11.656,0,0,1-9.6-5.123c.077-3.2,6.4-4.962,9.6-4.962s9.523,1.762,9.6,4.962A11.675,11.675,0,0,1,19.375,31.283Z"
              transform="translate(-3.375 -3.375)"/>
    </svg>
);
