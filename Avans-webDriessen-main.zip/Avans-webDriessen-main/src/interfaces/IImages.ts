export interface IImages {
    [key: string]: string
}