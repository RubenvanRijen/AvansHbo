export interface IRoute {
    allowanceTypeName: string;
    kilometerAllowanceId: string;
    userId: string;
    statusName: string;
    companyName: string;
    startTime: string;
    endTime: string;
    startLocation: string;
    endLocation: string;
    serializedRoute: string;
    serializedMapRoute: string;
    distance: number;
    id: string;
    estimatedPayment: number;
}

export interface IRouteVM {
    userId?: string;
    statusName: string;
    companyName: string;
    startTime: string;
    endTime: string;
    serializedRoute?: string;
    serializedMapRoute?: string;
    distance?: number;
    id?: string;
    allowanceTypeName?: string;
    placementId?: string;
    kilometerAllowanceId?: string;
}
