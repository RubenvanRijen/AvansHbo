export interface IKilometerAllowance {
    allowanceTypeName: string;
    companyName: string;
    price: number;
    minDistance: number;
    id: string;
}