export default interface IUserPlacement {
    placementId: string;
    userId: string;
    id: string;
}
