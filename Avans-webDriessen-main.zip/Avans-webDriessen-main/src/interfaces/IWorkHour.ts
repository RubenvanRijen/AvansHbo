export interface IWorkHour {
    userId: string;
    startDateTime: string;
    endDateTime: string;
    id: string;
}