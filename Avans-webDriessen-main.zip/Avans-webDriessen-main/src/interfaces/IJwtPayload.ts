import { IRole } from "./IRole";

export interface IJwtPayload {
    sub: string
    email: string
    company?: string
    firstName?: string
    lastName?: string
    role?: IRole
}
