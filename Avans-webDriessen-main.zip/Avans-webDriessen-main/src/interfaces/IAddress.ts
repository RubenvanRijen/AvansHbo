export interface IAddress {
    zipcode: string
    houseNumber: number
    date: string
    time: string
}