export type IRole = 'Admin' | 'Employee' | 'Employer';
