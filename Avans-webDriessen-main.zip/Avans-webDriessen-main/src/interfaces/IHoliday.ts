export interface IHoliday {
    userId: string;
    date: string;
    id: string;
}