export interface ICoordinate {
    lat: number,
    lng: number
}