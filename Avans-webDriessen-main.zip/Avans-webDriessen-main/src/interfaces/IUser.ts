import { IRoute } from "./IRoute";
import { IWorkHour } from "./IWorkHour";
import { IHoliday } from "./IHoliday";

export interface IUser {
    roleName: string;
    companyName: string;
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    accountNumber: string;
    oAuthToken: string;
    image: string;
    routes: IRoute[];
    workHours: IWorkHour[];
    holidays: IHoliday[];
    id: string;
}