import { IconProp } from "@fortawesome/fontawesome-svg-core";

export interface INavLayout {
    menu: Array<INavMenu>
    dropdown: Array<INavDropdown>
    home: string
}

export interface INavMenu {
    name: string
    href: string
}

export interface INavDropdown {
    name: string
    href: string | Function
    icon: IconProp
}