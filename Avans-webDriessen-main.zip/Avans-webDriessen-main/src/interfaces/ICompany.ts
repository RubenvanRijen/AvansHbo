import { IRoute } from "./IRoute";
import { IKilometerAllowance } from "./IKilometerAllowance";
import { IUser } from "./IUser";
import { IHoliday } from "./IHoliday";

export interface ICompany {
    name: string;
    image: string;
    routes: IRoute[];
    kilometerAllowances: IKilometerAllowance[];
    users: IUser[];
    companyHolidays: IHoliday[];
}
