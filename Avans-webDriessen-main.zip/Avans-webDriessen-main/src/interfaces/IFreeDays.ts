export interface IFreeDays {
    id: string;
    companyName: string;
    date: string;
    startDate: string;
    endDate: string;
}
