import { IRoute } from "./IRoute";
import IUserPlacement from "../interfaces/IUserPlacement"

export default interface IPlacement {
    id: string,
    name: String,
    startDateTime: Date,
    endDateTime: Date,
    companyName: String,
    routes: IRoute[],
    userPlacements: IUserPlacement[],
};