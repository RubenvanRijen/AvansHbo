import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.bundle.min'
import React from 'react'
import Navbar from './components/Navbar'
import RoutesOverview from './pages/EmployeeRoutesPages/RoutesOverview'
import EmployerRoutesOverview from './pages/EmployerRoutesPages/EmployerRoutesOverview'
import Settings from './pages/Settings/Settings'
import Login from './pages/Login/Login'
import EmployeeOverView from './pages/admin/employees/EmployeeOverview'
import EmployerOverview from './pages/admin/employers/EmployerOverview'
import DeclarationHistory from './pages/DeclarationHistory/DeclarationHistory';
import CompanyOverview from './pages/admin/companies/CompanyOverview';
import {
    BrowserRouter as Router,
    BrowserRouter,
    Route,
    RouteProps,
    Switch,
    withRouter,
} from 'react-router-dom'
import { library } from '@fortawesome/fontawesome-svg-core'
import { fab } from '@fortawesome/free-brands-svg-icons'
import {
    faCalendar,
    faImage,
    faSignOutAlt,
    faTable,
    faUser,
    faUserFriends,
} from '@fortawesome/free-solid-svg-icons'
import JwtService from './services/JwtService'
import Profile from './pages/Profile/Profile'

library.add(fab, faCalendar, faTable, faImage, faUser, faSignOutAlt, faUserFriends)

const jwtService = new JwtService()

const AuthRoute: React.FC<RouteProps> = ({ children, ...rest }) => {
    const payload = jwtService.getJwtPayload()

    if (!payload) {
        window.location.href = '/login'
        return null
    }

    return <Route {...rest}>{children}</Route>
}

const EmployerRoute: React.FC<RouteProps> = ({ children, ...rest }) => {
    const payload = jwtService.getJwtPayload()

    if (!payload) {
        window.location.href = '/login'
        return null
    }
    if (!payload.company) {
        window.location.href = '/'
        return null
    }
    return <Route {...rest}>{children}</Route>
}

const AdminRoute: React.FC<RouteProps> = ({ children, ...rest }) => {
    const payload = jwtService.getJwtPayload()

    if (!payload) {
        window.location.href = '/login'
        return null
    }
    if (payload.role !== 'Admin') {
        window.location.href = '/'
        return null
    }
    return <Route {...rest}>{children}</Route>
}

function App() {
    const Main = withRouter(({ location }) => {
        return (
            <div className="App">
                <header className="App-header">
                    {location.pathname !== '/login' && location.pathname !== '/' && (
                        <Navbar jwtService={jwtService} />
                    )}
                    <Router>
                        <Switch>
                            <Route exact path="/">
                                <Login jwtService={jwtService} />
                            </Route>
                            <AdminRoute exact path="/employee-overview">
                                <EmployeeOverView jwtService={jwtService} />
                            </AdminRoute>
                            <AdminRoute exact path="/employer-overview">
                                <EmployerOverview jwtService={jwtService} />
                            </AdminRoute>
                            <AdminRoute exact path="/company-overview">
                                <CompanyOverview jwtService={jwtService} />
                            </AdminRoute>
                            <Route exact path="/login">
                                <Login jwtService={jwtService} />
                            </Route>
                            <EmployerRoute exact path="/users">
                                <h1>Overzicht Medewerkers</h1>
                            </EmployerRoute>

                            <AuthRoute exact path="/users/:id">
                                <h1>Medewerker Info</h1>
                            </AuthRoute>
                            <AuthRoute exact path="/organisation">
                                <Settings jwtService={jwtService} />
                            </AuthRoute>
                            <AuthRoute exact path="/employee/routes-overview">
                                <RoutesOverview jwtService={jwtService} />
                            </AuthRoute>
                            <EmployerRoute exact path="/employer/routes-overview">
                                <EmployerRoutesOverview jwtService={jwtService} />
                            </EmployerRoute>
                            <AuthRoute exact path="/profile">
                                <Profile jwtService={jwtService} />
                            </AuthRoute>
                            <Route exact path="/declarations">
                                <DeclarationHistory jwtService={jwtService} />
                            </Route>
                        </Switch>
                    </Router>
                </header>
            </div>
        )
    })

    return (
        <BrowserRouter>
            <Main />
        </BrowserRouter>
    )
}

export default App
