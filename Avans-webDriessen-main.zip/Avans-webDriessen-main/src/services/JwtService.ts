import {IJwtPayload} from '../interfaces/IJwtPayload';

export default class JwtService {

    public getJwt() {
        return sessionStorage.getItem('jwt');
    }

    public getJwtPayload() {
        return this.parseJwt(this.getJwt());
    }

    public setJwt(jwt: string) {
        return sessionStorage.setItem('jwt', jwt);
    }

    public removeJwt() {
        sessionStorage.removeItem('jwt');
    }

    private parseJwt(jwt: string | null): IJwtPayload | null {
        if (!jwt) return null;
        const jwtBody = atob(jwt.split('.')[1]);
        return JSON.parse(jwtBody);
    }

}
