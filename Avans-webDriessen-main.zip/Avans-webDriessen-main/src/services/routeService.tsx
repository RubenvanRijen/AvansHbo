import {ICoordinate} from "../interfaces/ICoordinate";
import {IRoute, IRouteVM} from "../interfaces/IRoute"
import {IAddress} from "../interfaces/IAddress";

import {isAll} from "../util/extentions/array.extention"
import moment from "moment";

import {RouteHelper} from "../util/mapHelper";

export default class RouteService {

    jwt: string | undefined = "";
    uid: string | undefined = "";

    constructor(uid: string | undefined, jwt: string | undefined) {
        this.jwt = jwt;
        this.uid = uid;
    }


    PENDING_STATUS = 'PENDING_BY_EMPLOYER'
    ROUTES_URL = process.env.REACT_APP_API_URL+'Routes';

    async addRouteFromAddress(from: IAddress, to: IAddress, companyName: string, type: string, placementId: string, allowanceId: string): Promise<IRoute | null> {
        if (!this.validateFromToAddress(from, to))
            return null;

        const fromLocation = await this.fetchAddress(from);
        const toLocation = await this.fetchAddress(to);

        if (!(fromLocation && toLocation))
            return null;

        const route = await this.createRoute(from, to, fromLocation, toLocation, companyName, type, placementId, allowanceId);

        if (!route)
            return null;

        return await this.addRoute(route);
    }

    async addRoute(route: IRouteVM): Promise<IRoute | null> {
        const url = process.env.REACT_APP_API_URL+"routes",
            method = 'POST',
            headers = {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.jwt}`
            },
            transformedRoute = {...route, statusName: this.PENDING_STATUS}

        const result = await fetch(url, {method, headers, body: JSON.stringify(transformedRoute)})
        return await result.json();
    }

    async fetchAddress(adress: IAddress): Promise<ICoordinate | null> {
        let helper = new RouteHelper();
        let query = `${adress.houseNumber} ${adress.zipcode}`;
        let routes = await helper.getRoutes(query);
        let bestMatch = routes[0];
        return bestMatch;
    }

    async createRoute(
        from: IAddress, to: IAddress,
        start: ICoordinate, end: ICoordinate,
        companyName: string, type: string,
        placementId: string, allowanceId: string
    ): Promise<IRouteVM | null> {
        const startDate = moment(`${from.date} ${from.time}`).format(),
            endDate = moment(`${to.date} ${to.time}`).format(),
            route = await new RouteHelper().getDirections({lat: start.lat, lng: start.lng}, {
                lat: end.lat,
                lng: end.lng
            }),
            latToLng = this.serializeRoute(start, end)

        if (!route || route.length < 1)
            return null;

        return {
            userId: this.uid,
            statusName: this.PENDING_STATUS,
            companyName: companyName,
            startTime: startDate,
            endTime: endDate,
            serializedRoute: latToLng,
            serializedMapRoute: JSON.stringify(route),
            allowanceTypeName: type,
            placementId: placementId,
            kilometerAllowanceId: allowanceId
        };
    }

    validateFromToAddress(from: IAddress, to: IAddress): boolean {
        const fromTime = moment(`${from.date} ${from.time}`);
        const toTime = moment(`${to.date} ${to.time}`);

        if (fromTime.diff(toTime) > 0)
            return false;

        return this.validateAddress(from, to)
    }

    validateAddress(...address: Array<IAddress>): boolean {
        const isZipCode = (zipCode: string) => /^[1-9][0-9]{3} ?[A-Z]{2}$/.test(zipCode)
        if (!isAll(isZipCode, ...address.map(a => a.zipcode))) {
            return false;
        }

        const isHouse = (houseNumber: string) => /^[1-9]\d{0,3}$/.test(houseNumber);
        if (!isAll(isHouse, ...address.map(a => a.houseNumber))) {
            return false;
        }

        return true;
    }

    serializeRoute(start: ICoordinate, end: ICoordinate) {
        return "[{\"longitude\":\"" + start.lng + "\",\"latitude\":\"" + start.lat + "\"},{\"longitude\":\"" + end.lng + "\",\"latitude\":\"" + end.lat + "\"}]";
    }
}
