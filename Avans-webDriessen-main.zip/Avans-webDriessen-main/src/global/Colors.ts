
// Status colors
export const darkGray = "#707070";
export const orange = "#FFB33E";
export const lightGreen = "#00D54E";

// Theme colors
export const brightRed = "#E71234";
export const red = "#FF0F1B"; // also status color
export const darkRed = "#BB0825";
export const white = "#FFFFFF";
export const darkWhite = "#F4F0ED";
export const gray = "#D3D3D3"
export const black = "#000000";
export const green = "#50BE64";
export const darkGreen = "#48ab5a";
export const blue = "#679def"