import React, {useState, useEffect} from 'react'
import axios from 'axios'
import RouteService from '../../services/routeService'

import {RouteRow} from '../../components/RouteRow'
import MapOverview from '../../components/MapOverview'
import RoutesAddPanel from '../../components/RoutesAddPanel'

import {IRoute} from '../../interfaces/IRoute'
import {ICoordinate} from '../../interfaces/ICoordinate'
import {IAddress} from '../../interfaces/IAddress'
import {ICompany} from '../../interfaces/ICompany'

import {IKilometerAllowance} from '../../interfaces/IKilometerAllowance'

import {RouteAToB} from '../../svg/RouteAToB'

import {AcceptButton} from '../../styled/Buttons'
import {Container, ContainerItem} from '../../styled/Containers'
import {HeadBar, HeadBarElement, HeadbarLable} from '../../styled/HeaderBars'
import {ItemsList as RouteList} from '../../styled/ItemsLists'
import * as Status from '../../global/StatusNames'
import {IImages} from "../../interfaces/IImages";
import JwtService from "../../services/JwtService";
import {IJwtPayload} from "../../interfaces/IJwtPayload";
import {Help} from '../../svg/Help'
import IPlacement from "../../interfaces/IPlacement";

interface jwtProps {
    jwtService: JwtService;
}

const RoutesOverview: React.FC<jwtProps> = ({jwtService}) => {
    const [routes, setRoutes] = useState<IRoute[]>()
    const [activeRoute, setActiveRoute] = useState<IRoute>()
    const [coordinates, setCoordinates] = useState<Array<ICoordinate>>([])
    const [isAddPanelActive, setIsAddPanelActive] = useState<Boolean>(false)
    const [companies, setCompanies] = useState<ICompany[]>()
    const [images, setImages] = useState<IImages>({})
    const [jwt, setJwt] = useState<string>()
    const [jwtPayload, setJwtPayload] = useState<IJwtPayload>()

    // search / filter
    const [companyValue, setCompanyValue] = useState<string>();
    const [dateValue, setDateValue] = useState<string>();
    const [startLocationValue, setStartLocationValue] = useState<string>();
    const [distanceValue, setDistanceValue] = useState<number>();
    const [endLocationValue, setEndLocationValue] = useState<string>();

    useEffect(() => {
        setJwt(jwtService.getJwt() ?? undefined);
        setJwtPayload(jwtService.getJwtPayload() ?? undefined);
    }, [jwtService]);

    const fetchCompanies = async () => {
        await axios(process.env.REACT_APP_API_URL + 'Companies', {
                headers: {
                    'Authorization': `Bearer ${jwtService.getJwt()}`
                }
            }
        )
            .then((result) => {
                setCompanies(result.data)
            })
            .catch((error) => console.error(error))
    }

    function showAddPanel() {
        setIsAddPanelActive(true)
        setActiveRoute(undefined)
        setCoordinates([])
    }

    function updateActiveRoute(route: IRoute) {
        setIsAddPanelActive(false)
        setActiveRoute(route)

        if (route?.serializedMapRoute != null) setCoordinates(JSON.parse(route.serializedMapRoute))
    }

    const addRoute = async (from: IAddress, to: IAddress, companyName: string, type: string) => {
        let placementId = 'x'

        await axios(process.env.REACT_APP_API_URL + 'Placements/Users/' + jwtService?.getJwtPayload()?.sub, {
                headers: {
                    'Authorization': `Bearer ${jwtService.getJwt()}`
                }
            }
        )
            .then((result) => {
                const placements: IPlacement[] = result.data;
                placements.forEach(placement => {
                    if (placement.companyName === companyName) {
                        placementId = placement.id;
                    }
                });

            })
            .catch((error) => console.error(error))

        let allowanceId = 'x'

        await axios(process.env.REACT_APP_API_URL + 'KilometerAllowances/Users/' + jwtService?.getJwtPayload()?.sub, {
                headers: {
                    'Authorization': `Bearer ${jwtService.getJwt()}`
                }
            }
        )
            .then((result) => {
                let allowances: IKilometerAllowance[] = result.data;
                allowances.forEach(allowance => {
                    if (allowance.companyName === companyName && allowance.allowanceTypeName === type) {
                        allowanceId = allowance.id;
                    }
                });

            })
            .catch((error) => console.error(error))

        const routeService = new RouteService(jwtPayload?.sub, jwt)
        routeService
            .addRouteFromAddress(from, to, companyName, type, placementId, allowanceId)
            .then((newRoute) => {
                if (newRoute === null) return

                const currentRoutes = routes || []
                setRoutes([...currentRoutes, newRoute])
                updateActiveRoute(newRoute)
            })
            .catch((error) => console.error(error))
    }

    const deleteRoute = async () => {
        await axios
            .delete(process.env.REACT_APP_API_URL + `Routes/${activeRoute?.id}`, {
                    headers: {
                        'Authorization': `Bearer ${jwtService.getJwt()}`
                    }
                }
            )
            .then(() => {
                setRoutes(routes?.filter((r) => r.id !== activeRoute?.id))
                setActiveRoute(undefined)
                setCoordinates([])
            })
            .catch((error) => console.error(error))
    }

    const confirmRoute = async () => {
        if (!jwt || !jwtPayload) return;
        if (activeRoute) {
            activeRoute.userId = '1136c538-367b-41a7-b114-86d44d9cb846' /* TODO: change to userid */
            activeRoute.statusName = Status.PENDING_BY_EMPLOYER

            const url = process.env.REACT_APP_API_URL + `routes/${activeRoute.id}`,
                method = 'PUT',
                headers = {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${jwtService.getJwt()}`
                },
                str = JSON.stringify(activeRoute)

            await fetch(url, {method, headers, body: str})
                .then(async (result) => {
                    const confirmedRoute: IRoute = await result.json()

                    if (confirmedRoute === null) return

                    const updateRoutes = routes || []
                    setRoutes(
                        updateRoutes.map((obj) => updateRoutes.find((o) => o.id === obj.id) || obj)
                    )
                    updateActiveRoute(confirmedRoute)
                })
                .catch((error) => console.error(error))
        }
    }

    useEffect(
        () => {
            fetchData()
            fetchCompanies()
        },
        // eslint-disable-next-line
        [companyValue, dateValue, startLocationValue, distanceValue, endLocationValue/*, declarationValue*/]
    )

    useEffect(
        () => {
            let images: IImages = {};
            companies?.forEach(company => {
                images[company.name] = company.image
            })
            setImages(images)
        },
        [routes, companies]
    )

    const fetchData = async () => {
        const userId = jwtService?.getJwtPayload()?.sub
        if (userId == null)
            return console.error("No JWT found")

        let baseRequest = process.env.REACT_APP_API_URL + `Routes/User/${userId}?PageNumber=1`

        if (companyValue !== undefined && companyValue !== "") {
            baseRequest += `&company=${companyValue}`
        }

        if (dateValue !== undefined && dateValue !== "") {
            const [year, month, day] = [...dateValue.split("-").map(n => parseInt(n.trim()))]
            baseRequest += `&startdate=${year}-${month}-${day - 1}`
            baseRequest += `&enddate=${year}-${month}-${day + 1}`
        }

        if (startLocationValue !== undefined && startLocationValue !== "") {
            baseRequest += `&startlocation=${startLocationValue}`
        }

        if (distanceValue !== undefined && distanceValue !== -1) {
            let convertedDistance = (distanceValue * 1000)
            baseRequest += `&mindistance=${Math.max(convertedDistance - 1000, 0)}&maxdistance=${convertedDistance + 1000}`
        }

        if (endLocationValue !== undefined && endLocationValue !== "") {
            baseRequest += `&endlocation=${endLocationValue}`
        }

        await axios(baseRequest, {
                headers: {
                    'Authorization': `Bearer ${jwtService.getJwt()}`
                }
            }
        )
            .then((result) => {
                setRoutes(result.data)
            })
            .catch((error) => {
                setRoutes([])
                console.error(error)
            })
    }

    return (
        <Container>
            <ContainerItem style={{flexBasis: '20%'}}>
                <HeadBar>
                    <HeadBarElement>
                        <RouteAToB/>
                        <h2 style={{margin: '0px 2px 0px 20px'}}>Mijn gereden routes</h2>
                        {/* <Help width="22px" height="22px" /> */}
                    </HeadBarElement>
                    <AcceptButton onClick={() => showAddPanel()}>Route toevoegen +</AcceptButton>
                </HeadBar>

                <HeadbarLable style={{margin: '0px', marginTop: '20px'}}>
                    <input onChange={e => setCompanyValue(e.target.value)}
                           style={{maxWidth: "120px", fontSize: "16px", marginLeft: "75px"}} type="text"
                           placeholder="organisatie"/>
                    <input onChange={e => setDateValue(e.target.value)} style={{maxWidth: "150px", fontSize: "16px"}}
                           type="date" placeholder="datum"/>
                    <input onChange={e => setStartLocationValue(e.target.value)}
                           style={{maxWidth: "130px", fontSize: "16px"}} type="text" placeholder="van"/>
                    <input onChange={e => setDistanceValue(parseInt(e.target.value) || -1)}
                           style={{maxWidth: "120px", fontSize: "16px"}} type="number" placeholder="afstand (km)"/>
                    <input onChange={e => setEndLocationValue(e.target.value)}
                           style={{maxWidth: "130px", fontSize: "16px"}} type="text" placeholder="naar"/>
                </HeadbarLable>

                <hr style={{margin: '0px'}}/>

                <RouteList style={{height: '74vh'}}>
                    {(routes && routes.length > 0) ?
                        routes.map((route) => (
                            <RouteRow
                                key={route.id}
                                route={route}
                                activeRoute={activeRoute}
                                setActiveRoute={updateActiveRoute}
                                image={images[route.companyName]}
                                isEmployer={false}
                            />
                        )) :
                        <div style={{textAlign: 'center', color: "gray"}}>
                            <Help style={{margin: "10px", width: "3em", height: "3em"}}></Help>
                            <h4>Geen routes gevonden.</h4>
                            <p>Er zijn geen resultaten gevonden voor deze gebruiker
                                {((companyValue !== undefined && companyValue !== "") || (dateValue !== undefined && dateValue !== "") || (startLocationValue !== undefined && startLocationValue !== "") || (distanceValue !== undefined && distanceValue !== -1) || (endLocationValue !== undefined && endLocationValue !== "")) ? " met de opgegeven filters" : ""}.
                            </p>
                        </div>}
                </RouteList>
            </ContainerItem>

            <ContainerItem>
                {isAddPanelActive ? (
                    <RoutesAddPanel
                        setIsAddPanelActive={setIsAddPanelActive}
                        addRoute={addRoute}
                        companies={companies}
                    />
                ) : (
                    <MapOverview
                        deleteRoute={deleteRoute}
                        confirmRoute={confirmRoute}
                        coordinates={coordinates}
                        setCoordinates={setCoordinates}
                        activeRoute={activeRoute}
                        setActiveRoute={setActiveRoute}
                        companies={companies}
                        isEmployer={false}
                        isEmployee={true}
                    />
                )}
            </ContainerItem>
        </Container>
    )
}

export default RoutesOverview
