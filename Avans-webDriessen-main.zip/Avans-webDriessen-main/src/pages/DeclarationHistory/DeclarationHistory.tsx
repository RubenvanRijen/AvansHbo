import '../../styled/DeclarationHistory.css';
import React, {useCallback, useEffect, useState} from 'react';
import JwtService from "../../services/JwtService";
import {IUser} from "../../interfaces/IUser";
import TextField from "@material-ui/core/TextField";
import {UserRow} from "../../components/UserRow";
import {ICompany} from "../../interfaces/ICompany";
import styled from "styled-components";
import * as Colors from "../../global/Colors";
import {IJwtPayload} from "../../interfaces/IJwtPayload";
import {IRoute} from "../../interfaces/IRoute";


const moment = require('moment');
moment().locale('nl')

const UserList = styled.div({
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',

    minHeight: '100px',
    padding: '20px 20px',
    margin: '10px 0px',

    boxShadow: 'inset 0px 2px 5px 0px rgba(50, 50, 40, 0.2)',
    backgroundColor: Colors.darkWhite,
    borderRadius: '4px',
    overflowY: 'scroll',
});

interface jwtProps {
    jwtService: JwtService;
}

const DeclarationHistory: React.FC<jwtProps> = ({jwtService}) => {
    const [jwt, setJwt] = useState<string>()
    const [jwtPayload, setJwtPayload] = useState<IJwtPayload>();
    const [originalUsers, setOriginalUsers] = useState<IUser[]>()
    const [users, setUsers] = useState<IUser[]>()
    const [activeUser, setActiveUser] = useState<IUser>()
    const [companies, setCompanies] = useState<ICompany[]>()
    const [routesActive, setRoutesActive] = useState<boolean>(false)
    const [nameInputField, setNameInputField] = useState<string>('')
    const columnHeader = ["Werknemer", "Afstand", "Soort reis", "Prijs", "Status", "Datum"];
    const [routes, setRoutes] = useState<IRoute[]>([]);
    const date = new Date();
    //filters
    const [monthValue, setMonthValue] = useState<string>('');
    const [yearValue, setYearValue] = useState<string>(date.getFullYear().toString());

    const typeOfTravel = {
        "WORK": "Werk",
        "HOME_TO_WORK": "Woon- werkverkeer"
    };
    const typeOfState = {
        "APPROVED": "Goed gekeurd",
        "REJECTED": "Afgekeurd",
        "PENDING_BY_EMPLOYEE": "In afwachting van werknemer",
        "PENDING_BY_EMPLOYER": "In afwachting van goedkeuring"
    }

    const datesData = [
        {"month": "Januari", "data": new Date(date.getFullYear(), 0, 1)},
        {"month": "Februari", "data": new Date(date.getFullYear(), 1, 1)},
        {"month": "Maart", "data": new Date(date.getFullYear(), 2, 1)},
        {"month": "April", "data": new Date(date.getFullYear(), 3, 1)},
        {"month": "Mei", "data": new Date(date.getFullYear(), 4, 1)},
        {"month": "Juni", "data": new Date(date.getFullYear(), 5, 1)},
        {"month": "Juli", "data": new Date(date.getFullYear(), 6, 1)},
        {"month": "Augustus", "data": new Date(date.getFullYear(), 7, 1)},
        {"month": "September", "data": new Date(date.getFullYear(), 8, 1)},
        {"month": "Oktober", "data": new Date(date.getFullYear(), 9, 1)},
        {"month": "November", "data": new Date(date.getFullYear(), 10, 1)},
        {"month": "December", "data": new Date(date.getFullYear(), 11, 1)}
    ];

    useEffect(() => {
        setJwt(jwtService.getJwt() ?? undefined);
        setJwtPayload(jwtService.getJwtPayload() ?? undefined);
    }, [jwtService]);

    //get users from companie
    const fetchData = useCallback(() => {
        if (!jwt) return;
        if (!jwtPayload) return;
        fetch(process.env.REACT_APP_API_URL + `Users/company/${jwtPayload?.company}`, {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${jwt}`,
            },
        })
            .then((res) => res.json())
            .then((users: IUser[]) => {
                setUsers(users);
                setOriginalUsers(users);
            })

        fetch(process.env.REACT_APP_API_URL + 'Companies', {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${jwt}`,
            },
        })
            .then((res) => res.json())
            .then((companies: ICompany[]) => {
                setCompanies(companies)
            })
    }, [jwt, jwtPayload]);
    //only call once
    useEffect(() => {
        fetchData()
    }, [jwt, fetchData]);

    //set active user;
    useEffect(() => setActiveUser(undefined), [users]);

    //if new user is chosen
    const onUserRowClicked = (user: IUser) => {
        if (activeUser === user) {
            setRoutesActive(false);
            setActiveUser(undefined);
            setRoutes([]);
        } else {
            setRoutesActive(true);
            setActiveUser(user);
            fetchRoutes(user, monthValue, yearValue);
        }
    }

    //get routes from users
    const fetchRoutes = useCallback(async (user: IUser, date: string, year: string) => {
        if (!jwt) return;
        if (!jwtPayload) return;
        if (!jwtPayload.company) return;
        if (!user) return;
        let baseUrl = process.env.REACT_APP_API_URL + `Routes/User/${user.id}?PageNumber=1&company=${jwtPayload?.company}`;

        if (date !== undefined && date !== "") {
            let originalData = new Date(date);
            let yearValue = parseInt(year);
            baseUrl += `&StartDate=${yearValue}-0${originalData.getMonth() + 1}-01`
            baseUrl += `&EndDate=${yearValue}-0${originalData.getMonth() + 1}-${new Date(originalData.getFullYear(), originalData.getMonth() + 1, 0).getDate()}`
        } else {
            let yearValue = parseInt(year);
            baseUrl += `&StartDate=${yearValue}-01-01`
            baseUrl += `&EndDate=${yearValue}-12-${new Date(yearValue, 12, 0).getDate()}`
        }

        await fetch(baseUrl, {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${jwt}`
            },
        })
            .then((res) => res.json())
            .then(async Routes => {
                if (Routes.status !== 404) {
                    setRoutes(Routes);
                } else {
                    setRoutes([]);
                }
            }).catch(() => {
                setRoutes([]);
            })
    }, [jwt, jwtPayload]);

    //set nameInput fields
    useEffect(() => {
        setNameInputField(nameInputField)
        if (nameInputField === '') {
            setUsers(originalUsers)
        } else {
            //In case a name starts with a capital letter, we ignore that.
            const filteredUsers = originalUsers?.filter((p) =>
                p.firstName.toUpperCase().includes(nameInputField.toUpperCase())
            )
            if (filteredUsers && filteredUsers?.length > 0) {
                setUsers(filteredUsers)
                return
            } else {
                setUsers([]);
            }
        }
    }, [originalUsers, nameInputField]);

    //if date changes then get the routes for that date
    useEffect(() => {
        setMonthValue(monthValue);
        setYearValue(yearValue);
        if (activeUser) {
            fetchRoutes(activeUser, monthValue, yearValue);
        }
        return;
    }, [monthValue, yearValue, activeUser, fetchRoutes]);

    //create the headers for table
    function generateHeader() {
        let res = [];
        for (let i = 0; i < columnHeader.length; i++) {
            res.push(<th>{columnHeader[i]}</th>)
        }
        return res;
    }

    //create the table
    function generateTable() {
        let res = [];
        if (routes !== undefined) {
            for (let i = 0; i < routes.length; i++) {
                res.push(
                    <tr key={"BodyTR" + i}>
                        <td>{activeUser?.firstName} {activeUser?.lastName}</td>

                        <td>{routes[i].distance ? ((routes[i].distance / 1000).toFixed(2)) : 0.00} Km</td>

                        {routes[i].allowanceTypeName ? (
                            // @ts-ignore
                            <td>{typeOfTravel[`${routes[i].allowanceTypeName}`]}</td>
                        ) : <td>Onbekend</td>}

                        {routes[i].estimatedPayment ? (
                            <td>€ {routes[i].estimatedPayment.toFixed(2)}</td>
                        ) : <td>Onbekend</td>}

                        {routes[i].statusName ? (
                            // @ts-ignore
                            <td>{typeOfState[`${routes[i].statusName}`]}</td>
                        ) : <td>Onbekend</td>}

                        {moment(routes[i]?.startTime).format('LL') === moment(routes[i]?.endTime).format('LL') ? (
                                <td>{moment(routes[i]?.startTime).format('LL')}</td>
                            ) :
                            <td>{moment(routes[i]?.startTime).format('LL')} - {moment(routes[i]?.endTime).format('LL')}</td>
                        }
                    </tr>
                )
            }
        }
        return res;
    }

    //set dates option
    function setDates() {
        let res: any[] = [];
        res.push(<option></option>)
        for (let k = 0; k < datesData.length; k++) {
            res.push(
                // @ts-ignore
                <option value={datesData[k].data}>{datesData[k].month}</option>
            );
        }
        return res;
    }


    return (
        <div className="row">
            <div className="col-5">
                <div className="row">
                    <div className="ml-4 mt-4 col d-flex justify-content-center">
                        <h3 style={{fontWeight: 'bold'}}>Declaratie geschiedenis</h3>
                    </div>
                    <div className="col mt-lg-5 d-flex justify-content-center">
                        <TextField
                            variant="outlined"
                            margin="dense"
                            id="year"
                            label="Zoek op jaar"
                            name="year"
                            autoComplete="firstName"
                            value={yearValue}
                            onChange={(e) => setYearValue(e.target.value)}
                            autoFocus
                        />
                    </div>
                    <div className="col mt-lg-5 pt-2 d-flex justify-content-center">
                        <select onChange={(e) => setMonthValue(e.target.value)} value={monthValue}
                                className="form-control" autoFocus
                                id="exampleFormControlSelect1">
                            {setDates()}
                        </select>
                    </div>
                    <div className="col mt-lg-5 d-flex justify-content-center">
                        <TextField
                            variant="outlined"
                            margin="dense"
                            id="firstName"
                            label="Zoek op voornaam"
                            name="firstName"
                            autoComplete="firstName"
                            value={nameInputField}
                            onChange={(e) => setNameInputField(e.target.value)}
                            autoFocus
                        />
                    </div>
                </div>
                <div className="ml-4">
                    <UserList>
                        {users &&
                        users.map((user) => (
                            <UserRow
                                key={user.id}
                                user={user}
                                activeUser={activeUser}
                                setActiveUser={onUserRowClicked}
                                companyImage={
                                    companies?.find(
                                        (company) => company.name === user.companyName
                                    )?.image
                                }
                            />
                        ))}
                    </UserList>
                </div>
            </div>
            <div className="col mt-lg-5">
                {routesActive && activeUser && (
                    <table key="Table" className="table mt-4 table-hover table-striped">
                        <thead key="Head">
                        <tr key="HeadTR">
                            {generateHeader()}
                        </tr>
                        </thead>
                        <tbody key="Body">
                        {generateTable()}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    )
}

export default DeclarationHistory;
