import './Login.css'
import React, {useState} from 'react'
import JwtService from '../../services/JwtService';
import {getNavLayoutCurrentUser} from '../../navigations/NavLayouts';
import Alert from "@material-ui/lab/Alert";

const url = process.env.REACT_APP_API_URL + 'authentication'
const jsonMediaType = 'application/json'

interface LoginProps {
    jwtService: JwtService;
}

const Login: React.FC<LoginProps> = ({jwtService}) => {
    const [username, setUsername] = useState<string>('')
    const [password, setPassword] = useState<string>('')
    const [errors, setErrors] = useState(false);

    const usernameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        let value = event.target.value
        setErrors(false);
        setUsername(value)
    }

    const passwordChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        let value = event.target.value
        setErrors(false);
        setPassword(value)
    }

    async function authorize() {
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': jsonMediaType,
                    Accept: jsonMediaType,
                },
                body: JSON.stringify({
                    email: username,
                    password: password,
                }),
            })

            if (response.status !== 200) {
                jwtService.removeJwt();
                setPassword('');
                setErrors(true);
                return
            }

            const responseBody = await response.json()
            const jwt = responseBody.jwt

            jwtService.setJwt(jwt);
            window.location.href = getNavLayoutCurrentUser()?.home || '/home'
        } catch (error) {
            console.error(error)
        }
    }

    return (
        <div className="background-container">
            <div className="main-logo-div"/>
            <div className="login-div">
                <div className="logo-div"/>
                <div className="input-div">
                    <input placeholder="Gebruikersnaam" type="username" onChange={usernameChange}/>
                </div>
                <div className="input-div">
                    <input placeholder="Wachtwoord" type="password" onChange={passwordChange}/>
                </div>
                <div className="white-bar"/>
                <button className="login-button low-border-shadow ml-2" onClick={authorize}>
                    Log in
                </button>
                {errors ? (
                    <Alert className="mt-2" severity="error">Verkeerd gebruikersnaam of wachtwoord</Alert>
                ) : <div className="Pop-Fix"></div>}
            </div>
            <span className="copyright text-center">
                Reiskosten tracker &copy;2020
                <br/>
                Powered by Driessen
            </span>
        </div>
    )
}

export default Login
