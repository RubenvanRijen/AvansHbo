import '../../styled/Profile.css';
import React, { useEffect, useState } from 'react';
import JwtService from "../../services/JwtService";
import { IJwtPayload } from "../../interfaces/IJwtPayload";
import { IUser } from "../../interfaces/IUser";
import Alert from "@material-ui/lab/Alert";
import translation from "../Register/Translation";
import defaultIcon from '../../Assets/default-profile-image.png'
import { AcceptButton, CancelButton } from '../../styled/Buttons'

interface jwtProps {
    jwtService: JwtService;
}

const Profile: React.FC<jwtProps> = ({ jwtService }) => {

    const [jwt, setJwt] = useState<string>();
    const [jwtPayload, setJwtPayload] = useState<IJwtPayload>();
    const [errors, setErrors] = useState(true);
    const [user, setUser] = useState<IUser>();
    const [errorMessages, setErrorMessages] = useState<any>('');

    //values
    const [firstName, setFirstName] = useState('')
    const [lastName, setLastName] = useState('')
    const [email, setEmail] = useState('')


    useEffect(() => {
        setJwt(jwtService.getJwt() ?? undefined);
        setJwtPayload(jwtService.getJwtPayload() ?? undefined);
    }, [jwtService]);


    useEffect(() => {
        getUserData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [jwt, jwtPayload, jwtService]);

    function getUserData() {
        if (!jwt || !jwtPayload) return;
        const url = process.env.REACT_APP_API_URL + `Users/${jwtPayload.sub}`;
        fetch(
            url,
            {
                method: 'GET',
                headers: {
                    Accept: 'application/json',
                    Authorization: `Bearer ${jwt}`,
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                }
            }
        )
            .then((response) => response.json())
            .then((responseJson) => {
                if (responseJson.status === 404) {
                    setErrors(true);
                } else {
                    if (responseJson.image == null) responseJson.image = defaultIcon;
                    setUser(responseJson);
                    setFirstName(responseJson.firstName);
                    setLastName(responseJson.lastName);
                    setEmail(responseJson.email);
                }
            })
            .catch((err) => {
                console.log(err)
            });
    }

    async function saveNewUser() {
        const errorTranslation: any = translation
        if (user === undefined || user === null) return;
        if (!jwt || !jwtPayload) return;
        let userData = {
            email: email,
            firstName: firstName,
            lastName: lastName,
        }


        const url = process.env.REACT_APP_API_URL + `Users/${jwtPayload.sub}`;
        await fetch(
            url,
            {
                method: 'PUT',
                headers: {
                    Accept: 'application/json',
                    Authorization: `Bearer ${jwt}`,
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify(userData)
            })
            .then(async (response) => await response.json())
            .then(async (responseJson) => {
                if (responseJson.status === 400) {
                    let errorMessage: any = {}
                    for (let key in responseJson.errors) {
                        for (let i = 0; i < responseJson.errors[key].length; i++) {
                            if (errorTranslation.hasOwnProperty(key)) {
                                errorMessage[key] = Object.values(errorTranslation[key])
                            }
                        }
                    }
                    setErrorMessages(errorMessage);
                    setErrors(true);
                    return;
                } else {
                    setErrors(false);
                    setErrorMessages([]);
                }
            })
            .catch(async (err) => {
                setErrors(true);
                setErrors(true);
                return;
            });
        if (!errors) {
            setErrors(false);
        }
    }

    function resetChanges() {
        if (user === undefined || user === null) return;
        setLastName(user!.lastName);
        setFirstName(user!.firstName);
        setEmail(user!.email);
        setErrors(true);
        setErrorMessages([]);
    }

    function changeUser(event: any) {
        const newValue = event.target.value;
        switch (event.target.id) {
            case "firstName":
                setFirstName(newValue);
                break;
            case "lastName":
                setLastName(newValue);
                break;
            case "email":
                setEmail(newValue);
                break;
        }
    }

    return (
        <div className="container customProfile d-flex justify-content-center mt-5">
            <div className="surround-profile-box p-4 text-left rounded">
                <p className="profile-text font-weight-bold">Profiel</p>
                {!errors ? (
                    <Alert severity="success">Wijzigingen successvol opgeslagen</Alert>
                ) : null}
                <div className="card profile-card border shadow-sm">
                    <div className="d-flex justify-content-center">
                        <img src={user?.image ? user?.image : defaultIcon} className="rounded-circle profilePicture mt-3" alt="Profiel afbeelding" />
                    </div>
                    <div className="card-body custom-profile-box">

                        <hr />
                        <div className="form-group">
                            <label htmlFor="exampleInputEmail1">Voornaam</label>
                            <input value={firstName || ''} onChange={changeUser} type="text"
                                className="form-control"
                                id="firstName"
                                aria-describedby="nameHelp" placeholder="Voornaam" />
                            {errorMessages.FirstName ? <Alert severity="error">{errorMessages.FirstName}</Alert> : null}

                        </div>
                        <div className="form-group">
                            <label htmlFor="exampleInputEmail1">Achternaam</label>
                            <input value={lastName || ''} onChange={changeUser} type="text"
                                className="form-control"
                                id="lastName"
                                aria-describedby="nameHelp" placeholder="Achternaam" />
                            {errorMessages.LastName ? <Alert severity="error">{errorMessages.LastName}</Alert> : null}

                        </div>
                        <div className="form-group">
                            <label htmlFor="exampleInputEmail1">Email</label>
                            <input value={email || ''} onChange={changeUser} type="text"
                                className="form-control"
                                id="email"
                                aria-describedby="emailHelp" placeholder="example@example.com" />
                            {errorMessages.Email ? <Alert severity="error">{errorMessages.Email}</Alert> : null}

                        </div>
                        <hr />
                    </div>
                </div>
                <div className="text-right mt-3 d-flex justify-content-end">
                    <div className="row text-right">
                        <CancelButton style={{ width: "120px", marginRight: "10px" }} type="submit" onClick={resetChanges}>Annuleren</CancelButton>
                        <AcceptButton style={{ width: "120px" }} type="submit" onClick={saveNewUser}>Opslaan</AcceptButton>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Profile;
