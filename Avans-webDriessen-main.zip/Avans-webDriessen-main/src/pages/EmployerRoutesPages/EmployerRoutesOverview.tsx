import React, {useEffect, useState} from 'react'
import styled from 'styled-components'
import {RouteAToB} from '../../svg/RouteAToB'
import {IRoute} from '../../interfaces/IRoute'
import * as Colors from '../../global/Colors'
import MapOverview from '../../components/MapOverview'
import {HeadBar, HeadBarElement, HeadbarLable} from '../../styled/HeaderBars'
import {RouteRow} from '../../components/RouteRow'
import * as Status from '../../global/StatusNames'
import {IJwtPayload} from '../../interfaces/IJwtPayload'
import {ICoordinate} from '../../interfaces/ICoordinate'
import {IUser} from "../../interfaces/IUser";
import {IImages} from "../../interfaces/IImages";
import JwtService from '../../services/JwtService';
import { Help } from '../../svg/Help'

const Container = styled.div({
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-around',
})

const ContainerItem = styled.div({
    flexGrow: 1,
    flexBasis: '30%',
    padding: '20px',
    margin: '40px 20px',
})

const RouteList = styled.div({
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',

    minHeight: '100px',
    padding: '20px 20px',
    margin: '10px 0px',

    boxShadow: 'inset 0px 2px 5px 0px rgba(50, 50, 40, 0.2)',
    backgroundColor: Colors.darkWhite,
    borderRadius: '4px',
    overflowY: 'scroll',
})

interface IEmployerRoutesOverviewProps {
    jwtService: JwtService
}

const EmployerRoutesOverview: React.FC<IEmployerRoutesOverviewProps> = ({jwtService}) => {
    const [images, setImages] = useState<IImages>({})
    const [activeRoute, setActiveRoute] = useState<IRoute>()
    const [coordinates, setCoordinates] = useState<Array<ICoordinate>>([])
    const [routes, setRoutes] = useState<IRoute[]>([])
    const [jwt, setJwt] = useState<string>()
    const [jwtPayload, setJwtPayload] = useState<IJwtPayload>()

    // search / filter
    const [dateValue, setDateValue] = useState<string>();
    const [startLocationValue, setStartLocationValue] = useState<string>();
    const [distanceValue, setDistanceValue] = useState<number>();
    const [endLocationValue, setEndLocationValue] = useState<string>();

    useEffect(() => {
        setJwt(jwtService.getJwt() ?? undefined);
        setJwtPayload(jwtService.getJwtPayload() ?? undefined);
    }, [jwtService]);

    useEffect(() => {
        if (!jwt || !jwtPayload)
            return;

        let baseRequest = process.env.REACT_APP_API_URL+`Routes/?company=${jwtPayload?.company}&status=PENDING_BY_EMPLOYER`

        if(dateValue!== undefined && dateValue !== "") {
            const [year, month, day] = [...dateValue.split("-").map(n => parseInt(n.trim()))]
            baseRequest += `&startdate=${year}-${month}-${day-1}`
            baseRequest += `&enddate=${year}-${month}-${day+1}`
        }

        if(startLocationValue !== undefined && startLocationValue !== "") {
            baseRequest += `&startlocation=${startLocationValue}`
        }

        if(distanceValue !== undefined && distanceValue !== -1) {
            let convertedDistance = (distanceValue * 1000)
            baseRequest += `&mindistance=${Math.max(convertedDistance - 1000, 0)}&maxdistance=${convertedDistance + 1000}`
        }

        if(endLocationValue !== undefined && endLocationValue !== "") {
            baseRequest += `&endlocation=${endLocationValue}`
        }

        fetch(
            baseRequest,
            {
                method: 'GET',
                headers: {
                    Accept: 'application/json',
                    Authorization: `Bearer ${jwt}`,
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                }
            }
        )
            .then((response) => response.json())
            .then((responseJson) => {
                if (responseJson.status === 404) {
                    setRoutes([])
                } else {
                    setRoutes(responseJson)
                }
            })
            .catch((err) => {
                console.log(err)
                setRoutes([])
            })
    }, [activeRoute, jwt, jwtPayload, dateValue, startLocationValue, distanceValue, endLocationValue])

    function updateActiveRoute(route: IRoute) {
        setActiveRoute(route)
        if (route?.serializedMapRoute != null) setCoordinates(JSON.parse(route.serializedMapRoute))
    }

    const rejectRoute = async () => {
        if (activeRoute) {
            activeRoute.userId = jwtPayload?.sub ?? ''
            activeRoute.statusName = Status.REJECTED

            const url = process.env.REACT_APP_API_URL+`routes/${activeRoute.id}`,
                method = 'PUT',
                headers = {
                    Accept: 'application/json',
                    Authorization: `Bearer ${jwt}`,
                    'Content-Type': 'application/json'
                },
                str = JSON.stringify(activeRoute)

            await fetch(url, {method, headers, body: str})
                .then(async (result) => {
                    const confirmedRoute: IRoute = await result.json()

                    if (confirmedRoute === null) return

                    const updateRoutes = routes || []
                    setRoutes(
                        updateRoutes.map((obj) => updateRoutes.find((o) => o.id === obj.id) || obj)
                    )
                    updateActiveRoute(confirmedRoute)
                })
                .catch((error) => console.error(error))
        }
    }

    const confirmRoute = async () => {
        if (activeRoute) {
            activeRoute.userId = jwtPayload?.sub ?? ''
            activeRoute.statusName = Status.APPROVED

            const url = process.env.REACT_APP_API_URL+`routes/${activeRoute.id}`,
                method = 'PUT',
                headers = {
                    Accept: 'application/json',
                    Authorization: `Bearer ${jwt}`,
                    'Content-Type': 'application/json'
                },
                str = JSON.stringify(activeRoute)

            await fetch(url, {method, headers, body: str})
                .then(async (result) => {
                    const confirmedRoute: IRoute = await result.json()

                    if (confirmedRoute === null) return

                    const updateRoutes = routes || []
                    setRoutes(
                        updateRoutes.map((obj) => updateRoutes.find((o) => o.id === obj.id) || obj)
                    )
                    updateActiveRoute(confirmedRoute)
                })
                .catch((error) => console.error(error))
        }
    }

    useEffect(() => {
        const getImage = (userId: string) => {
            fetch(process.env.REACT_APP_API_URL+`Users/${userId}`, {
                method: 'GET',
                headers: {
                    Accept: 'spplication/json',
                    Authorization: `Bearer ${jwt}`,
                    'Access-Control-Allow-Origin': '*',
                },
            })
                .then((response) => response.json())
                .then((body: IUser) => {
                    setImages(images => {
                        return {...images, [userId]: body.image}
                    })
                })
                .catch((err) => {
                    console.log(err)
                })
        };

        const uniqueUserIds: string[] = [];
        routes
            .filter((route: IRoute) => {
                const exists = uniqueUserIds.some(id => route.userId === id)
                uniqueUserIds.push(route.userId)
                return !exists
            })
            .forEach((route: IRoute) => getImage(route.userId))
    }, [routes, jwt])

    return (
        <Container>
            <ContainerItem style={{flexBasis: '20%', marginBottom: "0px"}}>
                <HeadBar>
                    <HeadBarElement>
                        <RouteAToB/>
                        <h2 style={{margin: '0px 2px 0px 20px'}}>
                            Alle routes voor {jwtPayload?.company}
                        </h2>
                    </HeadBarElement>
                </HeadBar>

                <HeadbarLable style={{ margin: '0px', marginTop: '20px' }}>
                    <input onChange={e => setDateValue(e.target.value)} style={{ maxWidth: "150px", fontSize: "16px" }} type="date" placeholder="datum" />
                    <input onChange={e => setStartLocationValue(e.target.value)} style={{ maxWidth: "130px", fontSize: "16px" }} type="text" placeholder="van" />
                    <input onChange={e => setDistanceValue(parseInt(e.target.value) || -1)} style={{ maxWidth: "120px", fontSize: "16px" }} type="number" placeholder="afstand (km)" />
                    <input onChange={e => setEndLocationValue(e.target.value)} style={{ maxWidth: "130px", fontSize: "16px" }} type="text" placeholder="naar" />
                </HeadbarLable>

                <hr style={{margin: '0px'}}/>

                <RouteList style={{height: '74vh'}}>
                    {routes.length > 0 ?
                    routes.map((route) => (
                        <RouteRow
                            key={route.id}
                            route={route}
                            activeRoute={activeRoute}
                            setActiveRoute={updateActiveRoute}
                            image={images[route.userId]}
                            isEmployer={true}
                        />
                    )) : <div style={{textAlign:'center', color:"gray"}}>
                            <Help style={{margin:"10px", width:"3em", height:"3em"}}></Help>
                            <h4>Geen routes gevonden.</h4>
                            <p>Er zijn geen resultaten gevonden voor dit bedrijf
                                {((dateValue!== undefined && dateValue !== "") || (startLocationValue !== undefined && startLocationValue !== "") || (distanceValue !== undefined && distanceValue !== -1) || (endLocationValue !== undefined && endLocationValue !== "")) ? " met de opgegeven filters" : ""}.
                            </p>
                        </div>}
                </RouteList>
            </ContainerItem>

            <ContainerItem style={{height: "827px", padding: "10px"}}>
                <MapOverview 
                    deleteRoute={rejectRoute}
                    confirmRoute={confirmRoute}
                    coordinates={coordinates}
                    setCoordinates={setCoordinates}
                    activeRoute={activeRoute}
                    setActiveRoute={setActiveRoute}
                    isEmployer={true}
                    isEmployee={false}
                />
            </ContainerItem>
        </Container>
    )
}

export default EmployerRoutesOverview
