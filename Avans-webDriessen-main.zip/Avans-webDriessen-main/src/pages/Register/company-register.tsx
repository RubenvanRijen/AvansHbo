// @ts-nocheck
import React, {useEffect, useState} from 'react'
import Button from '@material-ui/core/Button'
import CssBaseline from '@material-ui/core/CssBaseline'
import TextField from '@material-ui/core/TextField'
import Grid from '@material-ui/core/Grid'
import logodriessen from './logo-footer-driessen.png'
import {grey, red} from '@material-ui/core/colors'
import {createMuiTheme, makeStyles, ThemeProvider} from '@material-ui/core/styles'
import Alert from '@material-ui/lab/Alert'
import {FormControl, Input} from '@material-ui/core';
import JwtService from '../../services/JwtService'


const useStyles = makeStyles((theme) => ({
    image: {
        backgroundImage: 'url(https://i.imgur.com/bCOP3SC.jpg)',
        backgroundRepeat: 'no-repeat',
        backgroundColor:
            theme.palette.type === 'light' ? theme.palette.grey[100] : theme.palette.grey[900],
        backgroundSize: 'cover',
        backgroundPosition: 'center',
    },
    paper: {
        backgroundColor: '#f4f0ed',
        padding: '2em',
        borderRadius: '5px',
        margin: theme.spacing(8, 4),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '75%',
        marginTop: theme.spacing(1),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
}))

const theme = createMuiTheme({
    palette: {
        primary: red,
        secondary: grey,
    }
});


interface ICompanyRegisterProps {
    jwtService: JwtService,
    onRegistered: () => void,
    onCanceled: () => void
}

const CompanyRegister: React.FC<ICompanyRegisterProps> = ({jwtService, onRegistered, onCanceled}) => {
    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault()
        if (!jwt) return
        fetch(process.env.REACT_APP_API_URL + 'Companies', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                Authorization: `Bearer ${jwt}`,
            },
            body: JSON.stringify({
                name: name,
                image: image
            }),
        })
            .then(response => {
                if (response.status === 201) {
                    setSuccess(true);
                }
            })
    }

    const imageUploadHandler = event => {
        let file: File = event.target.files[0];
        console.log(file.type)
        if (!file.type.match(/image/)) {
            alert('Invalid format');
            return;
        }

        let reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = function () {
            setImage(reader.result);
        };
    }

    //set states for all fields
    const [jwt, setJwt] = useState<string>()
    const [success, setSuccess] = useState(false);
    const [error, setError] = useState<Object>('')
    const [name, setName] = useState('')
    const [image, setImage] = useState<string>('');
    const classes = useStyles()


    useEffect(() => {
        setJwt(jwtService.getJwt() ?? undefined)
    }, [jwtService])

    return (
        <Grid container component="main">
            <CssBaseline/>
            <div className={classes.paper}>
                <img src={logodriessen} alt="xd" width="100" height="100"/>

                {success ? (
                    <Alert severity="success">Organisatie is succesvol geregistreerd</Alert>
                ) : null}
                <h1>Organisatie toevoegen</h1>
                <form className={classes.form} onSubmit={handleSubmit}>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="name"
                        label="Naam"
                        name="name"
                        autoComplete="name"
                        value={name}
                        onChange={(e) => {
                            setName(e.target.value)
                            const {Name, ...rest} = error
                            setError(rest)
                        }}
                        autoFocus
                    />
                    {error.Name ? <Alert severity="error">{error.Name}</Alert> : null}

                    <FormControl variant="outlined" className="MuiFormControl-fullWidth MuiFormControl-marginNormal">
                        <label htmlFor="fileUpload" className="btn btn-primary btn-block btn-outlined">Upload een
                            afbeelding</label>
                        <Input inputProps={{
                            accept: "image/*",
                            id: 'fileUpload'
                        }} onChange={(e) => imageUploadHandler(e)} name="image" required type="file"
                               style={{display: 'none'}}/>
                    </FormControl>

                    <ThemeProvider theme={theme}>
                        <div className="row">
                            <div className="col">
                                <Button
                                    type="submit"
                                    fullWidth
                                    variant="contained"
                                    color="secondary"
                                    className={classes.submit}
                                    onClick={onCanceled}
                                >
                                    Annuleren
                                </Button>
                            </div>
                            <div className="col">
                                <Button
                                    type="submit"
                                    fullWidth
                                    variant="contained"
                                    color="primary"
                                    className={classes.submit}
                                >
                                    aanmaken
                                </Button>
                            </div>
                        </div>
                    </ThemeProvider>
                </form>
            </div>
        </Grid>
    )
}

export default CompanyRegister;
