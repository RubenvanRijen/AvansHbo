// @ts-nocheck
import React, { useState } from 'react'
import Button from '@material-ui/core/Button'
import CssBaseline from '@material-ui/core/CssBaseline'
import TextField from '@material-ui/core/TextField'
import Grid from '@material-ui/core/Grid'
import logodriessen from './logo-footer-driessen.png'
import { grey, red } from '@material-ui/core/colors'
import { createMuiTheme, makeStyles, ThemeProvider } from '@material-ui/core/styles'
import { Select, InputLabel, MenuItem, FormControl } from '@material-ui/core';
import Alert from '@material-ui/lab/Alert'
import translation from './Translation'

//Styling
const useStyles = makeStyles((theme) => ({
    image: {
        backgroundImage: 'url(https://i.imgur.com/bCOP3SC.jpg)',
        backgroundRepeat: 'no-repeat',
        backgroundColor:
            theme.palette.type === 'light' ? theme.palette.grey[100] : theme.palette.grey[900],
        backgroundSize: 'cover',
        backgroundPosition: 'center',
    },
    paper: {
        backgroundColor: '#f4f0ed',
        padding: '2em',
        borderRadius: '5px',
        margin: theme.spacing(8, 4),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '50%',
        marginTop: theme.spacing(1),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
}))

const theme = createMuiTheme({
    palette: {
        primary: red,
        secondary: grey,
    },
})

const errorTranslation: Object = translation

export default function SignInSide({ onRegistered, onCanceled, role, companies }) {
    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault()

        const bodyObject = {
            firstName: firstName,
            lastName: lastName,
            email: email,
            password: password,
            roleName: roleName,
            companyName: companyName
        };
        if (accountNumber) {
            bodyObject.accountNumber = accountNumber;
        }

        fetch(process.env.REACT_APP_API_URL + 'Users', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify(bodyObject),
        })
            .then((response) => response.json())
            .then((responseJson) => {
                if (responseJson.status === 400) {
                    let errorMessages: Object = {}
                    for (let key in responseJson.errors) {
                        for (let i = 0; i < responseJson.errors[key].length; i++) {
                            if (errorTranslation.hasOwnProperty(key)) {
                                errorMessages[key] = Object.values(errorTranslation[key])
                            }
                        }
                    }
                    setError(errorMessages)
                } else {
                    setSuccess('true')
                    onRegistered()
                }
            })
    }

    //set states for all fields
    const [success, setSuccess] = useState('false')
    const [error, setError] = useState<Object>('')
    const [firstName, setFirstName] = useState('')
    const [lastName, setLastName] = useState('')
    const [email, setEmail] = useState('')
    const [accountNumber, setAccountNumber] = useState('')
    const [password, setPassword] = useState('')
    const [roleName] = useState(role)
    const [companyName, setCompanyName] = useState<string>('geen');
    const classes = useStyles()

    return (
        <Grid container component="main">
            <CssBaseline />
            <div className={classes.paper}>
                <img src={logodriessen} alt="xd" width="100" height="100" />

                {success === 'true' ? (
                    <Alert severity="success">Gebruiker is succesvol geregistreerd</Alert>
                ) : null}
                <h1>{role === 'Employer' ? 'Werkgever' : 'Werknemer'} toevoegen</h1>
                <form className={classes.form} onSubmit={handleSubmit}>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="firstName"
                        label="Voornaam"
                        name="firstName"
                        autoComplete="firstName"
                        value={firstName}
                        onChange={(e) => {
                            setFirstName(e.target.value)
                            const { FirstName, ...rest } = error
                            setError(rest)
                        }}
                        autoFocus
                    />
                    {error.FirstName ? <Alert severity="error">{error.FirstName}</Alert> : null}

                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="lastName"
                        label="Achternaam"
                        name="lastName"
                        autoComplete="lastName"
                        value={lastName}
                        onChange={(e) => {
                            setLastName(e.target.value)
                            const { LastName, ...rest } = error
                            setError(rest)
                        }}
                        autoFocus
                    />
                    {error.LastName ? <Alert severity="error">{error.LastName}</Alert> : null}

                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="email"
                        label="Email adres"
                        name="email"
                        autoComplete="email"
                        value={email}
                        onChange={(e) => {
                            setEmail(e.target.value)
                            const { Email, ...rest } = error
                            setError(rest)
                        }}
                        autoFocus
                    />
                    {error.Email ? <Alert severity="error">{error.Email}</Alert> : null}
                    {role === 'Employee' && (
                        <TextField
                            variant="outlined"
                            margin="normal"
                            required
                            fullWidth
                            id="accountNumber"
                            label="Bankrekeningnummer"
                            name="accountNumber"
                            autoComplete="accountNumber"
                            value={accountNumber}
                            onChange={(e) => {
                                setAccountNumber(e.target.value)
                                const { AccountNumber, ...rest } = error
                                setError(rest)
                            }}
                            autoFocus
                        />
                    )}
                    {role === 'Employee' && error.AccountNumber ? (
                        <Alert severity="error">{error.AccountNumber}</Alert>
                    ) : null}

                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        name="password"
                        label="Wachtwoord"
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => {
                            setPassword(e.target.value)
                            const { Password, ...rest } = error
                            setError(rest)
                        }}
                        autoComplete="current-password"
                    />
                    {error.Password ? <Alert severity="error">{error.Password}</Alert> : null}

                    {role === 'Employer' &&
                        (
                            <FormControl variant="outlined" className="MuiFormControl-fullWidth MuiFormControl-marginNormal">
                                <InputLabel htmlFor="copmany">Bedrijf</InputLabel>
                                <Select value={companyName} width="100%" onChange={e => setCompanyName(e.target.value)} inputProps={{ id: 'company' }} label="Bedrijf">
                                    <MenuItem value="geen">Geen</MenuItem>
                                    {companies && companies.map(company =>
                                        <MenuItem key={company.name} value={company.name}>{company.name}&nbsp;<img src={company.image} alt="" height="25px" width="25px"></img></MenuItem>
                                    )}
                                </Select>
                            </FormControl>
                        )
                    }

                    <ThemeProvider theme={theme}>
                        <div className="row">
                            <div className="col">
                                <Button
                                    type="submit"
                                    fullWidth
                                    variant="contained"
                                    color="secondary"
                                    className={classes.submit}
                                    onClick={onCanceled}
                                >
                                    Annuleren
                                </Button>
                            </div>
                            <div className="col">
                                <Button
                                    type="submit"
                                    fullWidth
                                    variant="contained"
                                    color="primary"
                                    className={classes.submit}
                                >
                                    aanmaken
                                </Button>
                            </div>
                        </div>
                    </ThemeProvider>
                </form>
            </div>
        </Grid>
    )
}
