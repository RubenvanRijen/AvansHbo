export default {
    FirstName: {
        "The field FirstName must be a string or array type with a minimum length of '3'.":
            ' Voornaam mag alleen bestaan uit letters en dient minimaal 3 tekens te bevatten.',
    },

    LastName: {
        "The field LastName must be a string or array type with a minimum length of '3'.":
            ' Achternaam mag alleen bestaan uit letters en dient minimaal 3 tekens te bevatten.',
    },

    Password: {
        "The field Password must be a string or array type with a minimum length of '8'.":
            ' Het wachtwoord dient minimaal 8 tekens te bevatten.',
        'Password should at least contain a lower cae letter, upper case letter, numeric value and a special case characters':
            ' Het wachtwoord dient minimaal 1 kleine letter, 1 hoofdletter, 1 numerieke waarde en een speciale teken te bevatten.',
    },

    Email: {
        "The field Email must be a string or array type with a minimum length of '3'.":
            ' Een email adres dient minimaal 3 tekens te bevatten. ',
        'E-mail adress atleast needs a character, a @ and a character':
            ' Een email dient minimaal te bestaan uit een tekens, gevolgd door een @ en ten slotte weer met een teken.',
    },

    AccountNumber: {
        "The field AccountNumber must be a string or array type with a minimum length of '16'.":
            ' De bankrekeningnummer dient minimaal 16 tekens te bevatten.',
        "The field AccountNumber must be a string or array type with a maximum length of '22'.":
            ' De bankrekeningnummer dient maximaal 22 tekens te bevatten.',
    },
}
