import '../../styled/Settings.css'
import React, {useState} from 'react';
import {Row, Col} from 'react-bootstrap';
import SettingsBox from "../../components/SettingsBox";
import DatePickerFreeDays from "../../components/DatePickerFreeDays";
import OverViewFreeDays from "../../components/OverViewFreeDays";
import JwtService from "../../services/JwtService";

interface jwtProps {
    jwtService: JwtService;
}

const Settings: React.FC<jwtProps> = ({jwtService}) => {

    const [freeDays, setFreedays] = useState('SeeDates');
    const [style, setStyle] = useState('right-Colm2');

    function renderSwitch(Data: string) {
        switch (Data) {
            case 'PickDate':
                setStyle('right-Colm');
                break;
            case 'SeeDates':
                setStyle('right-Colm2')
                break;
            default:
                setStyle('right-Colm2');
                break;

        }
    }

    async function handleChange(newValue: string) {
        await renderSwitch(newValue);
        await setFreedays(newValue);
    }

    return (
        <Row className="mt-5">
            <Col sm={4} className="text-left left-Colm">
                <SettingsBox value={freeDays} jwtService={jwtService} onChange={handleChange}/>
            </Col>
            <div className="vl"/>
            <Col sm={7} className={style + " justify-content-center"}>
                {freeDays === "SeeDates"
                    ? <OverViewFreeDays jwtService={jwtService}/>
                    : <DatePickerFreeDays jwtService={jwtService}/>
                }
            </Col>
        </Row>
    );
}

export default Settings;
