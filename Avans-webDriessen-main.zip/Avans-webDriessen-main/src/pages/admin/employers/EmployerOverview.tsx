import React, { useCallback, useEffect, useState } from 'react'
import styled from 'styled-components'
import * as Colors from '../../../global/Colors'
import './EmployerOverview.css'
import { UserRow } from '../../../components/UserRow'
import { IUser } from '../../../interfaces/IUser'
import { AcceptButton } from '../../../styled/Buttons'
import { ICompany } from '../../../interfaces/ICompany'
import JwtService from '../../../services/JwtService'
import Register from '../../Register/Register'
import UserInformationForm from '../../../components/UserInformationForm'
import TextField from '@material-ui/core/TextField'
import UserIcon from '../../../Assets/default-profile-image.png'

const UserList = styled.div({
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',

    minHeight: '100px',
    padding: '20px 20px',
    margin: '10px 0px',

    boxShadow: 'inset 0px 2px 5px 0px rgba(50, 50, 40, 0.2)',
    backgroundColor: Colors.darkWhite,
    borderRadius: '4px',
    overflowY: 'scroll',
})

interface IEmployerOverViewProps {
    jwtService: JwtService
}

const EmployerOverView: React.FC<IEmployerOverViewProps> = ({ jwtService }) => {
    const [jwt, setJwt] = useState<string>()
    const [originalUsers, setOriginalUsers] = useState<IUser[]>()
    const [users, setUsers] = useState<IUser[]>()
    const [activeUser, setActiveUser] = useState<IUser>()
    const [companies, setCompanies] = useState<ICompany[]>()
    const [registerActive, setRegisterActive] = useState<boolean>(false)
    const [nameInputField, setNameInputField] = useState<string>('')
    const [companyInputField, setCompanyInputField] = useState<string>('')

    const fetchData = useCallback((activeUser?) => {
        if (!jwt) return

        fetch(process.env.REACT_APP_API_URL + 'Users', {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${jwt}`,
            },
        })
            .then((res) => res.json())
            .then((jsonRes) => {
                setUsers(jsonRes.filter((user: IUser) => user.roleName === 'Employer'))
                setOriginalUsers(jsonRes.filter((user: IUser) => user.roleName === 'Employer'))
            })

        fetch(process.env.REACT_APP_API_URL + 'Companies', {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${jwt}`,
            },
        })
            .then((res) => res.json())
            .then((companies: ICompany[]) => {
                setCompanies(companies)
                setActiveUser(activeUser)
            })
    }, [jwt])

    useEffect(() => {
        setJwt(jwtService.getJwt() ?? undefined)
    }, [jwtService])

    useEffect(() => {
        fetchData()
    }, [jwt, fetchData])

    useEffect(() => setActiveUser(undefined), [users])

    const onUserRowClicked = (user: IUser) => {
        if (registerActive) setRegisterActive(false)

        setActiveUser(user)
    }

    useEffect(() => {
        setNameInputField(nameInputField)
        if (nameInputField === '') {
            setUsers(originalUsers)
        } else {
            //In case a name starts with a capital letter, we ignore that.
            const filteredUsers = originalUsers?.filter((p) =>
                p.firstName.toUpperCase().includes(nameInputField.toUpperCase())
            )
            if (filteredUsers && filteredUsers?.length > 0) {
                setUsers(filteredUsers)
                return
            }
            setUsers([])
        }
    }, [originalUsers, nameInputField])

    useEffect(() => {
        setCompanyInputField(companyInputField)
        if (companyInputField === '') {
            setUsers(originalUsers)
        } else {
            //In case the company name starts with a capital letter, we ignore that.
            const filteredUsers = originalUsers?.filter((user) =>
                user.companyName?.toUpperCase().includes(companyInputField.toUpperCase())
            )
            if (filteredUsers && filteredUsers?.length > 0) {
                setUsers(filteredUsers)
                return
            }
            setUsers([])
        }
    }, [originalUsers, companyInputField])

    const onRegisterCanceled = () => {
        setRegisterActive(false)
        setActiveUser(undefined)
    }

    return (
        <div className="row mt-5">
            <div className="col-5">
                <div className="row">
                    <div className="col d-flex justify-content-center">
                        <img src={UserIcon} alt="user" width="30" height="30" style={{ borderRadius: '50%', marginRight: '10px' }} />
                        <h3 style={{ fontWeight: 'bold' }}>Werkgevers ({users?.length})</h3>
                    </div>
                    <div className="col d-flex justify-content-center">
                        <AcceptButton onClick={() => setRegisterActive(true)}>
                            Gebruiker    toevoegen +
                        </AcceptButton>
                    </div>
                </div>
                <div className="row">
                    <div className="col d-flex justify-content-center">
                        <TextField
                            variant="outlined"
                            margin="normal"
                            id="firstName"
                            label="Zoek op voornaam"
                            name="firstName"
                            autoComplete="firstName"
                            value={nameInputField}
                            onChange={(e) => setNameInputField(e.target.value)}
                            autoFocus
                        />
                    </div>
                    <div className="col d-flex justify-content-center">
                        <TextField
                            variant="outlined"
                            margin="normal"
                            id="companyName"
                            label="Zoek op bedrijfsnaam"
                            name="companyName"
                            autoComplete="companyName"
                            value={companyInputField}
                            onChange={(e) => setCompanyInputField(e.target.value)}
                            autoFocus
                        />
                    </div>
                </div>

                <div className="ml-4">
                    <UserList>
                        {users &&
                            users.map((user) => (
                                <UserRow
                                    key={user.id}
                                    user={user}
                                    activeUser={activeUser}
                                    setActiveUser={onUserRowClicked}
                                    companyImage={
                                        companies?.find(
                                            (company) => company.name === user.companyName
                                        )?.image
                                    }
                                />
                            ))}
                    </UserList>
                </div>
            </div>
            <div className="col">
                {registerActive && (
                    <Register
                        onRegistered={fetchData}
                        onCanceled={onRegisterCanceled}
                        role="Employer"
                        companies={companies}
                    />
                )}
                {!registerActive && activeUser && (
                    <UserInformationForm
                        companies={companies}
                        user={activeUser}
                        jwt={jwt}
                        role="Employer"
                        onDeleted={fetchData}
                        onUpdated={() => fetchData(activeUser)}
                    />
                )}
            </div>
        </div>
    )
}
export default EmployerOverView
