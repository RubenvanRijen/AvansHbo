import React, { useCallback, useEffect, useState } from 'react'
import styled from 'styled-components'
import * as Colors from '../../../global/Colors'
import { CompanyRow } from '../../../components/CompanyRow'
import { AcceptButton } from '../../../styled/Buttons'
import { ICompany } from '../../../interfaces/ICompany'
import JwtService from '../../../services/JwtService'
import CompanyRegister from '../../Register/company-register'
import TextField from '@material-ui/core/TextField'
import UserIcon from '../../../Assets/default-profile-image.png'

const UserList = styled.div({
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',

    minHeight: '100px',
    padding: '20px 20px',
    margin: '10px 0px',

    boxShadow: 'inset 0px 2px 5px 0px rgba(50, 50, 40, 0.2)',
    backgroundColor: Colors.darkWhite,
    borderRadius: '4px',
    overflowY: 'scroll',
})

interface IEmployeeOverViewProps {
    jwtService: JwtService
}

const EmployeeOverView: React.FC<IEmployeeOverViewProps> = ({ jwtService }) => {
    const [jwt, setJwt] = useState<string>()
    const [originalCompanies, setOriginalCompanies] = useState<ICompany[]>()
    const [companies, setCompanies] = useState<ICompany[]>()
    const [activeCompany, setActiveCompany] = useState<ICompany>()
    const [registerActive, setRegisterActive] = useState<boolean>(false)
    const [nameInputField, setNameInputField] = useState<string>('')

    const fetchData = useCallback(() => {
        if (!jwt) return

        fetch(process.env.REACT_APP_API_URL + 'Companies', {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${jwt}`,
            },
        })
            .then((res) => res.json())
            .then((jsonRes) => {
                setCompanies(jsonRes)
                setOriginalCompanies(jsonRes)
            })

        fetch(process.env.REACT_APP_API_URL + 'Companies', {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${jwt}`,
            },
        })
            .then((res) => res.json())
            .then((companies: ICompany[]) => {
                setCompanies(companies)
            })
    }, [jwt])

    useEffect(() => {
        setJwt(jwtService.getJwt() ?? undefined)
    }, [jwtService])

    useEffect(() => {
        setNameInputField(nameInputField)
        if (nameInputField === '') {
            setCompanies(originalCompanies)
        } else {
            //In case a name starts with a capital letter, we ignore that.
            const filteredUsers = originalCompanies?.filter((p) =>
                p.name.toUpperCase().includes(nameInputField.toUpperCase())
            )
            if (filteredUsers && filteredUsers?.length > 0) {
                setCompanies(filteredUsers)
                return
            }
            setCompanies([])
        }
    }, [originalCompanies, nameInputField])

    useEffect(() => {
        fetchData()
    }, [jwt, fetchData])

    useEffect(() => setActiveCompany(undefined), [companies])

    const onCompanyRowClicked = (company: ICompany) => {
        if (registerActive) setRegisterActive(false);

        setActiveCompany(company)
    }

    const onRegisterCanceled = () => {
        setRegisterActive(false)
        setActiveCompany(undefined)
    }

    return (
        <div className="row mt-5">
            <div className="col-5">
                <div className="row">
                    <div className="col d-flex justify-content-center">
                        <img src={UserIcon} alt="user" width="30" height="30" style={{ borderRadius: '50%', marginRight: '10px' }} />
                        <h3 style={{ fontWeight: 'bold' }}>Organisaties ({companies?.length})</h3>
                    </div>
                    <div className="col d-flex justify-content-center">
                        <AcceptButton onClick={() => setRegisterActive(true)}>
                            Organisatie toevoegen +
                        </AcceptButton>
                    </div>
                </div>
                <div className="row">
                    <div className="col d-flex justify-content-center">
                        <TextField
                            variant="outlined"
                            margin="normal"
                            id="companyName"
                            label="Zoek op bedrijfsnaam"
                            name="companyName"
                            autoComplete="companyName"
                            value={nameInputField}
                            onChange={(e) => setNameInputField(e.target.value)}
                            autoFocus
                        />
                    </div>
                </div>
                <div className="ml-4">
                    <UserList>
                        {companies &&
                            companies.map((company) => (
                                <CompanyRow
                                    key={company.name}
                                    company={company}
                                    activeCompany={activeCompany}
                                    setActiveCompany={onCompanyRowClicked}
                                />
                            ))}
                    </UserList>
                </div>
            </div>
            <div className="col">
                {registerActive && (
                    <CompanyRegister
                        jwtService={ jwtService }
                        onRegistered={fetchData}
                        onCanceled={onRegisterCanceled}
                    />
                )}
            </div>
        </div>
    )
}
export default EmployeeOverView
