import React from 'react'
import styled from 'styled-components'
import {Road} from '../svg/Road'
import {Clock} from '../svg/Clock'
import {Alert} from '../svg/route-states/Alert'
import {IRoute} from '../interfaces/IRoute'
import * as Status from '../global/StatusNames'
import * as Colors from '../global/Colors'
import moment from 'moment'

import {ItemPlate as RouteRowPlate} from '../styled/ItemsLists'

const CompanyLogo = styled.img({
    margin: '0px 10px 0px 20px',
})

const Date = styled.h5({
    margin: '0px 15px',
    fontWeight: 'normal',
    fontSize: '13.28px',
    marginBottom: '0px',
    lineHeight: 'normal'
})

const Grid = styled.div({
    display: 'flex',
    flexDirection: 'row',
    marginLeft: '15px',
    marginRight: '10px',
})

const RouteColumn = styled.div({
    display: 'flex',
    flexDirection: 'column',
    whiteSpace: 'nowrap',
    textOverflow: 'ellipsis',
    overflow: 'hidden',
})

const Row = styled.div({
    display: 'flex',
    flexDirection: 'row',
})

const Info = styled.h5({
    margin: '0px 10px 0px 0px',
    fontWeight: 'normal',
    fontSize: '13.28px',
    marginBottom: '0px',
    lineHeight: 'normal'

})

const Total = styled.h5({
    margin: '0px 0px 0px 5px',
    fontWeight: 'normal',
    fontSize: '13.28px',
    marginBottom: '0px',
    lineHeight: 'normal'

})

const Compensation = styled.h5({
    margin: '0px 30px',
    fontWeight: 'normal',
    fontSize: '13.28px',
    marginBottom: '0px',
    lineHeight: 'normal'

})

const Arrow = styled.h5({
    position: 'absolute',
    marginLeft: '108px',
    marginTop: '16px',
    color: 'grey',
    fontSize: '13.28px',
    marginBottom: '0px',
    lineHeight: 'normal'

});

export interface IProps {
    route: IRoute
    activeRoute: IRoute | undefined
    setActiveRoute: (route: IRoute) => void
    image: string | undefined
    isEmployer: boolean
}

export const RouteRow: React.FC<IProps> = ({route, activeRoute, setActiveRoute, image, isEmployer}) => {
    const getStatusColor = () => {
        if (isEmployer) {
            switch (route.statusName) {
                case Status.PENDING_BY_EMPLOYER:
                    return Colors.orange
                case Status.APPROVED:
                    return Colors.lightGreen
                case Status.REJECTED:
                    return Colors.red
                default:
                    return Colors.black
            }
        } else {
            switch (route.statusName) {
                case Status.PENDING_BY_EMPLOYEE:
                    return Colors.orange
                case Status.PENDING_BY_EMPLOYER:
                    return Colors.darkGray
                case Status.APPROVED:
                    return Colors.lightGreen
                case Status.REJECTED:
                    return Colors.red
                default:
                    return Colors.black
            }
        }
    }

    let color: string = getStatusColor() || Colors.black

    const ActiveStyle = {
        backgroundColor: `${color}40`, // hexacode with opacity
        borderTop: `1px dashed ${color}`,
        borderRight: `1px dashed ${color}`,
        borderBottom: `1px dashed ${color}`,
        outline: 'none'
    }

    function getDate(time: string) {
        return moment(time).format('L')
    }

    function getTime(time: string) {
        return moment(time).format('HH:mm')
    }

    function dateDiff(timeFrom: string, timeTo: string) {
        let t1 = moment(timeFrom)
        let t2 = moment(timeTo)

        let differenceInMs = t2.diff(t1)
        let duration = moment.duration(differenceInMs)

        let time = `${Math.floor(duration.asHours()) || '0'}:${duration.asMinutes() % 60 || '0'}`
        return moment(time, 'HH:mm').format('HH:mm')
    }

    return (
        <Row>
            <div style={{width: '50px', height: '80px'}}>
                {color === Colors.orange && (
                    <Alert width="30px" height="30px" style={{marginTop: '25px'}}/>
                )}
            </div>
            <RouteRowPlate
                onClick={() => setActiveRoute(route)}
                style={route?.id === activeRoute?.id ? ActiveStyle : {}}
            >
                <div style={{backgroundColor: color, width: '6px', height: '70px'}}/>
                <CompanyLogo width="35px" alt="company" height="35px" src={image}/>
                <Date style={{margin: '0px 15px'}}>{getDate(route.startTime)}</Date>
                <Grid>
                    <RouteColumn style={{width: '115px'}}>
                        <Info>{route.startLocation}</Info>
                        <hr style={{
                            width: '100%', border: '0.5px solid grey',
                            marginTop: '8px',
                            marginBottom: '8px'
                        }}/>
                        <Info>{getTime(route.startTime)}</Info>
                    </RouteColumn>
                    <RouteColumn style={{width: '115px'}}>
                        <Row style={{margin: '0px 20px 0px 20px'}}>
                            <Road
                                style={{marginTop: '3px', marginBottom: '-3px'}}
                                width="15px"
                                height="15px"
                                fill="black"
                            />
                            <Total>{Math.floor(route.distance / 1000)} km</Total>
                        </Row>
                        <hr style={{
                            width: '100%',
                            border: '0.5px dashed grey',
                            marginTop: '8px',
                            marginBottom: '8px'
                        }}/>
                        <Row style={{alignItems: 'flex-end', margin: '1px 20px 0px 20px'}}>
                            <Clock
                                style={{marginTop: '1px', marginBottom: '-1px'}}
                                width="12px"
                                height="12px"
                                fill="black"
                            />
                            <Total>{dateDiff(route.startTime, route.endTime)}</Total>
                        </Row>
                    </RouteColumn>
                    <RouteColumn style={{width: '115px', position: 'relative'}}>
                        <Info>{route.endLocation}</Info>
                        <hr style={{
                            width: '100%', border: '0.5px solid grey',
                            marginTop: '8px',
                            marginBottom: '8px'
                        }}/>
                        <Info>{getTime(route.endTime)}</Info>
                        <Arrow>></Arrow>
                    </RouteColumn>
                </Grid>
                <Compensation>&euro; {route.estimatedPayment ? (route.estimatedPayment.toFixed(2)) : 0.00}</Compensation>
            </RouteRowPlate>
        </Row>
    )
}
