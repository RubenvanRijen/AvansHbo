// @ts-nocheck
import React, { useEffect, useState } from 'react'
import Button from '@material-ui/core/Button'
import CssBaseline from '@material-ui/core/CssBaseline'
import TextField from '@material-ui/core/TextField'
import Grid from '@material-ui/core/Grid'
import { green, red } from '@material-ui/core/colors'
import { createMuiTheme, makeStyles, ThemeProvider } from '@material-ui/core/styles'
import Alert from '@material-ui/lab/Alert'
import translation from '../pages/Register/Translation';
import defaultImage from '../Assets/default-profile-image.png';
import { Select, InputLabel, MenuItem, FormControl } from '@material-ui/core';
//Styling
const useStyles = makeStyles((theme) => ({
    image: {
        backgroundImage: 'url(https://i.imgur.com/bCOP3SC.jpg)',
        backgroundRepeat: 'no-repeat',
        backgroundColor:
            theme.palette.type === 'light' ? theme.palette.grey[100] : theme.palette.grey[900],
        backgroundSize: 'cover',
        backgroundPosition: 'center'
    },
    paper: {
        margin: theme.spacing(8, 4),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: '#f4f0ed',
        borderRadius: '10px'
    },
    greyPaper: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: '#d4d4d4',
        width: '100%',
        padding: '30px',
        borderRadius: '10px'
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main
    },
    form: {
        width: '50%',
        marginTop: theme.spacing(1)
    },
    submit: {
        margin: theme.spacing(3, 0, 2)
    }
}))


const theme = createMuiTheme({
    palette: {
        primary: red,
        secondary: green
    }
})


const errorTranslation: Object = translation

interface IUserInformationFormProps {
    user: IUser | undefined
    jwt: string | undefined
    role: string | undefined
    onDeleted: () => void
    companies?: ICompany[]
    onUpdated?: () => void
}

const UserInformationForm: React.FC<IUserInformationFormProps> = ({ companies, user, jwt, role, onDeleted, onUpdated }) => {

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault()

        fetch(process.env.REACT_APP_API_URL+`Users/${user.id}`, {
            method: 'PUT',
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${jwt}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                firstName: firstName,
                lastName: lastName,
                email: email,
                accountNumber: accountNumber,
                companyName: companyName !== 'geen' ? companyName : null
            })
        })
            .then((response) => response.json())
            .then((responseJson) => {
                if (responseJson.status === 400) {
                    let errorMessages: Object = {}
                    for (let key in responseJson.errors) {
                        for (let i = 0; i < responseJson.errors[key].length; i++) {
                            if (errorTranslation.hasOwnProperty(key)) {
                                errorMessages[key] = Object.values(errorTranslation[key])
                            }
                        }
                    }
                    setError(errorMessages)
                } else {
                    setSuccess('true')
                    if (onUpdated) onUpdated();
                }
            })
    }

    const deleteUser = () => {
        fetch(process.env.REACT_APP_API_URL+`Users/${user.id}`, {
            method: 'DELETE',
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${jwt}`,
                'Content-Type': 'application/json'
            }
        }).then(response => {
            if (response.status === 204) setDeleted(true);
            onDeleted();
        })
    }


    //set states for all fields
    const [success, setSuccess] = useState(false)
    const [deleted, setDeleted] = useState(false);
    const [error, setError] = useState<Object>('')
    const [firstName, setFirstName] = useState(user.firstName)
    const [lastName, setLastName] = useState(user.lastName)
    const [email, setEmail] = useState(user.email)
    const [accountNumber, setAccountNumber] = useState(user.accountNumber)
    const [companyName, setCompanyName] = useState<string>(user.companyName ?? 'geen');

    useEffect(() => {
        setFirstName(user.firstName);
        setLastName(user.lastName);
        setEmail(user.email);
        setAccountNumber(user.accountNumber);
        setCompanyName(user.companyName ?? 'geen');
    }, [user]);

    const classes = useStyles()
    return (
        <Grid container component="main">
            <CssBaseline />
            <div className={classes.paper} style={{maxWidth: "600px"}}>
                <div className={classes.greyPaper}>
                    <h1>{user.firstName}&nbsp;{user.lastName}</h1>
                    <h2>{email}</h2>
                    <img src={user.image ? user.image : defaultImage} alt="" width="100" height="100" style={{ borderRadius: '50%' }} />
                </div>

                {success === 'true' ? (
                    <Alert severity="success">Gebruiker is aangepast</Alert>
                ) : null}
                {deleted === 'true' ? (
                    <Alert severity="success">Gebruiker is verwijderd</Alert>
                ) : null}

                <form className={classes.form} onSubmit={handleSubmit}>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="firstName"
                        label="Voornaam"
                        name="firstName"
                        autoComplete="firstName"
                        value={firstName}
                        onChange={(e) => {
                            setFirstName(e.target.value);
                            const { FirstName, ...rest } = error;
                            setError(rest);
                        }}
                        autoFocus
                    />
                    {error.FirstName ? <Alert severity="error">{error.FirstName}</Alert> : null}

                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="lastName"
                        label="Achternaam"
                        name="lastName"
                        autoComplete="lastName"
                        value={lastName}
                        onChange={(e) => {
                            setLastName(e.target.value);
                            const { LastName, ...rest } = error;
                            setError(rest);
                        }}
                        autoFocus
                    />
                    {error.LastName ? <Alert severity="error">{error.LastName}</Alert> : null}

                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="email"
                        label="Email adres"
                        name="email"
                        autoComplete="email"
                        value={email}
                        onChange={(e) => {
                            setEmail(e.target.value);
                            const { Email, ...rest } = error
                            setError(rest)
                        }}
                        autoFocus
                    />
                    {error.Email ? <Alert severity="error">{error.Email}</Alert> : null}

                    {role === 'Employee' &&
                        (<TextField
                            variant="outlined"
                            margin="normal"
                            required
                            fullWidth
                            id="accountNumber"
                            label="Bankrekeningnummer"
                            name="accountNumber"
                            autoComplete="accountNumber"
                            value={accountNumber}
                            onChange={(e) => {
                                setAccountNumber(e.target.value);
                                const { AccountNumber, ...rest } = error
                                setError(rest)
                            }}
                            autoFocus
                        />)
                    }
                    {error.AccountNumber ? (
                        <Alert severity="error">{error.AccountNumber}</Alert>
                    ) : null}

                    {role === 'Employer' &&
                        (
                            <FormControl variant="outlined" className="MuiFormControl-fullWidth MuiFormControl-marginNormal">
                                <InputLabel htmlFor="copmany">Bedrijf</InputLabel>
                                <Select value={companyName} width="100%" onChange={e => setCompanyName(e.target.value)} inputProps={{ id: 'company' }} label="Bedrijf">
                                    <MenuItem value="geen">Geen</MenuItem>
                                    {companies && companies.map(company =>
                                        <MenuItem key={company.name} value={company.name}><img style={{marginRight: "10px"}} src={company.image} alt="" height="25px" width="25px"></img>{company.name}&nbsp;</MenuItem>
                                    )}
                                </Select>
                            </FormControl>
                        )
                    }

                    <ThemeProvider theme={theme}>
                        <div className="row">
                            <div className="col">
                                <Button
                                    type="button"
                                    fullWidth
                                    variant="contained"
                                    color="primary"
                                    className={classes.submit}
                                    onClick={deleteUser}
                                >
                                    Verwijderen
                                </Button>
                            </div>
                            <div className="col">
                                <Button
                                    type="submit"
                                    fullWidth
                                    variant="contained"
                                    color="secondary"
                                    className={classes.submit}
                                >
                                    Wijzigen
                                </Button>
                            </div>
                        </div>
                    </ThemeProvider>
                </form>
            </div>
        </Grid >
    )
}
export default UserInformationForm;
