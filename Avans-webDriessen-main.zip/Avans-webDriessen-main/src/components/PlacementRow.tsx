import React, { useState, useEffect } from 'react'
import styled from 'styled-components'
import Switch from '@material-ui/core/Switch'

import { ItemPlate as RouteRowPlate } from '../styled/ItemsLists'
import { IUser } from '../interfaces/IUser'
import IPlacement from '../interfaces/IPlacement';
import defaultImage from '../Assets/company.png';

const UserLogo = styled.img({
    margin: '0px 10px 0px 20px'
})

const UserName = styled.h5({
    margin: '0px 15px',
    fontWeight: 'normal',
    fontSize: '18px',
    marginBottom: '0px',
    lineHeight: 'normal'
})

const Row = styled.div({
    display: 'flex',
    flexDirection: 'row'
})

export interface IProps {
    placement: IPlacement
    jwt: string
    user: IUser
    companyName: string
}

const PlacementRow: React.FC<IProps> = ({ user, placement, jwt, companyName }) => {
    const placements = placement.userPlacements?.find(p => p.placementId === placement.id && p.userId === user.id);
    const [checkState, setCheckState] = useState(!!placements);
    const [userPlacementId, setUserPlacementId] = useState<string | undefined>(placement.userPlacements?.find(p => p.placementId === placement.id && p.userId === user.id)?.id);
    const [companyImage, setCompanyImage] = useState<string>();

    useEffect(() => {
        fetch(`https://apidriessendev.azurewebsites.net/api/Companies/${companyName}`, {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${jwt}`
            }
        })
            .then(response => response.json())
            .then(jsonResponse => {
                setCompanyImage(jsonResponse.image);
            });
    }, [jwt, companyName]);

    const handleCheckState = () => {
        if (checkState) {
            if (userPlacementId) {
                fetch(`https://apidriessendev.azurewebsites.net/api/UserPlacements/${userPlacementId}`, {
                    method: 'DELETE',
                    headers: {
                        Accept: 'application/json',
                        Authorization: `Bearer ${jwt}`,
                        'Content-Type': 'application/json'
                    }
                }).then(response => {
                    if (response.status === 204) {
                        setCheckState(false);
                        return;
                    }
                });
            }
        } else {
            fetch('https://apidriessendev.azurewebsites.net/api/UserPlacements', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    Authorization: `Bearer ${jwt}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    userId: user.id,
                    placementId: placement.id
                })
            }).then(response => {
                if (response.status === 201) {
                    setCheckState(true);
                    return response.json();
                }
            }).then(userPlacement => {
                if (userPlacement) setUserPlacementId(userPlacement.id);
            })
        }
    }

    return (
        <Row>
            <RouteRowPlate>
                <div className="col flex-grow-0">
                    <UserLogo width="35px" alt="company" height="35px" src={companyImage ?? defaultImage} style={{ borderRadius: '50%' }} />
                </div>
                <div className="col flex-grow-0">
                    <UserName style={{ margin: '0px 15px 0px', textAlign: 'left' }}>{placement.name}</UserName>
                </div>

                <div className="col" />

                <div className="col flex-grow-0">
                    <Switch checked={checkState} onChange={handleCheckState} />
                </div>

            </RouteRowPlate>
        </Row>
    )
}
export default PlacementRow;
