import React from 'react'
import styled from 'styled-components'
import defaultImage from '../Assets/default-profile-image.png';
import { ItemPlate as RouteRowPlate } from '../styled/ItemsLists'
import { ICompany } from '../interfaces/ICompany';

const UserLogo = styled.img({
    margin: '0px 10px 0px 20px'
})

const UserName = styled.h5({
    margin: '0px 15px',
    fontWeight: 'normal',
    fontSize: '18px',
    marginBottom: '0px',
    lineHeight: 'normal'
})

const Row = styled.div({
    display: 'flex',
    flexDirection: 'row'
})

export interface IProps {
    company: ICompany
    activeCompany: ICompany | undefined
    setActiveCompany: (company: ICompany) => void
}

export const CompanyRow: React.FC<IProps> = ({ company, activeCompany, setActiveCompany }) => {
    const ActiveStyle = {
        backgroundColor: `#FFFFFF40`, // hexcode with opacity
        borderTop: `1px dashed black`,
        borderRight: `1px dashed black`,
        borderBottom: `1px dashed black`,
        outline: 'none'
    }

    return (
        <Row>
            <RouteRowPlate
                onClick={() => setActiveCompany(company)}
                style={company?.name === activeCompany?.name ? ActiveStyle : {}}
            >
                <div className="col flex-grow-0">
                    <UserLogo width="35px" alt="company" height="35px" src={company.image ? company.image : defaultImage} style={{ borderRadius: '50%' }} />
                </div>
                <div className="col flex-grow-0">
                    <UserName style={{ margin: '0px 15px 0px', textAlign: 'left' }}>{company.name}</UserName>
                </div>

                <div className="col" />
            </RouteRowPlate>
        </Row>
    )
}
