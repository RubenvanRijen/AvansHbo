// NOTE: De totaal container staat OnHold, deze wordt mogelijk later afgemaakt
import React, {useState} from 'react';
import styled from 'styled-components';

import {IAddress} from '../interfaces/IAddress'
import {ICompany} from '../interfaces/ICompany';

import {Container as PanelColumnsContainer} from '../styled/Containers'
import {ItemsContainer, ItemsContainerSkeleton} from '../styled/ItemsLists';
import {AcceptButton, CancelButton} from '../styled/Buttons';
import {Select, Option} from '../styled/Dropdown';
import * as Colors from '../global/Colors';

import {Home} from '../svg/Home';
import {Marker} from '../svg/Marker';

//#region styled`
const Panel = styled.div({
    backgroundColor: Colors.gray,
    height: "94%",
    width: "94%",
    padding: '20px',
    borderRadius: '5px',
    boxShadow: `inset 0 2.8px 2.2px rgba(0, 0, 0, 0.014), 
              inset 0 6.7px 5.3px rgba(0, 0, 0, 0.028)`
});

const PanelColumn = styled.div({
    width: "33%"
})

const FormLabel = styled.label({
    width: "100%",
    margin: "6px 4px",
    '*': {
        width: "100%"
    }
})

const PanelText = styled.div({
    color: "#666",
    fontSize: "1.1em",
    fontWeight: 600
})

const Footer = styled.div({
    display: "flex",
    margin: "20px 0px",
    justifyContent: "flex-end",
    '*': {
        margin: "5px"
    }
})
//#endregion

//#region Interface types
type IInputs = {
    from: IAddress,
    to: IAddress,
    companyName: string,
    type: string
}

type IProps = {
    setIsAddPanelActive: (isAddPanelActive: Boolean) => void;
    addRoute: (from: IAddress, to: IAddress, companyName: string, type: string) => void;
    companies: Array<ICompany> | undefined;
}
//#endregion

const RoutesAddPanel: React.FC<IProps> = ({setIsAddPanelActive, addRoute, companies}) => {

    const [inputs, setInputs] = useState<IInputs>({
        from: {zipcode: "", houseNumber: 0, date: "", time: ""},
        to: {zipcode: "", houseNumber: 0, date: "", time: ""},
        companyName: companies?.[0]?.name || "Invalid",
        type: 'WORK'
    });

    //#region function
    const handleSubmit = async () =>
        addRoute(inputs.from, inputs.to, inputs.companyName, inputs.type);
    //#endregion

    return (
        <Panel>
            <form>
                <PanelText>Gereden route toevoegen</PanelText>
                <PanelColumnsContainer>
                    {/* Van */}
                    <PanelColumn style={{flexBasis: "55%"}}>
                        <ItemsContainer>
                            <PanelSubForm from={true} inputs={inputs} setInputs={setInputs}
                                          companies={companies}/>
                        </ItemsContainer>
                    </PanelColumn>

                    {/*  Totaal */}
                    <PanelColumn>
                        <ItemsContainerSkeleton>
                        </ItemsContainerSkeleton>
                    </PanelColumn>

                    {/* Naar */}
                    <PanelColumn style={{flexBasis: "55%"}}>
                        <ItemsContainer>
                            <PanelSubForm from={false} inputs={inputs} setInputs={setInputs}
                                          companies={companies}/>
                        </ItemsContainer>
                    </PanelColumn>

                </PanelColumnsContainer>
            </form>

            <Footer>
                <CancelButton onClick={() => setIsAddPanelActive(false)}>Annuleren</CancelButton>
                <AcceptButton onClick={() => handleSubmit()}>Toevoegen</AcceptButton>
            </Footer>
        </Panel>
    );
}

//#region sub components
interface ISubProps {
    from: boolean;
    inputs: IInputs;
    setInputs: (input: IInputs) => void;
    companies: Array<ICompany> | undefined;
}

const PanelSubForm: React.FC<ISubProps> = ({from, inputs, setInputs, companies}) => {

    const header = from ? "Van" : "Naar",
        icon = from ? <Home style={{width: "90%", height: "90%"}}/> : <Marker style={{width: "90%", height: "90%"}}/>,
        prefix = from ? "from" : "to"

    const handleCompanyChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        event.persist();
        const companyName = event?.target?.value;
        if (companyName !== null)
            setInputs({...inputs, companyName});
    }

    const handleTypeChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        event.persist();
        const type = event?.target?.value;
        if (type !== null)
            setInputs({...inputs, type});
    }

    const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        event.persist();
        const value = event?.target?.value || "";
        const newInput = event?.target?.name?.dotToKeyValue(value) || {from: {}, to: {}};

        const from = {...inputs.from, ...newInput.from}
        const to = {...inputs.to, ...newInput.to}

        setInputs({...inputs, from, to});
    }

    return (<>
        <p>{header}</p>
        <hr style={{margin: 0, width: '100%'}}/>

        <p>{icon}</p>

        <FormLabel>Postcode
            <input type="text" onChange={handleInputChange} name={prefix + ".zipcode"} pattern="[1-9][0-9]{3} ?[A-Z]{2}"
                   value={inputs[prefix]['zipcode']}/>
        </FormLabel>

        <FormLabel>Huisnummer
            <input type="number" onChange={handleInputChange} name={prefix + ".houseNumber"}
                   value={inputs[prefix]['houseNumber']}/>
        </FormLabel>

        <hr style={{width: '100%'}}/>

        <FormLabel>Datum
            <input type="date" onChange={handleInputChange} name={prefix + ".date"} value={inputs[prefix]['date']}/>
        </FormLabel>

        <FormLabel>Tijd
            <input type="time" onChange={handleInputChange} name={prefix + ".time"} value={inputs[prefix]['time']}/>
        </FormLabel>

        <hr style={{width: '100%'}}/>

        {!from ||
        <FormLabel>Type
            <Select style={{margin: "4px 0px"}} value={inputs.type} onChange={handleTypeChange} id="routeType"
                    name="routeType">
                <Option key={'WORK'} value={'WORK'}>{'Dienstreizen'}</Option>
                <Option key={'HOME_TO_WORK'} value={'HOME_TO_WORK'}>{'Woon- werkverkeer'}</Option>
            </Select>
        </FormLabel>
        }

        {from ||
        <FormLabel>Bedrijf
            <Select style={{margin: "4px 0px"}} value={inputs.companyName} onChange={handleCompanyChange}
                    id="companyName" name="companyName">
                {
                    companies?.map(company => (<Option key={company.name} value={company.name}>{company.name}</Option>))
                }
            </Select>
        </FormLabel>
        }
    </>)
}
//#endregion

export default RoutesAddPanel;
