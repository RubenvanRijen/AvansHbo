// @ts-nocheck
import React, { useState, useEffect } from 'react'
import CssBaseline from '@material-ui/core/CssBaseline'
import Grid from '@material-ui/core/Grid'
import { makeStyles } from '@material-ui/core/styles'
import PlacementRow from './PlacementRow'
import TextField from '@material-ui/core/TextField'
import userImage from '../Assets/default-profile-image.png';



//Styling
const useStyles = makeStyles((theme) => ({
    image: {
        backgroundImage: 'url(https://i.imgur.com/bCOP3SC.jpg)',
        backgroundRepeat: 'no-repeat',
        backgroundColor:
            theme.palette.type === 'light' ? theme.palette.grey[100] : theme.palette.grey[900],
        backgroundSize: 'cover',
        backgroundPosition: 'center',
    },
    paper: {
        margin: theme.spacing(8, 4),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: '#f4f0ed'
    },
    greyPaper: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: '#d4d4d4',
        padding: '30px',
        width: '100%'
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        marginTop: theme.spacing(1),
    },
    bottomPart: {
        width: '97%',
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
}))

export interface IProps {
    user: IUser
    jwt: string | undefined
}

const PlacementPanel: React.FC<IProps> = ({ user, jwt }) => {

    const [placements, setPlacements] = useState<IPlacement[]>([]);
    const [filteredPlacements, setFilteredPlacements] = useState<IPlacement[]>([]);
    const [companyInputField, setCompanyInputField] = useState<string>('');
    const [placementInputField, setPlacementInputField] = useState<string>('');

    useEffect(() => {
        setCompanyInputField(companyInputField)
        if (companyInputField === '') {
            setFilteredPlacements(placements)
        } else {
            //In case a name starts with a capital letter, we ignore that.
            const filteredCompanies = placements?.filter((p) =>
                p.companyName?.toUpperCase().includes(companyInputField.toUpperCase())
            )
            if (filteredCompanies && filteredCompanies?.length > 0) {
                setFilteredPlacements(filteredCompanies)
                return
            }
            setFilteredPlacements([])
        }
    }, [placements, companyInputField])

    useEffect(() => {
        setPlacementInputField(placementInputField)
        if (placementInputField === '') {
            setFilteredPlacements(placements)
        } else {
            //In case the company name starts with a capital letter, we ignore that.
            const filteredPlacements = placements?.filter((p) =>
                p.name?.toUpperCase().includes(placementInputField.toUpperCase())
            )
            if (filteredPlacements && filteredPlacements?.length > 0) {
                setFilteredPlacements(filteredPlacements)
                return
            }
            setFilteredPlacements([])
        }
    }, [placements, placementInputField])


    useEffect(() => {
        fetch('https://apidriessendev.azurewebsites.net/api/Placements', {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${jwt}`
            }
        })
            .then(response => response.json())
            .then(jsonResponse => {
                setPlacements(jsonResponse);
            });
    }, [jwt]);

    const classes = useStyles()
    return (
        <Grid container component="main">
            <CssBaseline />
            <div className={classes.paper}>
                <div className={classes.greyPaper}>
                    <h1>{user.firstName}&nbsp;{user.lastName}</h1>
                    <h2>{user.email}</h2>
                    <img src={user.image ?? userImage} alt="userimage" width="100" height="100" style={{ borderRadius: '50%' }} />
                </div>

                <div className={classes.bottomPart}>
                    <div className="row">
                        <div className="col d-flex justify-content-center">
                            <TextField
                                variant="outlined"
                                margin="normal"
                                id="company"
                                label="Zoek op bedrijf"
                                name="company"
                                autoComplete="company"
                                value={companyInputField}
                                onChange={(e) => setCompanyInputField(e.target.value)}
                                autoFocus
                            />
                        </div>
                        <div className="col d-flex justify-content-center">
                            <TextField
                                variant="outlined"
                                margin="normal"
                                id="placement"
                                label="Zoek op plaatsing"
                                name="placement"
                                autoComplete="placement"
                                value={placementInputField}
                                onChange={(e) => setPlacementInputField(e.target.value)}
                                autoFocus
                            />
                        </div>
                    </div>
                    {filteredPlacements && filteredPlacements.map(placement => (
                        <PlacementRow key={placement.id} user={user} placement={placement} jwt={jwt} companyName={placement.companyName} />
                    ))}
                </div>
            </div>
        </Grid>
    )
}
export default PlacementPanel;
