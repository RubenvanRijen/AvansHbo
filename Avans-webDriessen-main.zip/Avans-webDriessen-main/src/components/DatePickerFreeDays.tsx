// @ts-nocheck
import React, {useEffect, useState} from "react";
import 'react-modern-calendar-datepicker/lib/DatePicker.css';
import {Calendar} from "react-modern-calendar-datepicker";
import {Row} from 'react-bootstrap';
import '../styled/DatePickerFreeDays.css'
import {confirmAlert} from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css' // Import css
import Alert from '@material-ui/lab/Alert'
import moment from "moment";
import {IJwtPayload} from "../interfaces/IJwtPayload";
import JwtService from "../services/JwtService";

moment().locale('nl');

const year = new Date().getFullYear();
const month = new Date().getMonth() + 1;
const day = new Date().getDate()

interface jwtProps {
    jwtService: JwtService;
}

const DatePickerFreeDays: React.FC<jwtProps> = ({jwtService}) => {

    const [jwt, setJwt] = useState<string>();
    const [jwtPayload, setJwtPayload] = useState<IJwtPayload>();

    useEffect(() => {
        setJwt(jwtService.getJwt() ?? undefined);
        setJwtPayload(jwtService.getJwtPayload() ?? undefined);
    }, [jwtService]);

    const [errors, setErrors] = useState(true);

    function badRequest() {
        confirmAlert({
            title: 'Error',
            message: 'De vakantie kon niet worden opgeslagen',
            buttons: [
                {
                    label: 'Okay',
                }

            ]
        });
    }

    const defaultFrom = {
        year: year,
        month: month,
        day: day,
    };
    const defaultTo = {
        year: year,
        month: month,
        day: day,
    };
    const defaultValue = {
        from: defaultFrom,
        to: defaultTo,
    };

    const [selectedDayRange, setSelectedDayRange] = useState(
        defaultValue
    );

    async function saveDate(dates: any) {
        if (!jwt || !jwtPayload) {
            badRequest();
            return;
        }
        if (!dates.from) {
            dates.from = dates.to;
        } else if (!dates.to) {
            dates.to = dates.from;
        }
        const FromDate = new Date(dates.from.year, dates.from.month - 1, dates.from.day + 1);
        const ToDate = new Date(dates.to.year, dates.to.month - 1, dates.to.day + 1);

        await fetch(process.env.REACT_APP_API_URL +'Holidays/CompanyHolidays', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                Authorization: `Bearer ${jwt}`,

            },
            body: JSON.stringify({
                companyName: jwtPayload?.company,
                startDate: moment(FromDate).format(),
                endDate: moment(ToDate).format()
            })
        })
            .then(response => response.json()
            )
            .then(responseJson => {
                if (responseJson.status) {
                    setErrors(true);
                    badRequest();
                } else {
                    setErrors(false);
                }
            });
        setSelectedDayRange(defaultValue);
    }

    return (
        <div>
            {!errors ? (
                <Alert severity="success">Vakantie is succesvol geregistreerd</Alert>
            ) : null}
            <Calendar
                value={selectedDayRange}
                onChange={setSelectedDayRange}
                colorPrimary="#FF0000"
                colorPrimaryLight="rgba(255,0,0, 0.4)"
                shouldHighlightWeekends
                calendarClassName="responsive-calendar"
                renderFooter={() => (
                    <div className="CalendarButtons" style={{}}>
                        <Row>
                            <button onClick={() => {
                                setSelectedDayRange(defaultValue)
                            }} className="bootstrapButton btn-outline-danger m-3 pr-3 pl-3 resetCalendarButton">
                                Reset
                            </button>
                            <button onClick={() => {
                                saveDate(selectedDayRange)
                            }} className="bootstrapButton btn-outline-success m-3 pr-3 pl-3 saveCalendarButton">
                                Save
                            </button>
                        </Row>
                    </div>
                )}
            />
        </div>
    );
};

export default DatePickerFreeDays;
