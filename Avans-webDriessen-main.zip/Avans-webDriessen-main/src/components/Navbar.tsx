import React, { useEffect, useState } from 'react'
import '../styled/NavBar.css'
import { Navbar, Nav } from 'react-bootstrap'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import JwtService from '../services/JwtService'
import defaultIcon from '../Assets/default-profile-image.png'
import { IJwtPayload } from '../interfaces/IJwtPayload'
import { INavDropdown } from '../interfaces/INavLayout'
import { getNavLayoutCurrentUser } from '../navigations/NavLayouts'

interface jwtProps {
    jwtService: JwtService
}

const Navbars: React.FC<jwtProps> = ({ jwtService }) => {
    const [jwt, setJwt] = useState<string>()
    const [jwtPayload, setJwtPayload] = useState<IJwtPayload>()
    const [user, setUser]: any = useState()
    //const [actions, setActions]: any = useState(1);

    useEffect(() => {
        setJwt(jwtService.getJwt() ?? undefined)
        setJwtPayload(jwtService.getJwtPayload() ?? undefined)
    }, [jwtService])

    useEffect(() => {
        if (user === undefined || user === null) {
            if (!jwt || !jwtPayload) return

            const url = process.env.REACT_APP_API_URL+`Users/${jwtPayload?.sub}`
            fetch(url, {
                method: 'GET',
                headers: {
                    Accept: 'application/json',
                    Authorization: `Bearer ${jwt}`,
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                },
            })
                .then((response) => response.json())
                .then((responseJson) => {
                    if (responseJson.status === 404) {
                        return
                    } else {
                        if (responseJson.image == null) responseJson.image = defaultIcon
                        setUser(responseJson)
                        //setActions(2)
                    }
                })
                .catch((err) => {
                    console.log(err)
                })
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [jwt, jwtService, jwtPayload])

    function getDropdownMenu(dropdowns: Array<INavDropdown>) {
        return (
            <div className="dropdown-menu m-0" aria-labelledby="dropdownMenuButton">
                {dropdowns.map((dropdown, i) => (
                    <button
                        key={i}
                        className="dropdown-item"
                        onClick={(e) => onNavClick(dropdown.href)}
                    >
                        <FontAwesomeIcon icon={dropdown.icon} className="mr-3" />
                        {dropdown.name}
                    </button>
                ))}{' '}
            </div>
        )
    }

    function onNavClick(href: Function | string) {
        typeof href === 'string' ? (window.location.href = href) : href()
    }

    return (
        <Navbar className="customNavbar py-0" variant="dark" expand="lg">
            <Navbar.Brand className="text-white" href={getNavLayoutCurrentUser()?.home || '/login'}>
                <img className="brandLogo" src="/driessenLogoTekst2.png" alt="Driessen" />
            </Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="mr-auto">
                    {(getNavLayoutCurrentUser()?.menu || []).map((menu, i) => (
                        <Nav.Link key={i} href={menu.href}>
                            {menu.name}
                        </Nav.Link>
                    ))}
                </Nav>

                <div className="profile-box text-right">
                    <div className="dropdown">
                        <button
                            className="btn menuButton"
                            type="button"
                            id="dropdownMenuButton"
                            data-toggle="dropdown"
                            aria-haspopup="true"
                            aria-expanded="false"
                        >
                            <div className="row flex-wrap text-white">
                                <div className="col-md-auto">
                                    <div className="profile-text text-right">
                                        <p>
                                            {user?.firstName} {user?.lastName}
                                        </p>
                                        <p className="text-white">{user?.companyName}</p>
                                    </div>
                                </div>
                                <div className="col text-right justify-content-center mt-1 mb-1">
                                    <img
                                        className="rounded-circle profilePicture"
                                        src={user?.image ? user?.image : defaultIcon}
                                        alt="Profiel"
                                    />
                                </div>
                            </div>
                        </button>
                        {getDropdownMenu(getNavLayoutCurrentUser()?.dropdown || [])}
                    </div>
                </div>
            </Navbar.Collapse>
        </Navbar>
    )
}

export default Navbars
