import React, {useEffect, useState} from "react";
import {} from 'react-bootstrap';
import '../styled/OverViewFreeDays.css'
import 'moment/locale/nl';
import JwtService from "../services/JwtService";
import {IJwtPayload} from "../interfaces/IJwtPayload";
import Alert from "@material-ui/lab/Alert";
import {IFreeDays} from "../interfaces/IFreeDays";
import { DeleteButton } from '../styled/Buttons';

const moment = require('moment');
moment().locale('nl')

interface jwtProps {
    jwtService: JwtService;
}

const OverViewFreeDays: React.FC<jwtProps> = ({jwtService}) => {

    const [jwt, setJwt] = useState<string>()
    const [jwtPayload, setJwtPayload] = useState<IJwtPayload>()
    const columnHeader = ["Start datum", "Eind datum", "Bedrijfsnaam", "Acties"];
    const [errors, setErrors] = useState(true);
    const [freeDays, setFreeDays] = useState<IFreeDays[]>();
    const [amountDeleted, setAmountDeleted] = useState(0);

    useEffect(() => {
        setJwt(jwtService.getJwt() ?? undefined);
        setJwtPayload(jwtService.getJwtPayload() ?? undefined);
        let count = amountDeleted + 1;
        setAmountDeleted(count);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [jwtService]);


    function generateHeader() {
        let res = [];
        for (let i = 0; i < columnHeader.length; i++) {
            res.push(<th key={columnHeader[i]}>{columnHeader[i]}</th>)
        }
        return res;
    }


    function generateTableData() {
        let res = [];
        if (freeDays !== undefined) {
            for (let i = 0; i < freeDays.length; i++) {
                res.push(
                    <tr key={"BodyTR" + i}>
                        <td key={(freeDays[i].date)}>{moment(freeDays[i].startDate).format('LL')}</td>
                        <td key={i}>{moment(freeDays[i].endDate).format('LL')}</td>
                        <td key={freeDays[i].companyName}>{freeDays[i].companyName}</td>
                        <td key={freeDays[i].id}>
                            <DeleteButton onClick={() => deleteDay(freeDays[i].id)}
                                >Verwijderen
                            </DeleteButton>
                        </td>
                    </tr>
                )
            }
        }
        return res;
    }

    async function deleteDay(guid: string) {
        if (!jwt || !jwtPayload) return;

        const url = process.env.REACT_APP_API_URL+"Holidays/CompanyHolidays/" + guid;
        await fetch(url, {
            method: 'DELETE',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                Authorization: `Bearer ${jwt}`,

            }
        }).catch((err) => {
            setErrors(true);

            return;
        });
        let count = amountDeleted + 1;
        setAmountDeleted(count);
        setErrors(false);
    }

    useEffect(() => {
        if (!jwt || !jwtPayload) return;
        if (!jwtPayload?.company) return;
        const url = process.env.REACT_APP_API_URL+`Holidays/CompanyHolidays/${jwtPayload?.company}/Companies`;
        fetch(
            url,
            {
                method: 'GET',
                headers: {
                    Accept: 'application/json',
                    Authorization: `Bearer ${jwt}`,
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                }
            }
        )
            .then((response) => response.json())
            .then((responseJson) => {
                if (responseJson.status === 404) {
                    setErrors(true);
                } else {
                    setFreeDays(responseJson);
                    return;
                }
            })
            .catch((err) => {
                console.log(err)
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [amountDeleted]);

    return (
        <div className="freeDaysTable">
            {!errors ? (
                <Alert severity="success">Vakantie is succesvol verwijderd</Alert>
            ) : null}
            <table key="Table" className="table  table-hover table-striped">
                <thead key="Head">
                <tr key="HeadTR">
                    {generateHeader()}
                </tr>
                </thead>
                <tbody key="Body">
                {generateTableData()}
                </tbody>
            </table>
        </div>
    );
};

export default OverViewFreeDays;
