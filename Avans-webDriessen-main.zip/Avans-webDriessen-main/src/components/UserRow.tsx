import React from 'react'
import styled from 'styled-components'
import defaultImage from '../Assets/default-profile-image.png';
import { ItemPlate as RouteRowPlate } from '../styled/ItemsLists'
import { IUser } from '../interfaces/IUser'
import { CancelButton } from '../styled/Buttons';

const UserLogo = styled.img({
    margin: '0px 10px 0px 20px'
})

const UserName = styled.h5({
    margin: '0px 15px',
    fontWeight: 'normal',
    fontSize: '18px',
    marginBottom: '0px',
    lineHeight: 'normal'
})

const Row = styled.div({
    display: 'flex',
    flexDirection: 'row'
})

export interface IProps {
    user: IUser
    activeUser: IUser | undefined
    setActiveUser: (user: IUser) => void
    companyImage: string | undefined
    onOptionsClicked?: (user: IUser) => void
}

export const UserRow: React.FC<IProps> = ({ user, activeUser, setActiveUser, companyImage, onOptionsClicked }) => {
    const ActiveStyle = {
        backgroundColor: `#FFFFFF40`, // hexacode with opacity
        borderTop: `1px dashed black`,
        borderRight: `1px dashed black`,
        borderBottom: `1px dashed black`,
        outline: 'none'
    }

    return (
        <Row>
            <RouteRowPlate
                onClick={() => setActiveUser(user)}
                style={user?.id === activeUser?.id ? ActiveStyle : {}}
            >
                <div className="col flex-grow-0">
                    <UserLogo width="35px" alt="company" height="35px" src={user.image ? user.image : defaultImage} style={{ borderRadius: '50%' }} />
                </div>
                <div className="col flex-grow-0">
                    <UserName style={{ margin: '0px 15px 0px', textAlign: 'left' }}>{user.firstName}&nbsp;{user.lastName}</UserName>
                </div>

                <div className="col" />

                <div className="col flex-grow-0">
                    {companyImage &&
                        <UserLogo width="35px" alt="company" height="35px" src={companyImage} />
                    }
                </div>
                {onOptionsClicked && (
                    <div className="col flex-grow-0">
                        <CancelButton onClick={() => onOptionsClicked(user)}>Plaatsingen</CancelButton>
                    </div>
                )}

            </RouteRowPlate>
        </Row>
    )
}
