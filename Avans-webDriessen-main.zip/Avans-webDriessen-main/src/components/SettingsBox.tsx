import '../styled/SettingsBoxes.css'
import React, {useEffect, useState} from 'react';
import {Card, ListGroup, Form, Row, Col} from 'react-bootstrap';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome'
import Alert from '@material-ui/lab/Alert'
import JwtService from "../services/JwtService";
import {IJwtPayload} from "../interfaces/IJwtPayload";
import {AcceptButton, CancelButton, RedButton} from '../styled/Buttons'

interface jwtProps {
    value: string;
    onChange: (newValue: string) => Promise<void>;
    jwtService: JwtService;
}

const SettingsBox: React.FC<jwtProps> = ({jwtService, value, onChange}) => {
    const [price, setPrice] = useState(0.0000);
    const [kilometers, setKilometers] = useState(0.00);
    const [oldPrice, setOldPrice] = useState(0.00);
    const [oldKilometers, setOldKilometers] = useState(0.00);
    const [errors, setErrors] = useState(true);
    const [compnayAllowances, setCompanyAllowances]: any[] = useState([]);
    const [jwt, setJwt] = useState<string>()
    const [jwtPayload, setJwtPayload] = useState<IJwtPayload>();
    const [chosenAllowance, setChosenAllowance]: any = useState();

    useEffect(() => {
        setJwt(jwtService.getJwt() ?? undefined);
        setJwtPayload(jwtService.getJwtPayload() ?? undefined);
    }, [jwtService]);

    function handleChange(event: any) {
        onChange(event);
    }


    async function getAllKilometerAllowances() {
        if (!jwt || !jwtPayload) return;
        let allowances: any[] = [];
        let values: any[] = [];
        const url = process.env.REACT_APP_API_URL + `KilometerAllowances`;
        await fetch(
            url,
            {
                method: 'GET',
                headers: {
                    Accept: 'application/json',
                    Authorization: `Bearer ${jwt}`,
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                }
            }
        )
            .then((response) => response.json())
            .then((responseJson) => {
                if (responseJson.status === 404) {
                    setErrors(false);
                } else {
                    responseJson.forEach(function (data: any) {
                        if (data.companyName === jwtPayload.company) {
                            allowances.push(data);
                        }
                    });
                    const uniqueSet = new Set(allowances);
                    uniqueSet.forEach(function (value) {
                        values.push(value);
                    });
                    if (allowances.length !== 0) {
                        setCompanyAllowances(values);
                        setChosenAllowance(allowances[0].id);
                        getPriceAndKilometers(allowances[0].id);
                    }
                }
            })
            .catch((err) => {
                console.log(err)
            });
        setErrors(true);
    }

    async function getPriceAndKilometers(value: any) {
        if (!jwt || !jwtPayload) return;
        if (chosenAllowance === undefined || chosenAllowance === null) return;
        const url = process.env.REACT_APP_API_URL + `KilometerAllowances/${value}`;
        await fetch(
            url,
            {
                method: 'GET',
                headers: {
                    Accept: 'application/json',
                    Authorization: `Bearer ${jwt}`,
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                }
            }
        )
            .then((response) => response.json())
            .then((responseJson) => {
                if (responseJson.status === 404) {
                    setErrors(false);
                } else {
                    setPrice(responseJson.price);
                    setKilometers(responseJson.minDistance);
                    setOldPrice(responseJson.price);
                    setOldKilometers(responseJson.minDistance);
                }
            })
            .catch((err) => {
                console.log(err)
            });
        setErrors(true);

    }

    async function changeKilometers(newValue: any) {
        setKilometers(newValue.target.value)
    }

    async function changeAllowanceType(newValue: any) {
        const newVal = newValue.target.value;
        await setChosenAllowance(newVal);
        getPriceAndKilometers(newVal);
    }

    async function changePrice(newValue: any) {
        setPrice(newValue.target.value)
    }

    async function resetChanges() {
        setKilometers(oldKilometers);
        setPrice(oldPrice);
    }

    async function saveChanges() {
        await fetch(process.env.REACT_APP_API_URL + `KilometerAllowances/${chosenAllowance}`, {
            method: 'PUT',
            headers: {
                Accept: 'application/json',
                Authorization: `Bearer ${jwt}`,
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify({
                allowanceTypeName: "Work",
                companyName: jwtPayload?.company,
                price: parseFloat(String(price)),
                minDistance: parseFloat(String(kilometers))
            })
        })
            .then(response => response.json()
            )
            .then(responseJson => {
                if (responseJson.status) {
                    setErrors(true);
                } else {
                    setErrors(false);
                }
            }).catch((err) => {
                console.log(err)
            });
    }

    if (price === 0.0000) {
        getAllKilometerAllowances();
    }

    function getAllowanceOptions() {
        let res: any[] = [];
        for (let k = 0; k < compnayAllowances.length; k++) {
            let value = compnayAllowances[k].allowanceTypeName.split('_').join(" ");
            let valueNL = "";
            if (value.toLocaleLowerCase() === "work") valueNL = "Dienstreizen"
            if (value.toLocaleLowerCase() === "home to work") valueNL = "Woon- werkverkeer"
            res.push(
                <option value={compnayAllowances[k].id}
                        key={value.toLocaleLowerCase()}>{valueNL.toLocaleLowerCase()}</option>
            );
        }
        if (res.length === 0) {
            res.push("No items have been made");
        }
        return res;
    }


    return (
        <ListGroup className="ml-3">
            <Row className="ml-1">
                <Col>
                    <h3>Mijn Organisatie</h3>
                </Col>
                <Col>
                    <CancelButton style={{maxWidth: "120px"}} onClick={resetChanges}
                                  className="mr-4">Annuleren</CancelButton>
                    <AcceptButton style={{maxWidth: "120px"}} onClick={saveChanges}>Opslaan</AcceptButton>
                </Col>
            </Row>
            <div className="mr-2 ml-2">
                {!errors ? (
                    <Alert severity="success">Wijzigingen successvol opgeslagen</Alert>
                ) : null}
            </div>
            <Card className="settingsBox m-2">
                <Card.Header className="cardHeaderColor">
                    <div className="row">
                        <div className="col"> Kilometer Vergoeding</div>
                        <div className="col text-right">
                            <select onChange={changeAllowanceType} value={chosenAllowance} className="btn btn-danger"
                                    id="exampleFormControlSelect1">
                                {getAllowanceOptions()}
                            </select>
                        </div>
                    </div>
                </Card.Header>
                <Form className="m-2">
                    <Form.Group controlId="formBasicEmail">
                        <Form.Label>Vergoeding per kilometer</Form.Label>
                        <Form.Control value={price} onChange={changePrice} type="text" placeholder="Prijs invullen"/>
                    </Form.Group>

                    <Form.Group controlId="formBasicPassword">
                        <Form.Label>Maximaal aantal vergoede kilometers per route</Form.Label>
                        <Form.Control value={kilometers} onChange={changeKilometers} type="text"
                                      placeholder="Kilometers invullen"/>
                    </Form.Group>
                </Form>
            </Card>

            <Card className="settingsBox m-2">
                <Card.Header className="cardHeaderColor">Vrije dagen</Card.Header>
                <div className="m-2">
                    <p>Vrije dagen instellen voor het hele bedrijf</p>
                    <Row className="row ml-0">
                        <button onClick={() => handleChange("PickDate")} className="btn btn-outline-danger">
                            <Row className="m-1">
                                <FontAwesomeIcon icon="calendar"/>
                                <div className="ml-3">Voeg een nieuwe dag toe</div>
                            </Row>
                        </button>
                        <button onClick={() => handleChange("SeeDates")} className="ml-2 btn btn-outline-danger">
                            <Row className="m-1">
                                <FontAwesomeIcon icon="table"/>
                                <div className="ml-3">Dagen inzien</div>
                            </Row>
                        </button>
                    </Row>
                </div>
            </Card>

            <Card className="settingsBox m-2">
                <Card.Header className="cardHeaderColor">BedrijfsLogo</Card.Header>
                <div className="m-2">
                    <p>Bedrijflogo aanpassen</p>
                    <div>
                        <RedButton style={{width: "100px"}}>Upload</RedButton>
                    </div>
                </div>
            </Card>

        </ListGroup>
    );
}

export default SettingsBox;
