import React, {createRef, SVGProps, FC} from 'react'
import {Map, TileLayer, Marker, Popup, Polyline, FeatureGroup} from 'react-leaflet'
import {IRoute} from '../interfaces/IRoute'
import {RouteHelper, markerHelper} from '../util/mapHelper'
import {ICoordinate} from '../interfaces/ICoordinate'
import {RouteAToB} from '../svg/RouteAToB'
import * as Status from '../global/StatusNames'
import * as Colors from '../global/Colors'
import { ContainerCenter } from '../styled/Containers'
import styled from 'styled-components'
import {Check} from '../svg/route-states/Check'
import {Alert} from '../svg/route-states/Alert'
import {ClockClassic} from '../svg/route-states/ClockClassic'
import {Cross} from '../svg/route-states/Cross'
import {DeleteButton, AcceptButton, RedButton} from '../styled/Buttons'
import {ICompany} from '../interfaces/ICompany'
import {Select, Option} from '../styled/Dropdown'
import L from 'leaflet'

const mapBoxApiKey = process.env.REACT_APP_MAPBOX_API_KEY
//#region Interface types
type IProps = {
    coordinates: Array<ICoordinate>
    setCoordinates: (route: Array<ICoordinate>) => void
    activeRoute: IRoute | undefined
    deleteRoute: () => void
    confirmRoute: () => void
    setActiveRoute: (route: IRoute) => void
    companies?: Array<ICompany> | undefined
    isEmployer: boolean
    isEmployee: boolean
}
//#endregion

const MapBorder = styled.div({
    padding: '0px 20px 0px 20px',
    width: '100%',
    height: '99%',
    borderRadius: '10px',
})

export const MapOverview: React.FC<IProps> = ({
    coordinates,
    setCoordinates,
    activeRoute,
    setActiveRoute,
    deleteRoute,
    confirmRoute,
    companies,
    isEmployer,
    isEmployee
}) => {
    //#region State
    const refmarkerFrom = createRef<Marker>()
    const refmarkerTo = createRef<Marker>()
    //#endregion

    //#region Computed properties
    const getFrom   = () => coordinates[0]
    const getTo     = () => coordinates[Math.max(coordinates.length - 1, 0)]
    const bounds    = () => new L.LatLngBounds(L.latLng(getFrom().lat, getFrom().lng), L.latLng(getTo().lat, getTo().lng))

    function UpdateCurrentRoute() {
        const markerFrom = refmarkerFrom.current
        const markerTo = refmarkerTo.current
        if (markerFrom == null && markerTo == null) return

        const from = markerFrom?.leafletElement?.getLatLng() || getFrom()
        const to = markerTo?.leafletElement?.getLatLng() || getTo()

        let helper = new RouteHelper()
        let directions = helper.getDirections(from, to)

        directions.then((newRoutes) => setCoordinates(newRoutes))
    }
    //#endregion

    //#region View
    if (coordinates.length === 0)
        return (
            <ContainerCenter style={{ width: '100%', height: '100%', flexDirection: 'column' }}>
                <RouteAToB style={{ height: '40%', width: '40%', fill: Colors.gray }} />
                <p style={{ color: Colors.gray, fontSize: '1.4em' }}>
                    Er is geen route geselecteerd
                </p>
            </ContainerCenter>
        )

    let color: string = Colors.black
    let text: string = ''
    let Indicator: FC<SVGProps<SVGSVGElement>> = Check

    // in case of employee
    async function getStatus() {
        if (isEmployer) {
            switch (activeRoute?.statusName) {
                case Status.PENDING_BY_EMPLOYER:
                    text = 'Er is een gereden route goedkeuring aangevraagd. Komt dit overeen?'
                    color = Colors.orange
                    Indicator = Alert
                    return
                case Status.APPROVED:
                    text = 'Deze route is goedgekeurd'
                    color = Colors.green
                    Indicator = Check
                    return
                case Status.REJECTED:
                    text = 'Deze route is afgekeurd'
                    color = Colors.red
                    Indicator = Cross
                    return
                default:
                    color = Colors.black
            }
        } else {
            switch (activeRoute?.statusName) {
                case Status.PENDING_BY_EMPLOYEE:
                    text = 'Er is een gereden route gedetecteerd. Komt dit overeen?'
                    color = Colors.orange
                    Indicator = Alert
                    return
                case Status.PENDING_BY_EMPLOYER:
                    text = 'In afwachting van goedkeuring werkgever'
                    color = Colors.darkGray
                    Indicator = ClockClassic
                    return
                case Status.APPROVED:
                    text = 'Deze route is goedgekeurd'
                    color = Colors.green
                    Indicator = Check
                    return
                case Status.REJECTED:
                    text = 'Deze route is afgekeurd'
                    color = Colors.red
                    Indicator = Cross
                    return
                default:
                    color = Colors.black
            }
        }
    }

    getStatus()

    const updateActiveRouteType = (event: React.ChangeEvent<HTMLSelectElement>) => {
        event.persist()
        const allowanceTypeName = event?.target?.value
        if (activeRoute && allowanceTypeName !== null) setActiveRoute({ ...activeRoute, allowanceTypeName })
    }

    const updateActiveCompany = (event: React.ChangeEvent<HTMLSelectElement>) => {
        event.persist()
        const companyName = event?.target?.value
        if (activeRoute && companyName !== null) setActiveRoute({ ...activeRoute, companyName })
    }

    return (
        <MapBorder style={{ backgroundColor: `${color}40`, border: `3px solid ${color}` }}>
            <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
                <Indicator />
                <h4 style={{
                    marginLeft: '15px',
                    fontSize: '1.0rem',
                    marginTop: '21.2833px',
                    fontWeight: 700,
                    marginBottom: '21.2833px'
                }}>{text}</h4>

                {activeRoute?.statusName === Status.PENDING_BY_EMPLOYEE && isEmployee && (
                    <>
                        <DeleteButton style={{fontSize: "14px"}} onClick={() => deleteRoute()}>
                            Nee, verwijderen
                        </DeleteButton>

                        <Select style={{fontSize: "12px"}}
                            onChange={updateActiveRouteType}
                            value={activeRoute.allowanceTypeName}
                            id="routeType"
                            name="routeType"
                        >
                            <Option key={'WORK'} value={'WORK'}>{'Dienstreizen'}</Option>
                            <Option key={'HOME_TO_WORK'} value={'HOME_TO_WORK'}>{'Woon- werkverkeer'}</Option>
                        </Select>

                        <Select style={{fontSize: "12px"}}
                            onChange={updateActiveCompany}
                            value={activeRoute.companyName}
                            id="companyName"
                            name="companyName"
                        >
                            {companies?.map((company) => (
                                <Option key={company.name} value={company.name}>
                                    {company.name}
                                </Option>
                            ))}
                        </Select>

                        <AcceptButton style={{fontSize: "14px", width: "140px"}} onClick={() => confirmRoute()}>
                            Ja, toevoegen
                        </AcceptButton>
                    </>
                )}

                {activeRoute?.statusName === Status.PENDING_BY_EMPLOYER && isEmployer && (
                    <>
                        <RedButton style={{width: "130px", marginLeft: "15px"}} onClick={() => deleteRoute()}>
                            Afkeuren
                        </RedButton>
                        <AcceptButton style={{width: "130px", marginLeft: "10px"}} onClick={() => confirmRoute()}>
                            Goedkeuren
                        </AcceptButton>
                    </>
                )}
            </div>
            <hr style={{ border: `1px solid ${color}` }} />
            <div style={{ height: '85%', zIndex: 100 }}>
                <Map
                    bounds={bounds()}
                    boundsOptions={{padding: [50, 50]}}
                    id="mapid"
                >
                    <TileLayer
                        url={"https://api.mapbox.com/styles/v1/mapbox/streets-v11/tiles/256/{z}/{x}/{y}?access_token=" + mapBoxApiKey}
                    />
                    <FeatureGroup>
                        <Marker
                            position={getFrom()}
                            icon={markerHelper.iconBlueMarker()}
                            ref={refmarkerFrom}
                            draggable={true}
                            ondragend={(e) => UpdateCurrentRoute()}
                        >
                            <Popup>From location</Popup>
                        </Marker>

                        <Marker
                            position={getTo()}
                            icon={markerHelper.iconRedMarker()}
                            ref={refmarkerTo}
                            draggable={true}
                            ondragend={(e) => UpdateCurrentRoute()}
                        >
                            <Popup>To location</Popup>
                        </Marker>

                        <Polyline color={Colors.blue} positions={coordinates} />
                    </FeatureGroup>
                </Map>
            </div>
        </MapBorder>
    )
    //#endregion
}

export default MapOverview
