﻿using hotelDeBotel.Models;
using Repository.Interfaces;
using Repository.Repositories;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace DiscountService
{
    public class DiscountService : IDiscountService
    {
        private IRoomsRepository _roomsRepository;
        private Random _random;
        private GregorianCalendar _gregorianCalendar;
        public int _discount;

        public DiscountService()
        {
            _random = new Random();
            _gregorianCalendar = new GregorianCalendar(GregorianCalendarTypes.Localized);
            _roomsRepository = new RoomsRepository();
            _discount = 0;
        }

        public int GetDiscount(DateTime reservationDate, List<string> customerNames, int amountOfRooms)
        {
            SetMondayTuesdayDiscount(reservationDate);
            SetWeekNumberDiscount(reservationDate);
            SetAmountOfRoomsDiscount(amountOfRooms);
            SetCharacterDiscount(customerNames);
            SetMultiplierToDiscount();
            SetDiscountLimit();

            return _discount;
        }

        public void SetMondayTuesdayDiscount(DateTime reservationDate)
        {
            if (reservationDate.DayOfWeek == DayOfWeek.Monday ||
                reservationDate.DayOfWeek == DayOfWeek.Tuesday)
            {
                _discount += 15;
            }
        }

        public void SetWeekNumberDiscount(DateTime reservationDate)
        {
            int weekNumber = _gregorianCalendar.GetWeekOfYear(reservationDate, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

            if (weekNumber % 2 == 0)
            {
                _discount += 3;
            }
        }

        public void SetAmountOfRoomsDiscount(int amountOfRooms)
        {
            _discount += amountOfRooms;
        }

        public void SetCharacterDiscount(List<string> customerNames)
        {
            char letter = 'A';
            foreach (var customerName in customerNames)
            {
                foreach (char s in customerName.ToUpper())
                {
                    if (s.Equals(letter))
                    {
                        _discount += 2;
                        letter++;
                    }
                }
            }
        }

        public void SetMultiplierToDiscount()
        {
            _discount *= _random.Next(5) + 1;
        }

        public void SetDiscountLimit()
        {
            if (_discount > 60)
            {
                _discount = 60;
            }
        }
    }
}
