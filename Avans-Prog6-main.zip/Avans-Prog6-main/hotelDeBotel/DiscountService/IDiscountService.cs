﻿using hotelDeBotel.Models;
using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace DiscountService
{
	[ServiceContract]
	public interface IDiscountService
	{
        [OperationContract]
        int GetDiscount(DateTime reservationDate, List<string> customerNames, int amountOfRooms);
	}
}
