using Microsoft.VisualStudio.TestTools.UnitTesting;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Web.Mvc;
using hotelDeBotel.Controllers;
using hotelDeBotel.Models;
using Repository.Repositories;

namespace hotelDeBotel.Tests.Controllers
{
    [TestClass]
    public class RoomsControllerTests
    {
        private IRoomsRepository _roomsRepository;
        private RoomsController _controller;
        private IBookingsRepository _bookingsRepository;
        private Customer _customer1;
        private Customer _customer2;
        private Booking _booking1;
        private Booking _booking2;
        private Room _room;
        private CustomersRepository _customersRepository;

        public RoomsControllerTests()
        {
            Initialize();
        }

        public void Initialize()
        {
            _roomsRepository = new RoomsRepository();
            _bookingsRepository = new BookingsRepository();
            _customersRepository = new CustomersRepository();
            _controller = new RoomsController(_roomsRepository);

            _customer2 = new Customer()
            {
                Name = "Aaron",
                Id = 1,
                Email = "rgj.vanrijen@student.avans.nl",
                HouseLetter = 'a',
                HouseNumber = 80,
                ZipCode = "5366CB",
                Bookings = new List<Booking>()
            };
            _customer1 = new Customer()
            {
                Name = "Ruben",
                Id = 0,
                Email = "rgj.vanrijen@student.avans.nl",
                HouseLetter = 'a',
                HouseNumber = 80,
                ZipCode = "5366CB",
                Bookings = new List<Booking>()
            };

            _room = new Room
            {
                AmountOfBeds = 2,
                Name = "deluxe",
                Description = "het is prechtig",
                Price = 500,
                ImageUrl = "http://www.shopedition.com/images/products/lrg/edition-hotels-bed-bedding-set-EDT-1230-01_lrg.jpg",
                Bookings = new List<Booking>()

            };

            _booking1 = new Booking
            {
                RoomId = 0,
                Id = 0,
                Price = 500,
                ReservationDate = DateTime.Parse("14/01/2019"),
                Customers = new List<Customer>()

            };
            _booking2 = new Booking
            {
                RoomId = 1,
                Id = 1,
                Price = 600,
                ReservationDate = DateTime.Parse("21/01/2019"),
                Customers = new List<Customer>()

            };
            _booking1.Customers.Add(_customer1);
            _booking2.Customers.Add(_customer2);
        }

        [TestMethod]
        public void RoomsListTest()
        {
            ViewResult result = _controller.RoomsList() as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void BookingsInfoTest()
        {
            _roomsRepository.Create(_room);
            ViewResult result = _controller.BookingsInfo(_room.Id) as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void DetailsTest()
        {
            _roomsRepository.Create(_room);
            ViewResult result = _controller.Details(_room.Id) as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void CreateTest()
        {
            ViewResult result = _controller.Create() as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void EditTest()
        {
            _roomsRepository.Create(_room);
            ViewResult result = _controller.Edit(_room.Id) as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void DeleteTest()
        {
            _roomsRepository.Create(_room);
            ViewResult result = _controller.Delete(_room.Id) as ViewResult;
            Assert.IsNotNull(result);
        }


    }
}
