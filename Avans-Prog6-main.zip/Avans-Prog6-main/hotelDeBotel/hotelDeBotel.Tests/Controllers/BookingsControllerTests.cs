﻿using hotelDeBotel.Controllers;
using hotelDeBotel.Models;
using hotelDeBotel.Repositories.Interfaces;
using hotelDeBotel.Repositories.RepositoryClasses;
using hotelDeBotel.ViewModels.Wizard;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Repository.Interfaces;
using Repository.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace hotelDeBotel.Tests.Controllers
{
    [TestClass]
    public class BookingsControllerTests
    {
        private WizardViewModel _wizardViewModel;
        private IBookingsRepository _bookingsRepository;
        private IRoomsRepository _roomsRepository;
        private IDiscountRepository _discountRepository;

        private Customer _customer1;
        private Customer _customer2;
        private Booking _booking1;
        private Booking _booking2;
        private Room _room;

        public BookingsControllerTests()
        {
            _wizardViewModel = new WizardViewModel();
            _bookingsRepository = new BookingsRepository();
            _roomsRepository = new RoomsRepository();
            _discountRepository = new DiscountRepository();

            _customer2 = new Customer()
            {
                Name = "Aaron",
                Id = 1,
                Email = "rgj.vanrijen@student.avans.nl",
                HouseLetter = 'a',
                HouseNumber = 80,
                ZipCode = "5366CB",
                Bookings = new List<Booking>()
            };
            _customer1 = new Customer()
            {
                Name = "Ruben",
                Id = 0,
                Email = "rgj.vanrijen@student.avans.nl",
                HouseLetter = 'a',
                HouseNumber = 80,
                ZipCode = "5366CB",
                Bookings = new List<Booking>()
            };

            _room = new Room
            {
                AmountOfBeds = 2,
                Name = "deluxe",
                Id = 0,
                Description = "het is prechtig",
                Price = 500,
                ImageUrl = "http://www.shopedition.com/images/products/lrg/edition-hotels-bed-bedding-set-EDT-1230-01_lrg.jpg",
                Bookings = new List<Booking>()

            };

            _booking1 = new Booking
            {
                RoomId = 0,
                Id = 0,
                Price = 500,
                ReservationDate = DateTime.Parse("14/01/2019"),
                Customers = new List<Customer>()

            };
            _booking2 = new Booking
            {
                RoomId = 0,
                Id = 1,
                Price = 600,
                ReservationDate = DateTime.Parse("21/01/2019"),
                Customers = new List<Customer>()

            };
            _booking1.Customers.Add(_customer1);
            _booking2.Customers.Add(_customer2);
            _booking1.Room = _room;
            _roomsRepository.Create(_room);
            _booking1.RoomId = _room.Id;
        }

        [TestMethod]
        public void TestDetailsView()
        {
            var controller = new BookingsController(_bookingsRepository, _roomsRepository);
            _bookingsRepository.Create(_booking1);
            int id = _bookingsRepository.GetBookings().FirstOrDefault().Id;
            var result = controller.Details(id) as ViewResult;
            Assert.IsInstanceOfType(result, typeof(ViewResult));
        }

        [TestMethod]
        public void TestDeleteView()
        {
            var controller = new BookingsController(_bookingsRepository, _roomsRepository);
            _bookingsRepository.Create(_booking1);
            int id = _bookingsRepository.GetBookings().FirstOrDefault().Id;
            var result = controller.Delete(id) as ViewResult;
            Assert.IsInstanceOfType(result, typeof(ViewResult));
        }

        [TestMethod]
        public void TestStepOneView()
        {
            Exception exception = null;
            try
            {
                var controller = new BookingsController(_bookingsRepository, _roomsRepository);
                var action = controller.StepOne(_roomsRepository.GetRooms().LastOrDefault().Id);
            }
            catch (Exception ex) { exception = ex; }
            Assert.IsNotNull(exception);
        }

        [TestMethod]
        public void TestStepTwoView()
        {
            Exception exception = null;
            try
            {
                var controller = new BookingsController(_bookingsRepository, _roomsRepository);
                var action = controller.StepTwo();
            }
            catch (Exception ex) { exception = ex; }
            Assert.IsNotNull(exception);
        }

        [TestMethod]
        public void TestStepThreeView()
        {
            Exception exception = null;
            try
            {
                var controller = new BookingsController(_bookingsRepository, _roomsRepository);
                var actionResult = controller.StepThree();
            }
            catch (Exception ex) { exception = ex; }
            Assert.IsNotNull(exception);
        }

        [TestMethod]
        public void RoomsListTest()
        {
            var controller = new BookingsController(_bookingsRepository, _roomsRepository);
            var actionResult = controller.BookingsList();
            ViewResult result = actionResult as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void DeleteTest()
        {
            var controller = new BookingsController(_bookingsRepository, _roomsRepository);
            _bookingsRepository.Create(_booking1);
            var actionResult = controller.Delete(_booking1.Id);
            ViewResult result = actionResult as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void DeleteConfirmedTest()
        {
            var controller = new BookingsController(_bookingsRepository, _roomsRepository);
            _bookingsRepository.Create(_booking1);
            var actionResult = controller.DeleteConfirmed(_booking1.Id);
            ViewResult result = actionResult as ViewResult;
            Assert.IsNull(result);
        }

        [TestMethod]
        public void Modelstatetest()
        {
            var controller = new BookingsController(_bookingsRepository, _roomsRepository);
            var result3 = controller.ModelState.IsValid;
            Assert.IsTrue(result3);
        }
    }
}
