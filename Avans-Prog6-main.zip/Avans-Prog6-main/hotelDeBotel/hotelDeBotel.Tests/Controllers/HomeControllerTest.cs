﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using hotelDeBotel;
using hotelDeBotel.Controllers;
using Repository.Interfaces;
using Repository.Repositories;

namespace hotelDeBotel.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        private IRoomsRepository _roomsRepository = new RoomsRepository();
        private IBookingsRepository _bookingsRepository = new BookingsRepository();

        [TestMethod]
        public void HomeTest()
        {
            HomeController controller = new HomeController(_roomsRepository, _bookingsRepository);
            ViewResult result = controller.Home() as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AboutTest()
        {
            HomeController controller = new HomeController(_roomsRepository, _bookingsRepository);
            ViewResult result = controller.About() as ViewResult;
            Assert.AreEqual("Wij zijn STRONG VIKING en RubenJeBro, de makers van het glorieuze Viking Village.", result.ViewBag.Message);
        }

    }
}
