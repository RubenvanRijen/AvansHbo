using AutoMoq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Repository.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using hotelDeBotel.Models;
using hotelDeBotel.Repositories.RepositoryClasses;

namespace hotelDeBotel.Tests.Repositories.RepositoryClasses
{
    [TestClass]
    public class RoomsRepositoryTests
    {
        public RoomsRepositoryTests()
        {
            Initialize();
        }
        private DiscountRepository _discountRepository;
        private Customer _customer1;
        private Customer _customer2;
        private Booking _booking1;
        private Booking _booking2;
        private Room _room;
        private BookingsRepository _bookingsRepository;
        private RoomsRepository _roomsRepository;
        private CustomersRepository _customersRepository;
        private void Initialize()
        {
            _discountRepository = new DiscountRepository();
            _bookingsRepository = new BookingsRepository();
            _roomsRepository = new RoomsRepository();
            _customersRepository = new CustomersRepository();

            _customer2 = new Customer()
            {
                Name = "Aaron",
                Id = 1,
                Email = "rgj.vanrijen@student.avans.nl",
                HouseLetter = 'a',
                HouseNumber = 80,
                ZipCode = "5366CB",
                Bookings = new List<Booking>()
            };
            _customer1 = new Customer()
            {
                Name = "Ruben",
                Id = 0,
                Email = "rgj.vanrijen@student.avans.nl",
                HouseLetter = 'a',
                HouseNumber = 80,
                ZipCode = "5366CB",
                Bookings = new List<Booking>()
            };

            _room = new Room
            {
                AmountOfBeds = 2,
                Name = "deluxe",
                Description = "het is prechtig",
                Price = 500,
                ImageUrl = "http://www.shopedition.com/images/products/lrg/edition-hotels-bed-bedding-set-EDT-1230-01_lrg.jpg",
                Bookings = new List<Booking>()

            };

            _booking1 = new Booking
            {
                RoomId = 0,
                Id = 0,
                Price = 500,
                ReservationDate = DateTime.Parse("14/01/2019"),
                Customers = new List<Customer>()

            };
            _booking2 = new Booking
            {
                RoomId = 1,
                Id = 1,
                Price = 600,
                ReservationDate = DateTime.Parse("21/01/2019"),
                Customers = new List<Customer>()

            };
            _booking1.Customers.Add(_customer1);
            _booking2.Customers.Add(_customer2);
        }
        [TestMethod]
        public void CreateTest()
        {
            _roomsRepository.Create(_room);
            var result = _roomsRepository.GetRooms().LastOrDefault();
            Assert.AreEqual(_room, result);
        }

        [TestMethod]
        public void DeleteTest()
        {
            _roomsRepository.Create(_room);
            _roomsRepository.Delete(_room.Id);

            var result = !_roomsRepository.GetRooms().Contains(_room);

            Assert.IsTrue(result);

        }

        [TestMethod]
        public void GetRoomTest()
        {
            _roomsRepository.Create(_room);
            var result = _roomsRepository.GetRoom(_room.Id);
            Assert.AreEqual(_room, result);
        }
        [TestMethod]
        public void GetRoomsTest()
        {
            var result = _roomsRepository.GetRooms().Count;
            Assert.AreNotEqual(result, 0);
        }
        [TestMethod]
        public void UpdateTest()
        {
            _roomsRepository.Create(_room);
            _room.AmountOfBeds = 4;
            _roomsRepository.Update(_room);
            Assert.AreEqual(_room.AmountOfBeds, 4);
        }
        //todo dit is nog verkeerd
        [TestMethod]
        public void DisposeTest()
        {
            _roomsRepository.Dispose();
            var result = _roomsRepository;
            Assert.AreNotEqual(result, null);
        }

    }
}
