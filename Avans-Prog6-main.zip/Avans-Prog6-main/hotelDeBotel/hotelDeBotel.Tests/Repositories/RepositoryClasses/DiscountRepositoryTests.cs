using System;
using System.Collections.Generic;
using AutoMoq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using hotelDeBotel.Models;
using hotelDeBotel.Repositories.RepositoryClasses;
using Repository.Interfaces;
using Repository.Repositories;

namespace hotelDeBotel.Tests.Repositories.RepositoryClasses
{
    [TestClass]
    public class DiscountRepositoryTests
    {
        public DiscountRepositoryTests()
        {
            Initialize();
        }
        private DiscountRepository _discountRepository;
        private Customer _customer1;
        private Customer _customer2;
        private Booking _booking1;
        private Booking _booking2;
        private Room _room;
        private BookingsRepository _bookingsRepository;
        private RoomsRepository _roomsRepository;
        private CustomersRepository _customersRepository;
        private void Initialize()
        {
            _discountRepository = new DiscountRepository();
            _bookingsRepository = new BookingsRepository();
            _roomsRepository = new RoomsRepository();
            _customersRepository = new CustomersRepository();

            _customer2 = new Customer()
            {
                Name = "Aaron",
                Id = 1,
                Email = "rgj.vanrijen@student.avans.nl",
                HouseLetter = 'a',
                HouseNumber = 80,
                ZipCode = "5366CB",
                Bookings = new List<Booking>()
            };
            _customer1 = new Customer()
            {
                Name = "Ruben",
                Id = 0,
                Email = "rgj.vanrijen@student.avans.nl",
                HouseLetter = 'a',
                HouseNumber = 80,
                ZipCode = "5366CB",
                Bookings = new List<Booking>()
            };

            _room = new Room
            {
                AmountOfBeds = 2,
                Name = "deluxe",
                Id = 0,
                Description = "het is prechtig",
                Price = 500,
                ImageUrl = "http://www.shopedition.com/images/products/lrg/edition-hotels-bed-bedding-set-EDT-1230-01_lrg.jpg",
                Bookings = new List<Booking>()

            };

            _booking1 = new Booking
            {
                RoomId = 0,
                Id = 0,
                Price = 500,
                ReservationDate = DateTime.Parse("14/01/2019"),
                Customers = new List<Customer>()

            };
            _booking2 = new Booking
            {
                RoomId = 0,
                Id = 1,
                Price = 600,
                ReservationDate = DateTime.Parse("21/01/2019"),
                Customers = new List<Customer>()

            };
            _booking1.Customers.Add(_customer1);
            _booking2.Customers.Add(_customer2);
        }

        [TestMethod]
        public void SetMondayTuesdayDiscountTestPass()
        {
            _discountRepository.SetMondayTuesdayDiscount(_booking1);
            _booking1.Discount = _discountRepository._discount;
            var result = _booking1.Discount;
            Assert.AreEqual(result, 15);
        }
        [TestMethod]
        public void SetMondayTuesdayDiscountTestFail()
        {
            _discountRepository.SetMondayTuesdayDiscount(_booking1);
            _booking1.Discount = _discountRepository._discount;
            var result = _booking1.Discount;
            Assert.AreNotEqual(result, 0);
        }
        [TestMethod]
        public void SetWeekNumberDiscountTestFail()
        {
            _discountRepository.SetWeekNumberDiscount(_booking1);
            _booking1.Discount = _discountRepository._discount;
            var result = _booking1.Discount;
            Assert.AreEqual(result, 0);
        }
        [TestMethod]
        public void SetWeekNumberDiscountTestPass()
        {
            _discountRepository.SetWeekNumberDiscount(_booking2);
            _booking2.Discount = _discountRepository._discount;
            var result = _booking2.Discount;
            Assert.AreEqual(result, 3);
        }

        [TestMethod]
        public void SetCharacterDiscountFail()
        {
            _discountRepository.SetCharacterDiscount(_booking1);
            _booking1.Discount = _discountRepository._discount;
            var result = _booking1.Discount;
            Assert.AreEqual(result, 0);
        }

        [TestMethod]
        public void SetCharacterDiscountPass()
        {
            _discountRepository.SetCharacterDiscount(_booking2);
            _booking2.Discount = _discountRepository._discount;
            var result = _booking2.Discount;
            Assert.AreEqual(result, 2);
        }

        [TestMethod]
        public void SetMultiplierToDiscount()
        {
            _discountRepository.SetMultiplierToDiscount();
            _booking2.Discount = 20;
            var result = _booking2.Discount;
            Assert.AreEqual(result, 20);
        }

        [TestMethod]
        public void SetDiscountLimitPass()
        {
            _discountRepository._discount = 80;
            _discountRepository.SetDiscountLimit();
            _booking1.Discount = _discountRepository._discount;
            var result = _booking1.Discount;
            Assert.AreEqual(result, 60);
        }

        [TestMethod]
        public void SetDiscountLimitFail()
        {
            _discountRepository._discount = 40;
            _discountRepository.SetDiscountLimit();
            _booking1.Discount = _discountRepository._discount;
            var result = _booking1.Discount;
            Assert.AreNotEqual(result, 60);
        }

        [TestMethod]
        public void SetAmountOfRoomsDiscount()
        {
            _discountRepository.SetAmountOfRoomsDiscount();
            _booking2.Discount = _discountRepository._discount;
            var result = _booking2.Discount;
            Assert.AreNotEqual(result, 0);
        }

        [TestMethod]
        public void GetDiscount()
        {
            _discountRepository.GetDiscount(_booking2);
            _booking2.Discount = _discountRepository._discount;
            var result = _booking2.Discount;
            Assert.AreNotEqual(result, 0);
        }

    }
}
