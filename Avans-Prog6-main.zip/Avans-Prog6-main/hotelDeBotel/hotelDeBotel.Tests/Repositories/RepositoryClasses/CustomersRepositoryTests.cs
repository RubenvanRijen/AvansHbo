using AutoMoq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Repository.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using hotelDeBotel.Models;
using hotelDeBotel.Repositories.RepositoryClasses;

namespace hotelDeBotel.Tests.Repositories.RepositoryClasses
{
    [TestClass]
    public class CustomersRepositoryTests
    {

        public CustomersRepositoryTests()
        {
            Initialize();
        }
        private DiscountRepository _discountRepository;
        private Customer _customer1;
        private Customer _customer2;
        private Booking _booking1;
        private Booking _booking2;
        private Room _room;
        private BookingsRepository _bookingsRepository;
        private RoomsRepository _roomsRepository;
        private CustomersRepository _customersRepository;
        private void Initialize()
        {
            _discountRepository = new DiscountRepository();
            _bookingsRepository = new BookingsRepository();
            _roomsRepository = new RoomsRepository();
            _customersRepository = new CustomersRepository();

            _customer2 = new Customer()
            {
                Name = "Aaron",
                Id = 1,
                Email = "rgj.vanrijen@student.avans.nl",
                HouseLetter = 'a',
                HouseNumber = 80,
                ZipCode = "5366CB",
                Bookings = new List<Booking>()
            };
            _customer1 = new Customer()
            {
                Name = "Ruben",
                Id = 0,
                Email = "rgj.vanrijen@student.avans.nl",
                HouseLetter = 'a',
                HouseNumber = 80,
                ZipCode = "5366CB",
                Bookings = new List<Booking>()
            };

            _room = new Room
            {
                AmountOfBeds = 2,
                Name = "deluxe",
                Description = "het is prechtig",
                Price = 500,
                ImageUrl = "http://www.shopedition.com/images/products/lrg/edition-hotels-bed-bedding-set-EDT-1230-01_lrg.jpg",
                Bookings = new List<Booking>()

            };

            _booking1 = new Booking
            {
                RoomId = 0,
                Id = 0,
                Price = 500,
                ReservationDate = DateTime.Parse("14/01/2019"),
                Customers = new List<Customer>()

            };
            _booking2 = new Booking
            {
                RoomId = 1,
                Id = 1,
                Price = 600,
                ReservationDate = DateTime.Parse("21/01/2019"),
                Customers = new List<Customer>()

            };
            _booking1.Customers.Add(_customer1);
            _booking2.Customers.Add(_customer2);
        }
        [TestMethod]
        public void CreateTest()
        {
            _customersRepository.Create(_customer1);
            var result = _customersRepository.GetCustomer(_customer1.Id);
            Assert.AreEqual(_customer1, result);
        }
        [TestMethod]
        public void DeleteTest()
        {
            _customersRepository.Create(_customer1);
            _customersRepository.Delete(_customer1.Id);

            var result = !_customersRepository.GetCustomers().Contains(_customer1);
            Assert.IsTrue(result);

        }

        [TestMethod]
        public void GetCustomerTest()
        {
            _customersRepository.Create(_customer1);
            var result = _customersRepository.GetCustomer(_customer1.Id);
            Assert.AreEqual(_customer1, result);
        }
        [TestMethod]
        public void GetCustomersTest()
        {
            var result = _customersRepository.GetCustomers().Count;
            Assert.AreNotEqual(result, 0);
        }
        [TestMethod]
        public void UpdateTest()
        {
            _customersRepository.Create(_customer1);
            _customer1.Name = "jackob";
            _customersRepository.Update(_customer1);
            Assert.AreEqual(_customer1.Name, "jackob");
        }
        //todo dit is nog verkeerd
        [TestMethod]
        public void DisposeTest()
        {
           _customersRepository.Dispose();
            var result = _customersRepository;
            Assert.AreNotEqual(result, null);
        }
    }
}
