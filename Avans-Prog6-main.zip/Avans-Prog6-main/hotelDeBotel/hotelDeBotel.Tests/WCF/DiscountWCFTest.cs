﻿using System;
using System.Collections.Generic;
using System.Linq;
using hotelDeBotel.Models;
using hotelDeBotel.Repositories.RepositoryClasses;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Repository.Repositories;

namespace hotelDeBotel.Tests.WCF
{
    [TestClass]
    public class DiscountWCFTest
    {
        public DiscountWCFTest()
        {
            Initialize();
        }

        private global::DiscountService.DiscountService _discountService;
        private DiscountRepository _discountRepository;
        private Customer _customer1;
        private Customer _customer2;
        private Booking _booking1;
        private Booking _booking2;
        private Room _room;
        private BookingsRepository _bookingsRepository;
        private RoomsRepository _roomsRepository;
        private CustomersRepository _customersRepository;
        private void Initialize()
        {
            _discountService = new global::DiscountService.DiscountService();
            _discountRepository = new DiscountRepository();
            _bookingsRepository = new BookingsRepository();
            _roomsRepository = new RoomsRepository();
            _customersRepository = new CustomersRepository();

            _customer2 = new Customer()
            {
                Name = "aaron",
                Id = 1,
                Email = "rgj.vanrijen@student.avans.nl",
                HouseLetter = 'a',
                HouseNumber = 80,
                ZipCode = "5366CB",
                Bookings = new List<Booking>()
            };
            _customer1 = new Customer()
            {
                Name = "Ruben",
                Id = 0,
                Email = "rgj.vanrijen@student.avans.nl",
                HouseLetter = 'a',
                HouseNumber = 80,
                ZipCode = "5366CB",
                Bookings = new List<Booking>()
            };

            _room = new Room
            {
                AmountOfBeds = 2,
                Name = "deluxe",
                Id = 0,
                Description = "het is prechtig",
                Price = 500,
                ImageUrl = "http://www.shopedition.com/images/products/lrg/edition-hotels-bed-bedding-set-EDT-1230-01_lrg.jpg",
                Bookings = new List<Booking>()

            };

            _booking1 = new Booking
            {
                RoomId = 0,
                Id = 0,
                Price = 500,
                ReservationDate = DateTime.Parse("14/01/2019"),
                Customers = new List<Customer>()

            };
            _booking2 = new Booking
            {
                RoomId = 0,
                Id = 1,
                Price = 600,
                ReservationDate = DateTime.Parse("21/01/2019"),
                Customers = new List<Customer>()

            };
            _booking1.Customers.Add(_customer1);
            _booking2.Customers.Add(_customer2);
        }

        [TestMethod]
        public void SetMondayTuesdayDiscountTestPass()
        {
            _discountService.SetMondayTuesdayDiscount(_booking1.ReservationDate);
            _booking1.Discount = _discountService._discount;
            var result = _booking1.Discount;
            Assert.AreEqual(result, 15);
        }
        [TestMethod]
        public void SetMondayTuesdayDiscountTestFail()
        {
            _discountService.SetMondayTuesdayDiscount(_booking1.ReservationDate);
            _booking1.Discount = _discountService._discount;
            var result = _booking1.Discount;
            Assert.AreNotEqual(result, 0);
        }
        [TestMethod]
        public void SetWeekNumberDiscountTestFail()
        {
            _discountService.SetWeekNumberDiscount(_booking1.ReservationDate);
            _booking1.Discount = _discountService._discount;
            var result = _booking1.Discount;
            Assert.AreEqual(result, 0);
        }
        [TestMethod]
        public void SetWeekNumberDiscountTestPass()
        {
            _discountService.SetWeekNumberDiscount(_booking2.ReservationDate);
            _booking2.Discount = _discountService._discount;
            var result = _booking2.Discount;
            Assert.AreEqual(result, 3);
        }

        [TestMethod]
        public void SetCharacterDiscountPass()
        {
            List<string> Test = new List<string>();
            var Customer =_booking2.Customers.FirstOrDefault().Name;
            Test.Add(Customer);
            _discountService.SetCharacterDiscount(Test);
            _booking2.Discount = _discountService._discount;
            var result = _booking2.Discount;
            Assert.AreEqual(result, 2);
        }

        [TestMethod]
        public void SetCharacterDiscountFail()
        {
            List<string> Test = new List<string>();
            var Customer = _booking1.Customers.FirstOrDefault().Name;
            Test.Add(Customer);
            _discountService.SetCharacterDiscount(Test);
            _booking1.Discount = _discountService._discount;
            var result = _booking1.Discount;
            Assert.AreEqual(result, 0);
        }

        [TestMethod]
        public void SetMultiplierToDiscount()
        {
            _discountService.SetMultiplierToDiscount();
            _booking2.Discount = 20;
            var result = _booking2.Discount;
            Assert.AreEqual(result, 20);
        }

        [TestMethod]
        public void SetDiscountLimitPass()
        {
            _discountService._discount = 80;
            _discountService.SetDiscountLimit();
            _booking1.Discount = _discountService._discount;
            var result = _booking1.Discount;
            Assert.AreEqual(result, 60);
        }

        [TestMethod]
        public void SetDiscountLimitFail()
        {
            _discountService._discount = 40;
            _discountService.SetDiscountLimit();
            _booking1.Discount = _discountService._discount;
            var result = _booking1.Discount;
            Assert.AreNotEqual(result, 60);
        }

        [TestMethod]
        public void SetAmountOfRoomsDiscount()
        {
            _discountService.SetAmountOfRoomsDiscount(_roomsRepository.GetRoomsCount());
            _booking2.Discount = _discountService._discount;
            var result = _booking2.Discount;
            Assert.AreNotEqual(result, 0);
        }

        [TestMethod]
        public void GetDiscount()
        {
            List<string> Test = new List<string>();
            foreach (var VARIABLE in _booking2.Customers)
            {
                Test.Add(VARIABLE.ToString());
            }
            _discountService.GetDiscount(_booking2.ReservationDate, Test, _roomsRepository.GetRoomsCount());
            _booking2.Discount = _discountService._discount;
            var result = _booking2.Discount;
            Assert.AreNotEqual(result, 0);
        }
    }
}
