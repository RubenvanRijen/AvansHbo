﻿using System.Data.Entity;

namespace hotelDeBotel.Models
{
    public class MyContext :DbContext
    {
        public MyContext() : base("name=VikingVillage")
        {
            Database.SetInitializer(new MyContextInitializer());
        }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Room> Rooms { get; set; }
        public DbSet<Booking> Bookings { get; set; }
    }
}