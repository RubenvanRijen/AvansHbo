﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace hotelDeBotel.Models
{
    public class Room : IValidatableObject
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MinLength(2)]
        [MaxLength(50)]
        public string Name { get; set; }

        [Required]
        [Range(2, 5)]
        public int AmountOfBeds { get; set; }

        [Required]
        [Range(0, 1000)]
        public double Price { get; set; }
        public string Description { get; set; }
        [Required]
        public string ImageUrl { get; set; }

        public virtual ICollection<Booking> Bookings { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var errors = new List<ValidationResult>();

            foreach (char s in Name)
            {
                if (char.IsNumber(s))
                {
                    errors.Add(new ValidationResult("Naam mag geen cijfers bevatten!"));
                    break;
                }
            }
            return errors;
        }
    }
}