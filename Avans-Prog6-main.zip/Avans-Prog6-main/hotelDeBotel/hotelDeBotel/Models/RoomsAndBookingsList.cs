﻿using System.Collections.Generic;

namespace hotelDeBotel.Models
{
    public class RoomsAndBookingsList
    {
        public IEnumerable<Room> Rooms { get; set; }
        public IEnumerable<Booking> Bookings { get; set; }

    }
}