﻿using hotelDeBotel.ViewModels.Wizard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace hotelDeBotel.Models.Validate
{
    public class StepOneValidator
    {
        public bool HasErrorsInValidation(WizardViewModel stepOne, System.Web.Mvc.ModelStateDictionary modelState)
        {
            bool hasError = false;

            if (stepOne.AmountOfPeople < 1 || stepOne.AmountOfPeople > stepOne.Room.AmountOfBeds)
            {
                modelState.AddModelError("AmountOfPeople", "Selecteer aantal vanaf 1 tot " + stepOne.Room.AmountOfBeds);
                hasError = true;
            }
            if (stepOne.ReservationDate < DateTime.Now.Date)
            {
                modelState.AddModelError("ReservationDate", "Reserveringsdatum kan niet in het verleden zijn");
                return true;
            }
            foreach (var reservations in stepOne.Room.Bookings)
            {
                if (stepOne.ReservationDate == reservations.ReservationDate)
                {
                    modelState.AddModelError("ReservationDate", "Er is al een boeking op deze datum voor deze kamer");
                    hasError = true;
                }
            }
            return hasError;
        }
    }
}