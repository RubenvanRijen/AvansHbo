﻿using System;
using System.Collections.Generic;
using System.Data.Entity;

namespace hotelDeBotel.Models
{
    public class MyContextInitializer : DropCreateDatabaseAlways<MyContext>
    {
        protected override void Seed(MyContext context)
        {
            base.Seed(context);

            // ROOMS
            Room room = new Room();
            room.AmountOfBeds = 2;
            room.ImageUrl = "https://cdn-image.travelandleisure.com/sites/default/files/styles/720x450/public/images/amexpub/0043/3510/201406-w-top-rated-hotel-beds-in-america-distrikt-hotel.jpg?itok=ukA7sx2n";
            room.Name = "Comfort Spot";
            room.Description = "Een kamer voor een stel die graag in een claustrofobisch kippenhok verblijven.";
            room.Price = 100;

            Room room2 = new Room();
            room2.AmountOfBeds = 3;
            room2.ImageUrl = "https://www.hiwembley.co.uk/images/Twin-hotel-bedroom-wembley.jpg";
            room2.Name = "FriendZone";
            room2.Description = "Voor degenen die met iemand op vakantie gaan waar ze eigenlijk een relatie mee willen, maar gefriendzoned worden.";
            room2.Price = 130;

            Room room3 = new Room();
            room3.AmountOfBeds = 2;
            room3.ImageUrl = "https://djdo2py1q6zlg.cloudfront.net/magazine/wp-content/uploads/2014/02/four-seasons-bed-toronto-636x431.jpg";
            room3.Name = "King Size Suite";
            room3.Description = "De naam al zegt het al: leef als een koning binnen deze kamer!";
            room3.Price = 250;

            Room room4 = new Room();
            room4.AmountOfBeds = 4;
            room4.ImageUrl = "http://www.plumdeluxe.com/wp-content/uploads/2012/07/w_hotel_bed.jpg";
            room4.Name = "Emperors Room";
            room4.Description = "Ben jij super rijk en awesome? Verblijf dan hier en laat je dominante positie naar voren komen.";
            room4.Price = 400;

            // ADD ROOMS
            context.Rooms.Add(room);
            context.Rooms.Add(room2);
            context.Rooms.Add(room3);
            context.Rooms.Add(room4);

            context.SaveChanges();
        }
    }
}