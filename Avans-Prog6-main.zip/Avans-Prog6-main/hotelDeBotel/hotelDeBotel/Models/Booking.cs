﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace hotelDeBotel.Models
{
    public class Booking
    {
        [Key]
        public int Id { get; set; }

        public int RoomId { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime ReservationDate { get; set; }

        [Range(0, 60)]
        public int Discount { get; set; }

        [Required]
        [Range(0, 1000)]
        public double Price { get; set; }

        public virtual ICollection<Customer> Customers { get; set; }

        [ForeignKey("RoomId")]
        public virtual Room Room { get; set; }
    }
}