﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace hotelDeBotel.Models
{
    public class Customer : IValidatableObject
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MinLength(2)]
        [MaxLength(50)]
        public string Name { get; set; }

        [Required]
        [RegularExpression(@"^[1-9][0-9]{3}\s?(?:[a-zA-Z]{2})$", ErrorMessage = "Voer geldige postcode in zoals 1234AB")]
        public string ZipCode { get; set; }

        [Required]
        [Range(1, 10000)]
        public int? HouseNumber { get; set; }

        public char? HouseLetter { get; set; }

        [Required]
        [RegularExpression(@"^[\w!#$%&'+-/=?^_`{|}~]+(.[\w!#$%&'+-/=?^_`{|}~]+)*" + "@" + @"((([-\w]+.)+[a-zA-Z]{2,4})|(([0-9]{1,3}.){3}[0-9]{1,3}))$", ErrorMessage = "Geen geldige email")]
        public string Email { get; set; }

        public virtual ICollection<Booking> Bookings { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var errors = new List<ValidationResult>();

            foreach(char s in Name)
            {
                if(char.IsNumber(s))
                {
                    errors.Add(new ValidationResult("Naam mag geen cijfers bevatten!"));
                    break;
                }
            }
            return errors;
        }
    }
}