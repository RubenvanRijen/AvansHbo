﻿using hotelDeBotel.Models;
using Repository.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Data.Entity.Migrations;

namespace Repository.Repositories
{
    public class BookingsRepository : BaseRepository, IBookingsRepository
    {
        public void Create(Booking booking)
        {
            booking.Room = Context.Rooms.Where(x => x.Id == booking.RoomId).First();
            Context.Bookings.Add(booking);
            Context.SaveChanges();
        }

        public void Delete(int id)
        {
            Booking booking = Context.Bookings.Find(id);
            Context.Bookings.Remove(booking);
            Context.SaveChanges();
        }

        public void Dispose()
        {
            Context.Dispose();
        }

        public Booking GetBooking(int? id)
        {
            return Context.Bookings.Where(x => x.Id == id).First();
        }

        public List<Booking> GetBookings()
        {
            return Context.Bookings.Include(b => b.Room).ToList();
        }

        public void Update(Booking booking)
        {
            Context.Bookings.AddOrUpdate(booking);
            Context.SaveChanges();
        }
    }
}
