﻿using hotelDeBotel.Models;
using Repository.Interfaces;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace Repository.Repositories
{
    public class RoomsRepository : BaseRepository, IRoomsRepository
    {
        public void Create(Room room)
        {
            Context.Rooms.Add(room);
            Context.SaveChanges();
        }

        public void Delete(int id)
        {
            Room room = Context.Rooms.Find(id);
            Context.Rooms.Remove(room);
            Context.SaveChanges();
        }

        public void Dispose()
        {
            Context.Dispose();
        }

        public Room GetRoom(int? id)
        {
            return Context.Rooms.Where(x => x.Id == id).First();
        }

        public List<Room> GetRooms()
        {
            return Context.Rooms.ToList();
        }

        public int GetRoomsCount()
        {
            return Context.Rooms.Count();
        }

        public void Update(Room room)
        {
            Context.Entry(room).State = EntityState.Modified;
            Context.SaveChanges();
        }
    }
}
