﻿using hotelDeBotel.Models;

namespace Repository.Repositories
{
    public class BaseRepository
    {
        public MyContext Context { get; set; }

        public BaseRepository()
        {
            Context = new MyContext();
        }
    }
}
