﻿using hotelDeBotel.Models;
using hotelDeBotel.Repositories.Interfaces;
using Repository.Repositories;
using System;
using System.Globalization;
using System.Linq;

namespace hotelDeBotel.Repositories.RepositoryClasses
{
    public class DiscountRepository : BaseRepository, IDiscountRepository
    {
        private Random _random;
        private GregorianCalendar _gregorianCalendar;

        public int _discount;

        public DiscountRepository()
        {
            _random = new Random();
            _gregorianCalendar = new GregorianCalendar(GregorianCalendarTypes.Localized);

            _discount = 0;
        }

        public int GetDiscount(Booking booking)
        {
            SetMondayTuesdayDiscount(booking);
            SetWeekNumberDiscount(booking);
            SetAmountOfRoomsDiscount();
            SetCharacterDiscount(booking);
            SetMultiplierToDiscount();
            SetDiscountLimit();

            return _discount;
        }

        public void SetMondayTuesdayDiscount(Booking booking)
        {
            if (booking.ReservationDate.DayOfWeek == DayOfWeek.Monday ||
                booking.ReservationDate.DayOfWeek == DayOfWeek.Tuesday)
            {
                _discount += 15;
            }
        }

        public void SetWeekNumberDiscount(Booking booking)
        {
            int weekNumber = _gregorianCalendar.GetWeekOfYear(booking.ReservationDate, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

            if (weekNumber % 2 == 0)
            {
                _discount += 3;
            }
        }

        public void SetAmountOfRoomsDiscount()
        {
            _discount += Context.Rooms.Count();
        }

        public void SetCharacterDiscount(Booking booking)
        {
            char letter = 'A';
            foreach (var customer in booking.Customers)
            {
                foreach (char s in customer.Name.ToUpper())
                {
                    if (s.Equals(letter))
                    {
                        _discount += 2;
                        letter++;
                    }
                }
            }
        }

        public void SetMultiplierToDiscount()
        {
            _discount *= _random.Next(5) + 1;
        }

        public void SetDiscountLimit()
        {
            if (_discount > 60)
            {
                _discount = 60;
            }
        }
    }
}