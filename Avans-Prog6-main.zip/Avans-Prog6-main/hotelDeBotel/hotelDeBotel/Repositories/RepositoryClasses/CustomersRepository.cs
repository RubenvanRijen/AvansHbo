﻿using hotelDeBotel.Models;
using Repository.Interfaces;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace Repository.Repositories
{
    public class CustomersRepository : BaseRepository, ICustomersRepository
    {
        public void Create(Customer Customer)
        {
            Context.Customers.Add(Customer);
            Context.SaveChanges();
        }

        public void Delete(int id)
        {
            Customer customer = Context.Customers.Find(id);
            Context.Customers.Remove(customer);
            Context.SaveChanges();
        }

        public void Dispose()
        {
            Context.Dispose();
        }

        public Customer GetCustomer(int? id)
        {
            return Context.Customers.Where(x => x.Id == id).First();
        }

        public List<Customer> GetCustomers()
        {
            return Context.Customers.ToList();
        }

        public void Update(Customer Customer)
        {
            Context.Entry(Customer).State = EntityState.Modified;
            Context.SaveChanges();
        }
    }
}
