﻿using hotelDeBotel.Models;
using System.Collections.Generic;

namespace Repository.Interfaces
{
    public interface IRoomsRepository
    {
        Room GetRoom(int? id);
        List<Room> GetRooms();
        void Create(Room room);
        void Update(Room room);
        int GetRoomsCount();
        void Delete(int id);
        void Dispose();
    }
}
