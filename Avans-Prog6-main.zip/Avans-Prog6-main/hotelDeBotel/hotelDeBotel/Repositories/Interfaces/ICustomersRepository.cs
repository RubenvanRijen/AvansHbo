﻿using hotelDeBotel.Models;
using System.Collections.Generic;

namespace Repository.Interfaces
{
    public interface ICustomersRepository
    {
        Customer GetCustomer(int? id);
        List<Customer> GetCustomers();
        void Create(Customer Customer);
        void Update(Customer Customer);
        void Delete(int id);
        void Dispose();
    }
}
