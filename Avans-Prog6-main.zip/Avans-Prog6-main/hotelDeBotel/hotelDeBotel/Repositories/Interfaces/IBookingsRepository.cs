﻿using hotelDeBotel.Models;
using System.Collections.Generic;

namespace Repository.Interfaces
{
    public interface IBookingsRepository
    {
        Booking GetBooking(int? id);
        List<Booking> GetBookings();
        void Create(Booking booking);
        void Update(Booking booking);
        void Delete(int id);
        void Dispose();
    }
}
