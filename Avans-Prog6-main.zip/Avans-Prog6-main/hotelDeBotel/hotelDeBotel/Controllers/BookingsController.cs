﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Web.Mvc;
using hotelDeBotel.DiscountService;
using hotelDeBotel.Models;
using hotelDeBotel.Models.Validate;
using hotelDeBotel.Repositories.Interfaces;
using hotelDeBotel.ViewModels.Wizard;
using Repository.Interfaces;

namespace hotelDeBotel.Controllers
{
    public class BookingsController : Controller
    {
        private IBookingsRepository _bookingsRepository;
        private IRoomsRepository _roomsRepository;

        public BookingsController(IBookingsRepository bookingsRepository, IRoomsRepository roomsRepository)
        {
            _bookingsRepository = bookingsRepository;
            _roomsRepository = roomsRepository;
        }

        public ActionResult BookingsList()
        {
            var bookings = _bookingsRepository.GetBookings();
            return View(bookings);
        }

        public ActionResult StepOne(int id)
        {
            WizardViewModel wizardViewModel = new WizardViewModel();
            wizardViewModel.Room = _roomsRepository.GetRoom(id);
            wizardViewModel.Booking = new Booking();
            wizardViewModel.Booking.Room = wizardViewModel.Room;
            wizardViewModel.Booking.RoomId = wizardViewModel.Room.Id;
            Session["wizard"] = wizardViewModel;
            return View(wizardViewModel);
        }

        [HttpPost]
        public ActionResult StepOne(WizardViewModel stepOne)
        {
            if (ModelState.IsValid)
            {
                WizardViewModel wizardViewModel = (WizardViewModel)Session["wizard"];
                stepOne.Room = wizardViewModel.Room;
                stepOne.Booking = wizardViewModel.Booking;

                StepOneValidator stepOneValidator = new StepOneValidator();
                if(stepOneValidator.HasErrorsInValidation(stepOne, ModelState))
                {
                    return View(stepOne);
                }
                wizardViewModel.AmountOfPeople = stepOne.AmountOfPeople;
                wizardViewModel.Booking.ReservationDate = stepOne.ReservationDate;
                Session["wizard"] = wizardViewModel;
                return RedirectToAction("StepTwo");
            }
            return View(stepOne);
        }

        public ActionResult StepTwo()
        {
            if (Session["wizard"] != null)
            {
                WizardViewModel wizardViewModel = (WizardViewModel)Session["wizard"];
                wizardViewModel.Customers = new Customer[wizardViewModel.AmountOfPeople];

                for (int i = 0; i < wizardViewModel.AmountOfPeople; i++)
                {
                    wizardViewModel.Customers[i] = new Customer();
                }
                return View(wizardViewModel);
            }
            return View();
        }

        [HttpPost]
        public ActionResult StepTwo(WizardViewModel stepTwo)
        {
            if (ModelState.IsValid)
            {
                WizardViewModel wizardViewModel = (WizardViewModel)Session["wizard"];

                wizardViewModel.Customers = stepTwo.Customers;
                wizardViewModel.Booking.Customers = wizardViewModel.Customers;

                Session["wizard"] = wizardViewModel;
                return RedirectToAction("StepThree");
            }
            return View(stepTwo);
        }

        public ActionResult StepThree()
        {
            WizardViewModel wizardViewModel = (WizardViewModel)Session["wizard"];

            Booking booking = wizardViewModel.Booking;
            List<string> customerNames = GetCustomerNames(wizardViewModel.Customers);
            booking.Discount = new DiscountServiceClient().GetDiscount(booking.ReservationDate, customerNames, _roomsRepository.GetRoomsCount());
            booking.Price = (wizardViewModel.Room.Price * (1 - ((double)booking.Discount / 100)));
            wizardViewModel.Booking = booking;

            return View(wizardViewModel);
        }

        private List<string> GetCustomerNames(Customer[] customers)
        {
            List<string> customerNames = new List<string>();
            for(int i = 0; i < customers.Length; i++)
            {
                customerNames.Add(customers[i].Name);
            }
            return customerNames;
        }

        [HttpPost]
        public ActionResult StepThree(WizardViewModel stepThree)
        {
            if (ModelState.IsValid)
            {
                WizardViewModel wizardViewModel = (WizardViewModel)Session["wizard"];
                _bookingsRepository.Create(wizardViewModel.Booking);
                return RedirectToAction("Home", "Home");
            }
            return View(stepThree);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Booking booking = _bookingsRepository.GetBooking(id);
            if (booking == null)
            {
                return HttpNotFound();
            }
            return View(booking);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Booking booking = _bookingsRepository.GetBooking(id);
            if (booking == null)
            {
                return HttpNotFound();
            }
            return View(booking);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            _bookingsRepository.Delete(id);
            return RedirectToAction("BookingsList");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _bookingsRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
