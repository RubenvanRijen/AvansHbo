﻿using System.Web.Mvc;
using hotelDeBotel.Models;
using Repository.Interfaces;
using Repository.Repositories;


namespace hotelDeBotel.Controllers
{
    public class HomeController : Controller
    {
        private IRoomsRepository _roomsRepository;
        private IBookingsRepository _bookingsRepository;

        public HomeController(IRoomsRepository roomsRepository, IBookingsRepository bookingsRepository)
        {
            _roomsRepository = roomsRepository;
            _bookingsRepository = bookingsRepository;
        }
        public ActionResult Home()
        {
            RoomsAndBookingsList mymodel = new RoomsAndBookingsList();
            mymodel.Rooms = _roomsRepository.GetRooms();
            mymodel.Bookings = _bookingsRepository.GetBookings();
            ViewBag.RoomId = new SelectList(_roomsRepository.GetRooms(), "Price", "Description", "ImageURL");
            return View(mymodel);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Wij zijn STRONG VIKING en RubenJeBro, de makers van het glorieuze Viking Village.";

            return View();
        }
    }
}
