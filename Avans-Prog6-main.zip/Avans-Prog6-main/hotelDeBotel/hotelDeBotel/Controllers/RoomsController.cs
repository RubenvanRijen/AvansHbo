﻿using System.Net;
using System.Web.Mvc;
using hotelDeBotel.Models;
using Repository.Interfaces;

namespace hotelDeBotel.Controllers
{
    public class RoomsController : Controller
    {
        private IRoomsRepository _roomsRepository;

        public RoomsController(IRoomsRepository roomsRepository)
        {
            _roomsRepository = roomsRepository;
        }

        // GET: Rooms
        public ActionResult RoomsList()
        {
            return View(_roomsRepository.GetRooms());
        }

        // GET: Rooms/Details/5
        public ActionResult BookingsInfo(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Room room = _roomsRepository.GetRoom(id);
            if (room == null)
            {
                return HttpNotFound();
            }
            return View(room);
        }
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Room room = _roomsRepository.GetRoom(id);
            if (room == null)
            {
                return HttpNotFound();
            }
            return View(room);
        }

        // GET: Rooms/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Rooms/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,AmountOfBeds,Price,Description,ImageUrl")] Room room)
        {
            if (ModelState.IsValid)
            {
                _roomsRepository.Create(room);
                return RedirectToAction("RoomsList");
            }

            return View(room);
        }

        // GET: Rooms/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Room room = _roomsRepository.GetRoom(id);
            if (room == null)
            {
                return HttpNotFound();
            }
            return View(room);
        }

        // POST: Rooms/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,AmountOfBeds,Price,Description,ImageUrl")] Room room)
        {
            if (ModelState.IsValid)
            {
                _roomsRepository.Update(room);
                return RedirectToAction("RoomsList");
            }
            return View(room);
        }

        // GET: Rooms/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Room room = _roomsRepository.GetRoom(id);
            if (room == null)
            {
                return HttpNotFound();
            }
            return View(room);
        }

        // POST: Rooms/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            _roomsRepository.Delete(id);
            return RedirectToAction("RoomsList");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _roomsRepository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
