﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(HotelDeBotels.Startup))]
namespace HotelDeBotels
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
