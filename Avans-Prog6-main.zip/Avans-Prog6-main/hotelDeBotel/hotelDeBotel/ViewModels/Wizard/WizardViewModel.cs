﻿using hotelDeBotel.Models;
using System;

namespace hotelDeBotel.ViewModels.Wizard
{
    public class WizardViewModel
    {
        public Room Room { get; set; }
        public Booking Booking { get; set; }
        public Customer[] Customers { get; set; }
        public int AmountOfPeople { get; set; }
        public DateTime ReservationDate { get; set; }
    }
}