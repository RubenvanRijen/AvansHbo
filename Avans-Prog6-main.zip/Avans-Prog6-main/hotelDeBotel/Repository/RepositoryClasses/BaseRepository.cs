﻿using hotelDeBotel.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repository.Repositories
{
    public class BaseRepository
    {
        public MyContext Context { get; set; }

        public BaseRepository()
        {
            Context = new MyContext();
        }
    }
}
