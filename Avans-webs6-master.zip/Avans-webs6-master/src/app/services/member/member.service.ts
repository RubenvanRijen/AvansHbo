import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {AngularFirestore, AngularFirestoreCollection} from '@angular/fire/firestore';
import {map} from 'rxjs/operators';
import {IMember} from "../../models/IMember";

@Injectable({
  providedIn: 'root',
})
export class MemberService {
  private MEMBERS_COLLECTION_NAME = 'members';
  members: Observable<IMember[]>;
  membersCollection: AngularFirestoreCollection<IMember>;

  constructor(private angularFirestore: AngularFirestore) {
    this.membersCollection = angularFirestore.collection<IMember>(this.MEMBERS_COLLECTION_NAME);
  }

  getMembers() {
    return this.membersCollection.snapshotChanges().pipe(map(actions => {
      return actions.map(action => ({uid: action.payload.doc.id, ...action.payload.doc.data()}));
    }));
  }

  getMember(memberUid: string){
    const memberDocuments = this.angularFirestore.doc<IMember>(
      `${this.MEMBERS_COLLECTION_NAME}/${memberUid}`
    );
    return memberDocuments.snapshotChanges().pipe(
      map((changes) => {
        const data = changes.payload.data();
        const uid = changes.payload.id;
        return {uid, ...data};
      })
    );
  }

  getMembersFromProject(projectUID: string) {
    let data = this.angularFirestore.collection(this.MEMBERS_COLLECTION_NAME, ref => ref.where('projectUID', '==', projectUID));
    return data.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as IMember;
        const uid = a.payload.doc.id;
        return {uid, ...data};
      }))
    );
  }

  getOneMemberFromOneProject(projectUID: string, userUID: string) {
    let data = this.angularFirestore.collection(this.MEMBERS_COLLECTION_NAME, ref => ref.where('projectUID', '==', projectUID)
      .where('userUID', '==', userUID));
    return data.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as IMember;
        const uid = a.payload.doc.id;
        return {uid, ...data};
      }))
    );
  }

  getAllProjectsFromMember(userUID: string) {
    let data = this.angularFirestore.collection(this.MEMBERS_COLLECTION_NAME, ref => ref.where('userUID', '==', userUID));
    return data.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as IMember;
        const uid = a.payload.doc.id;
        return {uid, ...data};
      }))
    );
  }

  async createMember(member: IMember) {
    return this.angularFirestore.collection(this.MEMBERS_COLLECTION_NAME).add(member);
  }

  async deleteMember(memberUID: string) {
    return this.angularFirestore.collection(this.MEMBERS_COLLECTION_NAME).doc(memberUID).delete().then(resulst => {
    }).catch(error => {
      console.log(error);
    });
  }

  async editMember(uid: string, member: IMember) {
    return this.angularFirestore.collection(this.MEMBERS_COLLECTION_NAME).doc(uid).update(member).then(result => {
    }).catch(error => {
      console.log(error);
    });

  }
}
