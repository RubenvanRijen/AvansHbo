import {TestBed} from '@angular/core/testing';

import {MemberService} from './member.service';
import {IUser} from "../../models/IUser";
import {IEpic} from "../../models/IEpic";
import {Observable, of} from "rxjs";
import {IMember} from "../../models/IMember";
import {ParticipantRol} from "../../models/ParticipantRol.enum";
import {RouterTestingModule} from "@angular/router/testing";
import {AngularFirestore} from "@angular/fire/firestore";
import {AngularFireAuth} from "@angular/fire/auth";

describe('MemberService', () => {
  let service: MemberService;
  let angularFirestoreMock;
  const authState: IUser = {
    displayName: "jim",
    email: "jim@gmail.com",
    uid: '17WvU2Vj58SnTz8v7EqyYYb0WRc2'
  };

  const member1 = <IMember>{
    uid: "1",
    projectUID: "1",
    rol: ParticipantRol.admin,
    userUID: "1",
    displayName: "displayName1"
  }

  const mockAngularFireAuth: any = {
    auth: jasmine.createSpyObj('auth', {
      'signInAnonymously': Promise.reject({
        code: 'auth/operation-not-allowed'
      }),
      // 'signInWithPopup': Promise.reject(),
      // 'signOut': Promise.reject()
    }),
    authState: of(authState)
  };
  beforeEach(() => {
    angularFirestoreMock = {
      collection<T>(path, queryFn) {
        return {
          valueChanges(options): Observable<any[]> {
            return of([member1]);
          },

          snapshotChanges(options): Observable<any[]> {
            return of([{
              payload: {
                doc: {
                  uid: '1',
                  data: () => (member1)
                }
              }
            }])
          },
          add(doc): Promise<IEpic> {
            return Promise.resolve(doc);
          },

          doc<T>(path) {
            return {
              valueChanges(): Observable<IMember> {
                return of(
                  member1
                )
              },
              update(doc): Promise<void> {
                return Promise.resolve();
              },

              delete(): Promise<void> {
                return Promise.resolve();
              }
            }
          }

        }
      },

      doc<T>(path) {
        return {
          valueChanges(): Observable<IMember> {
            return of(
              member1
            )
          },
          set(doc): Promise<void> {
            return Promise.resolve();
          },

          delete(): Promise<void> {
            return Promise.resolve();
          }
        }
      }
    }
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],

      providers: [
        {provide: AngularFirestore, useValue: angularFirestoreMock},
        {provide: AngularFireAuth, useValue: mockAngularFireAuth},

      ]
    });
    service = TestBed.inject(MemberService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it("should return memebers", () => {
    let epicsData = service.getMembers();
    epicsData.subscribe(data => {
      expect(data.length).toBe(1);
    })
  });

  it("should return members from project", () => {
    service.getMembersFromProject('1').subscribe(value => {
      expect(value).toEqual([member1]);
    })
  });

  it("should return one members from one project", () => {
    service.getOneMemberFromOneProject('1', '1').subscribe(value => {
      expect(value).toEqual([member1]);
    })
  });

  it("should return projects from memebers", () => {
    service.getAllProjectsFromMember('1').subscribe(value => {
      expect(value.length).toEqual(1);
    })
  });

  it("should create member", () => {
    spyOn(service, 'createMember').and.callThrough();
    service.createMember(member1);
    expect(service.createMember).toHaveBeenCalled();
  });

  it("should update member", () => {
    spyOn(service, 'editMember').and.callThrough();
    service.editMember("1", member1);
    expect(service.editMember).toHaveBeenCalled();
  });

  it("should delete member", () => {
    spyOn(service, 'deleteMember').and.callThrough();
    service.deleteMember("1");
    expect(service.deleteMember).toHaveBeenCalled();
  });


});
