import {TestBed} from '@angular/core/testing';

import {AuthGuardService} from './auth-guard.service';
import {AuthenticationService} from "../authentication/Authentication.service";
import {MockAuthenticationService} from "../../MockServices/MockAuthenticationService";
import {IUser} from "../../models/IUser";
import {Observable, of} from "rxjs";
import {AngularFireAuth} from "@angular/fire/auth";
import {AngularFirestore} from "@angular/fire/firestore";
import {RouterTestingModule} from "@angular/router/testing";

class MockRouter {
  navigate(path) {
  }
}

describe('AuthGuardService', () => {
  let service: AuthGuardService;
  let angularFirestoreMock;

  beforeEach(() => {
    const authState: IUser = {
      displayName: "jim",
      email: "jim@gmail.com",
      uid: '17WvU2Vj58SnTz8v7EqyYYb0WRc2'
    };

    const mockAngularFireAuth: any = {
      auth: jasmine.createSpyObj('auth', {
        'signInAnonymously': Promise.reject({
          code: 'auth/operation-not-allowed'
        }),
        // 'signInWithPopup': Promise.reject(),
        // 'signOut': Promise.reject()
      }),
      authState: of(authState)
    };

    angularFirestoreMock = {
      collection<T>(path, queryFn) {
        return {
          valueChanges(options): Observable<any[]> {
            return of([null]);
          },

          snapshotChanges(options): Observable<any[]> {
            return of([{
              payload: {
                doc: {
                  id: 'projectid',
                  data: () => (null)
                }
              }
            }])
          },

          add(doc): Promise<IUser> {
            return Promise.resolve(doc);
          },

          doc<T>(path) {
            return {
              valueChanges(): Observable<IUser> {
                return of(
                  null
                )
              },
              set(doc): Promise<void> {
                return Promise.resolve();
              },

              delete(): Promise<void> {
                return Promise.resolve();
              }
            }
          }

        }
      },

      doc<T>(path) {
        return {
          valueChanges(): Observable<IUser> {
            return of(
              null
            )
          },
          set(doc): Promise<void> {
            return Promise.resolve();
          },

          delete(): Promise<void> {
            return Promise.resolve();
          }
        }
      }
    }

    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        {provider: AuthenticationService, useClass: MockAuthenticationService},
        {provide: AngularFireAuth, useValue: mockAngularFireAuth},
        {provide: AngularFirestore, useValue: angularFirestoreMock},

      ]
    });
    service = TestBed.inject(AuthGuardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it("should be able to see page", () =>{
    spyOn(service, 'canActivate').and.callThrough();
    service.canActivate(null, null);
    expect(service.canActivate).toHaveBeenCalled();
  });
  it("should be able to see child page", () =>{
    spyOn(service, 'canActivateChild').and.callThrough();
    service.canActivateChild(null, null);
    expect(service.canActivateChild).toHaveBeenCalled();
  });

});
