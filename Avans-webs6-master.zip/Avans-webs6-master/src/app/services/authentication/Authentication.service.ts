import {Injectable} from '@angular/core';
import {AngularFirestore} from '@angular/fire/firestore';
import {AngularFireAuth} from '@angular/fire/auth';
import {Router} from '@angular/router';
import {first} from 'rxjs/operators';
import {UserService} from "../user/user.service";

@Injectable({
  providedIn: 'root',
})
export class AuthenticationService {
  user: any;


  constructor(
    private angularFireAuth: AngularFireAuth,
    private userService: UserService
  ) {
    this.angularFireAuth.authState.subscribe((user) => {
      if (user) {
        this.user = user;
        localStorage.setItem('user', JSON.stringify(this.user));
      } else {
        localStorage.setItem('user', null);
      }
    });


  }

  async login(email: string, password: string) {
    const result = await this.angularFireAuth.signInWithEmailAndPassword(
      email,
      password
    );
  }


  async register(email: string, password: string, username: string) {
    const result = await this.angularFireAuth.createUserWithEmailAndPassword(
      email,
      password
    );
    let user = result.user;
    if (user) {
      await user.updateProfile({displayName: username});
      await this.userService.addUser(username, email, user.uid);
    }
  }

  async getUser() {
    return JSON.parse((localStorage.getItem("user")));
  }

  async logout() {
    await this.angularFireAuth.signOut().then(function () {
      localStorage.removeItem('user');
    }).catch(function (error) {
      console.log(error);
    });
  }

  userStatus() {
    return this.angularFireAuth.authState;
  }

  loggedInUser() {
    return this.angularFireAuth.authState.pipe(first()).toPromise();
  }

  async returnLoggedInUser() {
    const user = await this.loggedInUser()
    if (user) {
      return user;
    } else {
      return null;
    }
  }
}
