import {TestBed} from '@angular/core/testing';

import {AuthenticationService} from './Authentication.service';
import {Observable, of} from "rxjs";
import {IUser} from "../../models/IUser";
import {AngularFirestore} from "@angular/fire/firestore";
import {UserService} from "../user/user.service";
import {MockUserService} from "../../MockServices/MockUserService";
import {AngularFireAuth} from "@angular/fire/auth";
import {RouterTestingModule} from "@angular/router/testing";


describe('AuthenticationService', () => {
  let service: AuthenticationService;
  let angularFirestoreMock;
  // An anonymous user
  const authState: IUser = {
    displayName: "jim",
    email: "jim@gmail.com",
    uid: '17WvU2Vj58SnTz8v7EqyYYb0WRc2'
  };

  const mockAngularFireAuth: any = {
    auth: jasmine.createSpyObj('auth', {
      'signInAnonymously': Promise.reject({
        code: 'auth/operation-not-allowed'
      }),
      // 'signInWithPopup': Promise.reject(),
      // 'signOut': Promise.reject()
    }),
    authState: of(authState)
  };
  beforeEach(() => {
    angularFirestoreMock = {
      collection<T>(path, queryFn) {
        return {
          valueChanges(options): Observable<any[]> {
            return of([null]);
          },

          snapshotChanges(options): Observable<any[]> {
            return of([{
              payload: {
                doc: {
                  id: 'projectid',
                  data: () => (null)
                }
              }
            }])
          },

          add(doc): Promise<IUser> {
            return Promise.resolve(doc);
          },

          doc<T>(path) {
            return {
              valueChanges(): Observable<IUser> {
                return of(
                  null
                )
              },
              set(doc): Promise<void> {
                return Promise.resolve();
              },

              delete(): Promise<void> {
                return Promise.resolve();
              }
            }
          }

        }
      },

      doc<T>(path) {
        return {
          valueChanges(): Observable<IUser> {
            return of(
              null
            )
          },
          set(doc): Promise<void> {
            return Promise.resolve();
          },

          delete(): Promise<void> {
            return Promise.resolve();
          }
        }
      }
    }
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],

      providers: [
        {provide: AngularFirestore, useValue: angularFirestoreMock},
        {provide: UserService, useValue: MockUserService},
        {provide: AngularFireAuth, useValue: mockAngularFireAuth},

      ]
    });
    service = TestBed.inject(AuthenticationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it("should login", () => {
    service.login("jim@gmail.com", "Test123?");
    expect(service.login("jim@gmail.com", "Test123?")).toBeTruthy();
  });

  it("Should register", () => {
    service.register("ruben2@gmail.com", "Test123?", "Ruben1");
    expect(service.register("ruben2@gmail.com", "Test123?", "Ruben1")).toBeTruthy();
  });

  it("should return user", () => {
    service.getUser().then(user => {
      expect(user.displayName).toBe("jim");
    });
  });

  it("should logout", () => {
    spyOn(service, 'logout').and.callThrough();
    service.logout();
    expect(service.logout).toHaveBeenCalled();
  });

  it("get user status", () => {
    spyOn(service, 'userStatus').and.callThrough();
    service.userStatus();
    expect(service.userStatus).toHaveBeenCalled();
  });

  it("get user", () => {
    spyOn(service, 'loggedInUser').and.callThrough();
    service.loggedInUser();
    expect(service.loggedInUser).toHaveBeenCalled();
  });

  it("get logged in user", () => {
    service.returnLoggedInUser().then(user => {
      expect(user.displayName).toBe("jim");
    });
  });
});
