import {TestBed} from '@angular/core/testing';

import {SprintService} from './sprint.service';
import {IUser} from "../../models/IUser";
import {IProject} from "../../models/IProject";
import {ProjectStatus} from "../../models/ProjectStatus.enum";
import {Observable, of} from "rxjs";
import {ISprint} from "../../models/ISprint";
import {SprintStatus} from "../../models/SprintStatus.enum";
import {IEpic} from "../../models/IEpic";
import {RouterTestingModule} from "@angular/router/testing";
import {AngularFirestore} from "@angular/fire/firestore";
import {AngularFireAuth} from "@angular/fire/auth";

describe('SprintService', () => {
  let service: SprintService;
  let angularFirestoreMock;
  const authState: IUser = {
    displayName: "jim",
    email: "jim@gmail.com",
    uid: '17WvU2Vj58SnTz8v7EqyYYb0WRc2'
  };

  const sprint = <ISprint>{
    endDate: "2020-05-05",
    projectUID: "1",
    startDate: "2020-04-04",
    title: "Title1",
    status: SprintStatus.Planning,
    description: "description1",
    uid: "1"
  };

  const mockAngularFireAuth: any = {
    auth: jasmine.createSpyObj('auth', {
      'signInAnonymously': Promise.reject({
        code: 'auth/operation-not-allowed'
      }),
    }),
    authState: of(authState)
  };
  beforeEach(() => {
    angularFirestoreMock = {
      collection<T>(path, queryFn) {
        return {
          valueChanges(options): Observable<any[]> {
            return of([sprint]);
          },

          snapshotChanges(options): Observable<any[]> {
            return of([{
              payload: {
                doc: {
                  uid: '1',
                  data: () => (sprint)
                }
              }
            }])
          },
          add(doc): Promise<IEpic> {
            return Promise.resolve(doc);
          },

          doc<T>(path) {
            return {
              valueChanges(): Observable<ISprint> {
                return of(
                  sprint
                )
              },
              update(doc): Promise<void> {
                return Promise.resolve();
              },
              set(doc): Promise<void> {
                return Promise.resolve();
              },
              delete(): Promise<void> {
                return Promise.resolve();
              }
            }
          }

        }
      },

      doc<T>(path) {
        return {
          valueChanges(): Observable<ISprint> {
            return of(
              sprint
            )
          },
          set(doc): Promise<void> {
            return Promise.resolve();
          },

          delete(): Promise<void> {
            return Promise.resolve();
          }
        }
      }
    }
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],

      providers: [
        {provide: AngularFirestore, useValue: angularFirestoreMock},
        {provide: AngularFireAuth, useValue: mockAngularFireAuth},

      ]
    });
    service = TestBed.inject(SprintService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it("should return sprints", () => {
    let epicsData = service.getSprints();
    epicsData.subscribe(data => {
      expect(data.length).toBe(1);
    })
  });

  it("should return sprints from projects", () => {
    service.getSprintsFromProject('1').subscribe(value => {
      expect(value).toEqual([sprint]);
    })
  });

  it("change sprint", () => {
    spyOn(service, 'changeActiveSprint').and.callThrough();
    service.changeActiveSprint("1", "true");
    expect(service.changeActiveSprint).toHaveBeenCalled();
  });


  it("should create sprint", () => {
    spyOn(service, 'createSprint').and.callThrough();
    service.createSprint(sprint);
    expect(service.createSprint).toHaveBeenCalled();
  });

  it("should update sprint", () => {
    spyOn(service, 'updateSprint').and.callThrough();
    service.updateSprint(sprint, "1");
    expect(service.updateSprint).toHaveBeenCalled();
  });


  it("should delete sprint", () => {
    spyOn(service, 'deleteSprint').and.callThrough();
    service.deleteSprint("1");
    expect(service.deleteSprint).toHaveBeenCalled();
  });

});
