import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {
  AngularFirestore,
  AngularFirestoreCollection,
} from '@angular/fire/firestore';
import {ISprint} from 'src/app/models/ISprint';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class SprintService {
  private SPRINTS_COLLECTION_NAME = 'sprints';
  private sprintCollection: AngularFirestoreCollection<ISprint>;
  public sprints: Observable<ISprint[]>;

  constructor(private angularFirestore: AngularFirestore) {
    this.sprintCollection = angularFirestore.collection<ISprint>(
      this.SPRINTS_COLLECTION_NAME
    );
  }

  getSprints() {
    return this.sprintCollection.snapshotChanges().pipe(
      map((actions) => {
        return actions.map((action) => ({
          uid: action.payload.doc.id,
          ...action.payload.doc.data(),
        }));
      })
    );
  }

  getSprint(uid: string) {
    const sprintDocuments = this.angularFirestore.doc<ISprint>(
      `${this.SPRINTS_COLLECTION_NAME}/${uid}`
    );
    return sprintDocuments.snapshotChanges().pipe(
      map((changes) => {
        const data = changes.payload.data();
        const uid = changes.payload.id;
        return {uid, ...data};
      })
    );
  }

  createSprint(sprint: ISprint) {
    return this.angularFirestore
      .collection(this.SPRINTS_COLLECTION_NAME)
      .add(sprint);
  }

  updateSprint(sprint: ISprint, uid: string) {
    return this.angularFirestore
      .collection(this.SPRINTS_COLLECTION_NAME)
      .doc(uid)
      .update(sprint);
  }

  changeActiveSprint(uid: string, value: string) {
    return this.angularFirestore.collection(this.SPRINTS_COLLECTION_NAME).doc(uid)
      .set({status: value}, {merge: true});
  }

  deleteSprint(uid: string) {
    return this.angularFirestore
      .doc(`${this.SPRINTS_COLLECTION_NAME}/` + uid)
      .delete();
  }

  getSprintsFromProject(uid: string) {
    const sprintCollection = this.angularFirestore.collection<ISprint>(
      this.SPRINTS_COLLECTION_NAME,
      (ref) => ref.where('projectUID', '==', uid)
    );
    return sprintCollection.snapshotChanges().pipe(
      map((actions) =>
        actions.map((a) => {
          const data = a.payload.doc.data() as ISprint;
          const uid = a.payload.doc.id;
          return {uid, ...data};
        })
      )
    );
  }
}
