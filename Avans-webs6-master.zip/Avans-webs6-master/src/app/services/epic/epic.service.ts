import {Injectable} from '@angular/core';
import {AngularFirestore, AngularFirestoreCollection} from "@angular/fire/firestore";
import {Observable} from "rxjs";
import {IEpic} from "../../models/IEpic";
import {map} from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class EpicService {

  private EPIC_COLLECTION_NAME = 'epics';
  private epicCollection: AngularFirestoreCollection<IEpic>;
  public epics: Observable<IEpic[]>;

  constructor(private angularFirestore: AngularFirestore) {
    this.epicCollection = angularFirestore.collection<IEpic>(this.EPIC_COLLECTION_NAME);
  }

  getAllEpics() {
    return this.epicCollection.snapshotChanges().pipe(map(actions => {
      return actions.map(action => ({uid: action.payload.doc.id, ...action.payload.doc.data()}));
    }));
  }

  getEpic(uid: string) {
    const epicDocument = this.angularFirestore.doc<IEpic>(`${this.EPIC_COLLECTION_NAME}/${uid}`);
    return epicDocument.snapshotChanges()
      .pipe(
        map(changes => {
          const data = changes.payload.data();
          const uid = changes.payload.id;
          return {uid, ...data};
        }));
  }

  getEpicsFromProject(uid: string) {
    const epicCollection = this.angularFirestore.collection<IEpic>(this.EPIC_COLLECTION_NAME, ref => ref.where('projectUID', '==', uid));
    return epicCollection.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as IEpic;
        const uid = a.payload.doc.id;
        return {uid, ...data};
      }))
    );
  }

  createEpic(epic: IEpic) {
    return this.angularFirestore.collection(this.EPIC_COLLECTION_NAME).add(epic);
  }

  deleteEpic(uid: string) {
    return this.angularFirestore.doc(`${this.EPIC_COLLECTION_NAME}/` + uid).delete();
  }

  updateEpic(uid:string, epic: IEpic) {
    return this.angularFirestore.collection(this.EPIC_COLLECTION_NAME).doc(uid)
      .update(epic);
  }

}
