import {TestBed} from '@angular/core/testing';

import {EpicService} from './epic.service';
import {IUser} from "../../models/IUser";
import {Observable, of} from "rxjs";
import {RouterTestingModule} from "@angular/router/testing";
import {AngularFirestore} from "@angular/fire/firestore";
import {UserService} from "../user/user.service";
import {MockUserService} from "../../MockServices/MockUserService";
import {AngularFireAuth} from "@angular/fire/auth";
import {IEpic} from "../../models/IEpic";

describe('EpicService', () => {
  let service: EpicService;
  let angularFirestoreMock;
  const authState: IUser = {
    displayName: "jim",
    email: "jim@gmail.com",
    uid: '17WvU2Vj58SnTz8v7EqyYYb0WRc2'
  };

  let epic = <IEpic>{
    title: "title",
    color: "red",
    projectUID: "1",
    uid: "1"
  }

  const mockAngularFireAuth: any = {
    auth: jasmine.createSpyObj('auth', {
      'signInAnonymously': Promise.reject({
        code: 'auth/operation-not-allowed'
      }),
      // 'signInWithPopup': Promise.reject(),
      // 'signOut': Promise.reject()
    }),
    authState: of(authState)
  };
  beforeEach(() => {
    angularFirestoreMock = {
      collection<T>(path, queryFn) {
        return {
          valueChanges(options): Observable<any[]> {
            return of([epic]);
          },

          snapshotChanges(options): Observable<any[]> {
            return of([{
              payload: {
                doc: {
                  uid: '1',
                  data: () => (epic)
                }
              }
            }])
          },
          add(doc): Promise<IEpic> {
            return Promise.resolve(doc);
          },

          doc<T>(path) {
            return {
              valueChanges(): Observable<IEpic> {
                return of(
                  epic
                )
              },
              update(doc): Promise<void> {
                return Promise.resolve();
              },

              delete(): Promise<void> {
                return Promise.resolve();
              }
            }
          }

        }
      },

      doc<T>(path) {
        return {
          valueChanges(): Observable<IEpic> {
            return of(
              epic
            )
          },
          set(doc): Promise<void> {
            return Promise.resolve();
          },

          delete(): Promise<void> {
            return Promise.resolve();
          }
        }
      }
    }
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],

      providers: [
        {provide: AngularFirestore, useValue: angularFirestoreMock},
        {provide: AngularFireAuth, useValue: mockAngularFireAuth},

      ]
    });
    service = TestBed.inject(EpicService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it("should return epics", () => {
    let epicsData = service.getAllEpics();
    epicsData.subscribe(data => {
      expect(data.length).toBe(1);
    })
  });

  it("should return epics from project", () => {
    service.getEpicsFromProject('1').subscribe(value => {
      expect(value).toEqual([epic]);
    })
  });

  it("should create epic", () => {
    spyOn(service, 'createEpic').and.callThrough();
    service.createEpic(epic);
    expect(service.createEpic).toHaveBeenCalled();
  });

  it("should update epic", () => {
    spyOn(service, 'updateEpic').and.callThrough();
    service.updateEpic("1", epic);
    expect(service.updateEpic).toHaveBeenCalled();
  });

  it("should delete epic", () => {
    spyOn(service, 'deleteEpic').and.callThrough();
    service.deleteEpic("1");
    expect(service.deleteEpic).toHaveBeenCalled();
  });

});
