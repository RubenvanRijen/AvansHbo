import {Injectable} from '@angular/core';
import {IProject} from '../../models/IProject';
import {AngularFirestore, AngularFirestoreCollection} from "@angular/fire/firestore";
import {Observable} from "rxjs";
import {map} from "rxjs/operators";

@Injectable({
  providedIn: 'root',
})
export class ProjectService {
  private PROJECTS_COLLECTION_NAME = 'projects';
  private projectCollection: AngularFirestoreCollection<IProject>;
  public projects: Observable<IProject[]>;

  constructor(private angularFirestore: AngularFirestore) {
    this.projectCollection = angularFirestore.collection<IProject>(this.PROJECTS_COLLECTION_NAME);
  }

  getProjects() {
    return this.projectCollection.snapshotChanges().pipe(map(actions => {
      return actions.map(action => ({uid: action.payload.doc.id, ...action.payload.doc.data()}));
    }));
  }

  getProject(id: string){
    const projectsDocuments = this.angularFirestore.doc<IProject>(`${this.PROJECTS_COLLECTION_NAME}/${id}`);
    return projectsDocuments.snapshotChanges()
      .pipe(
        map(changes => {
          const data = changes.payload.data();
          const uid = changes.payload.id;
          return {uid, ...data};
        }));
  }

  getOwnProjectsFiltering(uid: string, field: string, value: boolean) {
    const projectCollection = this.angularFirestore.collection<IProject>(this.PROJECTS_COLLECTION_NAME, ref => ref.where('members', 'array-contains', uid)
      .where(field, '==', value));
    return projectCollection.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as IProject;
        const uid = a.payload.doc.id;
        return {uid, ...data};
      }))
    );
  }

  getOwnProjects(uid: string) {
    const projectCollection = this.angularFirestore.collection<IProject>(this.PROJECTS_COLLECTION_NAME, ref => ref.where('members', 'array-contains', uid));
    return projectCollection.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as IProject;
        const uid = a.payload.doc.id;
        return {uid, ...data};
      }))
    );
  }

  filterProjects(field: string, value: boolean) {
    let data = this.angularFirestore.collection(this.PROJECTS_COLLECTION_NAME, ref => ref.where(field, '==', value));
    return data.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as IProject;
        const uid = a.payload.doc.id;
        return {uid, ...data};
      }))
    );
  }

  createProject(project: IProject) {
    return this.angularFirestore.collection(this.PROJECTS_COLLECTION_NAME).add(project);
  }

  updateProjectArchive(project: IProject) {
    return this.angularFirestore.collection(this.PROJECTS_COLLECTION_NAME).doc(project.uid)
      .set({archived: project.archived}, {merge: true});
  }

  updateProjectParticipants(project: IProject) {
    return this.angularFirestore.collection(this.PROJECTS_COLLECTION_NAME).doc(project.uid)
      .set({members: project.members}, {merge: true});
  }

  updateProject(project: IProject, uid: string) {
    return this.angularFirestore.collection(this.PROJECTS_COLLECTION_NAME).doc(uid)
      .update(project);
  }

  deleteProject(projectUID: string) {
    return this.angularFirestore.doc(`${this.PROJECTS_COLLECTION_NAME}/` + projectUID).delete();
  }

}
