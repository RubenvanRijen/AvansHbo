import {TestBed} from '@angular/core/testing';

import {ProjectService} from './project.service';
import {IUser} from "../../models/IUser";
import {Observable, of} from "rxjs";
import {IProject} from "../../models/IProject";
import {ProjectStatus} from "../../models/ProjectStatus.enum";
import {IEpic} from "../../models/IEpic";
import {RouterTestingModule} from "@angular/router/testing";
import {AngularFirestore} from "@angular/fire/firestore";
import {AngularFireAuth} from "@angular/fire/auth";

describe('ProjectService', () => {
  let service: ProjectService;
  let angularFirestoreMock;
  const authState: IUser = {
    displayName: "jim",
    email: "jim@gmail.com",
    uid: '17WvU2Vj58SnTz8v7EqyYYb0WRc2'
  };

  const project = <IProject>{
    memberUID: "1",
    displayNameUser: "displayName1",
    uid: "1",
    title: "Title1",
    description: "description1",
    owner: "owner1",
    status: ProjectStatus.Closed,
    archived: false,
    members: ["erwin"],
    isMember: true,
  }

  const mockAngularFireAuth: any = {
    auth: jasmine.createSpyObj('auth', {
      'signInAnonymously': Promise.reject({
        code: 'auth/operation-not-allowed'
      }),
    }),
    authState: of(authState)
  };
  beforeEach(() => {
    angularFirestoreMock = {
      collection<T>(path, queryFn) {
        return {
          valueChanges(options): Observable<any[]> {
            return of([project]);
          },

          snapshotChanges(options): Observable<any[]> {
            return of([{
              payload: {
                doc: {
                  uid: '1',
                  data: () => (project)
                }
              }
            }])
          },
          add(doc): Promise<IEpic> {
            return Promise.resolve(doc);
          },

          doc<T>(path) {
            return {
              valueChanges(): Observable<IProject> {
                return of(
                  project
                )
              },
              update(doc): Promise<void> {
                return Promise.resolve();
              },
              set(doc): Promise<void> {
                return Promise.resolve();
              },
              delete(): Promise<void> {
                return Promise.resolve();
              }
            }
          }

        }
      },

      doc<T>(path) {
        return {
          valueChanges(): Observable<IProject> {
            return of(
              project
            )
          },
          set(doc): Promise<void> {
            return Promise.resolve();
          },

          delete(): Promise<void> {
            return Promise.resolve();
          }
        }
      }
    }
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],

      providers: [
        {provide: AngularFirestore, useValue: angularFirestoreMock},
        {provide: AngularFireAuth, useValue: mockAngularFireAuth},

      ]
    });
    service = TestBed.inject(ProjectService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it("should return projects", () => {
    let epicsData = service.getProjects();
    epicsData.subscribe(data => {
      expect(data.length).toBe(1);
    })
  });

  it("should return own projects", () => {
    service.getOwnProjects('1').subscribe(value => {
      expect(value).toEqual([project]);
    })
  });

  it("should return one members from one project", () => {
    service.getOwnProjectsFiltering('1', 'UID', true).subscribe(value => {
      expect(value).toEqual([project]);
    })
  });

  it("should filter projects", () => {
    service.filterProjects('1', true).subscribe(value => {
      expect(value).toEqual([project]);
    })
  });


  it("should create project", () => {
    spyOn(service, 'createProject').and.callThrough();
    service.createProject(project);
    expect(service.createProject).toHaveBeenCalled();
  });

  it("should update project", () => {
    spyOn(service, 'updateProject').and.callThrough();
    service.updateProject(project, "1");
    expect(service.updateProject).toHaveBeenCalled();
  });

  it("should update project archive", () => {
    spyOn(service, 'updateProjectArchive').and.callThrough();
    service.updateProjectArchive(project);
    expect(service.updateProjectArchive).toHaveBeenCalled();
  });

  it("should update project members", () => {
    spyOn(service, 'updateProjectParticipants').and.callThrough();
    service.updateProjectParticipants(project);
    expect(service.updateProjectParticipants).toHaveBeenCalled();
  });

  it("should delete project", () => {
    spyOn(service, 'deleteProject').and.callThrough();
    service.deleteProject("1");
    expect(service.deleteProject).toHaveBeenCalled();
  });

});
