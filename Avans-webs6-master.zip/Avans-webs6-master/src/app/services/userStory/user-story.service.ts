import {Injectable} from '@angular/core';
import {IUserStory} from 'src/app/models/IUserStory';
import {Observable} from 'rxjs';
import {AngularFirestoreCollection, AngularFirestore} from '@angular/fire/firestore';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

export class UserStoryService {
  private USERSTORIES_COLLECTION_NAME = 'userStories';
  private userStoriesCollection: AngularFirestoreCollection<IUserStory>;
  public userStories: Observable<IUserStory[]>;

  constructor(private angularFirestore: AngularFirestore) {
    this.userStoriesCollection = angularFirestore.collection<IUserStory>(this.USERSTORIES_COLLECTION_NAME);
  }

  getUserStories() {
    return this.userStoriesCollection.snapshotChanges().pipe(
      map((actions) => {
        return actions.map((action) => ({
          uid: action.payload.doc.id,
          ...action.payload.doc.data(),
        }));
      })
    );
  }

  getUserStory(uid: string) {
    const userStoryDocuments = this.angularFirestore.doc<IUserStory>(`${this.USERSTORIES_COLLECTION_NAME}/${uid}`);
    return userStoryDocuments.snapshotChanges()
      .pipe(
        map(changes => {
          const data = changes.payload.data();
          const uid = changes.payload.id;
          return {uid, ...data};
        }));
  }

  updateUserStory(userStory: IUserStory, uid: string) {
    return this.angularFirestore.collection(this.USERSTORIES_COLLECTION_NAME).doc(uid)
      .update(userStory);
  }

  archiveUserStory(userStoryUID: string, type: boolean) {
    return this.angularFirestore.collection(this.USERSTORIES_COLLECTION_NAME).doc(userStoryUID)
      .set({isArchived: type}, {merge: true});
  }

  createUserStory(userStory: IUserStory) {
    return this.angularFirestore.collection(this.USERSTORIES_COLLECTION_NAME).add(userStory);
  }

  filterUserStories(field: string, uid: string) {
    let data = this.angularFirestore.collection(this.USERSTORIES_COLLECTION_NAME, ref => ref.where(field, '==', uid));
    return data.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as IUserStory;
        const uid = a.payload.doc.id;
        return {uid, ...data};
      }))
    );
  }

  filterUserStoriesWithMultipleFields(field: string, uid: string, field2: string, value: boolean) {
    let data = this.angularFirestore.collection(this.USERSTORIES_COLLECTION_NAME, ref => ref.where(field, '==', uid).where(field2, '==', value));
    return data.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as IUserStory;
        const uid = a.payload.doc.id;
        return {uid, ...data};
      }))
    );
  }

  updateUserStoryStatus(userStory: any, status: string, owner:string, ownerName:string) {
    let statusLastEdited = new Date;
    let newDate = statusLastEdited.toISOString().slice(0, 10);
    return this.angularFirestore.collection(this.USERSTORIES_COLLECTION_NAME).doc(userStory.uid)
      .set({status: status, statusLastEdited: newDate, owner:owner, ownerName: ownerName}, {merge: true});
  }

  updateUserStoryDate(userStory: any, statusLastEdited: string) {
    return this.angularFirestore.collection(this.USERSTORIES_COLLECTION_NAME).doc(userStory.uid)
      .set({statusLastEdited: statusLastEdited}, {merge: true});
  }
}
