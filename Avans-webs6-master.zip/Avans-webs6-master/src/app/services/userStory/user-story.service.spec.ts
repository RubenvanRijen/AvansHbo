import {TestBed} from '@angular/core/testing';

import {UserStoryService} from './user-story.service';
import {IUser} from "../../models/IUser";
import {IProject} from "../../models/IProject";
import {ProjectStatus} from "../../models/ProjectStatus.enum";
import {Observable, of} from "rxjs";
import {IUserStory} from "../../models/IUserStory";
import {UserStoryStatusEnum} from "../../models/UserStoryStatus.enum";
import {IEpic} from "../../models/IEpic";
import {RouterTestingModule} from "@angular/router/testing";
import {AngularFirestore} from "@angular/fire/firestore";
import {AngularFireAuth} from "@angular/fire/auth";

describe('UserStoryService', () => {
  let service: UserStoryService;
  let angularFirestoreMock;
  const authState: IUser = {
    displayName: "jim",
    email: "jim@gmail.com",
    uid: '17WvU2Vj58SnTz8v7EqyYYb0WRc2'
  };

  const userStory = <IUserStory>{
    isArchived: false,
    owner: "0123456789",
    ownerName: "Ruben",
    uid: "1",
    sprintName: "Sprint 1",
    sprintUID: "1",
    epicColor: "red",
    epicName: "epic1",
    epicUID: "1",
    storyPoints: 2,
    projectUID: "1",
    statusLastEdited: "2020-05-05",
    title: "title",
    status: UserStoryStatusEnum.New,
    description: "dit is een description"
  }

  const mockAngularFireAuth: any = {
    auth: jasmine.createSpyObj('auth', {
      'signInAnonymously': Promise.reject({
        code: 'auth/operation-not-allowed'
      }),
    }),
    authState: of(authState)
  };
  beforeEach(() => {
    angularFirestoreMock = {
      collection<T>(path, queryFn) {
        return {
          valueChanges(options): Observable<any[]> {
            return of([userStory]);
          },

          snapshotChanges(options): Observable<any[]> {
            return of([{
              payload: {
                doc: {
                  uid: '1',
                  data: () => (userStory)
                }
              }
            }])
          },
          add(doc): Promise<IEpic> {
            return Promise.resolve(doc);
          },

          doc<T>(path) {
            return {
              valueChanges(): Observable<IUserStory> {
                return of(
                  userStory
                )
              },
              update(doc): Promise<void> {
                return Promise.resolve();
              },
              set(doc): Promise<void> {
                return Promise.resolve();
              },
              delete(): Promise<void> {
                return Promise.resolve();
              }
            }
          }

        }
      },

      doc<T>(path) {
        return {
          valueChanges(): Observable<IUserStory> {
            return of(
              userStory
            )
          },
          set(doc): Promise<void> {
            return Promise.resolve();
          },

          delete(): Promise<void> {
            return Promise.resolve();
          }
        }
      }
    }
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],

      providers: [
        {provide: AngularFirestore, useValue: angularFirestoreMock},
        {provide: AngularFireAuth, useValue: mockAngularFireAuth},

      ]
    });
    service = TestBed.inject(UserStoryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it("should return userStories", () => {
    let epicsData = service.getUserStories();
    epicsData.subscribe(data => {
      expect(data.length).toBe(1);
    })
  });

  it("should return filterOne userStories", () => {
    service.filterUserStories('UID', '1').subscribe(value => {
      expect(value).toEqual([userStory]);
    })
  });

  it("should return filterTwo userStories", () => {
    service.filterUserStoriesWithMultipleFields('UID', '1', 'projectUID', true).subscribe(value => {
      expect(value).toEqual([userStory]);
    })
  });


  it("should create userStories", () => {
    spyOn(service, 'createUserStory').and.callThrough();
    service.createUserStory(userStory);
    expect(service.createUserStory).toHaveBeenCalled();
  });

  it("should update userStories", () => {
    spyOn(service, 'updateUserStory').and.callThrough();
    service.updateUserStory(userStory, "1");
    expect(service.updateUserStory).toHaveBeenCalled();
  });

  it("should update userStories archive", () => {
    spyOn(service, 'updateUserStoryStatus').and.callThrough();
    service.updateUserStoryStatus(userStory,
      'New',
      '',
      '');
    expect(service.updateUserStoryStatus).toHaveBeenCalled();
  });

  it("should update date of userStories", () => {
    spyOn(service, 'updateUserStoryDate').and.callThrough();
    service.updateUserStoryDate(userStory, "2020-05-05");
    expect(service.updateUserStoryDate).toHaveBeenCalled();
  });

});
