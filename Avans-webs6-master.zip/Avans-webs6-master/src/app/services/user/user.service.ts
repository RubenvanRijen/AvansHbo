import {Injectable} from '@angular/core';
import {IUser} from '../../models/IUser';
import {Observable} from 'rxjs';
import {AngularFirestore, AngularFirestoreCollection} from '@angular/fire/firestore';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private USERS_COLLECTION_NAME = 'users';
  users: Observable<IUser[]>;
  usersCollection: AngularFirestoreCollection<IUser>;
  countUsers = 0;

  constructor(private angularFirestore: AngularFirestore) {
    this.usersCollection = angularFirestore.collection<IUser>(this.USERS_COLLECTION_NAME);
  }

  getUsers() {
    return this.usersCollection.snapshotChanges().pipe(
      map((actions) => {
        return actions.map((action) => ({
          uid: action.payload.doc.id,
          ...action.payload.doc.data(),
        }));
      })
    );
  }

  getUser(userId: string) {
    const userDocuments = this.angularFirestore.doc<IUser>(
      `${this.USERS_COLLECTION_NAME}/${userId}`
    );
    return userDocuments.snapshotChanges().pipe(
      map((changes) => {
        const data = changes.payload.data();
        const uid = changes.payload.id;
        return {uid, ...data};
      })
    );
  }

  getUserOnEmail(email: string) {
    const userCollection = this.angularFirestore.collection<IUser>(this.USERS_COLLECTION_NAME, ref => ref.where('email', '==', email));
    return userCollection.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as IUser;
        const uid = a.payload.doc.id;
        return {uid, ...data};
      }))
    );
  }

  async addUser(displayName: string, email: string, uid: string) {
    await this.usersCollection.doc(uid).set({displayName: displayName, email: email, uid: uid});
  }
}
