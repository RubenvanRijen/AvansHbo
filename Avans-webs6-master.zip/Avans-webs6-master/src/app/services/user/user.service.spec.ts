import {TestBed} from '@angular/core/testing';

import {UserService} from './user.service';
import {IUser} from "../../models/IUser";
import {ISprint} from "../../models/ISprint";
import {SprintStatus} from "../../models/SprintStatus.enum";
import {Observable, of} from "rxjs";
import {IEpic} from "../../models/IEpic";
import {RouterTestingModule} from "@angular/router/testing";
import {AngularFirestore} from "@angular/fire/firestore";
import {AngularFireAuth} from "@angular/fire/auth";

describe('UserService', () => {
  let service: UserService;
  let angularFirestoreMock;
  const authState: IUser = {
    displayName: "jim",
    email: "jim@gmail.com",
    uid: '17WvU2Vj58SnTz8v7EqyYYb0WRc2'
  };

  const user = <IUser>{
    displayName: "displayName1",
    email: "Email1",
    uid: "1"
  };

  const mockAngularFireAuth: any = {
    auth: jasmine.createSpyObj('auth', {
      'signInAnonymously': Promise.reject({
        code: 'auth/operation-not-allowed'
      }),
    }),
    authState: of(authState)
  };
  beforeEach(() => {
    angularFirestoreMock = {
      collection<T>(path, queryFn) {
        return {
          valueChanges(options): Observable<any[]> {
            return of([user]);
          },

          snapshotChanges(options): Observable<any[]> {
            return of([{
              payload: {
                doc: {
                  uid: '1',
                  data: () => (user)
                }
              }
            }])
          },
          add(doc): Promise<IEpic> {
            return Promise.resolve(doc);
          },

          doc<T>(path) {
            return {
              valueChanges(): Observable<IUser> {
                return of(
                  user
                )
              },
              update(doc): Promise<void> {
                return Promise.resolve();
              },
              set(doc): Promise<void> {
                return Promise.resolve();
              },
              delete(): Promise<void> {
                return Promise.resolve();
              }
            }
          }

        }
      },

      doc<T>(path) {
        return {
          valueChanges(): Observable<IUser> {
            return of(
              user
            )
          },
          set(doc): Promise<void> {
            return Promise.resolve();
          },

          delete(): Promise<void> {
            return Promise.resolve();
          }
        }
      }
    }
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],

      providers: [
        {provide: AngularFirestore, useValue: angularFirestoreMock},
        {provide: AngularFireAuth, useValue: mockAngularFireAuth},

      ]
    });
    service = TestBed.inject(UserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it("should return users", () => {
    let epicsData = service.getUsers();
    epicsData.subscribe(data => {
      expect(data.length).toBe(1);
    })
  });


  it("should create user", () => {
    spyOn(service, 'addUser').and.callThrough();
    service.addUser("rubem", "ruben@gmail.com", "1");
    expect(service.addUser).toHaveBeenCalled();
  });
});
