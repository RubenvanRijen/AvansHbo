import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {ProjectItemComponent} from './project-item.component';
import {RouterTestingModule} from "@angular/router/testing";
import {UserStoryService} from "../../services/userStory/user-story.service";
import {MockUserStoryService} from "../../MockServices/MockUserStoryService";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {MockAuthenticationService} from "../../MockServices/MockAuthenticationService";
import {FormBuilder} from "@angular/forms";
import {MemberService} from "../../services/member/member.service";
import {MockMemberService} from "../../MockServices/MockMemberService";
import {ActivatedRoute, convertToParamMap, Data, Params} from "@angular/router";
import {ProjectService} from "../../services/project/project.service";
import {MockProjectService} from "../../MockServices/MockProjectService";
import {of} from "rxjs";

describe('ProjectItemComponent', () => {
  let component: ProjectItemComponent;
  let fixture: ComponentFixture<ProjectItemComponent>;

  beforeEach(async(async () => {
    await TestBed.configureTestingModule({
      declarations: [ProjectItemComponent],
      imports: [RouterTestingModule],
      providers: [
        {provide: ProjectService, useClass: MockProjectService},
        {
          provide: ActivatedRoute,
          useValue: { // Mock
            queryParams: of(
              {
                id: '1'
              }
            ),
            params: of(
              {
                id: '1'
              }
            )
          }
        }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectItemComponent);
    component = fixture.componentInstance;
    component.params = of({id: 1})
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
