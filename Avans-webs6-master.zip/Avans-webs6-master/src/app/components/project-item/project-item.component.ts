import {Component, OnInit} from '@angular/core';
import {Subscription} from "rxjs";
import {ActivatedRoute} from "@angular/router";
import {ProjectService} from "../../services/project/project.service";
import {IProject} from "../../models/IProject";

@Component({
  selector: 'app-project-item',
  templateUrl: './project-item.component.html',
  styleUrls: ['./project-item.component.sass']
})
export class ProjectItemComponent implements OnInit {

  private routeSub: Subscription;
  project: IProject;
  params: any;
  projectObserver: any;
  content: string = "backlog";

  constructor(private activatedRoute: ActivatedRoute, private projectService: ProjectService) {
  }

  ChangeComponent(page: string) {
    this.content = page;
  }

  ngOnInit(): void {
    this.routeSub = this.activatedRoute.params.subscribe(params => {
      this.params = params;
    });
    this.projectObserver = this.projectService.getProject(this.params.id).subscribe(project => {
      this.project = project;
    });
  }

  ngOnDestroy() {
    this.routeSub?.unsubscribe();
    this.projectObserver?.unsubscribe();
  }
}
