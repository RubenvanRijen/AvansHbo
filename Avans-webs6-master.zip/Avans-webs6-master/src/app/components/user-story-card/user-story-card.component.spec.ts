import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {UserStoryCardComponent} from './user-story-card.component';
import {RouterTestingModule} from "@angular/router/testing";
import {IUserStory} from "../../models/IUserStory";
import {UserStoryStatusEnum} from "../../models/UserStoryStatus.enum";

describe('UserStoryCardComponent', () => {
  let component: UserStoryCardComponent;
  let fixture: ComponentFixture<UserStoryCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [UserStoryCardComponent],
      imports: [RouterTestingModule],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserStoryCardComponent);
    component = fixture.componentInstance;
    component.userStory = <IUserStory>{
      isArchived: false,
      owner: "0123456789",
      ownerName: "Ruben",
      uid: "9876543210",
      sprintName: "Sprint 1",
      sprintUID: "5244125863",
      epicColor: "red",
      epicName: "epic1",
      epicUID: "2368547109",
      storyPoints: 2,
      projectUID: "24856321048",
      statusLastEdited: "2020-05-05",
      title: "title",
      status: UserStoryStatusEnum.New,
      description: "dit is een description",
    }
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have user story information', () => {
    expect(component.userStory.sprintUID).toBe("5244125863");
    expect(component.userStory.storyPoints).toBe(2);
    expect(component.userStory.status).toBe(UserStoryStatusEnum.New);
  });
});
