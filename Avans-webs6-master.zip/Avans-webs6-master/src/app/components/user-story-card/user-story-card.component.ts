import {Component, OnInit, Input} from '@angular/core';
import {IUserStory} from '../../models/IUserStory';

@Component({
  selector: 'app-user-story-card',
  templateUrl: './user-story-card.component.html',
  styleUrls: ['./user-story-card.component.sass']
})
export class UserStoryCardComponent implements OnInit {

  @Input()
  userStory: IUserStory;

  constructor() {
  }

  ngOnInit(): void {
  }

}
