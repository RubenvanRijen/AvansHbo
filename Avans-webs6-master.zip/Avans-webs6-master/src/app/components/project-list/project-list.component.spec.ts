import {async, ComponentFixture, fakeAsync, TestBed, tick} from '@angular/core/testing';

import {ProjectListComponent} from './project-list.component';
import {RouterTestingModule} from "@angular/router/testing";
import {ActivatedRoute} from "@angular/router";
import {ProjectService} from "../../services/project/project.service";
import {MockProjectService} from "../../MockServices/MockProjectService";
import {UserStoryService} from "../../services/userStory/user-story.service";
import {MockUserStoryService} from "../../MockServices/MockUserStoryService";
import {UserService} from "../../services/user/user.service";
import {MockUserService} from "../../MockServices/MockUserService";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {MockAuthenticationService} from "../../MockServices/MockAuthenticationService";
import {MemberService} from "../../services/member/member.service";
import {MockMemberService} from "../../MockServices/MockMemberService";
import * as firebase from "firebase";
import {IProject} from "../../models/IProject";

function setUser() {
  return new class implements firebase.User {
    displayName: string | null;
    email: string | null;
    emailVerified: boolean;
    isAnonymous: boolean;
    metadata: firebase.auth.UserMetadata;
    multiFactor: firebase.User.MultiFactorUser;
    phoneNumber: string | null;
    photoURL: string | null;
    providerData: (firebase.UserInfo | null)[];
    providerId: string;
    refreshToken: string;
    tenantId: string | null;
    uid: string;

    delete(): Promise<void> {
      return Promise.resolve(undefined);
    }

    getIdToken(forceRefresh?: boolean): Promise<string> {
      return Promise.resolve("");
    }

    getIdTokenResult(forceRefresh?: boolean): Promise<firebase.auth.IdTokenResult> {
      return Promise.resolve(undefined);
    }

    linkAndRetrieveDataWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithPhoneNumber(phoneNumber: string, applicationVerifier: firebase.auth.ApplicationVerifier): Promise<firebase.auth.ConfirmationResult> {
      return Promise.resolve(undefined);
    }

    linkWithPopup(provider: firebase.auth.AuthProvider): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithRedirect(provider: firebase.auth.AuthProvider): Promise<void> {
      return Promise.resolve(undefined);
    }

    reauthenticateAndRetrieveDataWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithPhoneNumber(phoneNumber: string, applicationVerifier: firebase.auth.ApplicationVerifier): Promise<firebase.auth.ConfirmationResult> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithPopup(provider: firebase.auth.AuthProvider): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithRedirect(provider: firebase.auth.AuthProvider): Promise<void> {
      return Promise.resolve(undefined);
    }

    reload(): Promise<void> {
      return Promise.resolve(undefined);
    }

    sendEmailVerification(actionCodeSettings?: firebase.auth.ActionCodeSettings | null): Promise<void> {
      return Promise.resolve(undefined);
    }

    toJSON(): Object {
      return undefined;
    }

    unlink(providerId: string): Promise<firebase.User> {
      return Promise.resolve(undefined);
    }

    updateEmail(newEmail: string): Promise<void> {
      return Promise.resolve(undefined);
    }

    updatePassword(newPassword: string): Promise<void> {
      return Promise.resolve(undefined);
    }

    updatePhoneNumber(phoneCredential: firebase.auth.AuthCredential): Promise<void> {
      return Promise.resolve(undefined);
    }

    updateProfile(profile: { displayName?: string | null; photoURL?: string | null }): Promise<void> {
      return Promise.resolve(undefined);
    }

    verifyBeforeUpdateEmail(newEmail: string, actionCodeSettings?: firebase.auth.ActionCodeSettings | null): Promise<void> {
      return Promise.resolve(undefined);
    }
  }
}


describe('ProjectListComponent', () => {
  let component: ProjectListComponent;
  let fixture: ComponentFixture<ProjectListComponent>;

  beforeEach((() => {
    TestBed.configureTestingModule({
      declarations: [ProjectListComponent],
      imports: [RouterTestingModule],
      providers: [
        {provide: UserService, useClass: MockUserService},
        {provide: ProjectService, useClass: MockProjectService},
        {provide: AuthenticationService, useClass: MockAuthenticationService},
        {provide: MemberService, useClass: MockMemberService},
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectListComponent);
    component = fixture.componentInstance;
    if (!component.user) {
      component.user = setUser();
      component.user.uid = "1";
    }
    fixture.detectChanges();
  });

  it('should create', () => {
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  describe("showProjectsFilter", () => {
    it('should filter projects on name', () => {
      component.showProjectsFilter('archived', false);
      expect(component.projectList.length).toBe(1);
    });
  });

  describe("getAllProjects", () => {
    it('should get all projects', () => {
      component.getAllProjects();
      expect(component.projectList.length).toBe(2);
    });
  });

  describe("getAllOwnProjects", () => {
    it('should get all owned projects', () => {
      component.getAllOwnProjects();
      expect(component.projectList.length).toBe(1);
    });
  });

  describe("showOwnProjectsFilter", () => {
    it('should filter projects on name', () => {
      component.showOwnProjectsFilter('archived', false);
      expect(component.projectList.length).toBe(1);
    });
  });

  it("archive project", () => {
    let k: any = component.archiveProject("1", true);
    expect(k).toBe(undefined);
    spyOn(component, 'archiveProject').and.returnValue(null);
    component.archiveProject("1", true);
    expect(component.archiveProject).toHaveBeenCalled();
  });

  it("unArchive project", () => {
    let k: any = component.archiveProject("1", false);
    expect(k).toBe(undefined);
    spyOn(component, 'archiveProject').and.returnValue(null);
    component.archiveProject("1", false);
    expect(component.archiveProject).toHaveBeenCalled();
  });

  it("join a project", fakeAsync(() => {
    component.getAllProjects();
    component.setIsProjectMember("1", true, "1");
    spyOn(component, 'setIsProjectMember').and.returnValue(null);
    component.setIsProjectMember("1", true, "1");
    tick(3000);
    expect(component.setIsProjectMember).toHaveBeenCalled();
  }));

  it("not join a project", fakeAsync(() => {
    component.getAllProjects();
    component.setIsProjectMember("1", false, "1");
    spyOn(component, 'setIsProjectMember').and.returnValue(null);
    component.setIsProjectMember("1", false, "1");
    tick(3000);
    expect(component.setIsProjectMember).toHaveBeenCalled();
  }));

})
