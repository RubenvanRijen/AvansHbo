import {Component, OnInit} from '@angular/core';
import {ProjectService} from '../../services/project/project.service';
import {IProject} from '../../models/IProject';
import {UserService} from 'src/app/services/user/user.service';
import * as firebase from "firebase";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {MemberService} from "../../services/member/member.service";
import {IMember} from "../../models/IMember";
import {ParticipantRol} from "../../models/ParticipantRol.enum";

@Component({
  selector: 'app-project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.sass'],
})
export class ProjectListComponent implements OnInit {
  projectList: IProject[];
  user: firebase.User;
  params: any;
  observerList: any;
  ownProjects: boolean;
  observerMember: any;

  constructor(
    private projectService: ProjectService,
    private userService: UserService,
    private authenticationService: AuthenticationService,
    private memberService: MemberService
  ) {
  }

  async ngOnInit(): Promise<void> {
    await this.authenticationService.returnLoggedInUser().then(data => {
      this.user = data;
    });
    this.getAllProjects();
  }
  
  unsubscribeObservers() {
    this.observerList?.unsubscribe();
    this.observerMember?.unsubscribe();
  }

  showProjectsFilter(field: string, value: boolean) {
    this.unsubscribeObservers();
    this.ownProjects = false;
    this.observerList = this.projectService.filterProjects(field, value).subscribe((projects: IProject[]) => {
      this.projectList = projects;
      this.projectList.map(project => {
        this.userService.getUser(project.owner).subscribe(data => {
          project.displayNameUser = data.displayName;
        });
        project.isMember = false;
        project.members.map(member => {
          if (member === this.user.uid) {
            project.isMember = true;
          }
        });
        this.observerMember = this.memberService.getOneMemberFromOneProject(project.uid, this.user.uid).subscribe(member => {
          if (member[0]?.uid) {
            project.memberUID = member[0].uid;
          }
        });
      });
    });
  }

  getAllProjects() {
    this.unsubscribeObservers();
    this.ownProjects = false;
    this.observerList = this.projectService.getProjects().subscribe((projects: IProject[]) => {
      this.projectList = projects;
      this.projectList.map(project => {
        this.userService.getUser(project.owner).subscribe(data => {
          project.displayNameUser = data.displayName;
        });
        project.isMember = false;
        project.members.map(member => {
          if (member === this.user?.uid) {
            project.isMember = true;
          }
        });
        this.observerMember = this.memberService.getOneMemberFromOneProject(project.uid, this.user.uid).subscribe(member => {
          if (member[0]?.uid) {
            project.memberUID = member[0].uid;
          }
        });
      });
    });
  }

  getAllOwnProjects() {
    this.unsubscribeObservers();
    this.ownProjects = true;
    this.observerList = this.projectService.getOwnProjects(this.user.uid).subscribe((projects: IProject[]) => {
      this.projectList = projects;
      this.projectList.map(project => {
        this.userService.getUser(project.owner).subscribe(data => {
          project.displayNameUser = data.displayName;
        });
        project.isMember = false;
        project.members.map(member => {
          if (member === this.user.uid) {
            project.isMember = true;
          }
        });
        this.observerMember = this.memberService.getOneMemberFromOneProject(project.uid, this.user.uid).subscribe(member => {
          if (member[0]?.uid) {
            project.memberUID = member[0].uid;
          }
        });
      });
    });
  }

  showOwnProjectsFilter(field: string, value: boolean) {
    this.unsubscribeObservers();
    this.ownProjects = true;
    this.observerList = this.projectService.getOwnProjectsFiltering(this.user.uid, field, value).subscribe((projects: IProject[]) => {
      this.projectList = projects;
      this.projectList.map(project => {
        this.userService.getUser(project.owner).subscribe(data => {
          project.displayNameUser = data.displayName;
        });
        project.isMember = false;
        project.members.map(member => {
          if (member === this.user.uid) {
            project.isMember = true;
          }
        });
        this.observerMember = this.memberService.getOneMemberFromOneProject(project.uid, this.user.uid).subscribe(member => {
          if (member[0]?.uid) {
            project.memberUID = member[0].uid;
          }
        });
      });
    });
  }

  archiveProject(uid: string, shouldArchive: boolean) {
    let project = <IProject>{
      uid: uid,
      archived: shouldArchive
    }
    this.projectService.updateProjectArchive(project).then(r => {
      return r;
    }).catch(function (error) {
      console.log(error);
    });
  }

  async setIsProjectMember(projectUID: any, join: boolean, memberUID: string) {
    let project: IProject;
    let canJoin: boolean = true;
    await this.projectList.map(projectData => {
      if (projectData.uid === projectUID) {
        project = projectData;
        return;
      }
    });
    if (project) {
      await project.members.map((member: string) => {
        if (member === this.user.uid) {
          canJoin = false;
        }
      })
    }
    if (join && canJoin && project) {
      await project.members.push(
        this.user.uid
      );
      let member = <IMember>{
        displayName: this.user.displayName,
        projectUID: projectUID,
        rol: ParticipantRol.developer,
        userUID: this.user.uid
      }
      await this.memberService.createMember(member);
    } else {
      if (project) {
        project.members.map(async (participant, index) => {
          if (participant === this.user.uid) {
            await project.members.splice(index, 1);
            return;
          }
        });
        await this.memberService.deleteMember(memberUID);
      }
    }
    project && await this.projectService.updateProjectParticipants(project);
  }

  ngOnDestroy() {
    this.observerList?.unsubscribe();
    this.observerMember?.unsubscribe();
  }
}
