import {Component, Input, OnInit} from '@angular/core';
import {MemberService} from "../../services/member/member.service";
import {IMember} from "../../models/IMember";
import {ParticipantRol} from "../../models/ParticipantRol.enum";
import * as firebase from "firebase";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {FormBuilder, Validators} from "@angular/forms";
import {UserStoryService} from "../../services/userStory/user-story.service";
import {IUserStory} from "../../models/IUserStory";
import {ProjectService} from "../../services/project/project.service";
import {IProject} from "../../models/IProject";
import {UserService} from "../../services/user/user.service";
import {IUser} from "../../models/IUser";

@Component({
  selector: 'app-member-overview',
  templateUrl: './member-overview.component.html',
  styleUrls: ['./member-overview.component.sass']
})
export class MemberOverviewComponent implements OnInit {
  membersObserver: any;
  editMembersObserver: any;
  members: IMember[];
  @Input()
  params: any;
  states: any;
  user: firebase.User;
  userRole: any;
  isSubmitted = false;
  memberForm: any;
  showForm: boolean = false;
  addMemberForm: any;
  project: IProject;
  projectObserver: any;
  newUser: IUser[];
  isParticipant:boolean = false;

  constructor(private memberService: MemberService,
              private authenticationService: AuthenticationService,
              private formBuilder: FormBuilder,
              private userStoryService: UserStoryService,
              private projectService: ProjectService,
              private userService: UserService) {

    let exampleMember = <IMember>{
      rol: ParticipantRol.developer,
      displayName: "testDisplayname",
      uid: "12345678987456"
    }
    this.setForm(exampleMember);
    this.setAddMemberForm();
  }

  async ngOnInit(): Promise<void> {
    await this.authenticationService.returnLoggedInUser().then(data => {
      this.user = data;
    });
    this.getMembers();
    this.projectObserver = this.projectService.getProject(this.params.id).subscribe((project: IProject) => {
      this.project = project;
      project.members.map((member) => {
        if (this.user) {
          if (member === this.user.uid) {
            this.isParticipant = true;
          }
        }
      });
    })
  }

  setAddMemberForm() {
    this.addMemberForm = this.formBuilder.group({
      memberEmail: ['', [Validators.required]]
    })
  }

  async addMember() {
    let canJoin: boolean = true;
    this.membersObserver = this.userService.getUserOnEmail(this.addMemberForm.value.memberEmail).subscribe(async (user: IUser[]) => {
      this.newUser = user;
      this.project.members.map((member: string) => {
        if (member === this.newUser[0].uid) {
          canJoin = false;
        }
      });
      if (canJoin) {
        await this.project.members.push(
          this.newUser[0].uid
        );
        let member = <IMember>{
          displayName: this.newUser[0].displayName,
          projectUID: this.params.id,
          rol: ParticipantRol.developer,
          userUID: this.newUser[0].uid
        }
        await this.memberService.createMember(member);
        await this.projectService.updateProjectParticipants(this.project);
      }
    })
  }

  async setForm(member: IMember) {
    this.states = this.getStates(member);
    this.memberForm = await this.formBuilder.group({
      editDisplayName: [member.displayName, [Validators.minLength(3)]],
      uid: [member.uid, []],
      editRol: [member.rol, []],
      userUID: [member.userUID, []]
    });
  }

  async showFormData(event: any) {
    const uid = event.target.id;
    this.editMembersObserver = await this.memberService.getMember(uid).subscribe(async data => {
      await this.setForm(data);
    });
    this.showForm = true;
  }

  getStates(member: IMember) {
    if (member.rol === ParticipantRol.admin) {
      return [
        {id: ParticipantRol.admin, name: ParticipantRol.admin}
      ]
    } else {
      return [
        {id: ParticipantRol.developer, name: ParticipantRol.developer},
        {id: ParticipantRol.stakeholder, name: ParticipantRol.stakeholder},
      ];
    }
  }

  get formControls() {
    return this.memberForm.controls;
  }

  getMembers() {
    this.membersObserver = this.memberService.getMembersFromProject(this.params.id).subscribe((members: IMember[]) => {
      this.members = members;
      members.map(member => {
        if (member.userUID === this.user.uid) {
          if (member.rol === ParticipantRol.admin) {
            this.userRole = ParticipantRol.admin;
          }
        }
      })
    });
  }

  updateMember() {
    this.isSubmitted = true;
    if (this.memberForm.invalid) {
      return;
    }
    if (this.memberForm.value.editRol === ParticipantRol.admin) {

    }
    let editMember = <IMember>{
      displayName: this.memberForm.value.editDisplayName,
      rol: this.memberForm.value.editRol,
    }

    this.memberService.editMember(this.memberForm.value.uid, editMember).then(r => {
      this.showForm = false;
      this.userStoryService.filterUserStories('owner', this.memberForm.value.uid).subscribe((userStories: IUserStory[]) => {
        userStories.map(story => {
          story.ownerName = this.memberForm.value.editDisplayName
          this.userStoryService.updateUserStory(story, story?.uid).then();
        })
      });
    }).catch(error => {
      console.log(error);
    });
    this.editMembersObserver?.unsubscribe();
  }

  backClicked() {
    this.showForm = false;
    this.editMembersObserver?.unsubscribe();
    this.membersObserver?.unsubscribe();
  }

  ngOnDestroy() {
    this.membersObserver?.unsubscribe();
    this.editMembersObserver?.unsubscribe();
    this.membersObserver?.unsubscribe();
  }
}
