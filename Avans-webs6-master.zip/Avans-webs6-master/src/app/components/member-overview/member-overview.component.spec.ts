import {async, ComponentFixture, fakeAsync, TestBed, tick} from '@angular/core/testing';

import {MemberOverviewComponent} from './member-overview.component';
import {RouterTestingModule} from '@angular/router/testing';
import {ProjectService} from '../../services/project/project.service';
import {MockProjectService} from '../../MockServices/MockProjectService';
import {AuthenticationService} from '../../services/authentication/Authentication.service';
import {MockAuthenticationService} from '../../MockServices/MockAuthenticationService';
import {FormBuilder} from '@angular/forms';
import {MemberService} from '../../services/member/member.service';
import {MockMemberService} from '../../MockServices/MockMemberService';
import {UserStoryService} from '../../services/userStory/user-story.service';
import {MockUserStoryService} from '../../MockServices/MockUserStoryService';
import {IMember} from 'src/app/models/IMember';
import {ParticipantRol} from 'src/app/models/ParticipantRol.enum';
import * as firebase from "firebase";
import {UserService} from "../../services/user/user.service";
import {MockUserService} from "../../MockServices/MockUserService";

function setForm(member: IMember) {
  let form = new FormBuilder();
  return form.group({
    editDisplayName: [member.displayName],
    uid: [member.uid],
    editRol: [member.rol],
    userUID: [member.userUID]
  });
}

function setUser() {
  return new class implements firebase.User {
    displayName: string | null;
    email: string | null;
    emailVerified: boolean;
    isAnonymous: boolean;
    metadata: firebase.auth.UserMetadata;
    multiFactor: firebase.User.MultiFactorUser;
    phoneNumber: string | null;
    photoURL: string | null;
    providerData: (firebase.UserInfo | null)[];
    providerId: string;
    refreshToken: string;
    tenantId: string | null;
    uid: string;

    delete(): Promise<void> {
      return Promise.resolve(undefined);
    }

    getIdToken(forceRefresh?: boolean): Promise<string> {
      return Promise.resolve("");
    }

    getIdTokenResult(forceRefresh?: boolean): Promise<firebase.auth.IdTokenResult> {
      return Promise.resolve(undefined);
    }

    linkAndRetrieveDataWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithPhoneNumber(phoneNumber: string, applicationVerifier: firebase.auth.ApplicationVerifier): Promise<firebase.auth.ConfirmationResult> {
      return Promise.resolve(undefined);
    }

    linkWithPopup(provider: firebase.auth.AuthProvider): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithRedirect(provider: firebase.auth.AuthProvider): Promise<void> {
      return Promise.resolve(undefined);
    }

    reauthenticateAndRetrieveDataWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithPhoneNumber(phoneNumber: string, applicationVerifier: firebase.auth.ApplicationVerifier): Promise<firebase.auth.ConfirmationResult> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithPopup(provider: firebase.auth.AuthProvider): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithRedirect(provider: firebase.auth.AuthProvider): Promise<void> {
      return Promise.resolve(undefined);
    }

    reload(): Promise<void> {
      return Promise.resolve(undefined);
    }

    sendEmailVerification(actionCodeSettings?: firebase.auth.ActionCodeSettings | null): Promise<void> {
      return Promise.resolve(undefined);
    }

    toJSON(): Object {
      return undefined;
    }

    unlink(providerId: string): Promise<firebase.User> {
      return Promise.resolve(undefined);
    }

    updateEmail(newEmail: string): Promise<void> {
      return Promise.resolve(undefined);
    }

    updatePassword(newPassword: string): Promise<void> {
      return Promise.resolve(undefined);
    }

    updatePhoneNumber(phoneCredential: firebase.auth.AuthCredential): Promise<void> {
      return Promise.resolve(undefined);
    }

    updateProfile(profile: { displayName?: string | null; photoURL?: string | null }): Promise<void> {
      return Promise.resolve(undefined);
    }

    verifyBeforeUpdateEmail(newEmail: string, actionCodeSettings?: firebase.auth.ActionCodeSettings | null): Promise<void> {
      return Promise.resolve(undefined);
    }
  }
}

describe('MemberOverviewComponent', () => {
  let component: MemberOverviewComponent;
  let fixture: ComponentFixture<MemberOverviewComponent>;
  let adminMember: IMember = {
    projectUID: '2',
    displayName: 'Hagrid',
    rol: ParticipantRol.admin,
    userUID: '1',
    uid: '1',
  };
  let developerMember: IMember = {
    projectUID: '2',
    displayName: 'Hagrid',
    rol: ParticipantRol.developer,
    userUID: '2',
    uid: '2',
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MemberOverviewComponent],
      imports: [RouterTestingModule],
      providers: [
        {provide: UserStoryService, useClass: MockUserStoryService},
        {provide: AuthenticationService, useClass: MockAuthenticationService},
        {provide: FormBuilder, useClass: FormBuilder},
        {provide: MemberService, useClass: MockMemberService},
        {provide: UserService, useClass: MockUserService},
        {provide: ProjectService, useClass: MockProjectService},


      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemberOverviewComponent);
    component = fixture.componentInstance;
    component.params = {
      id: 1,
    };
    if (!component.user) {
      component.user = setUser();
      component.user.uid = "1";
    }
    adminMember.uid = "1";
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('getStates', () => {
    it('should return admin role', () => {
      expect(component.getStates(adminMember).length).toBe(1);
    });

    it('should return operating roles', () => {
      expect(component.getStates(developerMember).length).toBe(2);
    });
  });

  describe('form 2', () => {
    it("show the form", fakeAsync(() => {
      component.ngOnInit();
      component.showFormData({target: {id: 1}});
      tick(3000);
      expect(component.showForm).toBeTrue();
    }));
  });

  describe('form 1', () => {
    it("set the form data", () => {
      component.setForm(adminMember);
      expect(component.memberForm).not.toBeNull();
    });
  })
  describe('members', () => {
    it("get all memebers", () => {
      component.getMembers();
      expect(component.members.length).toBe(1);
    });
  });
  describe('Cancel', () => {
    it("cancel edit", () => {
      component.backClicked();
      expect(component.showForm).toBeFalse();
    });
  });

  describe('Update', () => {
    it("update a memeber", fakeAsync(() => {
      component.showForm = true;
      component.memberForm = setForm(adminMember);
      component.setForm(adminMember);
      component.updateMember();
      tick(3000);
      expect(component.showForm).toBeFalse();
    }));
  });

  it("add a member", () =>{
    spyOn(component, 'addMember').and.callThrough();
    component.addMember();
    expect(component.addMember).toHaveBeenCalled();
  });
});
