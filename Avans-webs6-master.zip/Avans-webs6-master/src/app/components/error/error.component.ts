import {Component, OnInit} from '@angular/core';
import {Location} from "@angular/common";
import { Router} from "@angular/router";

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.sass']
})
export class ErrorComponent implements OnInit {

  constructor(private location: Location,
              private router: Router,
  ) {
  }

  ngOnInit(): void {
  }

  backClicked() {
    this.location.back();
  }

  returnHome() {
    this.router.navigate(['/home']);
  }
}
