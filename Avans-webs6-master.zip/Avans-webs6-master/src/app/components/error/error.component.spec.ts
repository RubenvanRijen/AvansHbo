import {async, ComponentFixture, fakeAsync, TestBed, tick} from '@angular/core/testing';

import {ErrorComponent} from './error.component';
import {RouterTestingModule} from "@angular/router/testing";
import {Location} from "@angular/common";
import {HomeComponent} from "../home/home.component";
import {Router} from "@angular/router";


describe('ErrorComponent', () => {
  let component: ErrorComponent;
  let fixture: ComponentFixture<ErrorComponent>;
  let location: Location;
  let router: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ErrorComponent],
      imports: [RouterTestingModule.withRoutes([{path: "home", component: HomeComponent}])],
      providers: [
        {provide: Location, useClass: Location},
      ]
    })
      .compileComponents();
    location = TestBed.get(Location);
    router = TestBed.get(Router);

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should return home", fakeAsync(() => {
    component.ngOnInit();
    const navigateSpy = spyOn(router, 'navigate');

    component.returnHome();
    component.backClicked()
    tick(3000);
    expect(navigateSpy).toHaveBeenCalledWith(['/home']);
  }));


});
