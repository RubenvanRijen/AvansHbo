import {Component, OnInit, Output, EventEmitter} from '@angular/core';
import {faCrown, faClipboard, faRunning, faUsers} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.sass']
})
export class SideBarComponent implements OnInit {

  faCrown = faCrown;
  faClipboard = faClipboard;
  faRunning = faRunning;
  faUsers = faUsers;
  @Output() changeComponents = new EventEmitter<string>();

  constructor() {
  }

  setContent(page: string) {
    this.changeComponents.emit(page);
  }

  ngOnInit(): void {
  }
}
