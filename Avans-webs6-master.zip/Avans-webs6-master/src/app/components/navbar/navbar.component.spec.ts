import {async, ComponentFixture, fakeAsync, TestBed, tick} from '@angular/core/testing';

import {NavbarComponent} from './navbar.component';
import {RouterTestingModule} from "@angular/router/testing";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {MockAuthenticationService} from "../../MockServices/MockAuthenticationService";
import {FormBuilder} from "@angular/forms";
import {HomeComponent} from "../home/home.component";
import {Location} from "@angular/common";

describe('NavbarComponent', () => {
  let component: NavbarComponent;
  let fixture: ComponentFixture<NavbarComponent>;
  let location: Location;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NavbarComponent],
      imports: [RouterTestingModule.withRoutes([{
        path: "home", component: HomeComponent
      }])],
      providers: [{provide: AuthenticationService, useClass: MockAuthenticationService},
        {provide: FormBuilder, useClass: FormBuilder},
      ]
    })
      .compileComponents();
    location = TestBed.get(Location);

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should logout', fakeAsync(() => {
    component.ngOnInit();
    component.formControls;
    component.logout();
    tick(3000);
    expect(location.path()).toBe('/home');
    expect(component.isSubmitted).toBeTrue();
  }));
});
