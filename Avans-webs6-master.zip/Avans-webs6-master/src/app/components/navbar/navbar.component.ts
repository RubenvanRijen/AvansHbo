import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {Router} from "@angular/router";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {Observable} from "rxjs";
import * as firebase from "firebase";

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.sass']
})
export class NavbarComponent implements OnInit {
  logoutForm: FormGroup;
  isSubmitted = false;
  loggedIn: Observable<firebase.User>;

  constructor(private router: Router,
              private formBuilder: FormBuilder,
              private authenticationService: AuthenticationService,
  ) {
    this.loggedIn = this.authenticationService.userStatus();
  }

  async ngOnInit(): Promise<void> {
    this.logoutForm = this.formBuilder.group({});
  }

  get formControls() {
    return this.logoutForm.controls;
  }

  async logout(): Promise<void> {
    this.isSubmitted = true;
    if (this.logoutForm.invalid) {
      return;
    }
    this.authenticationService
      .logout()
      .then(
        () => {
          this.router.navigate(['/home'])
        },
        async (error) => {
          console.log(error);
        }
      );
  }
}
