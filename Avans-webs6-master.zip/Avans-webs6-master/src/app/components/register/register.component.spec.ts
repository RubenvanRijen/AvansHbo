import {async, ComponentFixture, fakeAsync, TestBed, tick} from '@angular/core/testing';

import {RegisterComponent} from './register.component';
import {RouterTestingModule} from "@angular/router/testing";
import {ActivatedRoute} from "@angular/router";
import {ProjectService} from "../../services/project/project.service";
import {MockProjectService} from "../../MockServices/MockProjectService";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {MockAuthenticationService} from "../../MockServices/MockAuthenticationService";
import {FormBuilder, Validators} from "@angular/forms";
import {Location} from "@angular/common";
import {ValidationService} from "../../services/Validation/validation.service";
import {HomeComponent} from "../home/home.component";

describe('RegisterComponent', () => {
  let component: RegisterComponent;
  let fixture: ComponentFixture<RegisterComponent>;
  let location: Location;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RegisterComponent],
      imports: [RouterTestingModule.withRoutes([{path: "home", component: HomeComponent}])],
      providers: [
        {provide: AuthenticationService, useClass: MockAuthenticationService},
        {provide: FormBuilder, useClass: FormBuilder}
      ]
    })
      .compileComponents();
    location = TestBed.get(Location);

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe("RegisterUser", () => {
    it('should create', () => {
      expect(component.registerUser).toBeTruthy();
    });
  })

  it("should register and redirect wrong", fakeAsync(() => {
    component.registerUser();
    tick(3000);
    expect(location.path()).toBe('')
  }));

  it("should register and redirect correctly", fakeAsync(() => {
    component.ngOnInit();
    let form = new FormBuilder();

    component.authForm = form.group([{
      email: ['jim@gmail.com'],
      username: ['Jim'],
      password: ['Test123?2']
    }]);
    component.formControls;
    component.registerUser();
    tick(3000);
    expect(location.path()).toBe('/home');
    expect(component.isSubmitted).toBeTrue();
  }));
});
