import {Component, OnInit} from '@angular/core';
import {FormBuilder, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {AuthenticationService} from '../../services/authentication/Authentication.service';
import {ValidationService} from "../../services/Validation/validation.service";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.sass']
})
export class RegisterComponent implements OnInit {
  authForm: any;
  isSubmitted = false;
  loginLink = '/login';

  constructor(private authenticationService: AuthenticationService,
              private router: Router,
              private formBuilder: FormBuilder) {

    this.authForm = this.formBuilder.group({
      email: ['', [Validators.required, ValidationService.emailValidator]],
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, ValidationService.passwordValidator]],
    });
  }

  ngOnInit(): void { }

  get formControls() {
    return this.authForm.controls;
  }

  async registerUser(): Promise<void> {
    this.isSubmitted = true;
    if (this.authForm.invalid) {
      return;
    }
    this.authenticationService
      .register(this.authForm.value.email, this.authForm.value.password, this.authForm.value.username)
      .then(
        () => {
          this.router.navigateByUrl('home');
        },
        async (error) => {
          console.log(error);
        }
      );
  }

}
