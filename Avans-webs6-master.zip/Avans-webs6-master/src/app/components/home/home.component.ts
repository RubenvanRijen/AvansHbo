import {Component, OnInit} from '@angular/core';
import {AuthenticationService} from '../../services/authentication/Authentication.service';
import {Observable} from "rxjs";
import * as firebase from "firebase";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.sass']
})
export class HomeComponent implements OnInit {
  loggedIn: Observable<firebase.User>;
  user: firebase.User;

  constructor(private authenticationService: AuthenticationService) {
    this.loggedIn = this.authenticationService.userStatus();
  }

  async ngOnInit(): Promise<void> {
    await this.authenticationService.returnLoggedInUser().then(data => {
      this.user = data;
    });
  }
}
