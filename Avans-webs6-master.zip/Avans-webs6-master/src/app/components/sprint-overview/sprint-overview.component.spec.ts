import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {SprintOverviewComponent} from './sprint-overview.component';
import {RouterTestingModule} from "@angular/router/testing";
import {ActivatedRoute} from "@angular/router";
import {ProjectService} from "../../services/project/project.service";
import {MockProjectService} from "../../MockServices/MockProjectService";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {MockAuthenticationService} from "../../MockServices/MockAuthenticationService";
import {SprintService} from "../../services/sprint/sprint.service";
import {MockSprintService} from "../../MockServices/MockSprintService";
import {FormBuilder, Validators} from "@angular/forms";
import {UserStoryService} from "../../services/userStory/user-story.service";
import {MockUserStoryService} from "../../MockServices/MockUserStoryService";
import {of} from "rxjs";
import {ISprint} from "../../models/ISprint";
import {SprintStatus} from "../../models/SprintStatus.enum";

function setForm(sprint: ISprint) {
  let form = new FormBuilder();
  return form.group({
    title: [sprint.title],
    startDate: [sprint.startDate],
    endDate: [sprint.endDate],
    uid: [sprint.uid],
    status: [sprint.status],
    description: [sprint.description]
  });
}

describe('SprintOverviewComponent', () => {
  let component: SprintOverviewComponent;
  let fixture: ComponentFixture<SprintOverviewComponent>;
  const sprint = <ISprint>{
    endDate: "2020-05-05",
    projectUID: "1",
    startDate: "2020-04-04",
    title: "Title1",
    status: SprintStatus.Planning,
    description: "description1",
    uid: "1"
  };


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SprintOverviewComponent],
      imports: [RouterTestingModule],
      providers: [
        {provide: AuthenticationService, useClass: MockAuthenticationService},
        {provide: SprintService, useClass: MockSprintService},
        {provide: ProjectService, useClass: MockProjectService},
        {provide: FormBuilder, useClass: FormBuilder},
        {provide: UserStoryService, useClass: MockUserStoryService},
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SprintOverviewComponent);
    component = fixture.componentInstance;
    component.params = of({
      id: 1
    });

    fixture.detectChanges();
  });

  it('should create', () => {
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it('should have no subscribes', () => {
    component.ngOnDestroy();
    expect(component.sprintObserver).toBe(undefined);
  });

  describe("getSprints", () => {
    it('should return sprints', () => {
      component.getSprints();
      expect(component.sprints.length).toBe(1);
    });
  })

  describe("showFormData", () => {
    it('should show form data edit', () => {
      component.showFormData("", true);
      expect(component.formText).toBe("Edit");
    });

    it('should show form data create', () => {
      component.showFormData("", false);
      expect(component.formText).toBe("Create");
    });
  })

  describe("getStates", () => {
    it('getStates should return states', () => {
      expect(component.getStates().length).toBe(4);
    });
  })

  it("CreateForm", () => {
    component.sprintForm = setForm(sprint);
    component.setFormCreate();
    component.createSprint();
    expect(component.isSubmitted).toBeTrue();
  });

  it("EditForm", () => {
    component.sprintForm = setForm(sprint);
    component.setFormEdit(sprint);
    component.updateSprint();
    expect(component.isSubmitted).toBeTrue();
  });

  it("cancel form", () => {
    component.backClicked();
    expect(component.showForm).toBeFalse();
  })

  it("delete sprint 1", () => {
    component.deleteSprint({target: {id: 1}});
    spyOn(component, 'deleteSprint');
    component.deleteSprint({target: {id: 1}});
    expect(component.deleteSprint).toHaveBeenCalled();
    expect(component.showForm).toBeFalse();
  });

  it("delete sprint 2", () => {
    component.deleteSprint({target: {id: 1}});
    expect(component.showForm).toBeFalse();
  });

  it("call good function", () => {
    component.isEdit = false;
    component.sprintForm = setForm(sprint);
    component.setFormCreate();
    component.updateOrCreateSprint();
    expect(component.isSubmitted).toBeTrue();
  });

  it("call good function", () => {
    component.isEdit = true;
    component.sprintForm = setForm(sprint);
    component.setFormEdit(sprint);
    component.updateOrCreateSprint();
    expect(component.isSubmitted).toBeTrue();
  });


});
