import {Component, Input, OnInit} from '@angular/core';
import {AuthenticationService} from 'src/app/services/authentication/Authentication.service';
import {ISprint} from 'src/app/models/ISprint';
import {SprintService} from 'src/app/services/sprint/sprint.service';
import {ProjectService} from 'src/app/services/project/project.service';
import {IProject} from 'src/app/models/IProject';
import {FormBuilder, Validators} from '@angular/forms';
import * as firebase from "firebase";
import {SprintStatus} from "../../models/SprintStatus.enum";
import {UserStoryService} from "../../services/userStory/user-story.service";
import {IUserStory} from "../../models/IUserStory";

@Component({
  selector: 'app-sprint-overview',
  templateUrl: './sprint-overview.component.html',
  styleUrls: ['./sprint-overview.component.sass'],
})
export class SprintOverviewComponent implements OnInit {
  user: firebase.User;
  sprints: ISprint[];
  projectObserver: any;
  isParticipant: boolean = false;
  sprintObserver: any;
  editSprintObserver: any;

  @Input()
  params: any;

  isSubmitted: boolean = false;
  isEdit: boolean = true;
  sprintForm: any;
  showForm: boolean = false;
  formText: string = 'Edit';
  states: any;
  updateUserStoriesObserver: any;
  deleteSprintUserStoriesObserver: any;

  constructor(
    private authenticationService: AuthenticationService,
    private sprintService: SprintService,
    private projectService: ProjectService,
    private formBuilder: FormBuilder,
    private userStoryService: UserStoryService
  ) {
    this.setFormCreate();
  }

  async ngOnInit(): Promise<void> {
    await this.authenticationService.returnLoggedInUser().then((user) => {
      this.user = user;
    });
    this.getSprints();
  }

  getSprints() {
    this.sprintObserver = this.sprintService
      .getSprintsFromProject(this.params.id)
      .subscribe((sprints: ISprint[]) => {
        this.sprints = sprints;
        this.projectObserver = this.projectService
          .getProject(this.params.id)
          .subscribe((project: IProject) => {
            project.members.map((member) => {
              if (this.user) {
                if (member === this.user?.uid) {
                  this.isParticipant = true;
                }
              }
            });
          });
      });
  }

  updateOrCreateSprint() {
    if (this.isEdit) {
      this.updateSprint();
    } else {
      this.createSprint();
    }
  }

  async showFormData(event: any, isEdit: boolean) {
    this.states = this.getStates();

    if (isEdit) {
      this.formText = 'Edit';
      this.isEdit = true;
      const uid = event.target.id;
      this.editSprintObserver = this.sprintService
        .getSprint(uid)
        .subscribe(async (data) => {
          await this.setFormEdit(data);
        });
    } else {
      this.isEdit = false;
      this.formText = 'Create';
      await this.setFormCreate();
    }
    this.showForm = true;
  }

  getStates() {
    return [
      {id: SprintStatus.Planning, name: SprintStatus.Planning},
      {id: SprintStatus.Accepted, name: SprintStatus.Accepted},
      {id: SprintStatus.Active, name: SprintStatus.Active},
      {id: SprintStatus.Closed, name: SprintStatus.Closed},
    ];
  }

  async setFormEdit(sprint: ISprint) {
    this.sprintForm = await this.formBuilder.group({
      title: [sprint.title, [Validators.minLength(3)]],
      startDate: [sprint.startDate, [Validators.required]],
      endDate: [sprint.endDate, [Validators.required]],
      uid: [sprint.uid, [Validators.required]],
      status: [sprint.status, [Validators.required]],
      description: [sprint.description, [Validators.required, Validators.minLength(5)]]
    });
  }

  async setFormCreate() {
    this.sprintForm = await this.formBuilder.group({
      title: ['', [Validators.minLength(3)]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      uid: ['', []],
      status: ['', []],
      description: ['', [Validators.required, Validators.minLength(5)]]

    });
  }

  get formControls() {
    return this.sprintForm.controls;
  }

  updateSprint() {
    this.isSubmitted = true;
    let date1 = new Date(this.sprintForm.value.startDate);
    let date2 = new Date(this.sprintForm.value.endDate);
    if (date1.getTime() > date2.getTime()) {
      return;
    }
    if (this.sprintForm.invalid) {
      return;
    }
    let newSprint = <ISprint>{
      endDate: this.sprintForm.value.endDate,
      projectUID: this.params.id,
      startDate: this.sprintForm.value.startDate,
      title: this.sprintForm.value.title,
      status: this.sprintForm.value.status,
      description: this.sprintForm.value.description
    };
    this.sprintService
      .updateSprint(newSprint, this.sprintForm.value.uid)
      .then(() => {
        this.showForm = false;
        this.updateUserStoriesObserver = this.userStoryService.filterUserStories('sprintUID', this.sprintForm.value.uid).subscribe((userStories: IUserStory[]) => {
          userStories.map(story => {
            story.sprintName = this.sprintForm.value.title;
            this.userStoryService.updateUserStory(story, story.uid);
          })
        });
        if (this.sprintForm.value.status === SprintStatus.Active) {
          this.sprints.map(sprint => {
            if (sprint.status === SprintStatus.Active && sprint.uid !== this.sprintForm.value.uid) {
              this.sprintService.changeActiveSprint(sprint.uid, SprintStatus.Planning);
            }
          })
        }
      })
      .catch((error) => {
        console.log(error);
      });
    if (this.editSprintObserver) {
      this.editSprintObserver.unsubscribe();
    }
  }

  backClicked() {
    this.showForm = false;
    if (this.editSprintObserver) {
      this.editSprintObserver.unsubscribe();
    }
    if (this.updateUserStoriesObserver) {
      this.updateUserStoriesObserver.unsubscribe();
    }
  }

  deleteSprint(event: any) {
    const uid = event.target.id;
    this.sprintService
      .deleteSprint(uid)
      .then(() => {
        this.deleteSprintUserStoriesObserver = this.userStoryService.filterUserStories('sprintUID', uid).subscribe((userStories: IUserStory[]) => {
          userStories.map(story => {
            story.sprintName = "";
            story.sprintUID = "";
            this.userStoryService.updateUserStory(story, story.uid);
          })
        });
      })
      .catch((error) => {
        console.log(error);
      });
  }

  createSprint() {
    this.isSubmitted = true;
    let date1 = new Date(this.sprintForm.value.startDate);
    let date2 = new Date(this.sprintForm.value.endDate);
    if (date1.getTime() > date2.getTime()) {
      return;
    }
    if (this.sprintForm.invalid) {
      return;
    }
    let newSprint = <ISprint>{
      endDate: this.sprintForm.value.endDate,
      projectUID: this.params.id,
      startDate: this.sprintForm.value.startDate,
      title: this.sprintForm.value.title,
      status: SprintStatus.Planning,
      description: this.sprintForm.value.description

    };
    this.sprintService
      .createSprint(newSprint)
      .then(() => {
        this.showForm = false;
      })
      .catch((error) => {
        console.log(error);
      });
  }

  ngOnDestroy() {
    this.sprintObserver?.unsubscribe();
    this.projectObserver?.unsubscribe();
    this.editSprintObserver?.unsubscribe()
    this.updateUserStoriesObserver?.unsubscribe();
    this.deleteSprintUserStoriesObserver?.unsubscribe();
  }
}
