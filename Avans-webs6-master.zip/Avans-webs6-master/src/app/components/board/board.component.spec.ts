import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {BoardComponent} from './board.component';
import {RouterTestingModule} from "@angular/router/testing";
import {UserStoryService} from "../../services/userStory/user-story.service";
import {MockUserStoryService} from "../../MockServices/MockUserStoryService";
import {SprintService} from "../../services/sprint/sprint.service";
import {MockSprintService} from "../../MockServices/MockSprintService";
import {ActivatedRoute, convertToParamMap} from "@angular/router";
import {MemberService} from "../../services/member/member.service";
import {MockMemberService} from "../../MockServices/MockMemberService";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {MockAuthenticationService} from "../../MockServices/MockAuthenticationService";
import {Observable, of} from "rxjs";
import * as firebase from "firebase";
import {UserStoryStatusEnum} from "../../models/UserStoryStatus.enum";

function setUser() {
  return new class implements firebase.User {
    displayName: string | null;
    email: string | null;
    emailVerified: boolean;
    isAnonymous: boolean;
    metadata: firebase.auth.UserMetadata;
    multiFactor: firebase.User.MultiFactorUser;
    phoneNumber: string | null;
    photoURL: string | null;
    providerData: (firebase.UserInfo | null)[];
    providerId: string;
    refreshToken: string;
    tenantId: string | null;
    uid: string;

    delete(): Promise<void> {
      return Promise.resolve(undefined);
    }

    getIdToken(forceRefresh?: boolean): Promise<string> {
      return Promise.resolve("");
    }

    getIdTokenResult(forceRefresh?: boolean): Promise<firebase.auth.IdTokenResult> {
      return Promise.resolve(undefined);
    }

    linkAndRetrieveDataWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithPhoneNumber(phoneNumber: string, applicationVerifier: firebase.auth.ApplicationVerifier): Promise<firebase.auth.ConfirmationResult> {
      return Promise.resolve(undefined);
    }

    linkWithPopup(provider: firebase.auth.AuthProvider): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithRedirect(provider: firebase.auth.AuthProvider): Promise<void> {
      return Promise.resolve(undefined);
    }

    reauthenticateAndRetrieveDataWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithPhoneNumber(phoneNumber: string, applicationVerifier: firebase.auth.ApplicationVerifier): Promise<firebase.auth.ConfirmationResult> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithPopup(provider: firebase.auth.AuthProvider): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithRedirect(provider: firebase.auth.AuthProvider): Promise<void> {
      return Promise.resolve(undefined);
    }

    reload(): Promise<void> {
      return Promise.resolve(undefined);
    }

    sendEmailVerification(actionCodeSettings?: firebase.auth.ActionCodeSettings | null): Promise<void> {
      return Promise.resolve(undefined);
    }

    toJSON(): Object {
      return undefined;
    }

    unlink(providerId: string): Promise<firebase.User> {
      return Promise.resolve(undefined);
    }

    updateEmail(newEmail: string): Promise<void> {
      return Promise.resolve(undefined);
    }

    updatePassword(newPassword: string): Promise<void> {
      return Promise.resolve(undefined);
    }

    updatePhoneNumber(phoneCredential: firebase.auth.AuthCredential): Promise<void> {
      return Promise.resolve(undefined);
    }

    updateProfile(profile: { displayName?: string | null; photoURL?: string | null }): Promise<void> {
      return Promise.resolve(undefined);
    }

    verifyBeforeUpdateEmail(newEmail: string, actionCodeSettings?: firebase.auth.ActionCodeSettings | null): Promise<void> {
      return Promise.resolve(undefined);
    }
  }
}

describe('BoardComponent', () => {
  let component: BoardComponent;
  let fixture: ComponentFixture<BoardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BoardComponent],
      imports: [RouterTestingModule],
      providers: [
        {provide: UserStoryService, useClass: MockUserStoryService},
        {provide: SprintService, useClass: MockSprintService},
        {
          provide: ActivatedRoute,
          useValue: {
            params: of({id: 123})
          }
        },
        {provide: MemberService, useClass: MockMemberService},
        {provide: AuthenticationService, useClass: MockAuthenticationService},

      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BoardComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
    if (!component.user) {
      component.user = setUser();
      component.user.uid = "1";
    }
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set userstories', () =>{
    expect(component.userStories.length).toBe(1);
  });

  it('should return stories', () =>{
    let stories = component.getUserStoriesByMemberAndStatus('0123456789', UserStoryStatusEnum.New);
    expect(stories.length).toBe(1);
  })
});
