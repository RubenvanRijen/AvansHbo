import { Component, OnInit } from '@angular/core';
import { UserStoryService } from '../../services/userStory/user-story.service';
import { IUserStory } from '../../models/IUserStory';
import { SprintService } from 'src/app/services/sprint/sprint.service';
import { ISprint } from 'src/app/models/ISprint';
import { ActivatedRoute } from '@angular/router';
import { MemberService } from '../../services/member/member.service';
import * as firebase from 'firebase';
import { IMember } from 'src/app/models/IMember';
import { UserStoryStatusEnum } from '../../models/UserStoryStatus.enum';
import { AuthenticationService } from 'src/app/services/authentication/Authentication.service';

@Component({
  selector: 'app-board',
  templateUrl: './board.component.html',
  styleUrls: ['./board.component.sass'],
})
export class BoardComponent implements OnInit {
  public userStoriesMap: UserStoryStatusEnum[] = [
    UserStoryStatusEnum.New,
    UserStoryStatusEnum.InProgress,
    UserStoryStatusEnum.ReadyForTest,
    UserStoryStatusEnum.Closed,
  ];
  userStories: IUserStory[];
  sprint: ISprint;
  params: any;
  routeStub: any;
  user: firebase.User;
  isMember: Boolean = false;
  noOwnerUserStories: IUserStory[];
  members: IMember[];
  memberObserver: any;
  isMemberObserver: any;

  constructor(
    userStoryService: UserStoryService,
    sprintService: SprintService,
    private activatedRoute: ActivatedRoute,
    memberService: MemberService,
    private authenticationService: AuthenticationService
  ) {
    this.routeStub = this.activatedRoute.params.subscribe((params) => {
      this.params = params;
    });
    this.memberObserver = memberService
      .getMembersFromProject(this.params.id)
      .subscribe((members: IMember[]) => {
        this.members = members;
      });

    this.authenticationService.getUser().then((data) => {
      this.isMemberObserver = memberService
        .getOneMemberFromOneProject(this.params.id, data.uid)
        .subscribe((data) => {
          if (data.length === 0) {
            this.isMember = false;
          } else {
            this.isMember = true;
          }
        });
    });

    sprintService
      .getSprint(this.params.sprintId)
      .subscribe((sprint: ISprint) => {
        this.sprint = sprint;
        userStoryService
          .filterUserStoriesWithMultipleFields(
            'sprintUID',
            this.sprint.uid,
            'isArchived',
            false
          )
          .subscribe((userStories: IUserStory[]) => {
            let tempStoryArrayOwner = [];
            let tempStoryArrayNoOwner = [];

            userStories.map((story) => {
              if (story.owner.length !== 0) {
                tempStoryArrayOwner.push(story);
              } else {
                tempStoryArrayNoOwner.push(story);
              }
            });
            this.userStories = tempStoryArrayOwner;
            this.noOwnerUserStories = tempStoryArrayNoOwner;
          });
      });
  }

  getUserStoriesByMemberAndStatus(uid: string, status: string) {
    let stories: IUserStory[] = [];
    if (this.userStories) {
      this.userStories.map((story) => {
        if (story.owner === uid && story.status === status) {
          stories.push(story);
        }
      });
    }
    return stories;
  }

  async ngOnInit(): Promise<void> {}

  ngOnDestroy(): void {
    this.routeStub?.unsubscribe();
    this.memberObserver?.unsubscribe();
    this.isMemberObserver?.unsubscribe();
  }
}
