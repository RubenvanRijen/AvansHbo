import {Component, OnInit} from '@angular/core';
import {ProjectService} from "../../services/project/project.service";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {FormBuilder, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {IProject} from "../../models/IProject";
import {ProjectStatus} from "../../models/ProjectStatus.enum";
import * as firebase from "firebase";
import {Location} from '@angular/common';
import {ParticipantRol} from "../../models/ParticipantRol.enum";
import {IMember} from "../../models/IMember";
import {MemberService} from "../../services/member/member.service";

@Component({
  selector: 'app-create-project',
  templateUrl: './create-project.component.html',
  styleUrls: ['./create-project.component.sass']
})
export class CreateProjectComponent implements OnInit {
  projectForm: any;
  isSubmitted = false;
  project: IProject;
  state: ProjectStatus;
  user: firebase.User;

  constructor(private projectService: ProjectService,
              private authenticationService: AuthenticationService,
              private router: Router,
              private formBuilder: FormBuilder,
              private location: Location,
              private memberService: MemberService) {
    this.state = ProjectStatus.InProgress;
    this.projectForm = this.formBuilder.group({
      title: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', [Validators.required, Validators.minLength(10)]],
    });
  }

  async ngOnInit(): Promise<void> {
    await this.authenticationService.returnLoggedInUser().then(data => {
      this.user = data;
    });
  }

  get formControls() {
    return this.projectForm.controls;
  }

  createProject() {
    this.isSubmitted = true;
    if (this.projectForm.invalid) {
      return;
    }

    this.project = <IProject>{
      archived: false,
      description: this.projectForm.value.description,
      title: this.projectForm.value.title,
      status: this.state,
      owner: this.user.uid,
      members: [this.user.uid]
    }
    this.projectService.createProject(this.project).then(
      (projectData) => {
        let member = <IMember>{
          rol: ParticipantRol.admin,
          userUID: this.user.uid,
          displayName: this.user.displayName,
          projectUID: projectData.id
        };
        this.memberService.createMember(member).then(r => {
        });
        this.backClicked();
      },
      async (error) => {
        console.log(error);
      }
    );
  }

  backClicked() {
    this.location.back();
  }

}
