import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {EditProjectComponent} from './edit-project.component';
import {RouterTestingModule} from "@angular/router/testing";
import {ProjectService} from "../../services/project/project.service";
import {MockProjectService} from "../../MockServices/MockProjectService";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {MockAuthenticationService} from "../../MockServices/MockAuthenticationService";
import {Router} from "@angular/router";
import {FormBuilder, Validators} from "@angular/forms";
import {Location} from "@angular/common";
import {MemberService} from "../../services/member/member.service";
import {MockMemberService} from "../../MockServices/MockMemberService";
import {ErrorComponent} from "../error/error.component";
import {IProject} from "../../models/IProject";
import {ProjectStatus} from "../../models/ProjectStatus.enum";

describe('EditProjectComponent', () => {
  let component: EditProjectComponent;
  let fixture: ComponentFixture<EditProjectComponent>;
  const project = <IProject>{
    memberUID: "1",
    displayNameUser: "displayName1",
    uid: "1",
    title: "Title1",
    description: "description1",
    owner: "owner1",
    status: ProjectStatus.Closed,
    archived: false,
    members: ["erwin"],
    isMember: true,
  }

  function setForm(project: IProject) {
    let form = new FormBuilder();
    return form.group({
      editTitle: [project.title],
      editDescription: [project.description],
      editStatus: [project.status],
    });
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EditProjectComponent],
      imports: [RouterTestingModule.withRoutes([{
        path: "error", component: ErrorComponent
      }])],
      providers: [
        {provide: ProjectService, useClass: MockProjectService},
        {provide: AuthenticationService, useClass: MockAuthenticationService},
        {provide: FormBuilder, useClass: FormBuilder},
        {provide: Location, useClass: Location},
        {provide: MemberService, useClass: MockMemberService}]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it("get all states", () => {
    expect(component.getStates().length).toBe(2);
  });

  it("update the project", () => {
    component.projectForm = setForm(project);
    component.editProject();
    expect(component.isSubmitted).toBeTrue();

  });
});
