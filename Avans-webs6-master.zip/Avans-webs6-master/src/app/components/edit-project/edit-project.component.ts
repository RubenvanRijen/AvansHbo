import {Component, OnInit} from '@angular/core';
import {ProjectService} from "../../services/project/project.service";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import { Validators, FormBuilder} from "@angular/forms";
import {Router} from "@angular/router";
import {IProject} from "../../models/IProject";
import {ProjectStatus} from "../../models/ProjectStatus.enum";
import * as firebase from "firebase";
import {Location} from '@angular/common';
import {ActivatedRoute} from "@angular/router";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-edit-project',
  templateUrl: './edit-project.component.html',
  styleUrls: ['./edit-project.component.sass']
})
export class EditProjectComponent implements OnInit {
  projectForm: any;
  isSubmitted = false;
  user: firebase.User;
  states: any;
  project: any;
  routeSub: Subscription;
  params: any;
  canEdit: boolean = false;
  projectObserver: any;

  constructor(private projectService: ProjectService,
              private authenticationService: AuthenticationService,
              private router: Router,
              private formBuilder: FormBuilder,
              private location: Location,
              private activatedRoute: ActivatedRoute,) {
    //get id of project from params
    this.routeSub = this.activatedRoute.params.subscribe(params => {
      this.params = params;
    });
    //get all info from project
    this.projectObserver = this.projectService.getProject(this.params.id).subscribe(project => {
      this.project = project;
      project.members.map(member => {
        let user = this.authenticationService.getUser().then(data => {
          if (data.uid === member) {
            this.canEdit = true;
          }
        });

        //set the form and validation
        this.projectForm = this.formBuilder.group({
          editTitle: [this.project.title, [Validators.minLength(3)]],
          editDescription: [this.project.description, [Validators.minLength(10)]],
          editStatus: [this.project.status, []],
        });
      });

    });

    //set the states for the form
    this.states = this.getStates();
  }

  async ngOnInit(): Promise<void> {
    //get the user information
    await this.authenticationService.returnLoggedInUser().then(data => {
      this.user = data;
    });
    if (!this.canEdit) {
      this.router.navigate(['error']);
    }
  }

  get formControls() {
    return this.projectForm.controls;
  }

  ngOnDestroy() {
    this.projectObserver.unsubscribe();
    this.routeSub.unsubscribe();
  }

  getStates() {
    return [
      {id: ProjectStatus.InProgress, name: ProjectStatus.InProgress},
      {id: ProjectStatus.Closed, name: ProjectStatus.Closed}
    ];
  }

  editProject() {
    this.isSubmitted = true;
    if (this.projectForm.invalid) {
      return;
    }
    let editProject = <IProject>{
      status: this.projectForm.value.editStatus,
      description: this.projectForm.value.editDescription,
      title: this.projectForm.value.editTitle,
    }
    this.projectService.updateProject(editProject, this.project.uid).then(() => {
        this.backClicked();
      },
      async (error) => {
        console.log(error.message);
      }
    );
  }

  backClicked() {
    this.location.back();
  }
}
