import { Component, OnInit, Input } from '@angular/core';
import { IUserStory } from '../../models/IUserStory';
import {
  CdkDragDrop,
  moveItemInArray,
  transferArrayItem,
} from '@angular/cdk/drag-drop';
import { UserStoryService } from '../../services/userStory/user-story.service';

@Component({
  selector: 'app-board-column',
  templateUrl: './board-column.component.html',
  styleUrls: ['./board-column.component.sass'],
})
export class BoardColumnComponent implements OnInit {
  @Input()
  status: string;
  @Input()
  userStories: IUserStory[];
  @Input()
  isMember: boolean;
  @Input()
  memberUid: string;
  @Input()
  memberName: string;

  CanDrag:boolean = false;

  constructor(private userStoryService: UserStoryService) {}

  ngOnInit(): void {}

  drop(event: CdkDragDrop<string[]>) {
    if (this.isMember) {
      this.CanDrag = true;
      if (event.previousContainer === event.container) {
        moveItemInArray(
          event.container?.data,
          event.previousIndex,
          event.currentIndex
        );
      } else {
        transferArrayItem(
          event.previousContainer?.data,
          event.container?.data,
          event.previousIndex,
          event.currentIndex
        );
        let userStory: any = event.container.data[event.currentIndex];
        let userStoryInfo = event.container.id.split('-').splice(0, 3);
        if (userStoryInfo[0] === 'No owner') {
          this.userStoryService.updateUserStoryStatus(
            userStory,
            'New',
            '',
            ''
          );
        } else {
          if (userStoryInfo[2].length !== 0 && userStoryInfo[1].length !== 0) {
            this.userStoryService.updateUserStoryStatus(
              userStory,
              userStoryInfo[0],
              userStoryInfo[1],
              userStoryInfo[2]
            );
          }
        }
      }
    }
    this.CanDrag = false;
  }
}
