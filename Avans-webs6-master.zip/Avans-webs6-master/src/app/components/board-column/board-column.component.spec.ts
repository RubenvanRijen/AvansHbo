import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {BoardColumnComponent} from './board-column.component';
import {RouterTestingModule} from "@angular/router/testing";
import {UserStoryService} from "../../services/userStory/user-story.service";
import {MockUserStoryService} from "../../MockServices/MockUserStoryService";
import {IUserStory} from "../../models/IUserStory";
import {UserStoryStatusEnum} from "../../models/UserStoryStatus.enum";
import {CdkDragDrop} from "@angular/cdk/drag-drop";
import {Observable} from "rxjs";


describe('BoardColumnComponent', () => {
  let component: BoardColumnComponent;
  let fixture: ComponentFixture<BoardColumnComponent>;
  let userStory = <IUserStory>{
    isArchived: false,
    owner: "0123456789",
    ownerName: "Ruben",
    uid: "9876543210",
    sprintName: "Sprint 1",
    sprintUID: "5244125863",
    epicColor: "red",
    epicName: "epic1",
    epicUID: "2368547109",
    storyPoints: 2,
    projectUID: "24856321048",
    statusLastEdited: "2020-05-05",
    title: "title",
    status: UserStoryStatusEnum.New,
    description: "dit is een description",
  }

  let ckdrag: CdkDragDrop<string[]> = {
    container: null,
    currentIndex: 0,
    distance: {x: 0, y: 0},
    isPointerOverContainer: false,
    item: undefined,
    previousContainer: null,
    previousIndex: 0
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BoardColumnComponent],
      imports: [RouterTestingModule],
      providers: [{provide: UserStoryService, useClass: MockUserStoryService}]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BoardColumnComponent);
    component = fixture.componentInstance;
    component.isMember = false;
    component.memberName = "Ruben";
    component.memberUid = "1";
    component.status = "No owner";
    component.userStories = [userStory];
    component.ngOnInit();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should be able to drag', () => {
    component.drop(ckdrag)
    expect(component.CanDrag).toBe(false);
  });

  it('should be able to drag', () => {
    component.isMember = true
    spyOn(component, 'drop').and.returnValue(undefined);
    component.drop(ckdrag);
    expect(component.drop).toHaveBeenCalled();
  });
});
