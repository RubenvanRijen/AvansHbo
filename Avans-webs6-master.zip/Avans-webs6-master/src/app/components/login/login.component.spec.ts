import {async, ComponentFixture, fakeAsync, TestBed, tick} from '@angular/core/testing';
import {LoginComponent} from './login.component';
import {RouterTestingModule} from "@angular/router/testing";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {MockAuthenticationService} from "../../MockServices/MockAuthenticationService";
import {FormBuilder, Validators} from "@angular/forms";
import {Location} from "@angular/common";
import {ValidationService} from "../../services/Validation/validation.service";
import {HttpClientTestingModule} from "@angular/common/http/testing";
import {HomeComponent} from "../home/home.component";

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let location: Location;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoginComponent],
      imports: [RouterTestingModule.withRoutes([{path: 'home', component: HomeComponent}])],
      providers: [
        {provide: AuthenticationService, useClass: MockAuthenticationService},
        {provide: FormBuilder, useClass: FormBuilder}
      ]
    })
      .compileComponents();
    location = TestBed.get(Location);

  }));

  beforeEach(() => {

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("login success", fakeAsync(() => {
    component.ngOnInit();
    let authForm = new FormBuilder();
    component.authForm = authForm.group({
      email: 'jim@gmail.com',
      password: 'Test1234?'
    })
    component.formControls;
    component.loginUser();
    tick(3000);
    expect(location.path()).toBe('/home');
    expect(component.registerLink).toBe('/register')
  }));

});
