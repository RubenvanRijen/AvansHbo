import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../services/authentication/Authentication.service';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { ValidationService } from '../../services/Validation/validation.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.sass'],
})
export class LoginComponent implements OnInit {
  authForm: any;
  isSubmitted = false;
  registerLink = '/register';
  CanLogIn = true;
  constructor(
    private authenticationService: AuthenticationService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.authForm = this.formBuilder.group({
      email: ['', [Validators.required, ValidationService.emailValidator]],
      password: ['', Validators.required],
    });
  }

  get formControls() {
    return this.authForm.controls;
  }

  async loginUser(): Promise<void> {
    this.isSubmitted = true;
    if (this.authForm.invalid) {
      return;
    }
    this.authenticationService
      .login(this.authForm.value.email, this.authForm.value.password)
      .then(
        () => {
          this.router.navigate(['/home']);
        },
        async (error) => {
          this.CanLogIn = false;
          console.log(error);
        }
      );
  }
}
