import {Component, Input, OnInit} from '@angular/core';
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import * as firebase from "firebase";
import {IEpic} from "../../models/IEpic";
import {EpicService} from "../../services/epic/epic.service";
import {FormBuilder, Validators} from "@angular/forms";
import {ProjectService} from "../../services/project/project.service";
import {IProject} from "../../models/IProject";
import {UserStoryService} from "../../services/userStory/user-story.service";
import {IUserStory} from "../../models/IUserStory";

@Component({
  selector: 'app-epic-overview',
  templateUrl: './epic-overview.component.html',
  styleUrls: ['./epic-overview.component.sass']
})
export class EpicOverviewComponent implements OnInit {
  user: firebase.User;
  epicsList: IEpic[];
  epicObserver: any;
  @Input()
  params: any;
  isEdit: boolean = true;
  showForm: boolean = false;
  isSubmitted = false;
  epicForm: any;
  colors: any;
  projectObserver: any;
  isParticipant: boolean = false;
  editEpicObserver: any;
  formText: string = "Edit";
  updateUserStoryObserver: any;
  deleteUserStoryEpic: any;

  constructor(private authenticationService: AuthenticationService,
              private epicService: EpicService,
              private formBuilder: FormBuilder,
              private projectService: ProjectService,
              private userStoryService: UserStoryService) {
    this.setFormCreate();
  }

  async ngOnInit(): Promise<void> {
    await this.authenticationService.returnLoggedInUser().then(data => {
      this.user = data;
    });
    this.getEpics();
  }

  getEpics() {
    this.epicObserver = this.epicService.getEpicsFromProject(this.params.id).subscribe((epics: IEpic[]) => {
      this.epicsList = epics;
      this.projectObserver = this.projectService.getProject(this.params.id).subscribe((project: IProject) => {
        project.members.map(member => {
          if (member === this.user.uid) {
            this.isParticipant = true;
          }
        })
      });
    });
  }

  async setFormEdit(epic: IEpic) {
    this.colors = this.setColors();
    this.epicForm = await this.formBuilder.group({
      title: [epic.title, [Validators.minLength(3)]],
      uid: [epic.uid, []],
      color: [epic.color, []],
    });
  }

  async setFormCreate() {
    this.colors = this.setColors();
    this.epicForm = await this.formBuilder.group({
      title: ['', [Validators.minLength(3)]],
      uid: [''],
      color: [''],
    });
  }

  setColors() {
    return [
      {id: "success", name: "green"},
      {id: "danger", name: "red"},
      {id: "warning", name: "yellow"},
      {id: "primary", name: "blue"},
      {id: "secondary", name: "gray"}
    ];
  }

  get formControls() {
    return this.epicForm.controls;
  }

  async showFormData(event: any, isEdit: boolean) {
    if (isEdit) {
      this.formText = "Edit";
      const uid = event.target.id;
      this.isEdit = true;
      this.editEpicObserver = await this.epicService.getEpic(uid).subscribe(async data => {
        await this.setFormEdit(data);
      });
    } else {
      this.isEdit = false;
      this.formText = "Create";
      await this.setFormCreate();
    }
    this.showForm = true;
  }

  backClicked() {
    this.showForm = false;
    if (this.updateUserStoryObserver) {
      this.updateUserStoryObserver.unsubscribe();
    }
    if (this.editEpicObserver) {
      this.editEpicObserver.unsubscribe();
    }
  }

  updateOrCreateEpic() {
    if (this.isEdit) {
      this.updateEpic();
    } else {
      this.createEpic();
    }
  }

  deleteEpic(event: any) {
    const uid = event.target.id;
    this.epicService.deleteEpic(uid).then(result => {
      this.deleteUserStoryEpic = this.userStoryService.filterUserStories("epicUID", uid).subscribe((userStories: IUserStory[]) => {
        userStories.map(story => {
          story.epicName = "";
          story.epicColor = "";
          this.userStoryService.updateUserStory(story, story.uid);
        })
      })
    }).catch(error => {
      console.log(error);
    })
  }

  createEpic() {
    this.isSubmitted = true;
    if (this.epicForm.invalid) {
      return;
    }
    let createEpic = <IEpic>{
      title: this.epicForm.value.title,
      color: this.epicForm.value.color,
      projectUID: this.params.id
    }
    this.epicService.createEpic(createEpic).then(r => {
      this.showForm = false;
    }).catch(error => {
      console.log(error);
    });
  }

  updateEpic() {
    this.isSubmitted = true;
    if (this.epicForm.invalid) {
      return;
    }

    let editEpic = <IEpic>{
      title: this.epicForm.value.title,
      color: this.epicForm.value.color,
    }

    this.epicService.updateEpic(this.epicForm.value.uid, editEpic).then(r => {
      this.showForm = false;
      this.updateUserStoryObserver = this.userStoryService.filterUserStories('epicUID', this.epicForm.value.uid).subscribe((userStories: IUserStory[]) => {
        userStories.map(story => {
          story.epicName = this.epicForm.value.title;
          story.epicColor = this.epicForm.value.color;
          this.userStoryService.updateUserStory(story, story.uid);
        })
      })
    }).catch(error => {
      console.log(error);
    });
    this.editEpicObserver?.unsubscribe();
  }


  ngOnDestroy() {
    this.epicObserver?.unsubscribe();
    this.projectObserver?.unsubscribe();
    this.editEpicObserver?.unsubscribe();
    this.updateUserStoryObserver?.unsubscribe();
    this.deleteUserStoryEpic?.unsubscribe();
  }
}
