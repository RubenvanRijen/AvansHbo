import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {EpicOverviewComponent} from './epic-overview.component';
import {RouterTestingModule} from "@angular/router/testing";
import {ProjectService} from "../../services/project/project.service";
import {MockProjectService} from "../../MockServices/MockProjectService";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {MockAuthenticationService} from "../../MockServices/MockAuthenticationService";
import {Router} from "@angular/router";
import {FormBuilder, Validators} from "@angular/forms";
import {Location} from "@angular/common";
import {MemberService} from "../../services/member/member.service";
import {MockMemberService} from "../../MockServices/MockMemberService";
import {EpicService} from "../../services/epic/epic.service";
import {MockEpicService} from "../../MockServices/MockEpicService";
import {UserStoryService} from "../../services/userStory/user-story.service";
import {MockUserStoryService} from "../../MockServices/MockUserStoryService";
import {of} from "rxjs";
import * as firebase from "firebase";
import {IEpic} from "../../models/IEpic";

function setUser() {
  return new class implements firebase.User {
    displayName: string | null;
    email: string | null;
    emailVerified: boolean;
    isAnonymous: boolean;
    metadata: firebase.auth.UserMetadata;
    multiFactor: firebase.User.MultiFactorUser;
    phoneNumber: string | null;
    photoURL: string | null;
    providerData: (firebase.UserInfo | null)[];
    providerId: string;
    refreshToken: string;
    tenantId: string | null;
    uid: string;

    delete(): Promise<void> {
      return Promise.resolve(undefined);
    }

    getIdToken(forceRefresh?: boolean): Promise<string> {
      return Promise.resolve("");
    }

    getIdTokenResult(forceRefresh?: boolean): Promise<firebase.auth.IdTokenResult> {
      return Promise.resolve(undefined);
    }

    linkAndRetrieveDataWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithPhoneNumber(phoneNumber: string, applicationVerifier: firebase.auth.ApplicationVerifier): Promise<firebase.auth.ConfirmationResult> {
      return Promise.resolve(undefined);
    }

    linkWithPopup(provider: firebase.auth.AuthProvider): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithRedirect(provider: firebase.auth.AuthProvider): Promise<void> {
      return Promise.resolve(undefined);
    }

    reauthenticateAndRetrieveDataWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithPhoneNumber(phoneNumber: string, applicationVerifier: firebase.auth.ApplicationVerifier): Promise<firebase.auth.ConfirmationResult> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithPopup(provider: firebase.auth.AuthProvider): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithRedirect(provider: firebase.auth.AuthProvider): Promise<void> {
      return Promise.resolve(undefined);
    }

    reload(): Promise<void> {
      return Promise.resolve(undefined);
    }

    sendEmailVerification(actionCodeSettings?: firebase.auth.ActionCodeSettings | null): Promise<void> {
      return Promise.resolve(undefined);
    }

    toJSON(): Object {
      return undefined;
    }

    unlink(providerId: string): Promise<firebase.User> {
      return Promise.resolve(undefined);
    }

    updateEmail(newEmail: string): Promise<void> {
      return Promise.resolve(undefined);
    }

    updatePassword(newPassword: string): Promise<void> {
      return Promise.resolve(undefined);
    }

    updatePhoneNumber(phoneCredential: firebase.auth.AuthCredential): Promise<void> {
      return Promise.resolve(undefined);
    }

    updateProfile(profile: { displayName?: string | null; photoURL?: string | null }): Promise<void> {
      return Promise.resolve(undefined);
    }

    verifyBeforeUpdateEmail(newEmail: string, actionCodeSettings?: firebase.auth.ActionCodeSettings | null): Promise<void> {
      return Promise.resolve(undefined);
    }
  }
}

function setForm(epic: IEpic) {
  let form = new FormBuilder();
  return form.group({
    title: [epic.title],
    uid: [epic.uid],
    color: [epic.color],
  });
}

describe('EpicOverviewComponent', () => {
  let component: EpicOverviewComponent;
  let fixture: ComponentFixture<EpicOverviewComponent>;
  let epic = <IEpic>{
    title: "title",
    color: "red",
    projectUID: "1"
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EpicOverviewComponent],
      imports: [RouterTestingModule],
      providers: [
        {provide: AuthenticationService, useClass: MockAuthenticationService},
        {provide: EpicService, useClass: MockEpicService},
        {provide: FormBuilder, useClass: FormBuilder},
        {provide: ProjectService, useClass: MockProjectService},
        {provide: UserStoryService, useClass: MockUserStoryService}]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EpicOverviewComponent);
    component = fixture.componentInstance;
    component.params = of({id: 1})
    if (!component.user) {
      component.user = setUser();
      component.user.uid = "1";
    }
    fixture.detectChanges();
  });

  it('should create', () => {
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  describe("setColors", () => {
    it("should return 5 colors", () => {
      expect(component.setColors().length).toBe(5);
    })
  })

  describe("showFormData", () => {
    it('should show form data edit', () => {
      component.showFormData("", true);
      expect(component.formText).toBe("Edit");
    });

    it('should show form data create', () => {
      component.showFormData("", false);
      expect(component.formText).toBe("Create");
    });
  });

  it("shoudl return all epics", () => {
    component.getEpics();
    expect(component.epicsList.length).toBe(2);
  });

  it("cancel edit", () => {
    component.backClicked();
    expect(component.showForm).toBeFalse();
  });

  it("update or create function(create)", () => {
    component.isEdit = false;
    component.epicForm = setForm(epic);
    component.setFormCreate();
    component.updateOrCreateEpic();
    expect(component.isSubmitted).toBeTrue();
  });

  it("update or create function(create)", () => {
    component.isEdit = true;
    component.epicForm = setForm(epic);
    component.setFormEdit(epic);
    component.updateOrCreateEpic();
    expect(component.isSubmitted).toBeTrue();
  });

  it("delete epic 1", () => {
    component.deleteEpic({target: {id: 1}});
    spyOn(component, 'deleteEpic');
    component.deleteEpic({target: {id: 1}});
    expect(component.deleteEpic).toHaveBeenCalled();
    expect(component.showForm).toBeFalse();
  });

  it("Create epic", () => {
    component.epicForm = setForm(epic);
    component.setFormCreate();
    component.createEpic();
    expect(component.isSubmitted).toBeTrue();
  });

  it("Update epic", () => {
    component.epicForm = setForm(epic);
    component.setFormEdit(epic);
    component.updateEpic();
    expect(component.isSubmitted).toBeTrue();
  });
});
