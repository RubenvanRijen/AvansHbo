import {Component, Input, OnInit} from '@angular/core';
import {UserStoryService} from "../../services/userStory/user-story.service";
import {IUserStory} from "../../models/IUserStory";
import {IProject} from "../../models/IProject";
import {ProjectService} from "../../services/project/project.service";
import * as firebase from "firebase";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {UserStoryStatusEnum} from "../../models/UserStoryStatus.enum";
import {ISprint} from "../../models/ISprint";
import {FormBuilder, Validators} from "@angular/forms";
import {EpicService} from "../../services/epic/epic.service";
import {IEpic} from "../../models/IEpic";
import {SprintService} from "../../services/sprint/sprint.service";
import {MemberService} from "../../services/member/member.service";
import {IMember} from "../../models/IMember";

@Component({
  selector: 'app-backlog',
  templateUrl: './backlog.component.html',
  styleUrls: ['./backlog.component.sass']
})
export class BacklogComponent implements OnInit {

  isSubmitted: boolean = false;
  isEdit: boolean = true;
  userStoryForm: any;
  showForm: boolean = false;
  formText: string = 'Edit';
  states: any;

  userStoryObserver: any;
  userStorieList: IUserStory[] = [];
  projectObserver: any;
  isParticipant: boolean = false;
  user: firebase.User;
  editUserStoryObserver: any;
  epicObserver: any;
  epics: any;
  sprintObserver: any;
  sprints: any;
  epicArray: any = [];
  sprintArray: any = [];
  epicObserverName: any;
  memberArray: any[] = [];
  memberObserver: any;
  archivedStories: Boolean = false;

  @Input()
  params: any;

  constructor(private userStoryService: UserStoryService,
              private projectService: ProjectService,
              private authenticationService: AuthenticationService,
              private formBuilder: FormBuilder,
              private epicService: EpicService,
              private sprintService: SprintService,
              private memberService: MemberService
  ) {
    this.setFormCreate();
  }

  async ngOnInit(): Promise<void> {
    await this.authenticationService.returnLoggedInUser().then((user) => {
      this.user = user;
    });
    this.getUserStories(false);
  }

  getUserStories(isArchived: boolean) {
    if (this.userStoryObserver) {
      this.userStoryObserver.unsubscribe();
    }
    this.archivedStories = isArchived;

    this.userStoryObserver = this.userStoryService.filterUserStoriesWithMultipleFields("projectUID", this.params.id, 'isArchived', isArchived).subscribe((userStories: IUserStory[]) => {
      this.userStorieList = userStories;
      this.projectObserver = this.projectService
        .getProject(this.params.id)
        .subscribe((project: IProject) => {
          project.members.map((member) => {
            if (this.user) {
              if (member === this.user.uid) {
                this.isParticipant = true;
              }
            }
          });
        });
    });
  }

  async updateOrCreateUserStory() {
    if (this.isEdit) {
      await this.updateUserStory();
    } else {
      this.createUserStory();
    }
  }

  async showFormData(event: any, isEdit: boolean) {
    this.states = this.getStates();
    this.getEpics();
    this.getSprints();
    this.getMembers();
    if (isEdit) {
      this.formText = 'Edit';
      this.isEdit = true;
      const uid = event.target.id;
      this.editUserStoryObserver = this.userStoryService
        .getUserStory(uid)
        .subscribe(async (data) => {
          await this.setFormEdit(data);
        });
    } else {
      this.isEdit = false;
      this.formText = 'Create';
      await this.setFormCreate();
    }
    this.showForm = true;
  }

  getStates() {
    return [
      {id: UserStoryStatusEnum.InProgress, name: UserStoryStatusEnum.InProgress},
      {id: UserStoryStatusEnum.New, name: UserStoryStatusEnum.New},
      {id: UserStoryStatusEnum.ReadyForTest, name: UserStoryStatusEnum.ReadyForTest},
      {id: UserStoryStatusEnum.Closed, name: UserStoryStatusEnum.Closed},
    ];
  }

  getEpics() {
    this.epicObserver = this.epicService.getEpicsFromProject(this.params.id).subscribe((epics: IEpic[]) => {
      this.epicArray = [];
      epics.map(epic => {
        this.epicArray.push({id: epic.uid, name: epic.title, color: epic.color})
      });
      this.epicArray.push({id: "", name: "", color: ""})

    });
  }

  getSprints() {
    this.sprintObserver = this.sprintService.getSprintsFromProject(this.params.id).subscribe((sprints: ISprint[]) => {
      this.sprintArray = [];
      sprints.map(sprint => {
        this.sprintArray.push({id: sprint.uid, name: sprint.title})
      });
      this.sprintArray.push({id: "", name: ""})
    });
  }

  getMembers() {
    this.memberObserver = this.memberService.getMembersFromProject(this.params.id).subscribe((members: IMember[]) => {
      this.memberArray = [];
      members.map(member => {
        this.memberArray.push({
          id: member.uid,
          name: member.displayName,
          userUID: member.userUID,
          rol: member.rol,
          projectUID: member.projectUID
        });
      });
      this.memberArray.push({
        id: '',
        name: '',
        userUID: '',
        rol: '',
        projectUID: ''
      })
    });
  }

  async setFormEdit(userStory: IUserStory) {
    this.userStoryForm = await this.formBuilder.group({
      title: [userStory.title, [Validators.minLength(3)]],
      storyPoints: [userStory.storyPoints, [Validators.min(1), Validators.required]],
      description: [userStory.description, [Validators.minLength(5), Validators.required]],
      uid: [userStory.uid, []],
      status: [userStory.status, [Validators.required]],
      epicUID: [userStory.epicUID, []],
      projectUID: [userStory.projectUID, []],
      sprintUID: [userStory.sprintUID, []],
      statusLastEdited: [userStory.statusLastEdited, []],
      owner: [userStory.owner],
      ownerName: [userStory.ownerName]
    });
  }

  async setFormCreate() {
    this.userStoryForm = await this.formBuilder.group({
      title: ['', [Validators.minLength(3), Validators.required]],
      storyPoints: ['', [Validators.min(1), Validators.required]],
      description: ['', [Validators.minLength(5)]],
      uid: ['', []],
      status: ['', []],
      epicUID: ['', []],
      projectUID: ['', []],
      sprintUID: ['', []],
      statusLastEdited: ['', []],
      owner: ['', []],
      ownerName: ['', []]
    });
  }

  get formControls() {
    return this.userStoryForm.controls;
  }

  async updateUserStory() {
    this.isSubmitted = true;
    if (this.userStoryForm.invalid) {
      return;
    }
    let statusLastEdited = new Date;
    let newDate = statusLastEdited.toISOString().slice(0, 10);
    let epicTitle;
    let sprintTitle;
    let epicColor;
    let owner;
    let ownerName;

    await this.epicArray.map(data => {
      if (data.id === this.userStoryForm.value.epicUID) {
        epicTitle = data.name;
        epicColor = data.color;
      }
    });

    await this.memberArray.map(data => {
      if (data.id === this.userStoryForm.value.owner) {
        owner = data.id;
        ownerName = data.name;
      }
    })

    await this.sprintArray.map(data => {
      if (data.id === this.userStoryForm.value.sprintUID) {
        sprintTitle = data.name
      }
    });

    let newUserStory = <IUserStory>{
      title: this.userStoryForm.value.title,
      description: this.userStoryForm.value.description,
      storyPoints: this.userStoryForm.value.storyPoints,
      status: this.userStoryForm.value.status,
      sprintUID: this.userStoryForm.value.sprintUID,
      epicUID: this.userStoryForm.value.epicUID,
      statusLastEdited: newDate,
      epicName: epicTitle ?? '',
      sprintName: sprintTitle ?? '',
      epicColor: epicColor ?? '',
      owner: owner ?? '',
      ownerName: ownerName ?? '',
    };

    this.userStoryService
      .updateUserStory(newUserStory, this.userStoryForm.value.uid)
      .then(() => {
        this.showForm = false;
      })
      .catch((error) => {
        console.log(error);
      });
    this.editUserStoryObserver.unsubscribe();
    if (this.epicObserver) {
      this.epicObserver.unsubscribe();
    }
    if (this.sprintObserver) {
      this.sprintObserver.unsubscribe();
    }
    if (this.memberObserver) {
      this.memberObserver.unsubscribe();
    }
  }

  backClicked() {
    this.showForm = false;
    if (this.editUserStoryObserver) {
      this.editUserStoryObserver.unsubscribe();
    }
    if (this.epicObserverName) {
      this.epicObserverName.unsubscribe();
    }
    if (this.memberObserver) {
      this.memberObserver.unsubscribe();
    }
  }

  archiveOrUnArchive(event: any, value: boolean) {
    const uid = event.target.id;
    this.userStoryService
      .archiveUserStory(uid, value)
      .then((result) => {
        return result;
      })
      .catch((error) => {
        console.log(error);
      });
  }


  async createUserStory() {
    this.isSubmitted = true;
    if (this.userStoryForm.invalid) {
      return;
    }
    let epicTitle;
    let sprintTitle;
    let epicColor;

    await this.epicArray.map(data => {
      if (data.id === this.userStoryForm.value.epicUID) {
        epicTitle = data.name;
        epicColor = data.color;
      }
    });

    await this.sprintArray.map(data => {
      if (data.id === this.userStoryForm.value.sprintUID) {
        sprintTitle = data.name
      }
    });
    let statusLastEdited = new Date;
    let newDate = statusLastEdited.toISOString().slice(0, 10);
    let newUserStory = <IUserStory>{
      description: this.userStoryForm.value.description,
      statusLastEdited: newDate,
      sprintUID: this.userStoryForm.value.sprintUID,
      epicUID: this.userStoryForm.value.epicUID,
      status: UserStoryStatusEnum.New,
      title: this.userStoryForm.value.title,
      projectUID: this.params.id,
      storyPoints: this.userStoryForm.value.storyPoints,
      epicColor: epicColor,
      sprintName: sprintTitle,
      epicName: epicTitle,
      isArchived: false,
      owner: this.userStoryForm.value.owner,
      ownerName: this.userStoryForm.value.ownerName,
    };

    this.userStoryService
      .createUserStory(newUserStory)
      .then(() => {
        this.showForm = false;
      })
      .catch((error) => {
        console.log({error});
      });
    this.epicObserver?.unsubscribe();
    this.sprintObserver?.unsubscribe();
    this.memberObserver?.unsubscribe();
  }

  ngOnDestroy() {
    this.userStoryObserver?.unsubscribe();
    this.projectObserver?.unsubscribe();
    this.editUserStoryObserver?.unsubscribe();
    this.epicObserver?.unsubscribe();
    this.sprintObserver?.unsubscribe();
    this.epicObserverName?.unsubscribe();
    this.memberObserver?.unsubscribe();
  }
}
