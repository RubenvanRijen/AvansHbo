import {async, ComponentFixture, fakeAsync, TestBed, tick} from '@angular/core/testing';
import {BacklogComponent} from './backlog.component';
import {UserStoryService} from "../../services/userStory/user-story.service";
import {ProjectService} from "../../services/project/project.service";
import {RouterTestingModule} from "@angular/router/testing";
import {MockUserStoryService} from "../../MockServices/MockUserStoryService";
import {MockProjectService} from "../../MockServices/MockProjectService";
import {AuthenticationService} from "../../services/authentication/Authentication.service";
import {MockAuthenticationService} from "../../MockServices/MockAuthenticationService";
import {FormBuilder, Validators} from "@angular/forms";
import {EpicService} from "../../services/epic/epic.service";
import {MockEpicService} from "../../MockServices/MockEpicService";
import {SprintService} from "../../services/sprint/sprint.service";
import {MockSprintService} from "../../MockServices/MockSprintService";
import {MemberService} from "../../services/member/member.service";
import {MockMemberService} from "../../MockServices/MockMemberService";
import {of} from "rxjs";
import {UserStoryStatusEnum} from "../../models/UserStoryStatus.enum";
import {IUserStory} from "../../models/IUserStory";
import * as firebase from "firebase";

function setUser() {
  return new class implements firebase.User {
    displayName: string | null;
    email: string | null;
    emailVerified: boolean;
    isAnonymous: boolean;
    metadata: firebase.auth.UserMetadata;
    multiFactor: firebase.User.MultiFactorUser;
    phoneNumber: string | null;
    photoURL: string | null;
    providerData: (firebase.UserInfo | null)[];
    providerId: string;
    refreshToken: string;
    tenantId: string | null;
    uid: string;

    delete(): Promise<void> {
      return Promise.resolve(undefined);
    }

    getIdToken(forceRefresh?: boolean): Promise<string> {
      return Promise.resolve("");
    }

    getIdTokenResult(forceRefresh?: boolean): Promise<firebase.auth.IdTokenResult> {
      return Promise.resolve(undefined);
    }

    linkAndRetrieveDataWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithPhoneNumber(phoneNumber: string, applicationVerifier: firebase.auth.ApplicationVerifier): Promise<firebase.auth.ConfirmationResult> {
      return Promise.resolve(undefined);
    }

    linkWithPopup(provider: firebase.auth.AuthProvider): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    linkWithRedirect(provider: firebase.auth.AuthProvider): Promise<void> {
      return Promise.resolve(undefined);
    }

    reauthenticateAndRetrieveDataWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithCredential(credential: firebase.auth.AuthCredential): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithPhoneNumber(phoneNumber: string, applicationVerifier: firebase.auth.ApplicationVerifier): Promise<firebase.auth.ConfirmationResult> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithPopup(provider: firebase.auth.AuthProvider): Promise<firebase.auth.UserCredential> {
      return Promise.resolve(undefined);
    }

    reauthenticateWithRedirect(provider: firebase.auth.AuthProvider): Promise<void> {
      return Promise.resolve(undefined);
    }

    reload(): Promise<void> {
      return Promise.resolve(undefined);
    }

    sendEmailVerification(actionCodeSettings?: firebase.auth.ActionCodeSettings | null): Promise<void> {
      return Promise.resolve(undefined);
    }

    toJSON(): Object {
      return undefined;
    }

    unlink(providerId: string): Promise<firebase.User> {
      return Promise.resolve(undefined);
    }

    updateEmail(newEmail: string): Promise<void> {
      return Promise.resolve(undefined);
    }

    updatePassword(newPassword: string): Promise<void> {
      return Promise.resolve(undefined);
    }

    updatePhoneNumber(phoneCredential: firebase.auth.AuthCredential): Promise<void> {
      return Promise.resolve(undefined);
    }

    updateProfile(profile: { displayName?: string | null; photoURL?: string | null }): Promise<void> {
      return Promise.resolve(undefined);
    }

    verifyBeforeUpdateEmail(newEmail: string, actionCodeSettings?: firebase.auth.ActionCodeSettings | null): Promise<void> {
      return Promise.resolve(undefined);
    }
  }
}

function setForm(userStory) {
  let form = new FormBuilder;
  form.group({
    title: [userStory.title],
    storyPoints: [userStory.storyPoints],
    description: [userStory.description],
    uid: [userStory.uid],
    status: [userStory.status],
    epicUID: [userStory.epicUID],
    projectUID: [userStory.projectUID],
    sprintUID: [userStory.sprintUID],
    statusLastEdited: [userStory.statusLastEdited],
    owner: [userStory.owner],
    ownerName: [userStory.ownerName]
  });
  return form;
}

describe('BacklogComponent', () => {
  let component: BacklogComponent;
  let fixture: ComponentFixture<BacklogComponent>;
  let spy: any;
  let userStory = <IUserStory>{
    isArchived: false,
    owner: "0123456789",
    ownerName: "Ruben",
    uid: "1",
    sprintName: "Sprint 1",
    sprintUID: "1",
    epicColor: "red",
    epicName: "epic1",
    epicUID: "1",
    storyPoints: 2,
    projectUID: "1",
    statusLastEdited: "2020-05-05",
    title: "title",
    status: UserStoryStatusEnum.New,
    description: "dit is een description"
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BacklogComponent],
      imports: [RouterTestingModule],
      providers: [
        {provide: UserStoryService, useClass: MockUserStoryService},
        {provide: ProjectService, useClass: MockProjectService},
        {provide: AuthenticationService, useClass: MockAuthenticationService},
        {provide: FormBuilder, useClass: FormBuilder},
        {provide: EpicService, useClass: MockEpicService},
        {provide: SprintService, useClass: MockSprintService},
        {provide: MemberService, useClass: MockMemberService},
        {provide: UserStoryService, useClass: MockUserStoryService},
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BacklogComponent);
    component = fixture.componentInstance;
    component.params = of({id: 1});
    component.getUserStories(false);
    component.getMembers();
    component.getEpics();
    component.getSprints();
    if (!component.user) {
      component.user = setUser();
      component.user.uid = "1";
    }
    fixture.detectChanges();
  });

  it('should create', () => {
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it("UserStorielist should be filled", () => {
    component.getUserStories(false);
    expect(component.userStorieList.length).toBe(1);
    expect(component.userStorieList[0].title).toBe("title")
  });

  it("UserStorielist should be filled", () => {
    component.getUserStories(true);
    expect(component.userStorieList.length).toBe(1);
    expect(component.userStorieList[0].title).toBe("title")
  });

  it("return all states", () => {
    let states = component.getStates();
    expect(states.length).toBe(4)
  });

  it("members array", () => {
    component.getMembers();
    expect(component.memberArray.length).toBe(2);
  });

  it("sprints array", () => {
    component.getSprints();
    expect(component.sprintArray.length).toBe(2);
  });

  it("epic array", () => {
    component.getEpics();
    expect(component.epicArray.length).toBe(3);
  });

  it("Editform", () => {
    component.setFormEdit(userStory);
    component.createUserStory();
    expect(component.showForm).toBeFalse();
  });

  it("CreateForm", () => {

    component.setFormEdit(userStory);
    component.updateUserStory();
    expect(component.showForm).toBeFalse();
  });


  it("Cancel button", () => {
    component.backClicked()
    expect(component.showForm).toBeFalse();
  });

  it("set form", () => {
    component.ngOnInit()
    component.showFormData({target: {id: 1}}, false);
    expect(component.formText).toBe('Create');
  });

  it("set form", () => {
    component.ngOnInit()
    component.showFormData({target: {id: 1}}, true);
    expect(component.formText).toBe('Edit');
  });

  it("get user stories", () => {
    component.ngOnInit()
    component.getUserStories(false);
    expect(component.userStorieList.length).toBe(1);
  });

  it("create new userStory", () => {
    component.userStoryForm = setForm(userStory);
    component.setFormCreate();
    component.createUserStory();
    expect(component.isSubmitted).toBeTrue();
    spyOn(component, 'createUserStory').and.returnValue(null);
    component.createUserStory();
    expect(component.createUserStory).toHaveBeenCalled();
  });

  it("edit  userStory", () => {
    component.userStoryForm = setForm(userStory);
    component.setFormEdit(userStory);
    component.updateUserStory();
    expect(component.isSubmitted).toBeTrue();
    spyOn(component, 'updateUserStory').and.returnValue(null);
    component.updateUserStory();
    expect(component.updateUserStory).toHaveBeenCalled();
  });

  it("archive project", () => {
    component.archiveOrUnArchive({target: {id: 1}}, false);
    spyOn(component, 'archiveOrUnArchive').and.returnValue(null);
    component.archiveOrUnArchive({target: {id: 1}}, false);
    expect(component.archiveOrUnArchive).toHaveBeenCalled();
    expect(component.showForm).toBeFalse();
  });

  it("archive project", () => {
    component.archiveOrUnArchive({target: {id: 1}}, true);
    spyOn(component, 'archiveOrUnArchive').and.returnValue(null);
    component.archiveOrUnArchive({target: {id: 1}}, true);
    expect(component.archiveOrUnArchive).toHaveBeenCalled();
    expect(component.showForm).toBeFalse();
  });

  it("set kind edit of form", () => {
    component.isEdit = false;
    component.userStoryForm = setForm(userStory);
    component.setFormEdit(userStory);
    component.updateOrCreateUserStory();
    expect(component.isSubmitted).toBeTrue();
  });

  it("set kind create of form", () => {
    component.isEdit = true;
    component.userStoryForm = setForm(userStory);
    component.setFormCreate();
    component.updateOrCreateUserStory();
    expect(component.isSubmitted).toBeTrue();
  });

});
