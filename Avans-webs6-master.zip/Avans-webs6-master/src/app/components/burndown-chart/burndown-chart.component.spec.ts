import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {BurndownChartComponent} from './burndown-chart.component';
import {RouterTestingModule} from "@angular/router/testing";
import {UserStoryService} from "../../services/userStory/user-story.service";
import {MockUserStoryService} from "../../MockServices/MockUserStoryService";
import {ISprint} from "../../models/ISprint";
import {SprintStatus} from "../../models/SprintStatus.enum";
import {IUserStory} from "../../models/IUserStory";
import {UserStoryStatusEnum} from "../../models/UserStoryStatus.enum";

describe('BurndownChartComponent', () => {
  let component: BurndownChartComponent;
  let fixture: ComponentFixture<BurndownChartComponent>;
  let sprint2 = <ISprint>{
    endDate: "2020-05-05",
    projectUID: "projectUID1",
    startDate: "2020-04-04",
    title: "Title1",
    status: SprintStatus.Planning,
    description: "description1",
    uid: "UID1"
  };
  let userStory = <IUserStory>{
    isArchived: false,
    owner: "0123456789",
    ownerName: "Ruben",
    uid: "9876543210",
    sprintName: "Sprint 1",
    sprintUID: "5244125863",
    epicColor: "red",
    epicName: "epic1",
    epicUID: "2368547109",
    storyPoints: 2,
    projectUID: "24856321048",
    statusLastEdited: "2020-05-05",
    title: "title",
    status: UserStoryStatusEnum.New,
    description: "dit is een description"
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BurndownChartComponent],
      imports: [RouterTestingModule],
      providers: [
        {provide: UserStoryService, useClass: MockUserStoryService}]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BurndownChartComponent);
    component = fixture.componentInstance;

    component.params = {
      sprintUID: 5
    }
    component.sprint = sprint2;
    component.userStories = [userStory];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("create chart called", () => {
    component.ngOnInit();
    spyOn(component, 'createChart').and.returnValue(null);
    component.createChart("title", 10, [1, 2, 3, 4]);
    expect(component.createChart).toHaveBeenCalled();
  });
});
