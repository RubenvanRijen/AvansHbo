import {Component, OnInit, Input} from '@angular/core';
import * as CanvasJS from '../../../assets/canvasjs.min.js';
import {IUserStory} from 'src/app/models/IUserStory.js';
import {ISprint} from 'src/app/models/ISprint.js';
import {UserStoryStatusEnum} from 'src/app/models/UserStoryStatus.enum.js';
import {UserStoryService} from "../../services/userStory/user-story.service";

@Component({
  selector: 'app-burndown-chart',
  templateUrl: './burndown-chart.component.html',
  styleUrls: ['./burndown-chart.component.sass'],
})
export class BurndownChartComponent implements OnInit {
  @Input()
  sprint: ISprint;
  @Input()
  userStories: IUserStory[];
  @Input()
  params: any

  constructor(private userStoryService: UserStoryService) {
  }

  ngOnInit(): void {
    this.userStoryService.filterUserStoriesWithMultipleFields('sprintUID', this.params.sprintId, 'isArchived', false).subscribe((userStories: IUserStory[]) => {
      this.userStories = userStories;

      if (this.userStories) {
        let tempUserStories = this.userStories;

        let totalStoryPoints = 0;
        tempUserStories.forEach((userStory) => {
          totalStoryPoints += userStory.storyPoints;
        });

        let leftStoryPoints = totalStoryPoints;
        let dataPoints = [];

        // get total days of sprint
        let startDate = new Date(this.sprint.startDate);
        let endDate = new Date(this.sprint.endDate);

        for (let date = startDate; date <= endDate; date.setDate(date.getDate() + 1)) {
          let newDate = new Date(date).toISOString().slice(0, 10);

          tempUserStories.forEach((userStory, index) => {
            let lastEdited = new Date(userStory.statusLastEdited).toISOString().slice(0, 10);
            if ((userStory.status === UserStoryStatusEnum.ReadyForTest || userStory.status === UserStoryStatusEnum.Closed)
              && lastEdited === newDate) {
              leftStoryPoints -= userStory.storyPoints;
            }
          });
          dataPoints.push({label: newDate, y: leftStoryPoints});
        }

        let chartTitle = `${this.sprint.title} - Burndown`;
        this.createChart(chartTitle, totalStoryPoints + 2, dataPoints);
      }
    });
  }

  createChart(title: string, maxY: number, dataPoints: any[]) {
    let chart = new CanvasJS.Chart('chartContainer', {
      animationEnabled: true,
      exportEnabled: true,
      backgroundColor: '#f3fcff',
      title: {
        text: title,
      },
      axisY: {
        maximum: maxY,
      },
      data: [
        {
          type: 'area',
          dataPoints: dataPoints,
        },
        {
          type: 'area',
          color: '#436a94',
          dataPoints: [dataPoints[0], {
            label: dataPoints[dataPoints.length - 1].label,
            x: (dataPoints.length - 1),
            y: 0
          }]
        }
      ],
    });
    chart.render();
  }
}
