import {UserStoryStatusEnum} from './UserStoryStatus.enum';

export interface IUserStory {
  uid: string;
  title: string;
  description: string;
  storyPoints: number;
  statusLastEdited: string;
  status: UserStoryStatusEnum;
  sprintUID: string;
  projectUID: string;
  epicUID: string;
  sprintName: string;
  epicName: string;
  epicColor: string;
  owner: string;
  ownerName: string;
  isArchived: boolean;
}
