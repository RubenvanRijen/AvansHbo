export enum ProjectStatus {
  InProgress = "InProgress",
  Closed = "Closed"
}
