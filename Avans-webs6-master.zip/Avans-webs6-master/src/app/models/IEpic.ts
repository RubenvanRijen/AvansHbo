export interface IEpic {
  uid: string;
  title: string;
  color: string;
  projectUID: string;
}
