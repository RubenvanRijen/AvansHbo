export enum UserStoryStatusEnum {
  New = "New",
  InProgress = "InProgress",
  ReadyForTest = "ReadyForTest",
  Closed = "Closed"
}
