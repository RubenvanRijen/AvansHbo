import {SprintStatus} from "./SprintStatus.enum";

export interface ISprint {
  uid: string;
  title: string;
  startDate: string;
  endDate: string;
  projectUID: string;
  status: SprintStatus;
  description: string;
}
