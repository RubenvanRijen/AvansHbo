export enum SprintStatus {
  Planning = "Planning",
  Active = "Active",
  Accepted = "Accepted",
  Closed = "Closed"
}
