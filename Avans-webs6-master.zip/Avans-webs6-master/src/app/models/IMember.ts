import {ParticipantRol} from "./ParticipantRol.enum";

export interface IMember {
  uid: string;
  displayName: string;
  userUID: string,
  rol: ParticipantRol;
  projectUID: string;
}
