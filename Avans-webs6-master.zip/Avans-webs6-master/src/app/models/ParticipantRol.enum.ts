export enum ParticipantRol {
  admin = "admin",
  developer = "developer",
  stakeholder = "stakeholder"
}
