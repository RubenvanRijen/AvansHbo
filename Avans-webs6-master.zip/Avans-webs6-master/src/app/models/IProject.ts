import {ProjectStatus} from "./ProjectStatus.enum";

export interface IProject {
  memberUID: string;
  displayNameUser: string;
  uid: string;
  title: string;
  description: string;
  owner: string;
  status: ProjectStatus;
  archived: boolean;
  members: [string];
  isMember: boolean;
}
