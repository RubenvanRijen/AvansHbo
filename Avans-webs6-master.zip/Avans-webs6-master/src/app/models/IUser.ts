export interface IUser {
  email: string;
  displayName: string;
  uid: string;
}
