import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './components/main/app.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { CommonModule } from '@angular/common';
import { ProjectItemComponent } from './components/project-item/project-item.component';
import { environment } from 'src/environments/environment.prod';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DragDropModule } from '@angular/cdk/drag-drop';


import {AngularFireAuthGuard} from '@angular/fire/auth-guard';
import {AngularFireModule} from '@angular/fire';
import {AngularFirestoreModule} from '@angular/fire/firestore';
import {AngularFireStorageModule} from '@angular/fire/storage';
import {AngularFireAuthModule} from '@angular/fire/auth';
import {LoginComponent} from './components/login/login.component';
import {RegisterComponent} from './components/register/register.component';
import {HomeComponent} from './components/home/home.component';
import {AboutUsComponent} from './components/about-us/about-us.component';
import {ProjectListComponent} from "./components/project-list/project-list.component";
import {CreateProjectComponent} from './components/create-project/create-project.component';
import { ControlMessagesComponent } from './components/control-messages/control-messages.component';
import {ValidationService} from "./services/Validation/validation.service";
import { EditProjectComponent } from './components/edit-project/edit-project.component';
import { BoardComponent } from './components/board/board.component';
import { BoardColumnComponent } from './components/board-column/board-column.component';
import { UserStoryCardComponent } from './components/user-story-card/user-story-card.component';
import { ErrorComponent } from './components/error/error.component';
import { SideBarComponent } from './components/side-bar/side-bar.component';
import { SprintOverviewComponent } from './components/sprint-overview/sprint-overview.component';
import { EpicOverviewComponent } from './components/epic-overview/epic-overview.component';
import { MemberOverviewComponent } from './components/member-overview/member-overview.component';
import { BacklogComponent } from './components/backlog/backlog.component';
import { BurndownChartComponent } from './components/burndown-chart/burndown-chart.component';

const fireBaseConfig = {
  apiKey: environment.firebase.api_key,
  authDomain: environment.firebase.authDomain,
  databaseURL: environment.firebase.databaseURL,
  projectId: environment.firebase.projectId,
  storageBucket: environment.firebase.storageBucket,
  messagingSenderId: environment.firebase.messagingSenderId,
};

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    ProjectItemComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    AboutUsComponent,
    ProjectListComponent,
    BoardComponent,
    BoardColumnComponent,
    UserStoryCardComponent,
    CreateProjectComponent,
    ControlMessagesComponent,
    EditProjectComponent,
    ErrorComponent,
    SideBarComponent,
    SprintOverviewComponent,
    EpicOverviewComponent,
    MemberOverviewComponent,
    BacklogComponent,
    BurndownChartComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    FontAwesomeModule,
    FormsModule,
    ReactiveFormsModule,
    AngularFireModule.initializeApp(fireBaseConfig),
    AngularFirestoreModule,
    AngularFireAuthModule,
    AngularFireStorageModule,
    DragDropModule
  ],
  providers: [AngularFireAuthGuard, ValidationService],
  bootstrap: [AppComponent]
})
export class AppModule {}
