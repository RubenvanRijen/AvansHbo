import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ProjectListComponent} from './components/project-list/project-list.component';
import {ProjectItemComponent} from './components/project-item/project-item.component';
import {LoginComponent} from './components/login/login.component';
import {RegisterComponent} from './components/register/register.component';
import {HomeComponent} from "./components/home/home.component";
import {AboutUsComponent} from "./components/about-us/about-us.component";
import {AuthGuardService} from './services/authGuard/auth-guard.service';
import {BoardComponent} from './components/board/board.component';
import {CreateProjectComponent} from "./components/create-project/create-project.component";
import {EditProjectComponent} from "./components/edit-project/edit-project.component";
import {ErrorComponent} from "./components/error/error.component";

const routes: Routes = [
  {
    path: 'projects',
    component: ProjectListComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'project/create',
    component: CreateProjectComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'projects/:id',
    component: ProjectItemComponent,
    canActivate: [AuthGuardService]
  }, {
    path: 'projects/edit/:id',
    component: EditProjectComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'projects/:id/sprints/:sprintId',
    component: BoardComponent,
    canActivate: [AuthGuardService]
  },
  {path: 'login', component: LoginComponent},
  {path: 'register', component: RegisterComponent},
  {path: 'home', component: HomeComponent},
  {path: '', component: HomeComponent},
  {path: 'aboutUs', component: AboutUsComponent},
  {path: 'error', component: ErrorComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
