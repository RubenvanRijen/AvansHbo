import {Injectable} from '@angular/core';
import {ISprint} from "../models/ISprint";
import {SprintStatus} from "../models/SprintStatus.enum";
import {of} from "rxjs";


@Injectable({
  providedIn: 'root',
})
export class MockSprintService {


  constructor() {

  }

  getSprints() {
    let sprint1 = <ISprint>{
      endDate: "2020-05-05",
      projectUID: "1",
      startDate: "2020-04-04",
      title: "Title1",
      status: SprintStatus.Planning,
      description: "description1",
      uid: "1"
    };
    let sprint2 = <ISprint>{
      endDate: "2020-05-05",
      projectUID: "1",
      startDate: "2020-04-04",
      title: "Title1",
      status: SprintStatus.Planning,
      description: "description1",
      uid: "2"
    };
    return of([sprint1, sprint2]);
  }

  getSprint(uid: string) {
    let sprint2 = <ISprint>{
      endDate: "2020-05-05",
      projectUID: "1",
      startDate: "2020-04-04",
      title: "Title1",
      status: SprintStatus.Planning,
      description: "description1",
      uid: "1"
    };
    return of(sprint2);

  }

  createSprint(sprint: ISprint) {
    return of(sprint).toPromise();
  }

  updateSprint(sprint: ISprint, uid: string) {
    return of(sprint).toPromise();
  }

  changeActiveSprint(uid: string, value: string) {
    let sprint2 = <ISprint>{
      endDate: "2020-05-05",
      projectUID: "1",
      startDate: "2020-04-04",
      title: "Title1",
      status: SprintStatus.Planning,
      description: "description1",
      uid: "1"
    };
    return of(sprint2).toPromise();
  }

  deleteSprint(uid: string) {
    let sprint2 = <ISprint>{
      endDate: "2020-05-05",
      projectUID: "1",
      startDate: "2020-04-04",
      title: "Title1",
      status: SprintStatus.Planning,
      description: "description1",
      uid: "1"
    };
    return of(sprint2).toPromise();
  }

  getSprintsFromProject(uid: string) {
    let sprint2 = <ISprint>{
      endDate: "2020-05-05",
      projectUID: "1",
      startDate: "2020-04-04",
      title: "Title1",
      status: SprintStatus.Planning,
      description: "description1",
      uid: "1"
    };
    return of([sprint2]);
  }
}
