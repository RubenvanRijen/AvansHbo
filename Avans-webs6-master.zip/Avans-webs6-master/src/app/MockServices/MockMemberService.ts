import {Injectable} from '@angular/core';
import {IMember} from "../models/IMember";
import {of} from "rxjs";
import {ParticipantRol} from "../models/ParticipantRol.enum";
import {IProject} from "../models/IProject";
import {ProjectStatus} from "../models/ProjectStatus.enum";


@Injectable({
  providedIn: 'root',
})
export class MockMemberService {


  constructor() {
  }

  getMembers() {
    const member1 = <IMember>{
      uid: "1",
      projectUID: "1",
      rol: ParticipantRol.admin,
      userUID: "1",
      displayName: "displayName1"
    }
    const member2 = <IMember>{
      uid: "2",
      projectUID: "2",
      rol: ParticipantRol.developer,
      userUID: "2",
      displayName: "displayName2"
    }
    return of([member1, member2]);
  }

  getMember(memberUid: string) {
    const member1 = <IMember>{
      uid: "1",
      projectUID: "1",
      rol: ParticipantRol.admin,
      userUID: "1",
      displayName: "displayName1"
    }
    return of(member1);

  }

  getMembersFromProject(projectUID: string) {
    const member1 = <IMember>{
      uid: "1",
      projectUID: "1",
      rol: ParticipantRol.admin,
      userUID: "1",
      displayName: "displayName1"
    }
    return of([member1]);
  }

  getOneMemberFromOneProject(projectUID: string, userUID: string) {
    const member1 = <IMember>{
      uid: "1",
      projectUID: "1",
      rol: ParticipantRol.admin,
      userUID: "1",
      displayName: "displayName1"
    }
    return of(member1);
  }

  getAllProjectsFromMember(userUID: string) {
    const project = <IProject>{
      memberUID: "1",
      displayNameUser: "displayName1",
      uid: "1",
      title: "Title1",
      description: "description1",
      owner: "owner1",
      status: ProjectStatus.Closed,
      archived: false,
      members: ["erwin"],
      isMember: true,
    }
    return of([project]);
  }

  async createMember(member: IMember) {
    return new Promise(resolve => {
      resolve(member);
    });
  }

  async deleteMember(memberUID: string) {

    let member = <IMember>{
      uid: "1",
      displayName: "DisplayName1",
      userUID: "1",
      rol: ParticipantRol.developer,
      projectUID: "1",
    };
    return of(member).toPromise();

  }

  async editMember(uid: string, member: IMember) {
    return of(member).toPromise();
  }
}
