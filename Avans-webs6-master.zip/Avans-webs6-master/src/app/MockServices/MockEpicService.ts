import {Injectable} from '@angular/core';
import {IEpic} from "../models/IEpic";
import {of} from "rxjs";


@Injectable({
  providedIn: 'root'
})
export class MockEpicService {


  constructor() {
  }

  getAllEpics() {
    let epics: IEpic[] = [];
    epics.push(new class implements IEpic {
      color: "TestRed1";
      projectUID: "testProjects1";
      title: "testTitle1";
      uid: "2";
    });
    epics.push(new class implements IEpic {
      color: "TestRed2";
      projectUID: "testProjects2";
      title: "testTitle2";
      uid: "1";
    });
    return of(epics);
  }

  getEpic(uid: string) {
    let epic = (new class implements IEpic {
      color: "TestRed2";
      projectUID: "testProjects2";
      title: "testTitle2";
      uid: "1";
    });
    return of(epic);
  }

  getEpicsFromProject(uid: string) {
    let epics: IEpic[] = [];
    epics.push(new class implements IEpic {
      color: "TestRed1";
      projectUID: "testProjects1";
      title: "testTitle1";
      uid: "1";
    });
    epics.push(new class implements IEpic {
      color: "TestRed2";
      projectUID: "testProjects2";
      title: "testTitle2";
      uid: "2";
    });
    return of(epics);
  }

  createEpic(epic: IEpic) {
    return of(epic).toPromise();
  }

  deleteEpic(uid: string) {
    let epic = (new class implements IEpic {
      color: "TestRed2";
      projectUID: "testProjects2";
      title: "testTitle2";
      uid: "1";
    });
    return of(epic).toPromise();
  }

  updateEpic(uid: string, epic: IEpic) {
    return of(epic).toPromise();

  }

}
