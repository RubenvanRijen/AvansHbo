import {Injectable} from '@angular/core';
import {IUserStory} from 'src/app/models/IUserStory';
import {of} from 'rxjs';
import {UserStoryStatusEnum} from "../models/UserStoryStatus.enum";


@Injectable({
  providedIn: 'root'
})

export class MockUserStoryService {


  constructor() {
  }

  getUserStories() {
    let userStory = <IUserStory>{
      isArchived: false,
      owner: "0123456789",
      ownerName: "Ruben",
      uid: "1",
      sprintName: "Sprint 1",
      sprintUID: "1",
      epicColor: "red",
      epicName: "epic1",
      epicUID: "1",
      storyPoints: 2,
      projectUID: "1",
      statusLastEdited: "2020-05-05",
      title: "title",
      status: UserStoryStatusEnum.New,
      description: "dit is een description"
    }
    return of([userStory]);
  }

  getUserStory(uid: string) {
    let userStory = <IUserStory>{
      isArchived: false,
      owner: "0123456789",
      ownerName: "Ruben",
      uid: "1",
      sprintName: "Sprint 1",
      sprintUID: "1",
      epicColor: "red",
      epicName: "epic1",
      epicUID: "1",
      storyPoints: 2,
      projectUID: "1",
      statusLastEdited: "2020-05-05",
      title: "title",
      status: UserStoryStatusEnum.New,
      description: "dit is een description"
    }
    return of(userStory);
  }

  updateUserStory(userStory: IUserStory, uid: string) {
    return of(userStory).toPromise();
  }

  archiveUserStory(userStoryUID: string, type: boolean) {
    return of(true).toPromise();
  }

  createUserStory(userStory: IUserStory) {
    return of(userStory).toPromise();
  }

  filterUserStories(field: string, uid: string) {
    let userStory = <IUserStory>{
      isArchived: false,
      owner: "0123456789",
      ownerName: "Ruben",
      uid: "1",
      sprintName: "Sprint 1",
      sprintUID: "1",
      epicColor: "red",
      epicName: "epic1",
      epicUID: "1",
      storyPoints: 2,
      projectUID: "1",
      statusLastEdited: "2020-05-05",
      title: "title",
      status: UserStoryStatusEnum.New,
      description: "dit is een description"
    }
    return of([userStory]);
  }

  filterUserStoriesWithMultipleFields(field: string, uid: string, field2: string, value: boolean) {
    let userStory = <IUserStory>{
      isArchived: false,
      owner: "0123456789",
      ownerName: "Ruben",
      uid: "1",
      sprintName: "Sprint 1",
      sprintUID: "1",
      epicColor: "red",
      epicName: "epic1",
      epicUID: "1",
      storyPoints: 2,
      projectUID: "1",
      statusLastEdited: "2020-05-05",
      title: "title",
      status: UserStoryStatusEnum.New,
      description: "dit is een description"
    }
    return of([userStory]);
  }


  updateUserStoryStatus(userStory: any, status: string, owner: string, ownerName: string) {
    return of(userStory).toPromise();
  }

  updateUserStoryDate(userStory: any, statusLastEdited: string) {
    return of(userStory).toPromise();

  }
}
