import {Injectable} from '@angular/core';
import {IUser} from "../models/IUser";
import {Observable, of} from "rxjs";

@Injectable({
  providedIn: 'root',
})
export class MockAuthenticationService {


  constructor() {
  }

  async login(email: string, password: string) {
    return new Promise(resolve => {
      resolve(true);
    });
  }


  async register(email: string, password: string, username: string) {
    return new Promise(resolve => {
      resolve(true);
    });
  }

  async getUser() {
    let user: IUser = new class implements IUser {
      displayName: "jim";
      email: "jim@gmail.com";
      uid: "1";
      id: "1";
    }
    return of(user).toPromise();
  }

  async logout() {
    return new Promise(resolve => {
      resolve(true);
    });
  }

  userStatus() {
    return new Observable(null);
  }

  loggedInUser() {
    let user: IUser = new class implements IUser {
      displayName: "jim";
      email: "jim@gmail.com";
      uid: "1";
      id: "1";
    }
    return of(user).toPromise();
  }

  returnLoggedInUser() {
     return of({
      uid: "1",
      displayName: "display",
      email: "jim@hail.coim",
      emailVerified: true,
      id: "1"
    }).toPromise();
  }


}
