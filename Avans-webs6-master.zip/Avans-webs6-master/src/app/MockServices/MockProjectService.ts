import {Injectable} from '@angular/core';
import {of} from "rxjs";
import {IProject} from "../models/IProject";
import {ProjectStatus} from "../models/ProjectStatus.enum";


@Injectable({
  providedIn: 'root',
})
export class MockProjectService {

  constructor() {

  }

  getProjects() {
    const project1 = <IProject>{
      memberUID: "1",
      displayNameUser: "displayName1",
      uid: "1",
      title: "Title1",
      description: "description1",
      owner: "owner1",
      status: ProjectStatus.Closed,
      archived: false,
      members: ["erwin"],
      isMember: true,
    }
    const project2 = <IProject>{
      memberUID: "1",
      displayNameUser: "displayName1",
      uid: "1",
      title: "Title1",
      description: "description1",
      owner: "owner1",
      status: ProjectStatus.Closed,
      archived: false,
      members: ["erwin"],
      isMember: true,
    }
    return of([project1, project2]);
  }

  getProject(id: string) {
    const project = <IProject>{
      memberUID: "1",
      displayNameUser: "displayName1",
      uid: "1",
      title: "Title1",
      description: "description1",
      owner: "owner1",
      status: ProjectStatus.Closed,
      archived: false,
      members: ["erwin"],
      isMember: true,
    }
    return of(project);
  }

  getOwnProjectsFiltering(uid: string, field: string, value: boolean) {
    const project = <IProject>{
      memberUID: "1",
      displayNameUser: "displayName1",
      uid: "1",
      title: "Title1",
      description: "description1",
      owner: "owner1",
      status: ProjectStatus.Closed,
      archived: false,
      members: ["erwin"],
      isMember: true
    }
    return of([project]);
  }

  getOwnProjects(uid: string) {
    const project = <IProject>{
      memberUID: "1",
      displayNameUser: "displayName1",
      uid: "1",
      title: "Title1",
      description: "description1",
      owner: "owner1",
      status: ProjectStatus.Closed,
      archived: false,
      members: ["erwin"],
      isMember: true,
    }
    return of([project]);
  }

  filterProjects(field: string, value: boolean) {
    const project = <IProject>{
      memberUID: "1",
      displayNameUser: "displayName1",
      uid: "1",
      title: "Title1",
      description: "description1",
      owner: "owner1",
      status: ProjectStatus.Closed,
      archived: false,
      members: ["erwin"],
      isMember: true,
    }
    return of([project])
  }

  createProject(project: IProject) {
    return of(project).toPromise();
  }

  updateProjectArchive(project: IProject) {
    return of(project).toPromise();
  }

  updateProjectParticipants(project: IProject) {
    return of(project).toPromise();
  }

  updateProject(project: IProject, uid: string) {
    return of(project).toPromise();
  }

  deleteProject(projectUID: string) {
    const project = <IProject>{
      memberUID: "1",
      displayNameUser: "displayName1",
      uid: "1",
      title: "Title1",
      description: "description1",
      owner: "owner1",
      status: ProjectStatus.Closed,
      archived: false,
      members: ["erwin"],
      isMember: true,
    }
    return of(project).toPromise()
  }
}
