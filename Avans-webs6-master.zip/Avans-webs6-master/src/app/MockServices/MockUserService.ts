import {Injectable} from '@angular/core';
import {IUser} from "../models/IUser";
import {of} from "rxjs";


@Injectable({
  providedIn: 'root',
})
export class MockUserService {

  constructor() {
  }

  getUsers() {
    let user1 = <IUser>{
      displayName: "displayName1",
      email: "Email1",
      uid: "1"
    };
    return of([user1]);
  }

  getUser(userId: string) {
    let user1 = <IUser>{
      displayName: "displayName1",
      email: "Email1",
      uid: "1"
    };
    return of(user1);
  }

  async addUser(displayName: string, email: string, uid: string) {
    let user1 = <IUser>{
      displayName: "displayName1",
      email: "Email1",
      uid: "1"
    };
    return of(user1).toPromise();
  }
}
