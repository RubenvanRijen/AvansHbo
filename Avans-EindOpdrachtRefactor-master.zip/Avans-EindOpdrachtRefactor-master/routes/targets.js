const express = require('express');
const router = express.Router();
const targetValidation = require("../Validation/TargetValidation");
const targetController = require("../Controllers/TargetController");
const pagination = require("../Middleware/pagination");
const targetModel = require("../Models/Target");
//passport strategies defined
const passport = require("passport");
const passportConfig = require("../Middleware/passport");
const passJWT = passport.authenticate('jwt', {session: false});

//route - tests - controller - views
router.get("/", passJWT, pagination.pagination(targetModel), async (req, res, next) => {
    targetController.getAllTargets(req, res, next);
});

//route - tests - controller - views
router.get("/:targetTitle", passJWT, async (req, res, next) => {
    targetController.getTargetById(req, res, next);
});

module.exports = router;
