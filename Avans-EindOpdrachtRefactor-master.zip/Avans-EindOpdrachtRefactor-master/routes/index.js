const express = require('express');
const router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
    res.render('index', {user: req.user});
});

router.get('/login', function (req, res, next) {
    res.render('./user/login');
});

router.get('/signUp', function (req, res, next) {
    res.render('./user/signUp');
});

router.get('/dashboard', function (req, res, next) {
    res.render('dashboard', {user: req.user});
});

module.exports = router;
