const express = require('express');
const router = express.Router();

const userController = require("../Controllers/UserController");
const userValidation = require("../Validation/UserValidation");
const userModel = require("../Models/User");
//passport strategies defined
const passport = require("passport");
const passportConfig = require("../Middleware/passport");
const passJWT = passport.authenticate('jwt', {session: false});
const passLocal = passport.authenticate('local', {session: false});
const passGoogle = passport.authenticate('google', {scope: ['profile', 'email'], session: false});
const passFacebook = passport.authenticate('facebook', {scope: ['email'], session: false});
const passFacebookToken = passport.authenticate('facebookToken', {session: false});
const passGoogleToken = passport.authenticate('googleToken', {session: false});
const pagination = require("../Middleware/pagination");


/* GET users listing. */

//route - tests - controller - views
router.get("/", passJWT, passportConfig.isAdmin, pagination.pagination(userModel), async (req, res, next) => {
    await userController.getAllUsers(req, res, next);
});
//route - tests - controller - views
router.get("/information", passJWT, async (req, res, next) => {
    await userController.getUserInformation(req, res, next);
});

//route - tests - controller - views
router.post("/signIn", userValidation.loginValidation, passLocal, async (req, res, next) => {
    await userController.signIn(req, res, next);
});

//route - tests - controller - views
router.post("/signUp", userValidation.signUpValidation, async (req, res, next) => {
    await userController.signUp(req, res, next);
});

//route - tests - controller - views
router.post('/logout', passJWT, async (req, res, next) => {
    await userController.logout(req, res, next);
});

//google OAuth
router.post('/oauth/google', passGoogle);

//Google redirect
router.get('/oauth/google/redirect', passport.authenticate('google', {
    failureRedirect: '/signIn',
    session: false
}), async (req, res, next) => {
    await userController.signIn(req, res, next);

});

//facebook OAuth
router.post('/oauth/facebook', passFacebook);

//facebook redirect
router.get('/oauth/facebook/redirect', passport.authenticate('facebook', {
    failureRedirect: '/signIn',
    session: false
}), async (req, res, next) => {
    await userController.signIn(req, res, next);
});

//google token OAuth
//route - tests - controller - views
router.post('/oauthToken/google', passGoogleToken, async (req, res, next) => {
    await userController.signIn(req, res, next);
});

//facebook token OAuth
//route - tests - controller - views
router.post('/oauthToken/facebook', passFacebookToken, async (req, res, next) => {
    await userController.signIn(req, res, next);

});

module.exports = router;
