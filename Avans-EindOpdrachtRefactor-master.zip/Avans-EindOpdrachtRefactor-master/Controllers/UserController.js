const express = require("express");
const mongoose = require('mongoose');
const userModel = require("../Models/User");
const JWT = require('jsonwebtoken');
const http = require('http');
const paginate = require('paginate')({
    mongoose: mongoose
});

signToken = user => {
    return token = JWT.sign({
        iss: 'CloudServices',
        id: user._id,
        isAdmin: user.isAdmin,
        iat: new Date().getTime(),//current time
        exp: new Date().setDate(new Date().getDate() + 1) //current time plus one day
    }, process.env.JWT_SECRET);
}

//route - tests - controller - views
async function getUserInformation(req, res, next) {
    let user, username = req.user.username;
    try {
        user = await userModel.findOne({username: username});

        if (res.contentType === 'application/json') {
            return res.status(200).json({user});
        } else {
            return res.status(200).render('./user/profile', {
                user: req.user
            });
        }
    } catch (err) {
        if (res.contentType === 'application/json') {
            return res.status(500).json({message: err.message});
        } else {
            return res.status(500).render('error', {
                user: req.user
            });
        }
    }
}

//route - tests - controller - views
async function getAllUsers(req, res, next) {
    let users;

    try {
        users = res.paginatedResults;
        if (res.contentType === 'application/json') {
            return res.status(200).json(users);
        } else {
            await userModel.find({}).paginate({page: req.query.page}, function (err, users) {
                return res.status(200).render('./user/allUsers', {
                    users: users,
                    user: req.user
                });
            });
        }
    } catch (err) {
        if (res.contentType === 'application/json') {
            return res.status(500).json(err.message);
        } else {
            return res.status(500).render('error', {
                user: req.user
            });
        }
    }
}

//route - tests - controller - views
async function signIn(req, res, next) {
    let token;
    try {
        token = signToken(req.user);
        res.cookie('access_token', token, {
            httpOnly: true
        });
        if (res.contentType === 'application/json') {
            return res.status(200).json({message: 'success', token: token});
        } else {
            return res.status(201).render('dashboard', {
                user: req.user
            });
        }
    } catch (err) {
        if (res.contentType === 'application/json') {
            return res.status(500).json({message: err.message});
        } else {
            return res.status(500).render('./user/login', {
                errors: err.message,
            });
        }
    }
}

//router - tests - controller - views
async function signUp(req, res, next) {
    try {
        let foundUser = await userModel.findOne({'local.email': req.body.email});
        if (foundUser) {
            if (res.contentType === 'application/json') {
                return res.status(500).json({message: "Email is already taken"});
            } else {
                return res.status(500).render('./user/signUp', {
                    errors: ["email is already taken"],
                });
            }
        }

        // Is there a Google/Facebook account with the same email?
        foundUser = await userModel.findOne({
            $or: [
                {"google.email": req.body.email},
                {"facebook.email": req.body.email},
            ]
        });
        if (foundUser) {
            // Let's merge them
            foundUser.local = {
                email: req.body.email,
                password: req.body.password,
            }
            await foundUser.save();
            // Generate the token
            const token = signToken(foundUser);

            res.cookie('access_token', token, {
                httpOnly: true
            });
            if (res.contentType === 'application/json') {
                return res.status(201).json({message: 'success', token: token});
            } else {
                return res.status(201).render('dashboard', {
                    user: foundUser
                });
            }
        } else {
            const newUser = new userModel({
                method: 'local',
                local: {
                    email: req.body.email,
                    password: req.body.password,
                },
                username: req.body.username,
                isAdmin: req.body.isAdmin
            });
            await newUser.save();

            const token = signToken(newUser);
            res.cookie('access_token', token, {
                httpOnly: true
            });
            if (res.contentType === 'application/json') {
                return res.status(201).json({message: 'success', token: token});
            } else {
                return res.status(201).render('dashboard', {
                    user: newUser
                });
            }
        }
    } catch (err) {
        if (res.contentType === 'application/json') {
            return res.status(500).json({message: err.message, token: "No token available"});
        } else {
            return res.status(500).render('./user/signUp', {
                errors: err.message,
            });
        }
    }
}

//route - tests - controller - views
async function logout(req, res, next) {
    try {
        res.clearCookie('access_token');
        if (res.contentType === 'application/json') {
            return res.status(200).json({message: "logout was successfully done"})

        } else {
            return res.status(200).render('index', {});
        }
    } catch (err) {
        if (res.contentType === 'application/json') {
            return res.status(500).json({message: err.message})

        } else {
            return res.status(500).render('error', {
                user: req.user
            });
        }
    }
}


module.exports = {
    getAllUsers,
    signIn,
    signUp,
    getUserInformation,
    logout
}