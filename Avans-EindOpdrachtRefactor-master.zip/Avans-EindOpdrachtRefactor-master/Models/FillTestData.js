const userModel = require("./User");
const targetModel = require("./Target");

const mongoose = require('mongoose');
const byCrypt = require("bcryptjs");

const userSeed = [

    new userModel({
        local: {
            email: "ruben@gmail.com",
        },
        username: "Ruben",
        isAdmin: true,
        method: 'local'
    }),
    new userModel({
        username: "Jim",
        local: {
            email: "jim@gmail.com",
        },
        isAdmin: true,
        method: 'local'
    }),
    new userModel({
        username: "Stijn",
        local: {
            email: "stijn@gmail.com",
        },
        isAdmin: false,
        method: 'local'
    })
];

const targetSeed = [
    new targetModel({
        targetTitle: "target1",
        description: "Dit is een beschrijving van een target",
        image: "sample",
        radius: 300,
        creator: "ruben",
        uploads: [],
        hints: ["hint1", "hint2", "hint3"],
        tags: [

            {
                en: "mountain"
            },
            {
                en: "landscape"
            }
        ],
        coordinates: {
            longitude: 51.36,
            latitude: 2.9857
        }
    }),
    new targetModel({
        targetTitle: "target2",
        description: "Dit is een beschrijving van een target",
        image: "sample",
        radius: 300,
        creator: "ruben",
        uploads: [],
        hints: ["hint1", "hint2", "hint3"],
        tags: [

            {
                en: "mountain"
            },
            {
                en: "landscape"
            }
        ],
        coordinates: {
            longitude: 51.36,
            latitude: 2.9857
        }
    })
];


module.exports = async function () {
    //users
    await userModel.find({}).then(users => {
        if (!users.length) {
            console.log("\tNo users found, filling testdata");
            for (let k = 0; k < userSeed.length; k++) {
                const salt = byCrypt.genSaltSync(10);
                userSeed[k].local.password = byCrypt.hashSync('Test123?', salt);
            }
            userModel
                .insertMany(userSeed)
                .then(() => console.log("\tFilling user testdata succesfull"))
                .catch(err => console.log("\tFilling user testdata failed", err));
        }
    });

    //targets
    await targetModel.find({}).then(targets => {
        if (!targets.length) {
            console.log("\tNo targets found, filling testdata");
            targetModel
                .insertMany(targetSeed)
                .then(() => console.log("\tFilling targets testdata succesfull"))
                .catch(err => console.log("\tFilling targets testdata failed", err));
        }
    });
};
