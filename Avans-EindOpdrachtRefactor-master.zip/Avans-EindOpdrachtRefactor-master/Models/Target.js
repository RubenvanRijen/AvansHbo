const mongoose = require("mongoose");
const uploadModel = require('mongoose').model('Upload').schema
let targetSchema = new mongoose.Schema(
    {
        targetTitle: {type: String, required: true, minlength: 4, maxlength: 20, lowercase: true},
        description: {type: String, required: true, maxlength: 200, minlength: 3},
        image: {type: String, required: true},
        radius: {type: Number, required: true, min: 50, max: 5000},
        creator: {type: String, ref: "User", required: true, lowercase: true},
        uploads: [{type: uploadModel, required: false,}],
        hints: [{type: String, required: false}],
        tags: {type: Object, required: true},
        coordinates: {
            longitude: {type: mongoose.Types.Decimal128, required: true},
            latitude: {type: mongoose.Types.Decimal128, required: true}
        }
    },
    {
        toJSON: {virtuals: true},
        toObject: {virtuals: true}
    }
);


// Create a model
const target = mongoose.model('Target', targetSchema);

module.exports = target;



