const app = require("../app");
const passportStub = require('passport-stub');
const request = require("supertest");
const chai = require('chai');
const {expect} = chai;
const chaiHttp = require('chai-http');
const faker = require('faker');
const userModel = require("../Models/User");
passportStub.install(app);
chai.use(chaiHttp);
const passport = require("passport");
const passportConfig = require("../Middleware/passport");

describe("Tests for authentication", function () {
    let tokenAdmin;
    let tokenNoAdmin;

    const passFacebookToken = passport.authenticate('facebookToken', {session: false});
    const passGoogleToken = passport.authenticate('googleToken', {session: false});

    const userDataAdmin = {
        username: faker.name.findName(),
        email: faker.internet.email(),
        password: "Test123?",
        isAdmin: true,
        method: 'local'
    }

    const userDataNoAdmin = {
        username: faker.name.findName(),
        email: faker.internet.email(),
        password: "Test123?",
        isAdmin: false,
        method: 'local'
    }

    const badUser = {
        username: faker.name.findName(),
        email: faker.internet.email(),
        isAdmin: true
    }
    const badUserData = {
        email: badUser.email,
        password: "Test123?"
    }

    const constantUserAdmin = {
        username: "TestAdmin",
        email: "testadmin@gmail.com",
        password: "Test123?",
        isAdmin: true,
        method: 'local'
    }
    const userAdminData = {
        email: "testadmin@gmail.com",
        password: "Test123?"
    }

    const constantUserNoAdmin = {
        username: "TestNoAdmin",
        email: "testnoadmin@gmail.com",
        password: "Test123?",
        isAdmin: false,
        method: 'local'
    }
    const userNoAdminData = {
        email: "testnoadmin@gmail.com",
        password: "Test123?",
    }

    this.beforeAll(async function () {
        let admin = await userModel.findOne({username: constantUserAdmin.username});
        if (admin === null) {
            let result1 = await request(app)
                .post('/users/signUp')
                .set('content-type', 'application/json')
                .send(constantUserAdmin)
                .expect(201);
            tokenAdmin = result1.body.token;
        } else {
            let result2 = await request(app)
                .post('/users/signIn')
                .set('content-type', 'application/json')
                .send(userAdminData)
                .expect(200);
            tokenAdmin = result2.body.token;
        }

        let noAdmin = await userModel.findOne({username: constantUserNoAdmin.username});
        if (noAdmin === null) {
            let result3 = await request(app)
                .post('/users/signUp')
                .set('content-type', 'application/json')
                .send(constantUserNoAdmin)
                .expect(201);
            tokenNoAdmin = result3.body.token;
        } else {
            let result4 = await request(app)
                .post('/users/signIn')
                .set('content-type', 'application/json')
                .send(userNoAdminData)
                .expect(200);
            tokenNoAdmin = result4.body.token;
        }
    });


    this.afterAll(async function () {
        const admin = await userModel.deleteOne({username: userDataAdmin.username});
        const noAdmin = await userModel.deleteOne({username: userDataNoAdmin.username});
    });

    // create a admin user / no admin user / wrong account
    describe("create new user noAdmin/Admin", function () {
        it("should return 201 for new created user", function (done) {
            request(app)
                .post('/users/signUp')
                .set('content-type', 'application/json')
                .send(userDataAdmin)
                .expect(201)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    expect(res.body.message).to.equal("success");
                    done();
                });
        });

        it("should return 201 for new created user", function (done) {
            request(app)
                .post('/users/signUp')
                .set('content-type', 'application/json')
                .send(userDataNoAdmin)
                .expect(201)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    expect(res.body.message).to.equal("success");
                    done();
                });
        });

        it("should return 400 for new created user with no email", function (done) {
            request(app)
                .post('/users/signUp')
                .set('content-type', 'application/json')
                .send(badUser)
                .expect(400)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    expect(res.body.message[0]).to.equal("No password was given");
                    done();
                });
        });
    });
    // get all the users test with admin and no admin
    describe("get users noAdmin/Admin", function () {
        it("should return 200 for getting users", function (done) {
            request(app)
                .get('/users/')
                .set('content-type', 'application/json')
                .set('Authorization', tokenAdmin)
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });

        it("should return 401 for getting users", function (done) {
            passportStub.login(tokenNoAdmin)
            request(app)
                .get('/users/')
                .set('content-type', 'application/json')
                .set('Authorization', tokenNoAdmin)
                .expect(401)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });
    });

    // sign in with correct account and bad account
    describe("login in with bad/good account", function () {
        it("should return 200 for logging in with correct account", function (done) {
            request(app)
                .post('/users/signIn')
                .set('content-type', 'application/json')
                .send(userAdminData)
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    expect(res.body.message).to.equal("success");
                    done();
                });
        });

        it("should return 401 for logging in with bad account", function (done) {
            request(app)
                .post('/users/signIn')
                .set('content-type', 'application/json')
                .send(badUserData)
                .expect(401)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });
    });

    describe("get user information", function () {
        it("should return 200 for getting information", function (done) {
            request(app)
                .get('/users/information')
                .set('content-type', 'application/json')
                .set('Authorization', tokenAdmin)
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    expect(res.body.user.username).to.equal("testadmin");

                    done();
                });
        });

        it("should return 401 for getting information", function (done) {
            request(app)
                .get('/users/information')
                .set('content-type', 'application/json')
                .expect(401)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });
    });

    // get all the users test with admin and no admin
    describe("get users noAdmin/Admin html", function () {
        it("should return 200 for getting users html", function (done) {
            request(app)
                .get('/users/')
                .set('content-type', 'text/html')
                .set('Authorization', tokenAdmin)
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });

        it("should return 401 for getting users html", function (done) {
            passportStub.login(tokenNoAdmin)
            request(app)
                .get('/users/')
                .set('content-type', 'text/html')
                .set('Authorization', tokenNoAdmin)
                .expect(401)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });
    });


    describe("get user information html", function () {
        it("should return 200 for getting information html", function (done) {
            request(app)
                .get('/users/information')
                .set('content-type', 'text/html')
                .set('Authorization', tokenAdmin)
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });

        it("should return 401 for getting information html", function (done) {
            request(app)
                .get('/users/information')
                .set('content-type', 'text/html')
                .expect(401)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });
    });

    describe("logout html", function () {
        it("should return 200 for logging out html", function (done) {
            request(app)
                .post('/users/logout')
                .set('content-type', 'text/html')
                .set('Authorization', tokenNoAdmin)
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });
    });
    //get a new token everytime otherwise this test wil fail. There is no better way because tokens just expire
    describe("googleToken", function () {
        it("should return 401 for logging in with no google token", function (done) {
            let token = 'ya29.a0Ae4lvC2iVBIp-4uiKpgZNwksMSQVx6z67LGr5TSazRFjNXCV6TV1h3uRzWfPLhw4BihoIL2SA8hJHhF_1M4u-I6UV-8VRI-xp_4-2TvSqP8pLS4SpzF15n-fCl6o6E97ZPohcIMvlvwpDeFnOz9PAof_gRY71JyiEr8';
            request(app)
                .post('/users/oauthToken/google')
                .set('content-type', 'application/json')
                .set({"Authorization": token})
                .expect(401)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });
    });

    //get a new token everytime otherwise this test wil fail. There is no better way because tokens just expire
    describe("facebookToken", function () {
        it("should return 401 for logging in with facebook no token", function (done) {
            let token = 'ya29.a0Ae4lvC2iVBIp-4uiKpgZNwksMSQVx6z67LGr5TSazRFjNXCV6TV1h3uRzWfPLhw4BihoIL2SA8hJHhF_1M4u-I6UV-8VRI-xp_4-2TvSqP8pLS4SpzF15n-fCl6o6E97ZPohcIMvlvwpDeFnOz9PAof_gRY71JyiEr8';
            request(app)
                .post('/users/oauthToken/facebook')
                .set('content-type', 'application/json')
                .set({"Authorization": token})
                .expect(401)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });
    });

    //get a new token everytime otherwise this test wil fail. There is no better way because tokens just expire
    describe("googleOAuth", function () {
        it("should return google date", function (done) {
            request(app)
                .post('/users/oauth/google')
                .set('content-type', 'application/json')
                .expect(302)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });
    });

    describe("logout", function () {
        it("should return 200 for logging out", function (done) {
            request(app)
                .post('/users/logout')
                .set('content-type', 'application/json')
                .set('Authorization', tokenNoAdmin)
                .expect(200)
                .end(function (err, res) {
                    if (err) {
                        return done(err);
                    }
                    done();
                });
        });
    });


});