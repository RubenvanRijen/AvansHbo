let express = require("express");
let router = express.Router();
const scavengerController = require("../controllers/PhotoScavengerHuntController");

/* GET home page. */
router.get("/", function (req, res, next) {
  res.render("login/index");
});

router.get("/login", function (req, res, next) {
  res.render("login/login");
});

router.get("/signup", function (req, res, next) {
  res.render("login/signup");
});

// CREATE HUNT FORM
router.get("/huntform", function (req, res, next) {
  res.render('photoscavengerhunts/editphotoscavengerhunt', {
    isCreate: true
  });
});

// CREATE TARGET FORM
router.get("/photoscavengerhunts/:scavengerTitle/target-form", scavengerController.getHunt,function (req, res, next) {
  res.render('targets/edittarget', {
    isCreate: true,
    scavengerTitle: req.params.scavengerTitle
  });
});

// CREATE UPLOAD FORM
router.get("/photoscavengerhunts/:scavengerTitle/targets/:targetTitle/uploads/upload-form",function (req, res, next) {
  res.render('uploads/editupload', {
    isCreate: true,
    targetTitle: req.params.targetTitle,
    scavengerTitle: req.params.scavengerTitle

  });
});

module.exports = router;
