const express = require("express");
const router = express.Router();
const mongoose = require('mongoose');
const userValidator = require("../Validation/UserValidation");
const paginationMiddleware = require("../Middleware/Pagination");

const userController = require("../controllers/UserController");
const user = mongoose.model('User');

const passport = require("passport")
const passportConf = require("../Middleware/passport");
const passJWT = passport.authenticate('jwt', { session: false });
const passLocal = passport.authenticate('local', { session: false });
const passGoogle = passport.authenticate('google', { scope: ['profile', 'email'], session: false });
const passFacebook = passport.authenticate('facebook', { scope: ['email'], session: false });
const passFacebookToken = passport.authenticate('facebookToken', { session: false });
const passGoogleToken = passport.authenticate('googleToken', { session: false });

// Routes
router.get("/", passJWT, userValidator.setContentHeaders, userValidator.checkIfAdmin, paginationMiddleware.pagination(user), async (req, res, next) => {
    userController.getUsers(req, res, next)
});

router.post("/", userValidator.setContentHeaders, userValidator.createUserValidationRules, async (req, res, next) => {
    userController.addUser(req, res, next);
});

router.get("/:username", passJWT, userValidator.setContentHeaders, userValidator.checkIfSameUser, userValidator.checkIfUserExist, async (req, res, next) => {
    userController.getUser(req, res, next);
});

router.post("/signin", userValidator.logInFields, passLocal, userValidator.setContentHeaders, async (req, res, next) => {
    userController.signIn(req, res, next);
});

router.post('/oauth/google', passGoogle);

router.get('/oauth/google/redirect', passport.authenticate('google', {
    failureRedirect: '/',
    session: false
}), userValidator.setContentHeaders, async (req, res, next) => {
    userController.googleOAuth(req, res, next);
});

router.post('/oauth/facebook', passFacebook);

router.get('/oauth/facebook/redirect', passport.authenticate('facebook', {
    failureRedirect: '/',
    session: false
}), userValidator.setContentHeaders, async (req, res, next) => {
    userController.facebookOAuth(req, res, next);
});

router.post('/oauthToken/google', passGoogleToken);

router.post('/oauthToken/facebook', passFacebookToken);


router.get('/info/status', passJWT, userValidator.setContentHeaders, async (req, res, next) => {
    userController.checkStatus(req, res, next);
});

router.post('/logout', passJWT, userValidator.setContentHeaders, async (req, res, next) => {
    userController.logout(req, res, next);
})


module.exports = router;

