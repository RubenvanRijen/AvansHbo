const express = require("express");
const router = express.Router();
const mongoose = require('mongoose');
const targetsController = require("../controllers/TargetsController");
const uploadController = require("../controllers/UploadsController");
const target = mongoose.model('Target');
const paginationMiddleware = require("../Middleware/Pagination");
const imageController = require("../controllers/ImageController");
const targetValidation = require("../Validation/TargetValidation");
const uploadValidation = require("../Validation/UploadValidation");
const passport = require("passport")
const passportConf = require("../Middleware/passport");
const passJWT = passport.authenticate('jwt', {session: false});
const userValidation = require("../Validation/UserValidation");
const photoValidation = require("../Validation/PhotoScavengerHuntValidation");

//get all the targets
router.get("/", passJWT, userValidation.setContentHeaders, paginationMiddleware.pagination(target), async (req, res, next) => {
    targetsController.getTargets(req, res, next);
});

module.exports = router;
