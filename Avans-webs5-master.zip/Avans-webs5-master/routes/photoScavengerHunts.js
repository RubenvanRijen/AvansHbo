let express = require("express");
let router = express.Router();
const mongoose = require('mongoose');
const photoScavengerHuntController = require("../controllers/PhotoScavengerHuntController");
const targetController = require("../controllers/TargetsController");
const scavengerHuntValidation = require("../Validation/PhotoScavengerHuntValidation");
const userValidation = require("../Validation/UserValidation");
const paginateMiddleware = require("../Middleware/Pagination");
const photoScavengerHunt = mongoose.model('PhotoScavengerHunt');
const target = mongoose.model('Target');
const imageController = require("../controllers/ImageController");
const targetValidation = require("../Validation/TargetValidation");
const uploadController = require("../controllers/UploadsController");

const passport = require("passport")
const passportConf = require("../Middleware/passport");
const passJWT = passport.authenticate('jwt', { session: false });
const uploadValidation = require("../Validation/UploadValidation");

//Routes
//get all photoScavengerHunts
router.get("/", passJWT, userValidation.setContentHeaders, paginateMiddleware.pagination(photoScavengerHunt), async (req, res, next) => {
    photoScavengerHuntController.getPhotoScavengerHunts(req, res, next);
});

//get one hunt by id
router.get("/:scavengerTitle", passJWT, userValidation.setContentHeaders, async (req, res, next) => {
    photoScavengerHuntController.getPhotoScavengerHuntById(req, res, next);
});

//create a new hunt without targets en uploads.
router.post("/", passJWT, userValidation.setContentHeaders, scavengerHuntValidation.createPhotoScavengeHuntTargetsRule, scavengerHuntValidation.createPhotoScavengeHuntParticipantsRule,
    scavengerHuntValidation.createPhotoScavengeHuntFeedbackRule, async (req, res, next) => {
        photoScavengerHuntController.createPhotoScavengerHunt(req, res, next);
    });

//delete a hunt
router.delete("/:scavengerTitle", passJWT, scavengerHuntValidation.checkIfSameUser, userValidation.setContentHeaders, async (req, res, next) => {
    photoScavengerHuntController.deletePhotoScavengerHunt(req, res, next);
});

//update a hunt
router.patch("/:scavengerTitle", passJWT, scavengerHuntValidation.checkIfSameUser, userValidation.setContentHeaders, scavengerHuntValidation.editPhotoScavengeHuntRules, async (req, res, next) => {
    photoScavengerHuntController.updatePhotoScavengerHunt(req, res, next);
});

//add feedback to a hunt
router.post("/:scavengerTitle/feedback", passJWT, userValidation.setContentHeaders, async (req, res, next) => {
    photoScavengerHuntController.addFeedback(req, res, next);
});

//remove feedback from a hunt
router.delete("/:scavengerTitle/feedback/:username", passJWT, userValidation.setContentHeaders, userValidation.checkIfUserExist, async (req, res, next) => {
    photoScavengerHuntController.removeFeedback(req, res, next);
});

//target routes ----- target routes

//edit the target title so update the target and change the target title in the hunts array.
router.patch("/:scavengerTitle/targets/:targetTitle", passJWT, scavengerHuntValidation.checkIfSameUser, userValidation.setContentHeaders, targetValidation.editTargetValidation, targetController.updateTarget, async (req, res, next) => {
    photoScavengerHuntController.editTargetTitle(req, res, next);
});

//get all the targets in a range
router.get("/targets/range", passJWT, userValidation.setContentHeaders, async (req, res, next) => {
    targetController.targetsInRange(req, res, next);
});

//get a target by id from a hunt
router.get("/:scavengerTitle/targets/:targetTitle", passJWT, async (req, res, next) => {
    targetController.getTargetById(req, res, next);
});

//get all the targets of one hunt
router.get("/:scavengerTitle/targets", passJWT, userValidation.setContentHeaders, async (req, res, next) => {
    targetController.getPhotoScavengerHuntsTargets(req, res, next);
});

//add a target to a hunt and create a target at the same time
router.post("/:scavengerTitle/targets", passJWT, scavengerHuntValidation.checkIfSameUser, userValidation.setContentHeaders, imageController.uploadImageTarget, targetController.createTarget, async (req, res, next) => {
    photoScavengerHuntController.addTarget(req, res, next);
});

//remove a target from a hunt and delete a target at the same time
router.delete("/:scavengerTitle/targets/:targetTitle", passJWT, scavengerHuntValidation.checkIfSameUser, userValidation.setContentHeaders, targetController.deleteTarget, async (req, res, next) => {
    photoScavengerHuntController.removeTarget(req, res, next);
});

//uploads ----- uploads routes

//get all the uploads from targets in a hunt
router.get("/:scavengerTitle/targets/uploads", passJWT, userValidation.setContentHeaders, async (req, res, next) => {
    photoScavengerHuntController.getUploadsFromTargetByHunt(req, res, next);
});

//get all uploads from a target via hunt
router.get("/:scavengerTitle/targets/:targetTitle/uploads", passJWT, userValidation.setContentHeaders, async (req, res, next) => {
    uploadController.getTargetUploads(req, res, next);
});

//get an upload from one hunt
router.get("/:scavengerTitle/targets/:targetTitle/uploads/:uploadTitle", passJWT, userValidation.setContentHeaders, async (req, res, next) => {
    photoScavengerHuntController.getUploadByIdFromTargetFromHunt(req, res, next);
});

//add an upload to a target via an hunt
router.post("/:scavengerTitle/targets/:targetTitle/uploads", passJWT, userValidation.setContentHeaders, imageController.getTargetImageId, imageController.getTargetTags,
    imageController.uploadImageUpload, imageController.getUploadTags, imageController.determineScore
    , uploadController.createUpload, async (req, res, next) => {
        targetController.addUpload(req, res, next);
    });

//delete an upload from array and collection via a hunt
router.delete("/:scavengerTitle/targets/:targetTitle/uploads/:uploadTitle", passJWT, userValidation.setContentHeaders, scavengerHuntValidation.checkIfSameUploader, uploadController.deleteUpload, async (req, res, next) => {
    targetController.removeUpload(req, res, next);
});

//edit an upload in collection and target array via hunt
router.patch("/:scavengerTitle/targets/:targetTitle/uploads/:uploadTitle", passJWT, userValidation.setContentHeaders, scavengerHuntValidation.checkIfSameUploader, uploadValidation.editUploadValidation, uploadController.updateUpload, async (req, res, next) => {
    targetController.editUploads(req, res, next);
});

module.exports = router;