let express = require("express");
let router = express.Router();
const mongoose = require('mongoose');
let uploadsController = require('../controllers/UploadsController');
const upload = mongoose.model('Upload');
const paginationMiddleware = require("../Middleware/Pagination");
const passport = require("passport")
const passportConf = require("../Middleware/passport");
const passJWT = passport.authenticate('jwt', {session: false});
const userValidation = require("../Validation/UserValidation");

// Routes
router.get("/", passJWT, userValidation.setContentHeaders, paginationMiddleware.pagination(upload), async (req, res, next) => {
    uploadsController.getUploads(req, res, next);
});

router.get("/:uploadTitle", passJWT, userValidation.setContentHeaders, async (req, res, next) => {
    uploadsController.getUploadById(req, res, next);
});

module.exports = router;