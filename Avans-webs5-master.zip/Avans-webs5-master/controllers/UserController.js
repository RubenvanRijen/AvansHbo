const express = require("express");
const mongoose = require('mongoose');
const User = mongoose.model('User');
const JWT = require('jsonwebtoken');
const http = require('http');

signToken = user => {
    return token = JWT.sign({
        iss: 'CloudServices',
        id: user._id,
        isAdmin: user.isAdmin,
        iat: new Date().getTime(),//current time
        exp: new Date().setDate(new Date().getDate() + 1) //current time plus one day
    }, process.env.JWT_SECRET);
}

// GET Users
async function getUsers(req, res, next) {
    try {
        const result = await User.find({});
        if (!result.length) {
            return res.status(404).json({ message: "No users to be found" });
        }
        return res.status(200).json(result);
    } catch (err) {
        return res.json({ message: err });
    }
}

// Find User
async function getUser(req, res, next) {
    let username;
    if (req.params.username) {
        username = req.params.username;
    }
    try {
        const result = foundUser = await User.findOne({
            $or: [
                { "google.username": req.body.username },
                { "facebook.username": req.body.username },
                { "local.username": req.body.username }
            ]
        });
        if (result === null) {
            return res.status(404).json({ message: "No user to be found" });
        }
        return res.status(200).json(result);

    } catch (err) {
        return res.json({ message: err });
    }
}

// Add User
async function addUser(req, res, next) {
    try {
        let foundUser = await User.findOne({ 'local.email': req.body.email });
        if (foundUser) {
            if (res.accepts === 'application/json') {
                return res.status(403).json({ message: 'Email is already taken' });
            } else if (res.accepts === 'text/html' || res.accepts === "application/x-www-form-urlencoded") {
                return res.render('login/signup', {
                    user: req.username,
                    errors: "Email is already taken"
                });
            }
        }

        // Is there a Google account with the same email?
        foundUser = await User.findOne({
            $or: [
                { "google.email": req.body.email },
                { "facebook.email": req.body.email },
            ]
        });
        if (foundUser) {
            const method = foundUser.method;
            let username = '';
            if (method === 'facebook') {
                username = foundUser.facebook.username;
            } else if (method === 'google') {
                username = foundUser.google.username;
            }
            // Let's merge them
            foundUser.local = {
                email: req.body.email,
                password: req.body.password,
                username: username
            }
            const result = await foundUser.save();
            // Generate the token
            const token = signToken(foundUser);

            res.cookie('access_token', token, {
                httpOnly: true
            });

            if (res.accepts === 'application/json') {
                return res.status(200).json({ message: 'success', token: token });
            } else if (res.accepts === 'text/html' || res.accepts === "application/x-www-form-urlencoded") {
                return res.render('login/login', {
                    user: req.username,
                    success: "Account successfully created"
                });
            }
        } else {

            const newUser = new User({
                method: 'local',
                local: {
                    email: req.body.email,
                    password: req.body.password,
                    username: req.body.username
                }
            });
            const result = await newUser.save();

            const token = signToken(newUser);
            res.cookie('access_token', token, {
                httpOnly: true
            });
            if (res.accepts === 'application/json') {
                return res.status(200).json({ message: 'success', token: token });
            } else if (res.accepts === 'text/html' || res.accepts === "application/x-www-form-urlencoded") {
                return res.render('login/login', {
                    user: req.username,
                    success: "Account successfully created"
                });
            }
        }
    } catch (err) {
        if (res.accepts === 'application/json') {
            return res.status(500).json({ message: err });
        } else if (res.accepts === 'text/html' || res.accepts === "application/x-www-form-urlencoded") {
            return res.render('login/signup', {
                user: req.username,
                errors: err
            });
        }
    }
}

//singIn
async function signIn(req, res, next) {
    try {
        const token = signToken(req.user);
        res.cookie('access_token', token, {
            httpOnly: true
        });
        if (res.accepts === 'application/json') {
            return res.status(200).json({ message: 'success', token: token });
        } else if (res.accepts === 'text/html' || res.accepts === "application/x-www-form-urlencoded") {
            return res.redirect("/photoscavengerhunts");
        }
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
}

async function googleOAuth(req, res, next) {
    try {
        const token = signToken(req.user);
        res.cookie('access_token', token, {
            httpOnly: true
        });
        if (res.accepts === 'application/json') {
            return res.status(200).json({ message: 'success', token: token });
        } else if (res.accepts === 'text/html' || accepts === "application/x-www-form-urlencoded") {
            return res.redirect("/photoscavengerhunts");
        }
    } catch (err) {
        return res.status(500).json({ message: err });
    }
}

async function facebookOAuth(req, res, next) {
    try {
        const token = signToken(req.user);
        res.cookie('access_token', token, {
            httpOnly: true
        });
        if (res.accepts === 'application/json') {
            return res.status(200).json({ message: 'success', token: token });
        } else if (res.accepts === 'text/html' || accepts === "application/x-www-form-urlencoded") {
            return res.redirect("/photoscavengerhunts");
        }
    } catch (err) {
        return res.status(500).json({ message: err });
    }
}

async function checkStatus(req, res, next) {
    res.status(200).json({ success: true });
}

async function logout(req, res, next) {
    res.clearCookie('access_token');
    res.status(200).json({ message: "logout was successfully done" })
}

module.exports = {
    getUsers,
    getUser,
    addUser,
    signIn,
    googleOAuth,
    facebookOAuth,
    checkStatus,
    logout
};