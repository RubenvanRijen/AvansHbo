const mongoose = require('mongoose');
const upload = mongoose.model("Upload");
const target = mongoose.model("Target");
const cloudinary = require("cloudinary");
const Formidable = require('formidable');
const paginate = require('paginate-array');

cloudinary.config({
    cloud_name: process.env.CLOUDINARY_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_SECRET
});

async function getUploads(req, res, next) {

    try {
        const result = res.paginatedResults;

        if (!result.results.length) {
            return res.status(404).json({message: "No uploads to be found"});
        }
        if (res.accepts === 'application/json') {
            return res.status(200).json(result);
        } else if (res.accepts === 'text/html') {
            return res.render('uploads/uploads', {
                Uploads: result.results,
                user: req.username
            })
        } else {
            return res.status(406);
        }
    } catch (err) {
        return res.status(500).json({message: err});
    }
}

async function getTargetUploads(req, res, next) {
    let targetTitle, uploadsData = [];
    if (req.params.targetTitle) {
        targetTitle = req.params.targetTitle;
    }
    try {
        const result = await target.findOne({targetTitle: targetTitle});
        if (result === null) {
            return res.status(404).json({message: "No upload to be found"});
        }
        for (let k = 0; k < result.uploads.length; k++) {
            try {
                const uploadFound = await upload.findOne({uploadTitle: result.uploads[k]})
                uploadsData.push(uploadFound);
            } catch (err) {
                return res.status(500).json({message: err.message});

            }
        }
        const paginateCollection = paginate(uploadsData);

        if (res.accepts === 'application/json') {
            return res.status(200).json(paginateCollection);
        } else {
            return res.render('uploads/uploads', {
                Uploads: paginateCollection,
                targetTitle: targetTitle,
                user: req.username,
                scavengerTitle: req.params.scavengerTitle,
                isAdmin: req.user.isAdmin

            });
        }

    } catch (err) {
        return res.status(500).json({message: err.message});
    }
}

async function getUploadById(req, res, next) {
    let uploadTitle;
    if (req.params.uploadTitle) {
        uploadTitle = req.params.uploadTitle;
    }

    try {
        const result = await upload.findOne({uploadTitle: uploadTitle});
        if (result === null) {
            return res.status(404).json({message: "No upload to be found"});
        }

        if (res.accepts === 'application/json') {
            return res.status(200).json(result);
        } else {
            return res.render('uploads/editupload', {
                upload: result,
                scavengerTitle: req.params.scavengerTitle,
                user: req.username,
                targetTitle: req.params.targetTitle,
                isEdit: true
            });
        }
    } catch (err) {
        return res.json({message: err});
    }
}

async function createUpload(req, res, next) {
    let imageId, uploadResult, deleteResult, username, newUpload;
    try {
        if (req.user.method === "local") {
            username = req.user.local.username;
        } else if (req.user.method === "google") {
            username = req.user.google.username;
        } else if (req.user.method === "facebook") {
            username = req.user.facebook.username;
        }
        if (res.fields.likesTarget === 'on') {
            res.fields.likesTarget = true;
        } else {
            res.fields.likesTarget = false;
        }
        res.fields.date = new Date();
        res.fields.participantUsername = username;
        // parse a file upload
        res.fields.image = res.imageId;
        res.fields.score = res.imageScore;
        newUpload = new upload(res.fields);
        newUpload.imageTags = res.uploadTags;
        if (newUpload.score === 100) {
            cloudinary.uploader.destroy(res.imageId, function (result) {
                deleteResult = result;
            });
            if (res.accepts === 'application/json') {
                return res.status(500).json({message: 'You are not allowed to upload the same image'});
            } else {
                return res.render('uploads/editupload', {
                    errors: "You are not allowed to upload the same image",
                    user: req.username,
                    scavengerTitle: req.params.scavengerTitle,
                    targetTitle: req.params.targetTitle,
                    isCreate: true
                });
            }
        }
        uploadResult = await newUpload.save();

    } catch (err) {
        cloudinary.uploader.destroy(res.imageId, function (result) {
            deleteResult = result;
        });
        if (res.accepts === 'application/json') {
            return res.status(500).json({message: err.message});
        } else {
            return res.render('uploads/editupload', {
                errors: err,
                user: req.username,
                scavengerTitle: req.params.scavengerTitle,
                targetTitle: req.params.targetTitle,
                isCreate: true
            });
        }
    }
    res.upload = newUpload;
    next();
}

async function deleteUpload(req, res, next) {
    let uploadTitle, uploadData;
    if (req.params.uploadTitle) {
        uploadTitle = req.params.uploadTitle;
    }
    try {
        uploadData = await upload.findOne({uploadTitle: uploadTitle});
        const result = await upload.remove({uploadTitle: uploadTitle});
        // return res.status(200).json(result);
    } catch (err) {
        return res.json({message: err});
    }
    res.upload = uploadData;
    next();
}

async function updateUpload(req, res, next) {
    let uploadTitle, uploadData;
    if (req.params.uploadTitle) {
        uploadTitle = req.params.uploadTitle;
    }
    try {
        if (req.body.likesTarget === 'on') {
            req.body.likesTarget = true;
        } else {
            req.body.likesTarget = false;
        }
        const result = await upload.updateOne({uploadTitle: uploadTitle}, {$set: req.body});
        uploadData = await upload.findOne({uploadTitle: req.body.uploadTitle});

    } catch (err) {
        return res.json({message: err.message});
    }
    res.upload = req.body;
    next();
}

module.exports = {
    getUploads,
    getTargetUploads,
    getUploadById,
    createUpload,
    deleteUpload,
    updateUpload

};