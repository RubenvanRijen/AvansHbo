let express = require("express");
const mongoose = require('mongoose');
const photoScavengerHunt = mongoose.model('PhotoScavengerHunt');
const target = mongoose.model('Target');
const upload = mongoose.model('Upload');
const paginate = require("paginate-array");

const https = require('https');


async function getPhotoScavengerHunts(req, res, next) {
    try {
        const result = res.paginatedResults;
        if (res.accepts === 'application/json') {
            return res.status(200).json(result);
        } else if (res.accepts === 'text/html') {
            return res.render('photoScavengerHunts/photoscavengerhunts', {
                PhotoScavengerHunts: result.results,
                user: req.username,
                isAdmin: req.user.isAdmin
            });
        } else {
            return res.status(406).json({ message: "no valid content-type" });
        }
    } catch (err) {
        return res.status(500).json({ message: err });
    }
}

async function getPhotoScavengerHuntById(req, res, next) {
    let scavengerTitle;
    if (req.params.scavengerTitle) {
        scavengerTitle = req.params.scavengerTitle;
    }

    try {
        const result = await photoScavengerHunt.findOne({ scavengerTitle: scavengerTitle });

        if (result === null) {
            return res.status(404).json({ message: "No photoScavengerHunt to be found" });
        }
        if (res.accepts === 'application/json') {
            return res.status(200).json(result);
        } else if (res.accepts === 'text/html' || res.accepts === 'application/x-www-form-urlencoded') {
            return res.render('photoScavengerHunts/editphotoscavengerhunt', {
                photoScavengerHunt: result,
                user: req.username,
                isEdit: true
            });
        }
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
}


async function createPhotoScavengerHunt(req, res, next) {
    const method = req.user.method;
    try {
        if (method === "local") {
            req.body.creator = req.user.local.username;
        } else if (method === "facebook") {
            req.body.creator = req.user.facebook.username;
        } else if (method === "google") {
            req.body.creator = req.user.google.username;
        }
        const newPhotoScavengerHunt = new photoScavengerHunt(req.body);
        const result = await newPhotoScavengerHunt.save();

        if (res.accepts === 'application/json') {
            return res.status(200).json(result);
        } else if (res.accepts === 'text/html' || res.accepts === "application/x-www-form-urlencoded") {
            return res.redirect("/photoscavengerhunts/");

        }
    } catch (err) {
        if (res.accepts === 'application/json') {
            return res.status(500).json({ message: err });
        } else if (res.accepts === 'text/html' || res.accepts === "application/x-www-form-urlencoded") {
            return res.render('photoscavengerhunts/editphotoscavengerhunt', {
                errors: err,
                user: req.username,
                isCreate: true
            });
        }
    }
}

async function deletePhotoScavengerHunt(req, res, next) {
    let scavengerTitle;
    if (req.params.scavengerTitle) {
        scavengerTitle = req.params.scavengerTitle;
    }

    try {
        const result = await photoScavengerHunt.remove({ scavengerTitle: scavengerTitle });
        if (result.deletedCount === 0) {
            return res.status(404).json({ message: "No photoScavengerHunt to be found" });
        }

        if (res.accepts === 'application/json') {
            return res.status(200).json(result);
        } else if (res.accepts === 'text/html' || res.accepts === "application/x-www-form-urlencoded") {
            return res.redirect("/photoscavengerhunts/")

        } else {
            return res.status(406).json({ message: "no valid content-type" });
        }
    } catch (err) {
        return res.status(500).json({ message: err });
    }
}

async function updatePhotoScavengerHunt(req, res, next) {
    let scavengerTitle;

    if (req.params.scavengerTitle) {
        scavengerTitle = req.params.scavengerTitle;
    }
    try {
        const result = await photoScavengerHunt.updateOne({
            scavengerTitle: scavengerTitle
        }, { $set: req.body });

        if (res.accepts === 'application/json') {
            return res.status(200).json(result);
        } else if (res.accepts === 'text/html' || res.accepts === "application/x-www-form-urlencoded") {
            return res.redirect("/photoscavengerhunts/");

        }
    } catch (err) {
        if (res.accepts === 'application/json') {
            return res.status(500).json({ message: err });
        } else if (res.accepts === 'text/html' || res.accepts === "application/x-www-form-urlencoded") {
            return res.render('photoscavengerhunts/editphotoscavengerhunt', {
                errors: err,
                user: req.username,
                isEdit: true
            });
        }
    }
}

async function addTarget(req, res, next) {
    let scavengerTitle, targetsFound = [];
    if (req.params.scavengerTitle) {
        scavengerTitle = req.params.scavengerTitle;
    }
    try {
        const result = await photoScavengerHunt.findOne({ scavengerTitle: scavengerTitle });
        if (result === null) {
            return res.status(404).json({ message: "No photoScavengerHunt to be found" });
        }
        result.targets.push(res.target.targetTitle);
        await result.save();

        const newScavenge = await photoScavengerHunt.findOne({ scavengerTitle: scavengerTitle });

        if (res.accepts === 'application/json') {
            return res.status(200).json([newScavenge]);
        } else {
            return res.redirect("/photoscavengerhunts/" + scavengerTitle + "/targets");
        }
    } catch (err) {
        if (res.accepts === 'application/json') {
            return res.status(500).json({ message: err });
        } else {
            return res.render('targets/edittarget', {
                user: req.username,
                errors: err
            });
        }
    }
}

async function removeTarget(req, res, next) {
    let scavengerTitle, targetData = [];
    if (req.params.scavengerTitle) {
        scavengerTitle = req.params.scavengerTitle;
    }
    try {
        const result = await photoScavengerHunt.findOne({ scavengerTitle: scavengerTitle });
        if (result === null) {
            return res.status(404).json({ message: "No photoScavengerHunt to be found" });
        }

        result.targets.pull(req.params.targetTitle);

        await result.save();

        const newScavenge = await photoScavengerHunt.findOne({ scavengerTitle: scavengerTitle });

        if (res.accepts === 'application/json') {
            return res.status(200).json([newScavenge, result]);
        } else if (res.accepts === 'text/html' || res.accepts === "application/x-www-form-urlencoded") {
            return res.redirect("/photoscavengerhunts/" + scavengerTitle + "/targets")

        } else {
            return res.status(406).json({ message: "no valid content-type" });
        }
    } catch (err) {
        return res.json({ message: err.message });
    }
}

async function addFeedback(req, res, next) {
    let scavengerTitle;
    if (req.params.scavengerTitle) {
        scavengerTitle = req.params.scavengerTitle;
    }
    try {
        const result = await photoScavengerHunt.findOne({ scavengerTitle: scavengerTitle });
        if (result === null) {
            return res.status(404).json({ message: "No photoScavengerHunt to be found" });
        }
        result.feedback.push(req.body.feedback);
        let savedResult = await result.save();

        const newScavenge = await photoScavengerHunt.findOne({ scavengerTitle: scavengerTitle });
        return res.status(200).json({result: [newScavenge, result]});
    } catch (err) {
        return res.json({ message: err });
    }
}

async function removeFeedback(req, res, next) {
    let scavengerTitle;
    if (req.params.scavengerTitle) {
        scavengerTitle = req.params.scavengerTitle;
    }
    try {
        const result = await photoScavengerHunt.updateOne({
            scavengerTitle: scavengerTitle, "feedback.usernameGrader": req.params.username
        }, { $pull: { feedback: { usernameGrader: req.params.username } } });
        if (result.nModified === 0) {
            return res.status(404).json({ message: "No photoScavengerHunt of user to be found" });
        }
        const newScavenge = await photoScavengerHunt.findOne({ scavengerTitle: scavengerTitle });
        return res.status(200).json([newScavenge, result]);
    } catch (err) {

        return res.status(500).json({ message: err });
    }
}

async function editTargetTitle(req, res, next) {
    let scavengerTitle;
    if (req.params.scavengerTitle) {
        scavengerTitle = req.params.scavengerTitle;
    }
    try {
        const result = await photoScavengerHunt.findOne({ scavengerTitle: scavengerTitle });
        if (result === null) {
            return res.status(404).json({ message: "No photoScavengerHunt to be found" });
        }
        result.targets.pull(req.params.targetTitle);
        await result.save();
        result.targets.push(res.target.targetTitle);
        await result.save();

        const newScavenge = await photoScavengerHunt.findOne({ scavengerTitle: scavengerTitle });

        if (res.accepts === 'application/json') {
            return res.status(200).json([paginateCollection, result]);
        } else {
            return res.redirect("/photoscavengerhunts/" + scavengerTitle + "/targets")
        }
    } catch (err) {
        if (res.accepts === 'application/json') {
            return res.json({ message: err.message });
        } else {
            return res.render('targets/edittarget', {
                errors: err,
                user: req.username,
                scavengerTitle: req.params.scavengerTitle,
                isCreate: true
            });
        }
        return res.json({ message: err });
    }
}

async function getUploadsFromTargetByHunt(req, res, next) {
    let scavengerTitle = req.params.scavengerTitle,
        targetUploads = [], targets = [];
    try {
        let scavengeHunt = await photoScavengerHunt.findOne({ scavengerTitle: scavengerTitle });
        if (scavengeHunt === null) {
            return res.status(404).json({ message: "No hunt has been found" });
        }

        for (let k = 0; k < scavengeHunt.targets.length; k++) {
            try {
                let targetData = await target.findOne({ targetTitle: scavengeHunt.targets[k] });
                if (targetData === null) {
                    return res.status(404).json({ message: "No target has been found" });
                }
                for (let i = 0; i < targetData.uploads.length; i++) {
                    try {
                        let uploadData = await upload.findOne({ uploadTitle: targetData.uploads[i] });
                        if (uploadData === null) {
                            return res.status(404).json({ message: "No upload has been found" });
                        }
                        targetUploads.push(uploadData);
                    } catch (err) {
                        return res.status(500).json({ message: err });
                    }
                }
            } catch (err) {
                return res.status(500).json({ message: err.message });
            }
        }
        const paginateCollection = paginate(targetUploads);

        return res.status(200).json(paginateCollection);
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
}

async function getUploadByIdFromTargetFromHunt(req, res, next) {
    let scavengerTitle = req.params.scavengerTitle, uploadTitle = req.params.uploadTitle,
        targetTitle = req.params.targetTitle, targetIsPart = false, uploadIsPart = false, user = res.user;
    try {
        const scavengeHunt = await photoScavengerHunt.findOne({ scavengerTitle: scavengerTitle });
        if (scavengeHunt === null) {
            return res.status(404).json({ message: "No hunt has been found" });
        }
        for (let k = 0; k < scavengeHunt.targets.length; k++) {
            if (scavengeHunt.targets[k] === targetTitle) {
                targetIsPart = true;
                break;
            }
        }
        if (targetIsPart === false) {
            return res.status(404).json({ message: "the target has not been found in " + scavengerTitle });
        }
        const targetData = await target.findOne({ targetTitle: targetTitle });
        if (targetData === null) {
            return res.status(404).json({ message: "No target has been found" });
        }
        for (let k = 0; k < targetData.uploads.length; k++) {
            if (targetData.uploads[k] === uploadTitle) {
                uploadIsPart = true;
                break;
            }
        }
        if (uploadIsPart === false) {
            return res.status(404).json({ message: "No upload has been found in " + targetTitle });
        }
        const uploadData = await upload.findOne({ uploadTitle: uploadTitle });
        if (uploadData === null) {
            return res.status(404).json({ message: "No upload has been found " });
        }

        if (res.accepts === 'application/json') {
            res.status(200).json(uploadData);
        } else {
            return res.render('uploads/editupload', {
                upload: uploadData,
                user: req.username,
                scavengerTitle: scavengerTitle,
                targetTitle: targetTitle,
                isEdit: true
            });
        }
    } catch (err) {
        return res.status(500).json({ message: err });
    }

}

async function getHunt(req, res, next) {
    let result;

    try {
        result = photoScavengerHunt.findOne({ scavengerTitle: req.params.scavengerTitle });
        if (result === null) {
            return res.status(404).json({ message: "no hunt has been found" });
        }
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
    res.scavengerTitle = result.scavengerTitle;
    next();
}

module.exports = {
    getPhotoScavengerHunts,
    getPhotoScavengerHuntById,
    createPhotoScavengerHunt,
    deletePhotoScavengerHunt,
    updatePhotoScavengerHunt,
    addTarget,
    removeTarget,
    addFeedback,
    removeFeedback,
    editTargetTitle,
    getUploadByIdFromTargetFromHunt,
    getUploadsFromTargetByHunt,
    getHunt
};