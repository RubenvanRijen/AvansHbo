let express = require("express");
const mongoose = require('mongoose');
const cloudinary = require("cloudinary");
const Formidable = require('formidable');
const target = mongoose.model('Target');

cloudinary.config({
    cloud_name: process.env.CLOUDINARY_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_SECRET
});

async function getTargetImageId(req, res, next) {
    let targetTitle, imageId;
    if (req.params.targetTitle) {
        targetTitle = req.params.targetTitle;
    }
    try {
        const result = await target.findOne({ targetTitle: targetTitle });
        if (result === null) {
            return res.status(404).json("no target has been found");
        }
        imageId = result.image;
        res.targetImageId = imageId;
        next();
    } catch (e) {
        return res.status(500).json({ message: e.message });
    }

}

async function getTargetTags(req, res, next) {
    let imagetags;
    try {
        let request = require('request'),
            apiKey = process.env.IMAGGA_API_KEY,
            apiSecret = process.env.IMAGGA_API_SECRET,
            imageUrl = 'https://res.cloudinary.com/avans/image/upload/v1585901145/' + res.targetImageId;

        request.get('https://api.imagga.com/v2/tags?image_url=' + encodeURIComponent(imageUrl), function (error, response, body) {
            imagetags = body;
            res.targetImageTags = imagetags;
            next();
        }).auth(apiKey, apiSecret, true);
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }

}

async function getUploadTags(req, res, next) {
    let imagetags;
    try {
        let request = require('request'),
            apiKey = process.env.IMAGGA_API_KEY,
            apiSecret = process.env.IMAGGA_API_SECRET,
            imageUrl = 'https://res.cloudinary.com/avans/image/upload/v1585901145/' + res.imageId;

        request.get('https://api.imagga.com/v2/tags?image_url=' + encodeURIComponent(imageUrl), function (error, response, body) {
            imagetags = body;
            res.uploadImageTags = imagetags;
            next();
        }).auth(apiKey, apiSecret, true);
    } catch (err) {
        cloudinary.uploader.destroy(res.imageId, function (result) {
            deleteResult = result;
        });
        return res.status(500).json({ message: err.message });
    }

}

async function determineScore(req, res, next) {
    let targetTags = JSON.parse(res.targetImageTags), uploadTags = JSON.parse(res.uploadImageTags), imageScore, topUploadTags;
    try {
        // phase 1 - get top tags
        // get top tags of targetTags
        let topTargetTags = [];
        for (let i = 0; i < 5; i++) {
            let tag = targetTags.result.tags[i]
            topTargetTags.push(tag)
        }

        // get top tags of uploadTags
        topUploadTags = [];
        for (let i = 0; i < 5; i++) {
            let tag = uploadTags.result.tags[i]
            topUploadTags.push(tag)
        }

        // phase 2 - calculate score in % per tag
        let scores = [];
        for (let i = 0; i < topTargetTags.length; i++) {
            let isTagPresent = false;

            for (let j = 0; j < topUploadTags.length; j++) {
                if (topUploadTags[j].tag.en === topTargetTags[i].tag.en) {
                    // percentage
                    let confidence = (topTargetTags[i].confidence - topUploadTags[j].confidence) / topUploadTags[j].confidence;
                    if (confidence <= 0) {
                        confidence += 1;
                    }

                    const score = (confidence * 100);
                    scores[i] = score;
                    isTagPresent = true;
                    break;
                }
            }

            if (!isTagPresent) {
                scores[i] = 0;
            }
        }

        // phase 3 - calculate average score
        let total = 0;
        for (let i = 0; i < scores.length; i++) {
            total += scores[i];
        }
        imageScore = total / scores.length;
    } catch (err) {
        cloudinary.uploader.destroy(res.imageId, function (result) {
            deleteResult = result;
        });
        return res.status(500).json({ message: err.message });
    }

    res.imageScore = imageScore;
    res.uploadTags = topUploadTags;
    next();
}


async function uploadImageTarget(req, res, next) {
    let imageId;
    try {
        // parse a file upload
        const form = new Formidable();

        await form.parse(req, async (err, fields, files) => {
            if (files.image) {
                //https://cloudinary.com/documentation/upload_images
                await cloudinary.uploader.upload(files.image.path, async result => {
                    if (result.public_id) {
                        res.imageId = result.public_id;
                        res.fields = fields;
                        next();
                    }
                });
            } else {
                if (res.accepts === 'application/json') {
                    return res.status(500).json({ message: "No image has been found" });
                } else {
                    return res.render('targets/edittarget', {
                        errors: "No image has been found",
                        user: req.username,
                        scavengerTitle: req.params.scavengerTitle,
                        isCreate: true
                    });
                }
            }
        });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
}

async function uploadImageUpload(req, res, next) {
    let imageId;
    try {
        // parse a file upload
        const form = new Formidable();

        await form.parse(req, async (err, fields, files) => {
            if (files.image) {
                //https://cloudinary.com/documentation/upload_images
                await cloudinary.uploader.upload(files.image.path, async result => {
                    if (result.public_id) {
                        res.imageId = result.public_id;
                        res.fields = fields;
                        res.fields.user = res.user;
                        next();
                    }
                });
            } else {
                if (res.accepts === 'application/json') {
                    return res.status(500).json({ message: "No image has been found" });
                } else {
                    return res.render('uploads/editupload', {
                        errors: "No image has been found",
                        scavengerTitle: req.params.scavengerTitle,
                        targetTitle: req.params.targetTitle,
                        user: req.username,
                        isCreate: true
                    });
                }
            }
        });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
}

async function deleteImage(req, res, next) {
    let data;
    if (res.imageId) {
        data = res.imageId;
    } else {
        data = res.upload.imageId;
    }
    try {
        await cloudinary.uploader.destroy(data, function (result) {
            console.log(result)
        });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
}

async function getImage(req, res, next) {
    let imageId = res.imageId;
    try {
        await cloudinary.image("https://res.cloudinary.com/avans/image/upload/v1585901145/" + imageId, { type: "fetch" });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
}

module.exports = { getImage, uploadImageTarget, uploadImageUpload, deleteImage, getTargetImageId, getTargetTags, getUploadTags, determineScore };