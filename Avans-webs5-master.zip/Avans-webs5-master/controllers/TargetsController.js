const mongoose = require('mongoose');
const target = mongoose.model('Target');
const photoScavengerHunt = mongoose.model('PhotoScavengerHunt');
const cloudinary = require("cloudinary");
const Formidable = require('formidable');
const geoip = require('geoip-lite');
const Distance = require('geo-distance');
const publicIp = require('public-ip');
const paginate = require("paginate-array");

cloudinary.config({
    cloud_name: process.env.CLOUDINARY_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_SECRET
});

async function getTargets(req, res, next) {
    try {
        const result = res.paginatedResults;

        if (!result.results.length) {
            return res.status(404).json({message: "No targets to be found"});
        }
        if (res.accepts === 'application/json') {
            return res.status(200).json(result);
        } else if (res.accepts === 'text/html') {
            return res.render('targets/targets', {
                Targets: result.results,
                user: req.username
            })
        } else {
            return res.status(406);
        }

    } catch (err) {
        return res.status(500).json({message: err});
    }
}

async function getPhotoScavengerHuntsTargets(req, res, next) {
    let scavengerTitle, targetsData = [];
    if (req.params.scavengerTitle) {
        scavengerTitle = req.params.scavengerTitle;
    }
    try {
        const result = await photoScavengerHunt.findOne({scavengerTitle: scavengerTitle});
        if (result === null) {
            return res.status(404).json({message: "No photoScavengerHunt to be found"});
        }
        for (let k = 0; k < result.targets.length; k++) {
            try {
                const targetFound = await target.findOne({targetTitle: result.targets[k]})
                targetsData.push(targetFound);
            } catch (err) {
                return res.status(500).json({message: err.message});
            }
        }
        const paginateCollection = paginate(targetsData);
        if (res.accepts === 'application/json') {
            return res.status(200).json(paginateCollection);
        } else if (res.accepts === 'text/html') {
            return res.render('targets/targets', {
                Targets: paginateCollection,
                user: req.username,
                scavengerTitle: result.scavengerTitle,
                creator: result.creator,
                isAdmin: req.user.isAdmin

            });
        } else {
            return res.status(406).json({message: "no valid content-type"});
        }
    } catch (err) {
        return res.status(500).json({message: err.message});
    }
}

async function getTargetById(req, res, next) {
    let targetTitle;
    if (req.params.targetTitle) {
        targetTitle = req.params.targetTitle;
    }

    try {
        const result = await target.findOne({targetTitle: targetTitle});
        if (result === null) {
            return res.status(404).json({message: "No target to be found"});
        }
        if (res.accepts === 'application/json') {
            return res.status(200).json(result);
        } else {
            return res.render('targets/edittarget', {
                target: result,
                user: req.username,
                scavengerTitle: req.params.scavengerTitle,
                isEdit: true
            });
        }
    } catch (err) {
        return res.json({message: err});
    }
}

async function createTarget(req, res, next) {
    let targetResult, newTarget, imageId, scavengerTitle = req.params.scavengerTitle;
    try {
        res.fields.image = res.imageId;
        res.fields.coordinates = {
            latitude: res.fields.latitude,
            longitude: res.fields.longitude
        }
        newTarget = new target(res.fields);
        targetResult = await newTarget.save();
    } catch (err) {
        if (res.imageId) {
            cloudinary.uploader.destroy(res.imageId, function (result) {
                console.log({result})
            });
        }
        if (res.accepts === 'application/json') {
            return res.status(500).json({message: err});
        } else {
            return res.render('targets/edittarget', {
                errors: err,
                user: req.username,
                scavengerTitle: scavengerTitle,
                isCreate: true
            });
        }
    }
    res.target = targetResult;
    next();
}

async function deleteTarget(req, res, next) {
    let targetTitle;
    if (req.params.targetTitle) {
        targetTitle = req.params.targetTitle;
    }
    try {
        const result = await target.remove({targetTitle: targetTitle});
        if (result.deletedCount === 0) {
            return res.status(404).json({message: "No target to be found"});
        }
    } catch (err) {
        return res.json({message: err});
    }
    next();
}

async function updateTarget(req, res, next) {
    let targetTitle, targetData, result;
    if (req.params.targetTitle) {
        targetTitle = req.params.targetTitle;
    }
    try {
        req.body.coordinates = {
            latitude: req.body.latitude,
            longitude: req.body.longitude
        }
        result = await target.updateOne({targetTitle: targetTitle}, {$set: req.body});
        targetData = await target.findOne({targetTitle: req.body.targetTitle});
        // return res.status(200).json(result);
    } catch (err) {
        if (res.accepts === 'application/json') {
            return res.status(500).json({message: err});
        } else {
            return res.render('targets/edittarget', {
                errors: err,
                user: req.username,
                scavengerTitle: req.params.scavengerTitle,
                isCreate: true
            });
        }
    }
    res.target = targetData;
    next();
}

async function addUpload(req, res, next) {
    let targetTitle;
    if (req.params.targetTitle) {
        targetTitle = req.params.targetTitle;
    }
    try {
        const result = await target.findOne({targetTitle: targetTitle});
        if (result === null) {
            return res.status(404).json({message: "No target to be found"});
        }
        const newArray = result.uploads.push(res.upload.uploadTitle);
        const data = result.save();
        if (res.accepts === 'application/json') {
            return res.status(200).json(data);
        } else {
            res.redirect("/photoscavengerhunts/" + req.params.scavengerTitle + "/targets/" + targetTitle + "/uploads");
        }
    } catch (err) {
        return res.json({message: err});
    }
}

async function removeUpload(req, res, next) {
    let targetTitle;
    if (req.params.targetTitle) {
        targetTitle = req.params.targetTitle;
    }
    try {
        const result = await target.findOne({targetTitle: targetTitle});
        if (result === null) {
            return res.status(404).json({message: "No target to be found"});
        }
        result.uploads.pull(req.params.uploadTitle);
        const data = result.save();

        if (res.accepts === 'application/json') {
            return res.status(200).json(data);
        } else {
            return res.redirect("/photoscavengerhunts/" + req.params.scavengerTitle + "/targets/" + targetTitle + "/uploads")
        }
    } catch (err) {
        if (res.accepts === 'application/json') {
            return res.status(500).json({message: err.message});
        } else {
            return res.redirect("/targets/" + targetTitle + "/uploads")
        }
    }
}

async function addHint(req, res, next) {
    let targetTitle;
    if (req.params.targetTitle) {
        targetTitle = req.params.targetTitle;
    }
    try {
        const result = await target.findOne({targetTitle: targetTitle});
        if (result === null) {
            return res.status(404).json({message: "No target to be found"});
        }
        result.hints.push(req.body.hints);
        await result.save();

        const newTarget = await target.findOne({targetTitle: targetTitle});
        return res.status(200).json([newTarget]);
    } catch (err) {
        return res.json({message: err});
    }
}

async function removeHint(req, res, next) {
    let targetTitle, id;
    if (req.params.targetTitle) {
        targetTitle = req.params.targetTitle;
    }
    if (req.params.id) {
        id = req.params.id;
    }
    try {
        const result = await target.findOne({targetTitle: targetTitle});
        if (result === null) {
            return res.status(404).json({message: "No target to be found"});
        }
        result.hints.pull(result.hints[id]);
        await result.save();

        const newTarget = await target.findOne({targetTitle: targetTitle});
        return res.status(200).json([newTarget]);
    } catch (err) {
        return res.json({message: err});
    }
}

async function editUploads(req, res, next) {
    let targetTitle;
    if (req.params.targetTitle) {
        targetTitle = req.params.targetTitle;
    }
    try {
        const result = await target.findOne({targetTitle: targetTitle});
        if (result === null) {
            return res.status(404).json({message: "No target to be found"});
        }
        result.uploads.pull(req.params.uploadTitle);
        await result.save();
        result.uploads.push(res.upload.uploadTitle);
        await result.save();

        const newTarget = await target.findOne({targetTitle: targetTitle});
        if (res.accepts === 'application/json') {
            return res.status(200).json([newTarget]);
        } else {
            res.redirect("/photoscavengerhunts/" + req.params.scavengerTitle + "/targets/" + targetTitle + "/uploads");
        }
    } catch (err) {
        return res.json({message: err.message});
    }
}

async function targetsInRange(req, res, next) {
    try {
        let ip = await publicIp.v4()

        // get long lat by ip
        let geo = geoip.lookup(ip).ll;

        let userLocation = {
            lat: geo[0],
            lon: geo[1]
        };

        let targets = await target.find({});
        let targetsInRange = [];
        for (let i = 0; i < targets.length; i++) {
            // get long lat of target
            let targetLocation = {
                lat: targets[i].coordinates.latitude.toString(),
                lon: targets[i].coordinates.longitude.toString()
            };

            // get distance to target
            let distanceFromUserToTarget = (Distance.between(userLocation, targetLocation) * 1000);

            // if radius < 500 m
            if (distanceFromUserToTarget < targets[i].radius) {
                targetsInRange.push(targets[i]);
            }
        }
        const paginateCollection = paginate(targetsInRange);
        if (res.accepts === 'application/json') {
            if (targetsInRange.length > 0) {
                return res.status(200).json(paginateCollection);
            } else {
                return res.status(404).json({message: "No nearby targets found"})
            }
        } else if (res.accepts === 'text/html') {
            return res.render('targets/targets', {
                Targets: paginateCollection.data,
                user: req.username
            })
        } else {
            return res.status(406);
        }

    } catch (err) {
        return res.json({message: err.message});
    }
}

module.exports = {
    getTargets,
    getPhotoScavengerHuntsTargets,
    getTargetById,
    createTarget,
    deleteTarget,
    updateTarget,
    addUpload,
    removeUpload,
    addHint,
    removeHint,
    editUploads,
    targetsInRange
};