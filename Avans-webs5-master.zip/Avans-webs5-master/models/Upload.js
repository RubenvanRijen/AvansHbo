const mongoose = require("mongoose");
const arrayUniquePlugin = require('mongoose-unique-array');

let uploadSchema = new mongoose.Schema(
    {
        uploadTitle: {type: String, required: true, lowercase: true, maxlength: 40, minlength: 3},
        score: {type: Number, required: true},
        date: {type: Date, required: true},
        likesTarget: {type: Boolean, required: true},
        image: {type: String, required: true},
        participantUsername: {type: String, required: true, ref: "User"},
        imageTags: {type: Object, required: false}
    },
    {
        toJSON: {virtuals: true},
        toObject: {virtuals: true}
    }
);
uploadSchema.index({uploadTitle: 1, participantUsername: 1}, {unique: true});

uploadSchema.plugin(arrayUniquePlugin);

mongoose.model("Upload", uploadSchema, "uploads");
