let mongoose = require("mongoose");
const arrayUniquePlugin = require('mongoose-unique-array');
const mongoosePaginate = require('mongoose-paginate-v2');

const PhotoScavengerHuntSchema = new mongoose.Schema(
    {
        scavengerTitle: {type: String, required: true, lowercase: true, maxlength: 20, minlength: 5},
        creator: {type: String, required: true, ref: "User"},
        targets: [{type: String, required: false, ref: "Target"}],
        participantsUsernames: [{type: String, required: false, lowercase: true, ref: "User"}],
        description: {type: String, required: true, maxlength: 200, minlength: 10},
        feedback: [
            {
                grade: {type: Number, required: true, max: 10, min: 0},
                comment: {type: String, required: true, maxlength: 100},
                usernameGrader: {type: String, required: true, ref: "User"}
            }
        ]
    },
    {
        toJSON: {virtuals: true},
        toObject: {virtuals: true}
    }
);
PhotoScavengerHuntSchema.index({scavengerTitle: 1}, {unique: true});
// PhotoScavengerHuntSchema.plugin(arrayUniquePlugin);
PhotoScavengerHuntSchema.plugin(mongoosePaginate);

mongoose.model("PhotoScavengerHunt", PhotoScavengerHuntSchema, "photoScavengerHunts");

