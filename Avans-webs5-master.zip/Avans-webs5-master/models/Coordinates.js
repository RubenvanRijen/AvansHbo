const mongoose = require("mongoose");

let coordinatesSchema = new mongoose.Schema(
    {
        longitude: {type: mongoose.Types.Decimal128, required: true},
        latitude: {type: mongoose.Types.Decimal128, required: true}
    },
    {
        toJSON: {virtuals: true},
        toObject: {virtuals: true}
    }
);


mongoose.model("Coordinates", coordinatesSchema, "coordinates");
