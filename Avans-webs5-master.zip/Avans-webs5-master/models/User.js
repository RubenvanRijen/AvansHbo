const mongoose = require("mongoose");
const validator = require('validator');
const passwordValidator = require('password-validator');
const byCrypt = require("bcryptjs");
let passwordSchema = new passwordValidator()
{
    passwordSchema.is().min(8)
        .is().max(100)
        .has().uppercase()
        .has().lowercase()
        .has().digits()
        .has().not().spaces()
        .is().not().oneOf(['Password', 'Password123']);
}


let userSchema = new mongoose.Schema(
    {
        method: {
            type: String,
            enum: ['local', 'google', 'facebook'],
            required: true
        },
        isAdmin: {type: Boolean, default: false, required: false},
        local: {
            email: {
                type: String, lowercase: true, validator: function (v) {
                    return validateEmail(v);
                }
            },
            username: {type: String, lowercase: true},
            password: {type: String,}
        },
        google: {
            id: {type: String},
            email: {type: String, lowercase: true},
            username: {type: String, lowercase: true},
        },
        facebook: {
            id: {type: String},
            email: {type: String, lowercase: true},
            username: {type: String, lowercase: true},
        },
    },
    {
        toJSON: {virtuals: true},
        toObject: {virtuals: true}
    }
);

userSchema.pre('save', async function (next) {
    try {
        if (!this.local.password) {
            next();
        }
        //the user schema is instantiated
        const user = this;

        //check if the user has been modified to know if the password has already been hashed
        if (!user.isModified('local.password')) {
            next();
        }
        // Generate a salt
        const salt = await byCrypt.genSalt(10);
        // Generate a password hash (salt + hash)
        const passwordHash = await byCrypt.hash(this.local.password, salt);
        // Re-assign hashed version over original, plain text password
        this.local.password = passwordHash;
        next();
    } catch (error) {
        next(error);
    }
});


userSchema.methods.isValidPassword = async function (newPassword) {
    try {
        return await byCrypt.compare(newPassword, this.local.password);
    } catch (error) {
        throw new Error(error);
    }
};

async function validateEmail(value) {
    return await validator.isEmail(value)
}

function validatePassword(value) {
    return passwordSchema.validate(value);
}


// Create a model
mongoose.model('User', userSchema);


