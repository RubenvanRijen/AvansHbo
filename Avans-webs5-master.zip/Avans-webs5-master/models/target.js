const mongoose = require("mongoose");
const arrayUniquePlugin = require('mongoose-unique-array');
const uploadSchema = require('mongoose').model('Upload').schema
const coordinateSchema = require('mongoose').model('Coordinates').schema


let targetSchema = new mongoose.Schema(
    {
        targetTitle: {type: String, required: true, unique: true, lowercase: true, maxlength: 50, minlength: 3},
        description: {type: String, required: true, maxlength: 200, minlength: 3},
        image: {type: String, required: true},
        radius: {type: Number, required: true, min: 50, max: 5000},
        coordinates: {type: coordinateSchema, required: true},
        hints: [{type: String, required: false}],
        uploads: [{type: String, required: false, lowercase: true, ref: "Upload"}]
    },
    {
        toJSON: {virtuals: true},
        toObject: {virtuals: true}
    }
);


targetSchema.plugin(arrayUniquePlugin);

mongoose.model("Target", targetSchema, "targets");
