const mongoose = require("mongoose");
const user = mongoose.model("User");
const target = mongoose.model("Target");
const upload = mongoose.model("Upload");
const coordinates = mongoose.model("Coordinates");
const photoScavengerHunt = mongoose.model("PhotoScavengerHunt");

const userSeed = [
    {
        username: "Ruben",
        email: "ruben@gmail.com",
        password: "Test123?",
        isAdmin: true
    },
    {
        username: "Jim",
        email: "jim@gmail.com",
        password: "Test123?",
        isAdmin: true
    },
    {
        username: "Stijn",
        email: "stijn@gmail.com",
        password: "Test123?",
        isAdmin: false
    }
];

const uploadSeed = [
    {
        uploadTitle: "Test1",
        score: 95,
        date: Date.now(),
        likesTarget: true,
        participantUsername: "Jim",
        image: "sample",
    },
    {
        uploadTitle: "Test2",
        score: 95,
        date: Date.now(),
        likesTarget: true,
        participantUsername: "Ruben",
        image: "sample",
    },
    {
        uploadTitle: "Test3",
        score: 95,
        date: Date.now(),
        likesTarget: true,
        participantUsername: "Jim",
        image: "sample",
    },
    {
        uploadTitle: "Test4",
        score: 95,
        date: Date.now(),
        likesTarget: true,
        participantUsername: "Ruben",
        image: "sample",
    },
    {
        uploadTitle: "Test5",
        score: 95,
        date: Date.now(),
        likesTarget: true,
        participantUsername: "Jim",
        image: "sample",
    },
    {
        uploadTitle: "Test6",
        score: 95,
        date: Date.now(),
        likesTarget: true,
        participantUsername: "Ruben",
        image: "sample",
    },
    {
        uploadTitle: "Test7",
        score: 95,
        date: Date.now(),
        likesTarget: true,
        participantUsername: "Ruben",
        image: "sample",
    },
    {
        uploadTitle: "Test8",
        score: 95,
        date: Date.now(),
        likesTarget: true,
        participantUsername: "Ruben",
        image: "sample",
    },
    {
        uploadTitle: "Test9",
        score: 95,
        date: Date.now(),
        likesTarget: true,
        participantUsername: "Ruben",
        image: "sample",
    },
    {
        uploadTitle: "Test10",
        score: 95,
        date: Date.now(),
        likesTarget: true,
        participantUsername: "Ruben",
        image: "sample",
    },
    {
        uploadTitle: "Test11",
        score: 95,
        date: Date.now(),
        likesTarget: true,
        participantUsername: "Ruben",
        image: "sample",
    },
    {
        uploadTitle: "Test12",
        score: 95,
        date: Date.now(),
        likesTarget: true,
        participantUsername: "Ruben",
        image: "sample",
    },

];

const targetSeed = [
    {
        targetTitle: "MacDonalds1",
        description: "Je wordt er dik van",
        image: "sample",
        radius: 200,
        coordinates: new coordinates(
            {
                longitude: 4.895168,
                latitude: 52.370216
            }
        ),
        hints: ["dit is een masale oorlog", "je wordt er dik van", "het is vet eten", "het is de magische M"],
        uploads: ["test1"]
    },
    {
        targetTitle: "MacDonalds3",
        description: "Je wordt er dik van",
        image: "sample",
        radius: 200,
        coordinates: new coordinates(
            {
                longitude: 4.895168,
                latitude: 52.370216
            }
        ),
        hints: ["dit is een masale oorlog", "je wordt er dik van", "het is vet eten", "het is de magische M"],
        uploads: ["test2", "test3"]
    }, {
        targetTitle: "MacDonalds4",
        description: "Je wordt er dik van",
        image: "sample",
        radius: 200,
        coordinates: new coordinates(
            {
                longitude: 4.895168,
                latitude: 52.370216
            }
        ),
        hints: ["dit is een masale oorlog", "je wordt er dik van", "het is vet eten", "het is de magische M"],
        uploads: ["test4", "test5"]
    }, {
        targetTitle: "MacDonalds5",
        description: "Je wordt er dik van",
        image: "sample",
        radius: 200,
        coordinates: new coordinates(
            {
                longitude: 4.895168,
                latitude: 52.370216
            }
        ),
        hints: ["dit is een masale oorlog", "je wordt er dik van", "het is vet eten", "het is de magische M"],
        uploads: ["test6", "test7"]
    }, {
        targetTitle: "MacDonalds6",
        description: "Je wordt er dik van",
        image: "sample",
        radius: 200,
        coordinates: new coordinates(
            {
                longitude: 4.895168,
                latitude: 52.370216
            }
        ),
        hints: ["dit is een masale oorlog", "je wordt er dik van", "het is vet eten", "het is de magische M"],
        uploads: ["test8", "test9"]
    }, {
        targetTitle: "MacDonalds7",
        description: "Je wordt er dik van",
        image: "sample",
        radius: 200,
        coordinates: new coordinates(
            {
                longitude: 4.895168,
                latitude: 52.370216
            }
        ),
        hints: ["dit is een masale oorlog", "je wordt er dik van", "het is vet eten", "het is de magische M"],
        uploads: ["test10", "test11"]
    }
];

const photoScavengerHuntSeed = [
    {
        scavengerTitle: "Den Bosch2",
        creator: "Ruben",
        targets: [
            "macdonalds1", "macdonalds3"
        ],
        participantsUsernames: [
            "Stijn", "Jim", "Ruben"
        ],
        description: "dit is een description",
        feedback: [
            {
                grade: 6,
                comment: "het is best okay kan beter",
                usernameGrader: "Ruben"
            },
            {
                grade: 6,
                comment: "het is best okay kan beter",
                usernameGrader: "Stijn"
            }
        ]
    },
    {
        scavengerTitle: "Den Bosch3",
        creator: "Jim",
        targets: [
            "macdonalds4", "macdonalds5"
        ],
        description: "dit is een description",
        participantsUsernames: [
            "Stijn", "Jim", "Ruben"
        ],
        feedback: [
            {
                grade: 6,
                comment: "het is best okay kan beter",
                usernameGrader: "Ruben"
            },
            {
                grade: 6,
                comment: "het is best okay kan beter",
                usernameGrader: "Stijn"
            }
        ]
    },
    {
        scavengerTitle: "Den Bosch4",
        creator: "Jim",
        targets: [
            "macdonalds6", "macdonalds7"
        ],
        participantsUsernames: [
            "Stijn", "Jim", "Ruben"
        ],
        description: "dit is een description",
        feedback: [
            {
                grade: 6,
                comment: "het is best okay kan beter",
                usernameGrader: "Ruben"
            },
            {
                grade: 6,
                comment: "het is best okay kan beter",
                usernameGrader: "Stijn"
            }
        ]
    }
];


module.exports = async function () {
    //users
    // let user = mongoose.model("User");
    // await user.find({}).then(users => {
    //     if (!users.length) {
    //         console.log("\tNo users found, filling testdata");
    //         user
    //             .insertMany(userSeed)
    //             .then(() => console.log("\tFilling user testdata succesfull"))
    //             .catch(err => console.log("\tFilling user testdata failed", err));
    //     }
    // });

    // //upload
    // let upload = mongoose.model("Upload");
    // await upload.find({}).then(uploads => {
    //     if (!uploads.length) {
    //         console.log("\tNo uploads found, filling testdata");
    //         upload
    //             .insertMany(uploadSeed)
    //             .then(() => console.log("\tFilling uploads testdata succesfull"))
    //             .catch(err => console.log("\tFilling uploads testdata failed", err));
    //     }
    // });

    // //targets
    // let target = mongoose.model("Target");
    // await target.find({}).then(targets => {
    //     if (!targets.length) {
    //         console.log("\tNo targets found, filling testdata");
    //         target
    //             .insertMany(targetSeed)
    //             .then(() => console.log("\tFilling targets testdata succesfull"))
    //             .catch(err => console.log("\tFilling targets testdata failed", err));
    //     }
    // });

    // //photoScavengerHunt
    // let photoScavengerHunt = mongoose.model("PhotoScavengerHunt");
    // await photoScavengerHunt.find({}).then(photoScavengerHunts => {
    //     if (!photoScavengerHunts.length) {
    //         console.log("\tNo photoScavengerHunts found, filling testdata");
    //         photoScavengerHunt
    //             .insertMany(photoScavengerHuntSeed)
    //             .then(() => console.log("\tFilling photoScavengerHunts testdata succesfull"))
    //             .catch(err => console.log("\tFilling photoScavengerHunts testdata failed", err));
    //     }
    // });
};
