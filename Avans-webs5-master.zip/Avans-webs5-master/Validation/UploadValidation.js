//TODO validatie op targets maken
const express = require("express");
const mongoose = require('mongoose');
const user = mongoose.model('User');
const photoScavengerHunt = mongoose.model('PhotoScavengerHunt');
const target = mongoose.model('Target');
const upload = mongoose.model('Upload');


async function editUploadValidation(req, res, next) {
    const values = req.body;

    try {
        if (values.score) {
            res.status(405).json({message: "de score mag niet aangepast worden"});
        }
        if (values.participantUsername) {
            res.status(405).json({message: "de participantUsername mag niet aangepast worden"});
        }
        if (values.image) {
            res.status(405).json({message: "de image mag niet aangepast worden"});
        }
        if (values.date) {
            res.status(405).json({message: "de date mag niet aangepast worden"});
        }

        // if (typeof values.likesTarget !== "boolean") {
        //     res.status(415).json({message: "the likesTarget  is not a boolean"});
        // }

        if (typeof values.uploadTitle !== 'string') {
            res.status(415).json({message: "de title  is not a string"});
        }

    } catch (err) {
        res.status(500).json({message: err.message})
    }
    next();
}

module.exports =
    {
        editUploadValidation
    };