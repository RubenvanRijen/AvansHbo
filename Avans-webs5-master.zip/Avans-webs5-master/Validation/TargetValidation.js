//TODO validatie op targets maken
const express = require("express");
const mongoose = require('mongoose');
const user = mongoose.model('User');
const photoScavengerHunt = mongoose.model('PhotoScavengerHunt');
const target = mongoose.model('Target');
const upload = mongoose.model('Upload');


async function editTargetValidation(req, res, next) {
    const values = req.body;

    try {
        if (values.hints) {
            res.status(405).json({ message: "de hints mogen niet aangepast worden" });
        }
        if (values.uploads) {
            res.status(405).json({ message: "de uploads mogen niet aangepast worden " });
        }
        if (values.image) {
            res.status(405).json({ message: "de image mag niet aangepast worden " });
        }

        // if (typeof values.latitude !== "number") {
        //     res.status(415).json({message: "the coordinates latitude is not a number"});
        // }
        // if (typeof values.longitude !== "number") {
        //     res.status(415).json({message: "the coordinates latitude is not a number"});
        // }
        // if (typeof values.radius !== "number") {
        //     res.status(415).json({message: "the radius latitude is not a number"});
        // }
        if (typeof values.targetTitle !== 'string') {
            if (res.accepts === 'application/json') {
                res.status(415).json({ message: "de title  is not a string" });
            } else {
                return res.render('targets/edittarget', {
                    errors: err,
                    scavengerTitle: req.params.scavengerTitle,
                    isCreate: true
                });
            }
        }
        if (typeof values.description !== 'string') {
            if (res.accepts === 'application/json') {
                res.status(415).json({ message: "de title  is not a string" });
            } else {
                return res.render('targets/edittarget', {
                    errors: err,
                    scavengerTitle: req.params.scavengerTitle,
                    isCreate: true
                });
            }
        }

    } catch (err) {
        res.status(500).json({ message: err.message })
    }
    next();
}

module.exports =
{
    editTargetValidation
};