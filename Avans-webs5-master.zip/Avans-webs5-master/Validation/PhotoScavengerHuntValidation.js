const express = require("express");
const mongoose = require('mongoose');
const user = mongoose.model('User');
const photoScavengerHunt = mongoose.model('PhotoScavengerHunt');
const target = mongoose.model('Target');
const upload = mongoose.model('Upload');

async function createPhotoScavengeHuntParticipantsRule(req, res, next) {
    const values = req.body;
    let participants;
    if (values.participantsUsernames) {
        participants = values.participantsUsernames;

        try {
            for (let i = 0; i < participants.length; ++i) {
                let foundUser = await User.findOne({
                    $or: [
                        {"google.username": participants[i]},
                        {"facebook.username": participants[i]},
                        {"local.username": participants[i]}
                    ]
                });
                if (foundUser === null) {
                    return res.status(404).json("De participant " + participants[i] + " bestaat niet");
                }
            }
        } catch (err) {
            return res.status(500).json({message: err});
        }
    }
    next();
}

async function createPhotoScavengeHuntTargetsRule(req, res, next) {
    const values = req.body;
    let targets = [];
    if (values.targets) {
        for (let k = 0; k < values.targets.length; k++) {
            targets.push(values.targets[k]);
        }
    }
    if (targets.length !== 0) {
        return res.status(405).json("Er mogen geen targets toegevoegd worden gedurenden het aanmaak process van een hunt");
    }
    next();
}

async function createPhotoScavengeHuntFeedbackRule(req, res, next) {
    const values = req.body;
    let feedback = [];
    if (values.feedback) {
        for (let k = 0; k < values.feedback.length; k++) {
            feedback.push(values.feedback[k]);
        }
    }
    if (feedback.length !== 0) {
        return res.status(405).json("Er mag geen feedback toegevoegd worden gedurenden het aanmaak process van een hunt");
    }
    next();
}

async function editPhotoScavengeHuntRules(req, res, next) {
    const values = req.body;
    if (values.participantsUsernames) {
        return res.status(405).json("Er mag geen participant toegevoegd/verwijdert worden gedurenden het update process van een hunt");
    }
    if (values.creator) {
        return res.status(405).json("De creator mag niet aangepast worden");
    }
    if (values.feedback) {
        return res.status(405).json("De feedback mag niet aangepast worden gedurenden het update process van een hunt");
    }
    if (values.targets) {
        return res.status(405).json("Er mogen geen targets toegevoegd/verwijdert worden gedurenden het update process van een hunt");
    }
    next();
}

async function addParticipantRule(req, res, next) {
    const values = req.body;
    let userData = values.participantsUsernames;
    if (userData) {
        let foundUser = await User.findOne({
            $or: [
                {"google.username": userData},
                {"facebook.username": userData},
                {"local.username": userData}
            ]
        });
        if (foundUser === null) {
            return res.status(404).json("De participant " + userData + " bestaat niet");
        }
    }
    next();
}

async function checkIfSameUser(req, res, next) {
    let user = req.user, scavengerTitle;
    if (req.params.scavengerTitle) {
        scavengerTitle = req.params.scavengerTitle;
    }
    const hunt = await photoScavengerHunt.findOne({scavengerTitle: scavengerTitle});
    if (hunt === null) {
        res.status(404).json({message: "No hunt has been found"});
    }

    if (user.method === "local") {
        if (hunt.creator !== user.local.username) {
            res.status(403).json({message: "Unauthorized"});
        }
    } else if (user.method === "google") {
        if (hunt.creator !== user.google.username) {
            res.status(403).json({message: "Unauthorized"});
        }
    } else if (user.method === "facebook") {
        if (hunt.creator !== user.facebook.username) {
            res.status(403).json({message: "Unauthorized"});
        }
    }
    next();
}

async function checkIfSameUploader(req, res, next) {
    let user = req.user, uploadTitle;
    if (req.params.uploadTitle) {
        uploadTitle = req.params.uploadTitle;
    }
    const uploadData = await upload.findOne({uploadTitle: uploadTitle});
    if (uploadData === null) {
        res.status(404).json({message: "No upload has been found"});
    }

    if (user.method === "local") {
        if (uploadData.participantUsername !== user.local.username) {
            res.status(403).json({message: "Unauthorized"});
        }
    } else if (user.method === "google") {
        if (uploadData.participantUsername !== user.google.username) {
            res.status(403).json({message: "Unauthorized"});
        }
    } else if (user.method === "facebook") {
        if (uploadData.participantUsername !== user.facebook.username) {
            res.status(403).json({message: "Unauthorized"});
        }
    }
    next();
}

module.exports = {
    createPhotoScavengeHuntParticipantsRule,
    createPhotoScavengeHuntTargetsRule,
    createPhotoScavengeHuntFeedbackRule,
    addParticipantRule,
    editPhotoScavengeHuntRules,
    checkIfSameUser,
    checkIfSameUploader

};