const express = require("express");
const mongoose = require('mongoose');
const user = mongoose.model('User');
const emailValidator = require("email-validator");

async function checkIfUserExist(req, res, next) {
    let username, result;
    if (req.params.username) {
        username = req.params.username;
    }
    try {
        result = await User.findOne({
            $or: [
                { "google.username": username },
                { "facebook.username": username },
                { "local.username": username }
            ]
        });
        if (result === null) {
            return res.status(404).json({ message: 'Cannot find user' });
        }
    } catch (err) {
        return res.status(500).json({ message: err });
    }
    res.user = result;
    next();
}

async function createUserValidationRules(req, res, next) {

    const values = req.body;
    let errors = [];
    if (!values.username) {
        errors.push("User needs an username");
    }
    if (!values.password) {
        errors.push("User needs a password");
    }
    if (!values.email) {
        errors.push("User needs an email");
    }

    if (errors.length > 0) {
        if (res.accepts === 'application/json') {
            return res.status(500).json({ message: errors });
        } else if (res.accepts === 'text/html' || res.accepts === "application/x-www-form-urlencoded") {
            return res.render('login/signup', {
                errors: errors
            });
        }
    }
    next();
}

async function setContentHeaders(req, res, next) {
    let accepts;
    if (req.headers['content-type']) {
        accepts = req.headers['content-type'];
    } else {
        accepts = "text/html";
    }
    res.accepts = accepts;
    next();
}


async function createUserEmailRules(req, res, next) {
    const values = req.body;
    let email;
    if (values.email) {
        email = values.email;
    }
    let correctEmail = emailValidator.validate(email);
    if (correctEmail === false) {
        return res.status(404).json("The mail " + email + " is not correct");
    }

    next();
}

async function checkIfAdmin(req, res, next) {
    let user = req.user;
    if (user.isAdmin !== true) {
        res.status(403).json({ message: "unauthorized" });
    }
    next();
}

async function checkIfSameUser(req, res, next) {
    let user = req.user, username;
    if (req.params.username) {
        username = req.params.username;
    }
    if (user.isAdmin === true) {
        next();
    }
    if (user.method === "local") {
        if (username !== user.local.username) {
            res.status(403).json({ message: "Unauthorized" });
        }
    } else if (user.method === "google") {
        if (username !== user.google.username) {
            res.status(403).json({ message: "Unauthorized" });
        }
    } else if (user.method === "facebook") {
        if (username !== user.facebook.username) {
            res.status(403).json({ message: "Unauthorized" });
        }
    }
    next();
}

async function logInFields(req, res, next) {
    if (!req.body.email) {
        return res.status(400).json({ message: "No email was given" });
    }
    if (!req.body.password) {
        return res.status(400).json({ message: "No password was given" });
    }
    next();
}

module.exports = {
    checkIfUserExist,
    createUserEmailRules,
    createUserValidationRules,
    setContentHeaders,
    checkIfAdmin,
    checkIfSameUser,
    logInFields
};