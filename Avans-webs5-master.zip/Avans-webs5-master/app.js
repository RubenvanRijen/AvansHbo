let createError = require("http-errors");
let express = require("express");
let path = require("path");
let cookieParser = require("cookie-parser");
let logger = require("morgan");
require('dotenv').config();
let methodOverride = require('method-override');
let cors = require('cors');
const passport = require('passport');
const helpers = require('handlebars-helpers')();

// =============================================================================
// DOCUMENTATION URL =============================================================
//https://documenter.getpostman.com/preview/10374734-b57c6185-576c-4b11-9714-cb908cc86c37?versionTag=latest&apiName=CURRENT&version=latest&top-bar=ffffff&right-sidebar=303030&highlight=ef5b25
// =============================================================================

const corsOptions = {
    origin: ['http://localhost:3000', 'https://still-bayou-42597.herokuapp.com'],
    optionsSuccessStatus: 200, // some legacy browsers (IE11, various SmartTVs) choke on 204
    credentials: true
}
//set express
let app = express();
app.use(cookieParser());
app.use(passport.initialize());
app.use(methodOverride('_method'));
app.use(cors(corsOptions));

//models
require("./models/User");
require("./models/Coordinates");
require("./models/Upload");
require("./models/target");
require("./models/PhotoScavengerHunt")


//routes
let indexRouter = require("./routes/index");
let usersRouter = require("./routes/users");
let uploadsRouter = require("./routes/uploads");
let photoScavengerHuntRouter = require("./routes/photoScavengerHunts");
let targetsRouter = require("./routes/targets");

// Data Access Layer
let mongoose = require("mongoose");
port = process.env.PORT || 8000
app.listen(port);
connectToDatabase();

//testData
require("./models/FillTestData")();

// view engine setup
const hbs = require('hbs');
app.set("views", path.join(__dirname, "views"));
app.set('view engine', 'hbs');
hbs.registerPartials(__dirname + '/views/partials');

hbs.registerHelper('eq', function(a, b, c, opts) {
    if (a == b || c) {
        return opts.fn(this)
    } else {
        return opts.inverse(this)
    }
})

// uncomment after placing your favicon in /public
//app.use(favicon(__dirname + '/public/favicon.ico'));
app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, "public")));

//routes
app.use("/", indexRouter, handleError);
app.use("/users", usersRouter, handleError);
app.use("/uploads", uploadsRouter, handleError);
app.use("/photoScavengerHunts", photoScavengerHuntRouter, handleError);
app.use("/targets", targetsRouter, handleError);


// catch 404 and forward to error handler
app.use(function (req, res, next) {
    next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get("env") === "development" ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render("error");
});

//functions
function connectToDatabase() {
    mongoose
        .connect(process.env.DB_CONNECTION, {
            useUnifiedTopology: true,
            useNewUrlParser: true,
            useCreateIndex: true,
        })
        .then(() => console.log("DB Connected!"))
        .catch(err => {
            console.log("Connection fout");
        });
}

function handleError(req, res, statusCode, message) {
    console.log();
    console.log("-------- Error handled --------");
    console.log("Request Params: " + JSON.stringify(req.params));
    console.log("Request Body: " + JSON.stringify(req.body));
    console.log(
        "Response sent: Statuscode " + statusCode + ', Message "' + message + '"'
    );
    console.log("-------- /Error handled --------");
    res.status(statusCode);
    res.json(message);
}

module.exports = app;
