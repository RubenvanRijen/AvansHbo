const express = require("express");
const mongoose = require('mongoose');
const passport = require('passport');
const JwtStrategy = require('passport-jwt').Strategy;
const { ExtractJwt } = require("passport-jwt");
const LocalStrategy = require('passport-local').Strategy;
const user = mongoose.model('User');
const GooglePlusTokeStrategy = require("passport-google-plus-token");
const FacebookTokenStrategy = require("passport-facebook-token");
const googleTrategy = require("passport-google-oauth20");
const FacebookStrategy = require('passport-facebook').Strategy;


const JWTExtractor = req => {
    let token = null;
    if (req.header('authorization')) {
        token = req.header('authorization');
    } else {
        if (req && req.cookies) {
            token = req.cookies['access_token'];
        }
    }
    return token;
}

// JSON WEB TOKENS STRATEGY
passport.use(new JwtStrategy({
    jwtFromRequest: JWTExtractor,
    secretOrKey: process.env.JWT_SECRET,
    passReqToCallback: true
}, async (req, payload, done) => {
    try {
        let username;
        // Find the user specified in token
        const foundUser = await user.findById(payload.id);

        // If user doesn't exists, handle it
        if (!foundUser) {
            return done(null, false);
        }
        if (foundUser.method === "local") {
            username = foundUser.local.username;
        } else if (foundUser.method === "google") {
            username = foundUser.google.username;
        } else if (foundUser.method === "facebook") {
            username = foundUser.facebook.username;
        }

        // Otherwise, return the user
        req.username = username;
        req.user = foundUser;
        done(null, foundUser);
    } catch (error) {
        done(error, false);
    }
}));

//GOOGLE OAUTH STRATEGY

passport.use("google", new googleTrategy({
    clientID: process.env.CLIENT_ID,
    clientSecret: process.env.CLIENT_SECRET,
    passReqToCallback: true,
    callbackURL: process.env.SITE_URL + 'users/oauth/google/redirect'
},
    async (req, accessToken, refreshToken, profile, done) => {
        // console.log('accessToken', accessToken);
        // console.log('refreshToken', refreshToken);
        // console.log('profile', profile);
        try {
            //check if this current user exist in DB
            let existingUser = await user.findOne({ "google.id": profile.id });
            if (existingUser) {
                return done(null, existingUser);
            }

            existingUser = await user.findOne({ 'local.email': profile.emails[0].value });
            if (existingUser) {
                const method = existingUser.method;
                let username = '';
                if (method === 'facebook') {
                    username = existingUser.facebook.username;
                } else if (method === 'local') {
                    username = existingUser.local.username;
                }
                //merge two accounts
                existingUser.google = {
                    id: profile.id,
                    email: profile.emails[0].value,
                    username: username
                }
                await existingUser.save();
                req.username = username;
                req.user = existingUser;
                return done(null, existingUser);
            }

            existingUser = await user.findOne({ 'facebook.email': profile.emails[0].value });
            if (existingUser) {
                const method = existingUser.method;
                let username = '';
                if (method === 'facebook') {
                    username = existingUser.facebook.username;
                } else if (method === 'local') {
                    username = existingUser.local.username;
                }
                //merge two accounts
                existingUser.google = {
                    id: profile.id,
                    email: profile.emails[0].value,
                    username: username
                }
                await existingUser.save();
                req.username = username;
                req.user = existingUser;
                return done(null, existingUser);
            }

            //If no user
            const newUser = new user({
                method: 'google',
                google: {
                    id: profile.id,
                    email: profile.emails[0].value,
                    username: profile.displayName
                }
            });

            const userDate = await newUser.save();
            req.username = newUser.google.username;
            req.user = newUser;

            done(null, userDate);
        } catch (err) {
            done(err, false, err.message);
        }
    }));

//FACEBOOK OAUTH STRATEGY
passport.use('facebook', new FacebookStrategy({
    clientID: process.env.FACEBOOK_APP_ID,
    clientSecret: process.env.FACEBOOK_APP_SECRET,
    passReqToCallback: true,
    callbackURL: process.env.SITE_URL + 'users/oauth/facebook/redirect',
    profileFields: ['id', 'displayName', 'photos', 'email']

}, async (req, accessToken, refreshToken, profile, done) => {
    try {
        // console.log('profile', profile);
        // console.log('accessToken', accessToken);
        // console.log('refreshToken', refreshToken);

        let existingUser = await user.findOne({ 'facebook.id': profile.id });
        if (existingUser) {
            return done(null, existingUser);
        }

        existingUser = await user.findOne({ 'local.email': profile.emails[0].value });
        if (existingUser) {
            const method = existingUser.method;
            let username = '';
            if (method === 'google') {
                username = existingUser.google.username;
            } else if (method === 'local') {
                username = existingUser.local.username;
            }
            //merge two accounts
            existingUser.facebook = {
                id: profile.id,
                email: profile.emails[0].value,
                username: username
            }
            await existingUser.save();
            req.username = username;
            req.user = existingUser;
            return done(null, existingUser);
        }

        existingUser = await user.findOne({ 'google.email': profile.emails[0].value });
        if (existingUser) {
            const method = existingUser.method;
            let username = '';
            if (method === 'google') {
                username = existingUser.google.username;
            } else if (method === 'local') {
                username = existingUser.local.username;
            }
            //merge two accounts
            existingUser.facebook = {
                id: profile.id,
                email: profile.emails[0].value,
                username: username
            }
            await existingUser.save();
            req.username = username;
            req.user = existingUser;
            return done(null, existingUser);
        }


        const newUser = new user({
            method: 'facebook',
            facebook: {
                id: profile.id,
                email: profile.emails[0].value,
                username: profile.displayName
            }
        });

        await newUser.save();
        req.username = newUser.facebook.username;
        req.user = newUser;
        done(null, newUser);

    } catch (err) {
        done(err, false, err.message);
    }
}));

// LOCAL STRATEGY
passport.use(new LocalStrategy({
    usernameField: 'email'
}, async (email, password, done) => {
    try {
        // Find the user given the email
        const userData = await user.findOne({ 'local.email': email });

        // If not, handle it
        if (!userData) {
            return done(null, false);
        }

        // Check if the password is correct
        const isMatch = await userData.isValidPassword(password);

        // If not, handle it
        if (!isMatch) {
            return done(null, false);
        }

        // Otherwise, return the user
        done(null, userData);
    } catch (error) {
        done(error, false);
    }
}));

//FACEBOOK token STRATEGY
passport.use('facebookToken', new FacebookTokenStrategy({
    clientID: process.env.FACEBOOK_APP_ID,
    clientSecret: process.env.FACEBOOK_APP_SECRET,
    passReqToCallback: true,
}, async (req, accessToken, refreshToken, profile, done) => {
    try {
        // console.log('profile', profile);
        // console.log('accessToken', accessToken);
        // console.log('refreshToken', refreshToken);

        let existingUser = await user.findOne({ 'facebook.id': profile.id });
        if (existingUser) {
            return done(null, existingUser);
        }

        existingUser = await user.findOne({ 'local.email': profile.emails[0].value });
        if (existingUser) {
            const method = existingUser.method;
            let username = '';
            if (method === 'google') {
                username = existingUser.google.username;
            } else if (method === 'local') {
                username = existingUser.local.username;
            }
            //merge two accounts
            existingUser.facebook = {
                id: profile.id,
                email: profile.emails[0].value,
                username: username
            }
            await existingUser.save();
            req.username = username;
            req.user = existingUser;
            return done(null, existingUser);
        }

        existingUser = await user.findOne({ 'google.email': profile.emails[0].value });
        if (existingUser) {
            const method = existingUser.method;
            let username = '';
            if (method === 'google') {
                username = existingUser.google.username;
            } else if (method === 'local') {
                username = existingUser.local.username;
            }
            //merge two accounts
            existingUser.facebook = {
                id: profile.id,
                email: profile.emails[0].value,
                username: username
            }
            await existingUser.save();
            req.username = username;
            req.user = existingUser;
            return done(null, existingUser);
        }


        const newUser = new user({
            method: 'facebook',
            facebook: {
                id: profile.id,
                email: profile.emails[0].value,
                username: profile.displayName
            }
        });

        await newUser.save();
        req.username = newUser.facebook.username;
        req.user = newUser;
        done(null, newUser);

    } catch (err) {
        done(err, false, err.message);
    }
}));

//GOOGLE token STRATEGY

passport.use("googleToken", new GooglePlusTokeStrategy({
    clientID: process.env.CLIENT_ID,
    clientSecret: process.env.CLIENT_SECRET,
    passReqToCallback: true,
},
    async (req, accessToken, refreshToken, profile, done) => {
        // console.log('accessToken', accessToken);
        // console.log('refreshToken', refreshToken);
        // console.log('profile', profile);
        try {
            //check if this current user exist in DB
            let existingUser = await user.findOne({ "google.id": profile.id });
            if (existingUser) {
                return done(null, existingUser);
            }

            existingUser = await user.findOne({ 'local.email': profile.emails[0].value });
            if (existingUser) {
                const method = existingUser.method;
                let username = '';
                if (method === 'facebook') {
                    username = existingUser.facebook.username;
                } else if (method === 'local') {
                    username = existingUser.local.username;
                }
                //merge two accounts
                existingUser.google = {
                    id: profile.id,
                    email: profile.emails[0].value,
                    username: username
                }
                await existingUser.save();
                req.username = username;
                req.user = existingUser;
                return done(null, existingUser);
            }

            existingUser = await user.findOne({ 'facebook.email': profile.emails[0].value });
            if (existingUser) {
                const method = existingUser.method;
                let username = '';
                if (method === 'facebook') {
                    username = existingUser.facebook.username;
                } else if (method === 'local') {
                    username = existingUser.local.username;
                }
                //merge two accounts
                existingUser.google = {
                    id: profile.id,
                    email: profile.emails[0].value,
                    username: username
                }
                await existingUser.save();
                req.username = username;
                req.user = existingUser;
                return done(null, existingUser);
            }

            //If no user
            const newUser = new user({
                method: 'google',
                google: {
                    id: profile.id,
                    email: profile.emails[0].value,
                    username: profile.displayName
                }
            });

            const userDate = await newUser.save();
            req.username = newUser.google.username;
            req.user = newUser;

            done(null, userDate);
        } catch (err) {
            done(err, false, err.message);
        }
    }));

module.exports = {};