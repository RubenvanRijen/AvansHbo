const app = require("../app");
const passportStub = require('passport-stub');
const request = require("supertest");
const path = require('path');
const chai = require('chai');
const {expect} = chai;
const chaiHttp = require('chai-http');
const faker = require('faker');
const mongoose = require('mongoose');
passportStub.install(app);
chai.use(chaiHttp);
const should = chai.should();
const uploadModel = mongoose.model("Upload");
const signup = '/users/signup';

describe("UploadsController", function() {
    // let token;
    // const upload = {
    //   uploadTitle: faker.random.word(),
    //   score: faker.random.number(100),
    //   date: faker.date.past(),
    //   likesTarget: faker.random.boolean(),
    //   image: faker.random.image(),
    //   participantUsername: faker.name.findName()
    // };

    // const preSave = {
    //     username: "mrtest",
    //     email: 'mr.sometest@gmail.com',
    //     password: faker.internet.password(),
    // };

    // before(async () => {
    //     const result = await chai
    //       .request(app)
    //       .post(signup)
    //       .send(preSave);
    //     expect(result.status).to.equal(200);
    //     token = result.body.token;
    // });

    // describe("getUploads", function() {
    //     it("should retrieve all uploads", done => {
    //         chai.request(app)
    //             .get("/uploads")
    //             .end(function(err, res){
    //                 res.should.have.status(200);
    //                 done();
    //             });
    //     // const stub = sinon.stub(uploadModel, "find").returns([upload]);
    //     // const uploads = await uploadsController.getUploads();
    //     // expect(stub.calledOnce).to.be.true;
    //     // expect(uploads.uploadTitle).to.equal(upload.uploadTitle);
    //     // expect(uploads.score).to.equal(upload.score);
    //     // expect(uploads.date).to.equal(upload.date);
    //     // expect(uploads.likesTarget).to.equal(upload.likesTarget);
    //     // expect(uploads.image).to.equal(upload.image);
    //   })
    // });
});