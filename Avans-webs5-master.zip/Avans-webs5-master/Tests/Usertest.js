const app = require("../app");
const passportStub = require('passport-stub');
const request = require("supertest");
const path = require('path');
const chai = require('chai');
const { expect } = chai;
const chaiHttp = require('chai-http');
const faker = require('faker');
const mongoose = require('mongoose');
passportStub.install(app);
chai.use(chaiHttp);

let token;

describe("Tests for authentication", function () {

    const user = {
        username: faker.name.findName(),
        email: faker.internet.email(),
        password: "Test123?"
    }
    const LogedInUser = {
        email: user.email,
        password: user.password
    }

    this.beforeEach(function () {

    });

    describe("Register", function () {
        it('should return 200 when all data is given correctly', function (done) {
            passportStub.logout();
            request(app)
                .post('/users/')
                .set('accept', 'application/json')
                .send(user)
                .expect(200)
                .expect('Content-Type', /json/)
                .end(function (err, res) {
                    if (err) { return done(err); }
                    expect(res.body.message).to.equal('success');
                    done();
                });
        });

        it('should return 403 when duplicate mail', function (done) {
            passportStub.logout();
            request(app)
                .post('/users/')
                .set('accept', 'application/json')
                .send(user)
                .expect(403)
                .expect('Content-Type', /json/)
                .end(function (err, res) {
                    if (err) { return done(err); }
                    expect(res.body.message).to.equal("Email is already taken");

                    done();
                });
        });
    });

    describe("login", function () {
        it('should return 400 when no user logs in', function (done) {
            passportStub.logout();
            request(app)
                .post('/users/signIn')
                .set('accept', 'application/json')
                .send({ LogedInUser })
                .expect(400)
                .end(function (err, res) {
                    if (err) { return done(err); }
                    expect(res.body.message).to.equal("No email was given");
                    done();
                });
        });

        it('should return 200 when user logs in', function (done) {
            passportStub.logout();
            request(app)
                .post('/users/signIn')
                .set('accept', 'application/json')
                .send( LogedInUser )
                .expect(200)
                .end(function (err, res) {
                    if (err) { return done(err); }
                    expect(res.body.message).to.equal('success');
                    done();
                });
        });
    });
})