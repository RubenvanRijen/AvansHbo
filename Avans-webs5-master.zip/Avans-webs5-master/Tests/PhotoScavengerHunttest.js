const app = require("../app");
const passportStub = require('passport-stub');
const request = require("supertest");
const path = require('path');
const chai = require('chai');
const { expect } = chai;
const chaiHttp = require('chai-http');
const faker = require('faker');
const mongoose = require('mongoose');
passportStub.install(app);
chai.use(chaiHttp);




describe("Tests for Photoscavengerhunts", function () {
    const photoScavengerHunt = {
        scavengerTitle: faker.name.jobTitle(),
        description: faker.name.jobDescriptor()
    }
    let newPhotoScavengerHunt = {
        scavengerTitle: faker.name.jobTitle(),
        description: faker.name.jobDescriptor()
    }
    let huntName = photoScavengerHunt.scavengerTitle;
    let token;
    const LogedInUser = {
        email: 'rgj.vanrijen@student.avans.nl',
        password: 'Test123?'
    }
    const feedback = {
        feedback: {
            grade: 2,
            comment: "No comment",
            usernameGrader: "Ruben"
        }
    }

    this.beforeAll(async function () {
        let result = await request(app)
            .post('/users/signIn')
            .set('content-type', 'application/json')
            .send(LogedInUser)
            .expect(200);
        token = result.body.token;
    });
    //get all hunts
    describe("getPhotoScavengerHunts", async function () {
        it('should return all photoScavengerHunts', function (done) {
            request(app)
                .get('/photoscavengerhunts')
                .set('content-type', 'application/json')
                .set('Authorization', token)
                .expect(200)
                .expect('Content-Type', /json/)
                .end(function (err, res) {
                    if (err) { return done(err); }
                    done();
                });
        });
    });
    //create hunt
    describe("create PhotoScavengerHunts", async function () {
        it('should return a new photoScavengerHunt', function (done) {
            request(app)
                .post('/photoscavengerhunts/')
                .set('content-type', 'application/json')
                .set('Authorization', token)
                .send(photoScavengerHunt)
                .expect(200)
                .expect('Content-Type', /json/)
                .end(function (err, res) {
                    if (err) { return done(err); }
                    done();
                });
        });
    });

    //get hunt by id
    describe("getPhotoScavengerHuntByTitle", async function () {
        let title = photoScavengerHunt.scavengerTitle;
        it('should return 200 for specific photoScavengerHunt', function (done) {
            request(app)
                .get('/photoscavengerhunts/' + title.toString())
                .set('content-type', 'application/json')
                .set('Authorization', token)
                .expect(200)
                .expect('Content-Type', /json/)
                .end(function (err, res) {
                    if (err) { return done(err); }
                    done();
                });
        });

        it('should return 404 for specific photoScavengerHunt', function (done) {
            request(app)
                .get('/photoscavengerhunts/NeppeTitle')
                .set('content-type', 'application/json')
                .set('Authorization', token)
                .expect(404)
                .expect('Content-Type', /json/)
                .end(function (err, res) {
                    if (err) { return done(err); }
                    done();
                });
        });
    });
    //add feedback to hunt
    describe("addFeedabckPhotoScavengerHuntByTitle", async function () {
        it('should add feedabck to a photoScavengerHunt', function (done) {
            request(app)
                .post('/photoscavengerhunts/' + huntName + "/feedback")
                .set('content-type', 'application/json')
                .set('Authorization', token)
                .send(feedback)
                .expect(200)
                .expect('Content-Type', /json/)
                .end(function (err, res) {
                    if (err) { return done(err); }
                    done();
                });
        });
    });

     //add feedback to hunt
     describe("addFeedabckPhotoScavengerHuntByTitle", async function () {
        it('should add feedabck to a photoScavengerHunt', function (done) {
            request(app)
                .post('/photoscavengerhunts/targets/range')
                .set('content-type', 'application/json')
                .set('Authorization', token)
                .send(feedback)
                .expect(200)
                .expect('Content-Type', /json/)
                .end(function (err, res) {
                    if (err) { return done(err); }
                    done();
                });
        });
    });

    //edit hunt
    describe("editPhotoScavengerHuntByTitle", async function () {
        let title = photoScavengerHunt.scavengerTitle;
        it('should edit a photoScavengerHunt', function (done) {
            request(app)
                .patch('/photoscavengerhunts/' + title.toString())
                .set('content-type', 'application/json')
                .set('Authorization', token)
                .send(photoScavengerHunt)
                .expect(200)
                .expect('Content-Type', /json/)
                .end(function (err, res) {
                    if (err) { return done(err); }
                    done();
                });
        });
    });



    //delete hunt
    describe("deltePhotoScavengerHuntByTitle", async function () {
        let title = photoScavengerHunt.scavengerTitle;

        it('should delete a photoScavengerHunt', function (done) {
            request(app)
                .delete('/photoscavengerhunts/' + title.toString())
                .set('content-type', 'application/json')
                .set('Authorization', token)
                .send(photoScavengerHunt)
                .expect(200)
                .expect('Content-Type', /json/)
                .end(function (err, res) {
                    if (err) { return done(err); }
                    done();
                });
        });
    });

})