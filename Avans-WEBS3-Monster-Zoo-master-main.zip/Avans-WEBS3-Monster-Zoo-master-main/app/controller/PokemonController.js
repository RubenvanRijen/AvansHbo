import { PokemonView } from "../view/PokemonView";

export class PokemonController {

    constructor(form) {
        this.form = form;
        this.pokemonView = new PokemonView(this.form, this);
    }

    getRandomPokemonInfo(statToRetrieve) {
        let monsterView = this.pokemonView;

        let number = Math.floor(Math.random() * 800) + 1;

        fetch('https://pokeapi.co/api/v2/pokemon/' + number)
            .then(function (resp) {
                return resp.json();
            })
            .then(function (data) {
                if (statToRetrieve == "name") {
                    monsterView.setPokemonName(data);
                } else if (statToRetrieve == "image") {
                    monsterView.setPokemonForm(data);
                }
            })
            .catch(function () {
                alert("Something went wrong :(");
            });
    }
}