import { WeatherAPI } from "../view/WeatherAPI";

export class WeatherController {

    constructor(monsterController, grid) {
        this.monsterController = monsterController;
        this.grid = grid;
        const key = '6f9d6591679354ad180c29672ff64c0b';
        this.cityID = 'Oss';
        this.weatherAPI = new WeatherAPI(this.monsterController, this.grid, this, key);
        this.apicall(key, this.cityID, this.weatherAPI);
    }


    apicall(key, cityID, weatherAPI) {
        fetch('https://api.openweathermap.org/data/2.5/weather?q=' + cityID + '&appid=' + key)
            .then(function(resp) {
                return resp.json();
            })
            .then(function(data) {
                weatherAPI.designWeatherBox(data);
            })
            .catch(function() {
                alert("Something went wrong :(");
            });
    }
}