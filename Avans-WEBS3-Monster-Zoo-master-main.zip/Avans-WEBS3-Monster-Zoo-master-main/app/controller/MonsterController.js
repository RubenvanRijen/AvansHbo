import WaterMonster from '../model/WaterMonster';
import FireMonster from '../model/FireMonster';
import EarthMonster from '../model/EarthMonster';
import AirMonster from '../model/AirMonster';

import { Drawing } from '../view/Drawing';
import { Grid } from '../view/Grid';
import { DragAndDrop } from '../view/DragAndDrop';
import { Form } from '../view/Form';
import { PokemonController } from '../controller/PokemonController';
import { MonsterView } from '../view/MonsterView';
import { WeatherController } from '../controller/WeatherController';

export default class MonsterController {

    constructor() {
        this.MonsterView = new MonsterView(this, this.WeatherController);
        this.drawing = new Drawing();
        this.grid = new Grid(this, this.MonsterView);
        this.form = new Form(this, this.drawing, this.MonsterView);

        this.pokemonController = new PokemonController(this.form);
        this.WeatherController = new WeatherController(this, this.grid);

        this.dragAndDrop = new DragAndDrop(this, this.form, this.grid);
    }

    addEntry(monster) {
        let existingEntries = JSON.parse(localStorage.getItem("monsters"));
        if (existingEntries == null) existingEntries = [];
        let entry = {
            monster
        };
        localStorage.setItem("entry", JSON.stringify(entry));

        for (let k = 0; k < existingEntries.length; k++) {
            let number = parseInt(existingEntries[k].monster.x);
            if (isNaN(number)) {
                existingEntries.splice(k, 1);
            }
        }
        for (let i = 0; i < existingEntries.length; i++) {
            existingEntries[i].monster.id = i;
        }
        entry.monster.id = existingEntries.length;

        existingEntries.push(entry);
        this.grid.generateGrid(localStorage.getItem("biome"));
        localStorage.setItem("monsters", JSON.stringify(existingEntries));
    };

    playMonsterSound(monster) {
        let audio;
        switch (monster.type) {
            case "Water":
                audio = new Audio('./Audio/water.mp3');
                break;
            case "Fire":
                audio = new Audio('./Audio/fire.mp3');
                break;
            case "Earth":
                audio = new Audio('./Audio/earth.mp3');
                break;
            case "Air":
                audio = new Audio('./Audio/wind.mp3');
                break;
            default:
                audio = new Audio('./Audio/mlg-airhorn.mp3');
                break;
        }
        audio.play();
    }

    setMonsterStats(monster, id, retrievedObject) {
        let arrayID = id.split("-");
        monster.biome = localStorage.getItem("biome");
        monster.y = arrayID[0];
        monster.x = arrayID[1];
        monster.placed = 1;
        localStorage.setItem('monsters', JSON.stringify(retrievedObject));
        return monster;
    }

    deleteEntry(monster) {
        let existingEntries = JSON.parse(localStorage.getItem("monsters"));
        if (existingEntries == null) existingEntries = [];

        for (let k = 0; k < existingEntries.length; k++) {
            if (existingEntries[k].monster.id == monster.id) {
                existingEntries.splice(k, 1);
            }
        }
        localStorage.setItem("monsters", JSON.stringify(existingEntries));
        let biome = localStorage.getItem("biome");
        this.grid.generateGrid(biome);
    }

    makeMonsterArray() {
        let monsters = [];
        localStorage.setItem("monsters", JSON.stringify(monsters));
    }

    getGrid(gridname) {
        let retrievedObject = localStorage.getItem(gridname);
        if (retrievedObject == null) {
            return false;
        } else {
            return JSON.parse(retrievedObject);
        }
    }

    saveMonsterInGrid(gridname) {
        this.getGrid(gridname);
    }

    getRandomInt(max) {
        return Math.floor(Math.random() * Math.floor(max));
    }

    setPower(monster) {
        let power = monster.power;
        let weather = localStorage.getItem('weather');
        switch (weather) {
            case "light rain":
                if (monster.type == "Water") {
                    power += 2;
                }
                break;
            case "shower rain":
                if (monster.type == "Water") {
                    power += 2;
                }
                break;
            case "snow":
                if (monster.type == "Water") {
                    power += 2;
                }
                break;
            case "clear sky":
                if (monster.type == "Earth" || monster.type == "Fire") {
                    power += 2;
                }
                break;
            case "few clouds":
                if (monster.type == "Earth" || monster.type == "Fire") {
                    power += 2;
                }
                break;
            case "scattered clouds":
                if (monster.type == "Air") {
                    power += 2;
                }
                break;
            case "mist":
                if (monster.type == "Air") {
                    power += 2;
                }
                break;
        }
        return power;
    }

    createMonster(name, type, amountOfArms, armsType, amountOfLegs, amountOfEyes, furType, canFly, canSwim, color) {


        let canvas = this.drawing.getCanvas();
        let image = canvas.toDataURL("image/png").replace("image/png", "image/monster");
        let retrievedObject = JSON.parse(localStorage.getItem("monsters"));

        let monster = this.getMonsterType(type);

        monster.name = name;
        monster.type = type;
        monster.amountOfArms = amountOfArms;
        monster.armsType = armsType;
        monster.amountOfLegs = amountOfLegs;
        monster.amountOfEyes = amountOfEyes;
        monster.furType = furType;
        monster.canFly = canFly;
        monster.canSwim = canSwim;
        monster.color = color;
        monster.image = image;
        monster.power = this.getRandomInt(11);
        monster.placed = 0;
        monster.x = null;
        monster.y = null;

        if (retrievedObject != null || retrievedObject != undefined) {
            monster.id = retrievedObject.length;
        } else {
            monster.id = 0;
        }
        this.addEntry(monster);
        return monster;
    }

    getMonsters() {
        let monsters = JSON.parse(localStorage.getItem("monsters"));
        return monsters;
    }

    getMonsterType(typeMonster) {
        let monster;
        switch (typeMonster) {
            case "Water":
                monster = new WaterMonster();
                break;
            case "Fire":
                monster = new FireMonster();
                break;
            case "Earth":
                monster = new EarthMonster();
                break;
            case "Air":
                monster = new AirMonster();
                break;
        }
        return monster;
    }
}