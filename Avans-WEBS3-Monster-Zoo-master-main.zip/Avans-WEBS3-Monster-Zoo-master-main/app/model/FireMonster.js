import Monster from './Monster';

export default class FireMonster extends Monster {
    constructor() {
        super();
        this.name = "";
        this.type = "Fire";
        this.power = 1;

        this.placed = 0;
        this.x = null;
        this.y = null;

        this.minAmountOfArms = 0;
        this.maxAmountOfArms = 6;
        this.amountOfArms = this.minAmountOfArms;

        this.typesArms = ['Tentacles', 'Claws', 'Claw-wings'];
        this.typeArms = this.typesArms[0];

        this.minAmountOfLegs = 0;
        this.maxAmountOfLegs = 2;
        this.amountOfLegs = this.minAmountOfLegs;
        this.legsStep = 1;

        this.minAmountOfEyes = 0;
        this.maxAmountOfEyes = 4;
        this.amountOfEyes = this.minAmountOfEyes;

        this.furTypes = ['Scales', 'Feathers'];
        this.furType = this.furTypes[0];

        this.canFly = false;
        this.canSwim = false;

        this.colors = ['Red', 'Orange', 'Brown'];
        this.color = this.colors[0];

        this.image = null;
    }
}