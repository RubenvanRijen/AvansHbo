import Monster from './Monster';

export default class AirMonster extends Monster
{
    constructor() {
        super();
        this.name = "";
        this.type = "Air";
        this.power = 1;

        this.placed = 0;
        this.x = null;
        this.y = null;

        this.amountOfArms = 2;
        this.minAmountOfArms = 2;
        this.maxAmountOfArms = 2;

        this.typesArms = ['Wings', 'Claw-wings'];
        this.typeArms = this.typesArms[0];

        this.minAmountOfLegs = 0;
        this.maxAmountOfLegs = 2;
        this.amountOfLegs = this.minAmountOfLegs;
        this.legsStep = 2;

        this.amountOfEyes = 2;
        this.minAmountOfEyes = 2;
        this.maxAmountOfEyes = 2;

        this.furTypes = ['Feathers', 'Hair', 'Scales'];     
        this.furType = this.furTypes[0];

        this.canFly = true;
        this.canSwim = false;

        this.colors = ['White', 'Blue', 'Purple'];
        this.color = this.colors[0];

        this.image = null;
    }
}