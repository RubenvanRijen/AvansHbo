import Monster from './Monster';

export default class EarthMonster extends Monster {
    constructor() {
        super();
        this.name = "";
        this.type = "Earth";
        this.power = 1;

        this.placed = 0;
        this.x = null;
        this.y = null;

        this.amountOfArms = 2;
        this.minAmountOfArms = 2;
        this.maxAmountOfArms = 2;

        this.typesArms = ['Claws'];
        this.typeArms = this.typesArms[0];

        this.minAmountOfLegs = 2;
        this.maxAmountOfLegs = 6;
        this.amountOfLegs = this.minAmountOfLegs;
        this.legsStep = 2;

        this.amountOfEyes = 2;
        this.minAmountOfEyes = 2;
        this.maxAmountOfEyes = 2;

        this.furTypes = ['Hair', 'Scales', 'Slime'];
        this.furType = this.furTypes[0];

        this.canFly = false;
        this.canSwim = false;

        this.colors = ['Purple', 'Orange', 'White'];
        this.color = this.colors[0];

        this.image = null;
    }
}