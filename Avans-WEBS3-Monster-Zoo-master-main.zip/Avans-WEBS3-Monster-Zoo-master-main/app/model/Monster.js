export default class Monster {
    constructor() {
        this.name;
        this.type;
        this.power;

        this.placed;
        this.x;
        this.y;

        this.minAmountOfArms;
        this.maxAmountOfArms;
        this.amountOfArms;

        this.typesArms = [];
        this.typeArms;

        this.minAmountOfLegs;
        this.maxAmountOfLegs;
        this.amountOfLegs;
        this.legsStep;

        this.minAmountOfEyes;
        this.maxAmountOfEyes;
        this.amountOfEyes;

        this.furTypes = [];
        this.furType;

        this.canFly;
        this.canSwim;

        this.colors = [];
        this.color;

        this.image;
    }
}