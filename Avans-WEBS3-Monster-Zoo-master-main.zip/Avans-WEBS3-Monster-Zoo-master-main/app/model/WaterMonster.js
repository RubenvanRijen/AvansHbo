import Monster from './Monster';

export default class WaterMonster extends Monster {
    constructor() {
        super();
        this.name = "";
        this.type = "Water";
        this.power = 1;

        this.placed = 0;
        this.x = null;
        this.y = null;

        this.minAmountOfArms = 0;
        this.maxAmountOfArms = 8;
        this.amountOfArms = this.minAmountOfArms;

        this.typesArms = ['Tentacles', 'Fins'];
        this.typeArms = this.typesArms[0];

        this.minAmountOfLegs = 0;
        this.maxAmountOfLegs = 4;
        this.amountOfLegs = this.minAmountOfLegs;
        this.legsStep = 1;

        this.minAmountOfEyes = 0;
        this.maxAmountOfEyes = 8;
        this.amountOfEyes = this.minAmountOfEyes;

        this.furTypes = ['Scales', 'Slime'];
        this.furType = this.furTypes[0];

        this.canFly = false;
        this.canSwim = true;

        this.colors = ['Blue', 'Red', 'Green'];
        this.color = this.colors[0];

        this.image = null;
    }
}