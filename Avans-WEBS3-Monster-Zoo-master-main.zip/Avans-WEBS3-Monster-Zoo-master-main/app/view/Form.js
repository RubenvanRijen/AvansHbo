import WaterMonster from '../model/WaterMonster';
import FireMonster from '../model/FireMonster';
import EarthMonster from '../model/EarthMonster';
import AirMonster from '../model/AirMonster';

export class Form {
    constructor(monsterController, drawing, monsterView) {
        this.monsterController = monsterController;
        this.drawing = drawing;
        this.monsterView = monsterView;

        this.nameField = document.getElementById('name');
        this.typeField = document.getElementById('type');
        this.armsField = document.getElementById('arms');
        this.armsTypeField = document.getElementById('armstype');
        this.legsField = document.getElementById('legs');
        this.eyesField = document.getElementById('eyes');
        this.canFlyField = document.getElementById('canfly');
        this.canSwimField = document.getElementById('canswim');
        this.furTypeField = document.getElementById('furtype');
        this.colorField = document.getElementById('color');
        this.imageLoader = document.getElementById('picture');
        this.createMonsterButton = document.getElementById('createmonster');
        this.monsterBox = document.getElementById("monster-box");
        this.canvas = document.getElementById('canvas');
        this.ctx = this.canvas.getContext('2d');

        this.typeField.addEventListener('change', (e) => {
            this.changeForm(e.target.value);
        });

        this.armsField.addEventListener('change', () => {
            if (this.typeField.options[this.typeField.selectedIndex].value == "Water") {
                this.setWaterPresets();
            } else if (this.typeField.options[this.typeField.selectedIndex].value == "Fire") {
                this.setFirePresets();
            }
        });

        this.furTypeField.addEventListener('change', () => {
            if (this.typeField.options[this.typeField.selectedIndex].value == "Fire") {
                this.setFirePresets();
            } else if (this.typeField.options[this.typeField.selectedIndex].value == "Air") {
                this.setAirPresets();
            }
        });

        this.imageLoader.addEventListener('change', () => {
            this.handleImage();
        });

        this.createMonsterButton.addEventListener('click', () => {
            if (this.nameField.value == "") {
                alert("Name is empty");
            } else if (this.typeField.value == "") {
                alert("Type is empty");
            } else {
                let monster = this.monsterController.createMonster(this.nameField.value, this.typeField.value, this.armsField.value, this.armsTypeField.value, this.legsField.value, this.eyesField.value,
                    this.furTypeField.value, this.canFlyField.checked, this.canSwimField.checked, this.colorField.value);
                this.monsterView.createMonster(monster, this.monsterBox, false);
                this.drawing.clearCanvas(this.ctx);
                document.getElementById("monster_create").reset();
            }
        });

        this.armsField.addEventListener('keypress', function(e) {
            e.preventDefault();
        });

        this.legsField.addEventListener('keypress', function(e) {
            e.preventDefault();
        });

        this.eyesField.addEventListener('keypress', function(e) {
            e.preventDefault();
        });
    }

    refillForm(monster) {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.nameField.value = monster.name;
        this.typeField.value = monster.type;
        this.changeForm(monster.type);
        this.armsField.value = monster.amountOfArms;
        this.armsTypeField.value = monster.armsType;
        this.legsField.value = monster.amountOfLegs;
        this.eyesField.value = monster.amountOfEyes;
        this.canFlyField.checked = monster.canFly;
        this.canSwimField.checked = monster.canSwim;
        this.colorField.value = monster.color;
        this.furTypeField.value = monster.furType;
        this.handleEditimage(monster);
    }

    createVisualMonster(monster) { // todo is this used
        this.monster = monster;
    }

    setWaterPresets() {
        let monster = new WaterMonster();
        if (this.armsField.value <= 4) {
            this.legsField.min = monster.minAmountOfLegs;
            this.legsField.max = monster.maxAmountOfLegs;
            this.legsField.disabled = false;
        } else {
            this.legsField.min = monster.minAmountOfLegs;
            this.legsField.max = monster.maxAmountOfLegs;
            this.legsField.value = 0;
            this.legsField.disabled = true;
        }
    }

    setFirePresets() {
        let monster = new FireMonster();

        if (arms.value <= 2) {
            this.legsField.min = monster.minAmountOfLegs;
            this.legsField.max = monster.maxAmountOfLegs;
            this.legsField.value = 2;
            this.legsField.disabled = true;
        } else {
            this.legsField.min = monster.minAmountOfLegs;
            this.legsField.max = monster.maxAmountOfLegs;
            this.legsField.value = 0;
            this.legsField.disabled = true;
        }

        if (this.furTypeField.options[this.furTypeField.selectedIndex].value == "Feathers") {
            this.canFlyField.checked = true;
        } else {
            this.canFlyField.checked = false;
        }
    }

    setEarthPresets() {
        this.armsField.disabled = true;
        this.eyesField.disabled = true;
    }

    setAirPresets() {
        this.armsField.disabled = true;
        this.eyesField.disabled = true;

        if (this.furTypeField.options[this.furTypeField.selectedIndex].value == "Hair" ||
            this.furTypeField.options[this.furTypeField.selectedIndex].value == "Scales") {
            this.canSwimField.checked = true;
        } else {
            this.canSwimField.checked = false;
        }
    }

    changeForm(typeMonster) {
        let monster;
        switch (typeMonster) {
            case "Water":
                monster = new WaterMonster();
                this.setPresets(monster);
                break;
            case "Fire":
                monster = new FireMonster();
                this.setPresets(monster);
                this.setFirePresets();
                break;
            case "Earth":
                monster = new EarthMonster();
                this.setPresets(monster);
                this.setEarthPresets();
                break;
            case "Air":
                monster = new AirMonster();
                this.setPresets(monster);
                this.setAirPresets();
                break;
        }
    }

    setPresets(monster) {
        this.armsField.min = monster.minAmountOfArms;
        this.armsField.max = monster.maxAmountOfArms;
        this.armsField.value = monster.amountOfArms;
        this.armsField.disabled = false;

        this.removeOptions(this.armsTypeField);
        this.addOptions(this.armsTypeField, monster);
        this.armsTypeField.disabled = false;

        this.legsField.min = monster.minAmountOfLegs;
        this.legsField.max = monster.maxAmountOfLegs;
        this.legsField.value = monster.amountOfLegs;
        this.legsField.step = monster.legsStep;
        this.legsField.disabled = false;

        this.eyesField.min = monster.minAmountOfEyes;
        this.eyesField.max = monster.maxAmountOfEyes;
        this.eyesField.value = monster.amountOfEyes;
        this.eyesField.disabled = false;

        this.removeOptions(this.furTypeField);
        this.addOptions(this.furTypeField, monster);
        this.furTypeField.disabled = false;

        this.canFlyField.checked = monster.canFly;
        this.canSwimField.checked = monster.canSwim;

        this.removeOptions(this.colorField);
        this.addOptions(this.colorField, monster);
        this.colorField.disabled = false;
    }

    removeOptions(selectbox) {
        for (let i = selectbox.options.length - 1; i >= 0; i--) {
            selectbox.remove(i);
        }
    }

    addOptions(selectbox, monster) {
        let options;
        switch (selectbox.id) {
            case "armstype":
                options = monster.typesArms;
                break;
            case "furtype":
                options = monster.furTypes;
                break;
            case "color":
                options = monster.colors;
                break;
        }
        let fragment = document.createDocumentFragment();

        options.forEach(function(options) {
            let option = document.createElement('option');
            option.innerHTML = options;
            option.value = options;
            fragment.appendChild(option);
        });
        selectbox.appendChild(fragment);
    }

    handleEditimage(monster) {
        let canvas = document.getElementById('canvas');
        let ctx = canvas.getContext('2d');

        let image = new Image();
        image.src = monster.image;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(image, 0, 0, image.width, image.height,
            0, 0, canvas.width, canvas.height);
    }

    setPokemonImage(imageURL) {
        let canvas = document.getElementById('canvas');
        let ctx = canvas.getContext('2d');

        let image = new Image();
        image.src = imageURL;
        image.setAttribute('crossOrigin', 'Anonymous');
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        image.onload = function() {
            ctx.drawImage(image, 0, 0, image.width, image.height,
                0, 0, canvas.width, canvas.height);
        };
        image.src = imageURL;
    }

    handleImage() {
        let canvas = document.getElementById('canvas');
        let ctx = canvas.getContext('2d');

        let reader = new FileReader();
        reader.onload = function(event) {
            let img = new Image();
            img.onload = function() {
                ctx.drawImage(img, 0, 0, img.width, img.height,
                    0, 0, canvas.width, canvas.height);
            }
            img.src = event.target.result;
        }
        reader.readAsDataURL(this.imageLoader.files[0]);
    }
}