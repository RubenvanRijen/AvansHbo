
export class PokemonView {

    constructor(form, pokemonController) {
        this.pokemonController = pokemonController;
        this.form = form;
        this.nameField = document.getElementById('name');
        this.pokemonButton = document.getElementById('pokemon-name');
        this.pokemonImage = document.getElementById('pokemon-image');
        
        this.pokemonButton.addEventListener('click', () => {
            this.pokemonController.getRandomPokemonInfo("name", this);
        });

        this.pokemonImage.addEventListener('click', () => {
            this.pokemonController.getRandomPokemonInfo("image", this);
        });
    }

    setPokemonName(data) {
        this.nameField.value = data.name;
    }
    setPokemonForm(data){
        this.form.setPokemonImage(data.sprites.front_default);
    }
}