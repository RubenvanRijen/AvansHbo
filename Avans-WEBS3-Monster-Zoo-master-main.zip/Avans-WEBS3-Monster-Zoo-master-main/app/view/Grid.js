export class Grid {

    constructor(monsterController, monsterView) {
        let icepoleName = "icePole";
        let SjahariName = "Sjahari";
        let jungleName = "jungle";
        this.monsterView = monsterView;
        this.monsterController = monsterController;

        this.generateGrid(icepoleName);
        document.getElementById('icePole').addEventListener('click', (e) => {
            this.generateGrid(icepoleName);
        });
        document.getElementById('Sjahari').addEventListener('click', (e) => {
            this.generateGrid(SjahariName);
        });
        document.getElementById('jungle').addEventListener('click', (e) => {
            this.generateGrid(jungleName);
        });
    }

    makeJSON(name) {
        let grid = this.monsterController.getGrid(name);
        if (grid == false) {
            let icePole = JSON.parse('{"name":"icePole","climate":"sub-zero cold","reference city": "Amsterdam","grid": [{ "name":"Row1", "Columns":[ "0", "0", "0", "0", "1", "1", "0", "0", "0","1" ] },{ "name":"Row2", "Columns":[ "0", "0", "0", "1", "0", "0", "1", "0", "0","1" ] },{ "name":"Row3", "Columns":[ "0", "0", "1", "0", "0", "0", "0", "0", "0","1" ] },{ "name":"Row4", "Columns":[ "0", "0", "0", "0", "0", "0", "0", "0", "1","1" ] },{"name":"Row5", "Columns":[ "0", "0", "0", "0", "0", "0", "0", "0", "0","1" ] },{ "name":"Row6", "Columns":[ "1", "0", "0", "0", "0", "0", "0", "0", "0","0" ] },{ "name":"Row7", "Columns":[ "1", "0", "0", "0", "0", "1", "0", "0", "0","0" ] },{ "name":"Row8", "Columns":[ "1", "0", "0", "0", "0", "0", "0", "0", "0","0" ] },{ "name":"Row9", "Columns":[ "1", "0", "0", "0", "1", "1", "0", "0", "0","0" ] },{ "name":"Row10", "Columns":[ "1", "0", "0", "0", "1", "1", "0", "0", "0","0" ] }]}');
            let Sjahari = JSON.parse('{"name":"Sjahari","climate":"burning hot","reference city": "Marrakech","grid": [{ "name": "Row1", "Columns": ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"] },{ "name": "Row2", "Columns": ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"] },{ "name": "Row3", "Columns": ["0", "0", "0", "0", "0", "0", "0", "1", "0", "0"] },{ "name": "Row4", "Columns": ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"] },  { "name": "Row5", "Columns": ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"] },{ "name": "Row6", "Columns": ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"] }, { "name": "Row7", "Columns": ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"] }, { "name": "Row8", "Columns": ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"] }, { "name": "Row9", "Columns": ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"] },{ "name": "Row10", "Columns": ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"] }]}');
            let jungle = JSON.parse('{"name": "jungle","climate": "bear grylls approved temperature","reference city": "Rio","grid": [{ "name": "Row1", "Columns": ["1", "0", "0", "0", "1", "1", "0", "0", "0", "1"] },{ "name": "Row2", "Columns": ["1", "0", "0", "1", "0", "0", "1", "0", "0", "1"] }, { "name": "Row3", "Columns": ["1", "0", "1", "0", "0", "0", "0", "1", "0", "1"] },{ "name": "Row4", "Columns": ["1", "1", "0", "0", "0", "0", "0", "0", "1", "1"] }, { "name": "Row5", "Columns": ["1", "0", "0", "0", "0", "0", "0", "0", "0", "1"] }, { "name": "Row6", "Columns": ["1", "1", "0", "0", "0", "0", "0", "0", "0", "1"] }, { "name": "Row7", "Columns": ["1", "0", "1", "0", "0", "0", "0", "0", "0", "1"] }, { "name": "Row8", "Columns": ["1", "0", "0", "1", "0", "0", "0", "0", "0", "1"] }, { "name": "Row9", "Columns": ["1", "0", "0", "0", "1", "1", "0", "0", "0", "1"] }, { "name": "Row10", "Columns": ["1", "0", "0", "0", "1", "1", "0", "0", "0", "1"] }]}');

            switch (name) {
                case "icePole":
                    localStorage.setItem(name, JSON.stringify(icePole));
                    localStorage.setItem("biome", name);
                    return icePole;
                case "Sjahari":
                    localStorage.setItem(name, JSON.stringify(Sjahari));
                    localStorage.setItem("biome", name);
                    return Sjahari;
                case "jungle":
                    localStorage.setItem(name, JSON.stringify(jungle));
                    localStorage.setItem("biome", name);
                    return jungle;
            }
        } else {
            localStorage.setItem("biome", name);
            return grid;
        }
    }

    generateGrid(name) {
        let grid = this.makeJSON(name);
        let template = document.getElementById('grid');
        template.innerText = "";

        for (let y = 0, len = grid["grid"].length; y < len; y++) {
            let div = document.createElement('div');
            div.setAttribute('id', grid["grid"][y]["name"]);
            div.setAttribute('class', 'row');
            template.append(div);

            for (let x = 0, len = grid["grid"][y]["Columns"].length; x < len; x++) {
                const rowUI = document.getElementById(grid["grid"][y]["name"]);
                let div = document.createElement('div');
                div.style.width = "80px";
                div.style.height = "80px";
                div.style.backgroundSize = "contain";
                if (grid["grid"][y]["Columns"][x] == 1) {
                    switch (name) {
                        case "Sjahari":
                            div.setAttribute('class', 'column-' + x + ' blocked-Sjahari');
                            div.style.backgroundImage = "url(images/dessert-blocked.jpg)";
                            break;
                        case "jungle":
                            div.setAttribute('class', 'column-' + x + ' blocked-jungle');
                            div.style.backgroundImage = "url(images/jungle-blocked.jpg)";
                            break;
                        case "icePole":
                            div.setAttribute('class', 'column-' + x + ' blocked-icePole');
                            div.style.backgroundImage = "url(images/ice-block-blocked.png)";
                            break;
                    }
                } else {
                    div.setAttribute('id', (y) + '-' + x);
                    div.style.zIndex = 1;
                    switch (name) {
                        case "Sjahari":
                            div.setAttribute('class', 'column-' + x + ' normal-Sjahari droptarget');
                            div.style.backgroundImage = "url(images/dessert-normale.jpg)";
                            break;
                        case "jungle":
                            div.setAttribute('class', 'column-' + x + ' normal-jungle droptarget');
                            div.style.backgroundImage = "url(images/jungle-normal.jpg)";
                            break;
                        case "icePole":
                            div.setAttribute('class', 'column-' + x + ' normal-icePole droptarget');
                            div.style.backgroundImage = "url(images/ice-block-normal.jpg)";
                            break;
                    }
                }
                rowUI.append(div);
                let monsters = this.monsterController.getMonsters();
                if (monsters != null || monsters != undefined) {
                    for (let z = 0, len = monsters.length; z < len; z++) {
                        if (monsters[z].monster.biome == name) {
                            if (monsters[z].monster.y == y && monsters[z].monster.x == x) {
                                this.monsterView.createMonster(monsters[z].monster, div, true);
                            }
                        }
                    }
                }
            }
        }
    }
}