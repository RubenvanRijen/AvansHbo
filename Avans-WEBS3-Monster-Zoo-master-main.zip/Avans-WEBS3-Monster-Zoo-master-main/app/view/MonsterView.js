export class MonsterView {

    constructor(monsterController, weatherAPI) {
        this.monsterController = monsterController;
        this.weatherAPI = weatherAPI;
    }

    createMonster(monster, div, boolean) {
        if (boolean == false) {
            let myNode = document.getElementById("monster-box");
            if (myNode.childNodes[1] != null) {
                let child = myNode.childNodes[1];
                child.remove();
            }
        }

        let image = document.createElement("img");
        image.src = monster.image;
        image.style.width = "80px";
        image.style.height = "80px";
        image.setAttribute('id', 'dragtarget' + monster.id);
        image.setAttribute('class', 'dragtarget');
        image.setAttribute('draggable', true);
        image.addEventListener("dragstart", function(event) {
            event.dataTransfer.setData("Text", event.target.id);
        });
        image.monster = monster;
        div.append(image);
        this.addToolTip(image, monster);
    }

    addToolTip(image, monster) {
        // add div to image
        let parent = image.parentNode;
        let wrapper = document.createElement('div');
        wrapper.classList.add("monster-container");
        parent.replaceChild(wrapper, image);
        wrapper.appendChild(image);

        // add div as sibling of image
        let tooltiptext = document.createElement('div');
        tooltiptext.classList.add("content");
        wrapper.appendChild(tooltiptext);
        // add text in div
        let monsterCon = this.monsterController;
        let power = monsterCon.setPower(image.monster);

        image.addEventListener("click", () => {
            if (power >= 7) {
                monsterCon.playMonsterSound(image.monster);
                this.useSpecialAttack(image, monster);
            }
        });
        let statsDescription = ["Name", "Type", "Arms", "ArmsType", "Legs", "Eyes", "Furtype", "Can Swim", "Can Fly", "Color", "power"];
        let stats = [image.monster.name, image.monster.type, image.monster.amountOfArms, image.monster.armsType, image.monster.amountOfLegs, image.monster.amountOfEyes, image.monster.furType, image.monster.canSwim, image.monster.canFly, image.monster.color, power];
        for (let i = 0; i < statsDescription.length; i++) {
            let text = document.createElement('h6');
            text.textContent = statsDescription[i] + ": " + stats[i];
            tooltiptext.appendChild(text);
        }

        // add delete button in div
        let deleteButton = document.createElement('button');
        deleteButton.textContent = "Delete";
        deleteButton.classList.add("btn");
        deleteButton.classList.add("btn-danger");
        deleteButton.classList.add("btn-block");
        deleteButton.classList.add("btn-sm");
        tooltiptext.appendChild(deleteButton);
        let biome = localStorage.getItem("biome");
        // delete button eventListener
        deleteButton.addEventListener('click', () => {
            this.deleteMonster(wrapper, this.monsterController);
            this.monsterController.grid.generateGrid(biome, this.monsterController);
        });
    }

    deleteMonster(monsterContainer) {
        let childs = monsterContainer.childNodes;
        let monster;
        for (let k = 0; k < childs.length; k++) {
            if (childs[k].monster != null) {
                monster = childs[k].monster;
            }
        }
        this.monsterController.deleteEntry(monster);
        monsterContainer.innerHTML = "";
    }

    useSpecialAttack(image, monster) {
        let imageHolder = monster.image;

        switch (image.monster.type) {
            case "Water":
                image.src = "./images/WaterSpecialAttack.gif";
                break;
            case "Fire":
                image.src = "./images/FireSpecialAttack.gif";
                break;
            case "Earth":
                image.src = "./images/EarthSpecialAttack.gif";
                break;
            case "Air":
                image.src = "./images/AirSpecialAttack.gif";
                break;
        }

        setTimeout(function() {
            image.src = imageHolder;
        }, 2500);
    }
}