export class DragAndDrop {

    constructor(monsterController, form, grid) {
        this.monsterController = monsterController;
        try {
            document.getElementById("dragtarget").addEventListener("dragstart", function(event) {
                event.dataTransfer.setData("Text", event.target.id);
            });
        } catch (e) {

        }

        document.addEventListener("dragover", function(event) {
            event.preventDefault();
        });

        document.addEventListener("drop", function(event) {
            event.preventDefault();
            if (event.target.classList.contains("droptarget")) {
                let data = event.dataTransfer.getData("Text");
                let image = document.getElementById(data);
                let id = event.target.id;
                let monsterArray = monsterController.getMonsters();

                if (image != null || image != undefined) {
                    if (image.monster != undefined) {
                        if (image.monster.placed == 0) {
                            if (monsterArray.length != 0) {
                                for (let index = 0; index < monsterArray.length; index++) {
                                    if (monsterArray[index].monster.biome == localStorage.getItem("biome")) {
                                        monsterController.playMonsterSound(monsterArray[index].monster);
                                    }
                                }
                            }
                        }
                        let arrayID = id.split("-");
                        let retrievedObject = monsterController.getMonsters();
                        for (let index = 0; index < retrievedObject.length; ++index) {
                            if (retrievedObject[index].monster.id === image.monster.id) {
                                image.monster.biome = localStorage.getItem("biome");
                                image.monster.y = arrayID[0];
                                image.monster.x = arrayID[1];
                                image.monster.placed = 1;
                                monsterController.setMonsterStats(retrievedObject[index].monster, id, retrievedObject);
                                if (id == "monster-box") {
                                    form.refillForm(image.monster);
                                }

                            }
                        }
                    }
                    image
                        .style
                        .maxWidth = "80px";
                    image
                        .style
                        .maxHeight = "80px";
                    let imageContainer = image.parentNode;
                    event
                        .target
                        .appendChild(imageContainer);
                }
                if (id == "monster-box") {
                    let myNode = document.getElementById("monster-box");
                    if (myNode.childNodes[1] != null) {
                        let child = myNode.childNodes[1];
                        child.remove();
                    }
                }
            }
            grid.generateGrid(localStorage.getItem("biome"));
        });
    }
}