export class WeatherAPI {

    constructor(monsterController, grid, weatherController, key) {
        this.weatherController = weatherController;
        this.monsterController = monsterController;
        this.grid = grid;
        this.temp = document.getElementById("temp");
        this.description = document.getElementById("description");
        this.location = document.getElementById("location");
        this.windspeed = document.getElementById("windspeed");
        this.image = document.getElementById("image");


        this.changeCityID = document.getElementById("ChangeCityID");
        this.inputChangeCityID = document.getElementById("CityID");

        this.changeCityID.addEventListener('click', (e) => {
            this.cityID = this.inputChangeCityID.value
            this.weatherController.apicall(key, this.cityID, this);
        });
    }

    designWeatherBox(data) {
        this.description.innerHTML = data.weather[0].description;
        this.description.setAttribute('class', data.weather[0].description);
        this.windspeed.innerHTML = data.wind.speed + " m/s";
        this.temp.innerHTML = Math.round((data.main.temp - 272.15) * 100) / 100 + " °C";
        this.image.src = "https://openweathermap.org/img/w/" + data.weather[0].icon + ".png"
        this.image.style.width = "100px";
        this.image.style.height = "100px";
        localStorage.setItem("weather", data.weather[0].description);
        this.location.innerHTML = data.name;
        this.name = localStorage.getItem("biome"); 
 
        if(this.name != null) {
            this.grid.generateGrid(this.name, this.monsterController);
        }
    }
}