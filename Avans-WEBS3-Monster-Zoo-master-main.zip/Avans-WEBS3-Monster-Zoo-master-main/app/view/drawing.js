export class Drawing {
    constructor() {
        this.canvasDiv = document.getElementById('canvasDiv');
        this.canvas = document.createElement('canvas');
        this.ctx = this.canvas.getContext('2d');
        this.clearButton = document.getElementById('clearButton');

        this.canvas.id = 'canvas';
        this.canvas.width = 350;
        this.canvas.height = 350;
        this.canvasDiv.appendChild(this.canvas);

        let inMemoryCanvas = document.createElement('canvas');
        let inMemoryCtx = inMemoryCanvas.getContext('2d');

        document.body.style.margin = 0;

        this.resizeCanvas(inMemoryCanvas, this.canvas, this.ctx, inMemoryCtx);

        this.pos = { x: 0, y: 0 };
        window.addEventListener('resize', this.resizeCanvas(inMemoryCanvas, this.canvas, this.ctx, inMemoryCtx));

        document.addEventListener('mousemove', (e) => {
            this.draw(e);
        });
        document.addEventListener('mousedown', (e) => {
            this.setPosition(e);
        });
        document.addEventListener('mouseenter', (e) => {
            this.setPosition(e);
        });

        this.clearButton.addEventListener('click', (e) => {
            this.clearCanvas(this.ctx);
        });
    }
    setPosition(e) {
        let bounds = this.canvas.getBoundingClientRect();
        this.pos.x = e.pageX - bounds.left - scrollX;
        this.pos.y = e.pageY - bounds.top - scrollY;
        this.pos.x /= bounds.width;
        this.pos.y /= bounds.height;
        this.pos.x *= canvas.width;
        this.pos.y *= canvas.height;
    }

    draw(e) {
        if (e.buttons !== 1) return;

        this.ctx.beginPath();

        let brushSize = document.getElementById('brushsize');
        this.ctx.lineWidth = brushSize.value;
        this.ctx.lineCap = 'round';

        let brush = document.getElementById('brushcolor');
        this.ctx.strokeStyle = brush.value;

        this.ctx.moveTo(this.pos.x, this.pos.y);
        this.setPosition(e);
        this.ctx.lineTo(this.pos.x, this.pos.y);

        this.ctx.stroke();
    }

    getCanvas() {
        return document.getElementById('canvas');
    }

    resizeCanvas(inMemoryCanvas, canvas, ctx, inMemoryCtx) {
        inMemoryCanvas.width = canvas.width;
        inMemoryCanvas.height = canvas.height;
        inMemoryCtx.drawImage(canvas, 0, 0);
        canvas.width = 380;
        ctx.drawImage(inMemoryCanvas, 0, 0);
    }

    clearCanvas(ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.beginPath();
    }
}