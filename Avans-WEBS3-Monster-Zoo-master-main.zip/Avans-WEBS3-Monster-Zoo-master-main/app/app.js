import MonsterController from './controller/MonsterController';

let controller = new MonsterController();
