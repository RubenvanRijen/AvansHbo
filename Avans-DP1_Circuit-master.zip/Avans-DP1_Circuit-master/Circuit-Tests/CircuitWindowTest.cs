﻿using System.Linq;
using System.Threading;
using CirCuit_WPF;
using NUnit.Framework;
using Refactor_DP1_Circuit;

namespace Circuit_Tests
{
    [TestFixture, Apartment(ApartmentState.STA)]
    public class CircuitWindowTest
    {
        [Test, Apartment(ApartmentState.STA)]
        public void InitTextBlock()
        {
            var fileConverter = new FileConverter();
            var nodeComponents = fileConverter.ConvertFile("Circuit1_FullAdder.txt");
            var circuitWindow = new CircuitWindow(nodeComponents);
            Assert.AreNotEqual(circuitWindow.TextBlock.Text.Length, 0);
        }
        
        [Test, Apartment(ApartmentState.STA)]
        public void ResetCircuitSuccess()
        {
            var fileConverter = new FileConverter();
            var nodeComponents = fileConverter.ConvertFile("Circuit1_FullAdder.txt");
            var circuitWindow = new CircuitWindow(nodeComponents);
            circuitWindow.ResetCircuit();
            var inputs = circuitWindow.NodeComponents.Where(c => c.IsInput()).ToArray();

            Assert.AreEqual(inputs[0].OutputValue, 1);
        }
    }
}