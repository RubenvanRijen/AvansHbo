﻿using NUnit.Framework;
using Refactor_DP1_Circuit;
using Refactor_DP1_Circuit.Builder;
using Refactor_DP1_Circuit.Nodes;

namespace Circuit_Tests
{
    public class BuilderTest
    {
        [Test]
        public void CompositeBuilderTest()
        {
            var director = new Director(new CompositeBuilder());
            director.ConstructComponent(new AndNode(), "builder", 1, 1, "");
            var obj = director.GetComponent();
            Assert.AreEqual(obj.Name, "builder");
            Assert.AreEqual(obj.OutputValue, 1);
            Assert.AreEqual(obj.AmountOfInputs, 1);
            Assert.IsTrue(obj is Composite);
        }

        [Test]
        public void LeafBuilderTest()
        {
            var director = new Director(new LeafBuilder());
            director.ConstructComponent(new AndNode(), "builder", 1, 1, "");
            var obj = director.GetComponent();
            Assert.AreEqual(obj.Name, "builder");
            Assert.AreEqual(obj.OutputValue, 1);
            Assert.AreEqual(obj.AmountOfInputs, 1);
            Assert.IsTrue(obj is Leaf);
        }
    }
}