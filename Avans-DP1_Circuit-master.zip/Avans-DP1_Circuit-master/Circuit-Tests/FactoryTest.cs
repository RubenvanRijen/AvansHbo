﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Refactor_DP1_Circuit.Factories;
using Assert = NUnit.Framework.Assert;

namespace Circuit_Tests
{
    [TestClass]
    public class FactoryTest
    {
        [TestMethod]
        public void FactoryRandomTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            var component = nodeFactory.CreateComponent("random", "INPUT_HIGH");
            Assert.IsTrue(component.IsInput());
            Assert.AreEqual("random", component.Name);
        }

        [TestMethod]
        public void FactoryStartTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            var component = nodeFactory.CreateComponent("Start", "START");
            Assert.AreEqual("Start", component.Name);
            Assert.AreEqual(0, component.AmountOfInputs);
        }

        [TestMethod]
        public void FactoryAndTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            var component = nodeFactory.CreateComponent("And", "AND");
            Assert.AreEqual("And", component.Name);
            Assert.AreEqual(2, component.AmountOfInputs);
        }

        [TestMethod]
        public void FactoryInputHighTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            var component = nodeFactory.CreateComponent("Input", "INPUT_HIGH");
            Assert.AreEqual("Input", component.Name);
            Assert.AreEqual(0, component.AmountOfInputs);
        }

        [TestMethod]
        public void FactoryInputLowTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            var component = nodeFactory.CreateComponent("Input", "INPUT_LOW");
            Assert.AreEqual("Input", component.Name);
            Assert.AreEqual(0, component.AmountOfInputs);
        }

        [TestMethod]
        public void FactoryProbeTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            var component = nodeFactory.CreateComponent("Probe", "PROBE");
            Assert.AreEqual("Probe", component.Name);
            Assert.AreEqual(1, component.AmountOfInputs);
        }

        [TestMethod]
        public void FactoryOrTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            var component = nodeFactory.CreateComponent("Or", "OR");
            Assert.AreEqual("Or", component.Name);
            Assert.AreEqual(2, component.AmountOfInputs);
        }

        [TestMethod]
        public void FactoryNotTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            var component = nodeFactory.CreateComponent("Not", "NOT");
            Assert.AreEqual("Not", component.Name);
            Assert.AreEqual(1, component.AmountOfInputs);
        }

        [TestMethod]
        public void FactoryXorTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            var component = nodeFactory.CreateComponent("Xor", "XOR");
            Assert.AreEqual("Xor", component.Name);
            Assert.AreEqual(2, component.AmountOfInputs);
        }

        [TestMethod]
        public void FactoryNandTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            var component = nodeFactory.CreateComponent("Nand", "NAND");
            Assert.AreEqual("Nand", component.Name);
            Assert.AreEqual(2, component.AmountOfInputs);
        }

        [TestMethod]
        public void FactoryNorTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            var component = nodeFactory.CreateComponent("Nor", "NOR");
            Assert.AreEqual("Nor", component.Name);
            Assert.AreEqual(2, component.AmountOfInputs);
        }

        [TestMethod]
        public void FactorySuccessTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            Assert.AreEqual(10, nodeFactory.Nodes.Count);
        }

        [TestMethod]
        public void FactoryFailTest()
        {
            AbstractFactory nodeFactory = new NodeFactory();
            nodeFactory.CreateNodes();
            Assert.AreNotEqual(15, nodeFactory.Nodes.Count);
        }
    }
}