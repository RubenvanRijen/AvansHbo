﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Refactor_DP1_Circuit;
using Refactor_DP1_Circuit.Nodes;

namespace Circuit_Tests
{
    [TestClass]
    public class CirCuitTest
    {
        [TestMethod]
        public void ParseInputTest1()
        {
            var fileConverter = new FileConverter();
            var list = fileConverter.ConvertFile("Circuit1_FullAdder.txt");
            Assert.AreEqual(17, list.Count);
        }

        [TestMethod]
        public void ParseInputTest2()
        {
            var fileConverter = new FileConverter();
            var list = fileConverter.ConvertFile("Circuit3_Encoder.txt");
            NUnit.Framework.Assert.AreEqual(15, list.Count);
        }

        [TestMethod]
        public void ParseInputTest3()
        {
            var fileConverter = new FileConverter();
            var list = fileConverter.ConvertFile("Circuit4_InfiniteLoop.txt");
            NUnit.Framework.Assert.AreEqual(11, list.Count);
        }

        [TestMethod]
        public void ParseInputTest4()
        {
            var fileConverter = new FileConverter();
            var list = fileConverter.ConvertFile("Circuit2_Decoder.txt");
            NUnit.Framework.Assert.AreEqual(23, list.Count);
        }

        [TestMethod]
        public void ParseInputTest5()
        {
            var fileConverter = new FileConverter();
            var list = fileConverter.ConvertFile("Circuit5_NotConnected.txt");
            NUnit.Framework.Assert.AreEqual(8, list.Count);
        }

        [TestMethod]
        public void FileValidationTest1()
        {
            var fileConverter = new FileConverter();
            var nodeComponents = fileConverter.ConvertFile("Circuit5_NotConnected.txt");
            var circuit = new Circuit();
            circuit.SetNodesValues(nodeComponents);
            var valid = nodeComponents.Where(nodeComponent => nodeComponent.AmountOfInputs >= 1).All(nodeComponent => nodeComponent.InputValues.Count != 0);

            NUnit.Framework.Assert.AreEqual(false, valid);
        }

        [TestMethod]
        public void FileValidationTest2()
        {
            var fileConverter = new FileConverter();
            var nodeComponents = fileConverter.ConvertFile("Circuit4_InfiniteLoop.txt");
            var circuit = new Circuit();
            circuit.SetNodesValues(nodeComponents);
            var valid = nodeComponents.Where(nodeComponent => nodeComponent.AmountOfInputs >= 1).All(nodeComponent => nodeComponent.InputValues.Count != 0);

            NUnit.Framework.Assert.AreEqual(false, valid);
        }

        [TestMethod]
        public void FileValidationTest3()
        {
            var fileConverter = new FileConverter();
            var nodeComponents = fileConverter.ConvertFile("Circuit2_Decoder.txt");
            var circuit = new Circuit();
            circuit.SetNodesValues(nodeComponents);
            var valid = nodeComponents.Where(nodeComponent => nodeComponent.AmountOfInputs == 1 || nodeComponent.AmountOfInputs > 1).All(nodeComponent => nodeComponent.InputValues.Count != 0);

            NUnit.Framework.Assert.AreEqual(true, valid);
        }

        [TestMethod]
        public void FileValidationTest4()
        {
            var fileConverter = new FileConverter();
            var nodeComponents = fileConverter.ConvertFile("Circuit3_Encoder.txt");
            var circuit = new Circuit();
            circuit.SetNodesValues(nodeComponents);
            var valid = nodeComponents.Where(nodeComponent => nodeComponent.AmountOfInputs >= 1).All(nodeComponent => nodeComponent.InputValues.Count != 0);

            NUnit.Framework.Assert.AreEqual(true, valid);
        }

        [TestMethod]
        public void FileValidationTest5()
        {
            var fileConverter = new FileConverter();
            var nodeComponents = fileConverter.ConvertFile("Circuit1_FullAdder.txt");
            var circuit = new Circuit();
            circuit.SetNodesValues(nodeComponents);
            var valid = nodeComponents.Where(nodeComponent => nodeComponent.AmountOfInputs >= 1).All(nodeComponent => nodeComponent.InputValues.Count != 0);

            NUnit.Framework.Assert.AreEqual(true, valid);
        }

        [TestMethod]
        [ExpectedException(typeof(System.IO.FileNotFoundException))]
        public void WrongFileErrorTest()
        {
            var fileConverter = new FileConverter();
            var list = fileConverter.ConvertFile("test.txt");
            Assert.AreEqual(17, list.Count);
        }

        [TestMethod]
        [ExpectedException(typeof(System.NullReferenceException))]
        public void PrettyPrinterTest()
        {
            var prettyPrinter = new CircuitPrinter();
            prettyPrinter.PrintCircuit(null);
        }

        [TestMethod]
        public void PrettyPrinterSuccessTest()
        {
            var prettyPrinter = new CircuitPrinter();

            var input = new Leaf {AmountOfInputs = 0, Node = new InputNode()};

            var composite = new Composite() {AmountOfInputs = 0};


            var normal = new Composite() {AmountOfInputs = 0};


            prettyPrinter.PrintCircuit(new List<NodeComponent>() {input, composite, normal});
        }
    }
}