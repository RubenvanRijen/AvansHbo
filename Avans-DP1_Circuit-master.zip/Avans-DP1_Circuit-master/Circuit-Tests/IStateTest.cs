﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Refactor_DP1_Circuit;
using Refactor_DP1_Circuit.Interface;
using Refactor_DP1_Circuit.State;

namespace Circuit_Tests
{
    [TestClass]
    public class IStateTest
    {
        private static NodeComponent NodeComponentOne(INode node)
        {
            var leaf = new Leaf {AmountOfInputs = 2, Node = node};
            var l1 = new Leaf();
            var l2 = new Leaf();
            l1.OutputValue = 0;
            l2.OutputValue = 0;
            leaf.AddInputValue(l1);
            leaf.AddInputValue(l2);
            return leaf;
        }

        [TestMethod]
        [ExpectedException(typeof(System.ArgumentNullException))]
        public void GateOpenTest()
        {
            var leaf = new Leaf {State = new GateOpen()};
            leaf.State.Handle(leaf, null);
        }

        [TestMethod]
        [ExpectedException(typeof(System.NullReferenceException))]
        public void GateClosedTest()
        {
            var leaf = new Leaf {State = new GateClosed()};
            leaf.State.Handle(leaf, null);
        }
    }
}