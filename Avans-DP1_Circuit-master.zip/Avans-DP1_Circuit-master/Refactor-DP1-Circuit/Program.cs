﻿namespace Refactor_DP1_Circuit
{
    internal static class Program
    {
        private static void Main(string[] args)
        {
            var mainViewModel = new Circuit();
            mainViewModel.StartCircuit();
        }
    }
}