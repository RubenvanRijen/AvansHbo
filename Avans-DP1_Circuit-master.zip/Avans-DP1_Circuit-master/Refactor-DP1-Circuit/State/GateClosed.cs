﻿using Refactor_DP1_Circuit.Interface;

namespace Refactor_DP1_Circuit.State
{
    public class GateClosed : IState
    {
        public void Handle(NodeComponent nodeComponent, NodeComponent component)
        {
            nodeComponent.InputValues.Add(component, component.OutputValue);
            if (nodeComponent.InputValues.Count < nodeComponent.AmountOfInputs) return;
            nodeComponent.SetNodeValues();
            nodeComponent.State = new GateOpen();
        }
    }
}