﻿using Refactor_DP1_Circuit.Interface;

namespace Refactor_DP1_Circuit.Builder
{
    public class Director
    {
        private readonly INodeBuilder _nodeBuilder;

        public Director(INodeBuilder nodeBuilder)
        {
            this._nodeBuilder = nodeBuilder;
        }

        public NodeComponent GetComponent()
        {
            return _nodeBuilder.GetComponent();
        }

        public void ConstructComponent(INode node, string identifier, int output, int inputs, string inputType)
        {
            _nodeBuilder.BuildSetNodesValues(node)
                .BuildName(identifier)
                .BuildOutputValue(output)
                .BuildAmountOfInputs(inputs)
                .BuildInputType(inputType);
        }
    }
}
