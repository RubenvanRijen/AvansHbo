﻿using Refactor_DP1_Circuit.Interface;

namespace Refactor_DP1_Circuit.Builder
{
    public class LeafBuilder : INodeBuilder
    {
        private readonly Leaf _leaf = new Leaf();

        public INodeBuilder BuildSetNodesValues(INode node)
        {
            _leaf.Node = node;
            return this;
        }

        public INodeBuilder BuildName(string identifier)
        {
            _leaf.Name = identifier;
            return this;
        }

        public INodeBuilder BuildOutputValue(int outputValue)
        {
            _leaf.OutputValue = outputValue;
            return this;
        }

        public INodeBuilder BuildAmountOfInputs(int amountOfInputs)
        {
            _leaf.AmountOfInputs = amountOfInputs;
            return this;
        }

        public INodeBuilder BuildInputType(string inputType)
        {
            _leaf.InputType = inputType;
            return this;
        }

        public NodeComponent GetComponent()
        {
            return _leaf;
        }
    }
}