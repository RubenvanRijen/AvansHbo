﻿using Refactor_DP1_Circuit.Interface;

namespace Refactor_DP1_Circuit.Builder
{
    public class CompositeBuilder : INodeBuilder
    {
        private readonly Composite _compositeNode = new Composite();

        public INodeBuilder BuildSetNodesValues(INode node)
        {
            _compositeNode.Node = node;
            return this;
        }

        public INodeBuilder BuildName(string identifier)
        {
            _compositeNode.Name = identifier;
            return this;
        }

        public INodeBuilder BuildOutputValue(int outputValue)
        {
            _compositeNode.OutputValue = outputValue;
            return this;
        }

        public INodeBuilder BuildAmountOfInputs(int amountOfInputs)
        {
            _compositeNode.AmountOfInputs = amountOfInputs;
            return this;
        }

        public INodeBuilder BuildInputType(string inputType)
        {
            _compositeNode.InputType = inputType;
            return this;
        }

        public NodeComponent GetComponent()
        {
            return _compositeNode;
        }
    }
}