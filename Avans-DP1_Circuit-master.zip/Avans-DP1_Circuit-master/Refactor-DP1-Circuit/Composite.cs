﻿using System.Collections.Generic;

namespace Refactor_DP1_Circuit
{
    public class Composite : NodeComponent
    {
        private List<NodeComponent> _children = new List<NodeComponent>();

        public List<NodeComponent> Children
        {
            get => _children;
            set => _children = value;
        }

        public override void Accept(Interface.IVisitor visitor)
        {
            visitor.Visit(this);
        }

        public override NodeComponent Clone()
        {
            return new Composite()
            {
                Node = this.Node, Name = this.Name, OutputValue = this.OutputValue,
                AmountOfInputs = this.AmountOfInputs, InputType =  this.InputType
            };
        }

        public override void Operation()
        {
            foreach (var child in Children)
            {
                child.AddInputValue(this);
            }
        }
    }
}