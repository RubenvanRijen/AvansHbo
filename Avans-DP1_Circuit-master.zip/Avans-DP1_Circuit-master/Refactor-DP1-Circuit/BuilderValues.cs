﻿using Refactor_DP1_Circuit.Interface;

namespace Refactor_DP1_Circuit
{
    public struct BuilderValues
    {
        public INode node;
        public int output;
        public INodeBuilder builder;
        public int amountOfInputs;
        public string inputType;
    }
}