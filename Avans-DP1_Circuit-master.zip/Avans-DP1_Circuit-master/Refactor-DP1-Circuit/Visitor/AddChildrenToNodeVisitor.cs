﻿using System;
using Refactor_DP1_Circuit.Interface;

namespace Refactor_DP1_Circuit.Visitor
{
    public class AddChildrenToNodeVisitor : IVisitor
    {
        private readonly NodeComponent _nodeComponent;

        public AddChildrenToNodeVisitor(NodeComponent nodeComponent)
        {
            this._nodeComponent = nodeComponent;
        }

        public override void Visit(Leaf leaf)
        {
            throw new NotSupportedException();
        }

        public override void Visit(Composite composite)
        {
            composite.Children.Add(_nodeComponent);
        }
    }
}