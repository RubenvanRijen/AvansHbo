﻿using Refactor_DP1_Circuit.Interface;

namespace Refactor_DP1_Circuit.Nodes
{
    public class InputNode : INode
    {
        public void SetNode(NodeComponent nodeComponent)
        {
      
        }
    }
}
