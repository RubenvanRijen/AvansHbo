﻿
using System.Linq;

using Refactor_DP1_Circuit.Interface;

namespace Refactor_DP1_Circuit.Nodes
{
    public class OrNode : INode
    {

    
        public void SetNode(NodeComponent nodeComponent)
        {
            nodeComponent.OutputValue = 0;
            if (nodeComponent.InputValues.Values.First() == 1 || nodeComponent.InputValues.Values.Last() == 1)
            {
                nodeComponent.OutputValue = 1;
            } 
            nodeComponent.TimesPassed++;
        }
    }
}
