﻿using Refactor_DP1_Circuit.Interface;

namespace Refactor_DP1_Circuit.Nodes
{
    public class StartNode : INode
    {
        public void SetNode(NodeComponent nodeComponent)
        {
      
        }
    }
}
