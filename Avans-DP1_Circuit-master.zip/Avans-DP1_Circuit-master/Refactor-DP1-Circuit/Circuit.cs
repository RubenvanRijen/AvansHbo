﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Refactor_DP1_Circuit
{
    public class Circuit
    {
        private FileConverter _fileConverter;
        private List<NodeComponent> _nodeComponents;
        private CircuitPrinter _circuitPrinter;
        private bool _validCircuit = false;
        private bool _canRun = true;
        private int _chosenCircuit = -1;
        private int _checkedCircuit = 0;
        private bool _infinity = false;

        private static readonly string[] Files =
        {
            "Circuit1_FullAdder.txt", "Circuit2_Decoder.txt", "Circuit3_Encoder.txt", "Circuit4_InfiniteLoop.txt",
            "Circuit5_NotConnected.txt"
        };


        public void StartCircuit()
        {
            _circuitPrinter = new CircuitPrinter();
            _fileConverter = new FileConverter();

            while (_canRun)
            {
                while (_validCircuit == false)
                {
                    _checkedCircuit = 0;
                    SetChosenCircuit();
                    _nodeComponents = _fileConverter.ConvertFile(Files[_chosenCircuit]);
                    Console.Clear();
                    SetNodesValues(_nodeComponents);
                    IsCircuitInfinityLoop();
                    if (!_infinity) _validCircuit = IsCircuitValid();
                    else
                    {
                        Console.WriteLine("Infinity loop found");
                        _validCircuit = false;
                        _infinity = false;
                    }
                }

                while (_validCircuit)
                {
                    if (_checkedCircuit != 0)
                    {
                        SetNodesValues(_nodeComponents);
                    }

                    _checkedCircuit++;
                    Console.Clear();
                    _circuitPrinter.SetTimePassed(_nodeComponents);
                    _circuitPrinter.PrintCircuit(_nodeComponents);
                    UserCommands();
                }
            }
        }

        private void SetChosenCircuit()
        {
            _chosenCircuit = -1;
            Console.WriteLine("Select Circuit Number 1 through 5");
            while (_chosenCircuit == -1)
            {
                switch (Console.ReadLine())
                {
                    case "1":
                        _chosenCircuit = 0;
                        break;
                    case "2":
                        _chosenCircuit = 1;
                        break;
                    case "3":
                        _chosenCircuit = 2;
                        break;
                    case "4":
                        _chosenCircuit = 3;
                        break;
                    case "5":
                        _chosenCircuit = 4;
                        break;
                    default:
                        Console.WriteLine("Wrong entry, try again (1-5)");
                        break;
                }
            }
        }

        private bool IsCircuitValid()
        {
            var valid = true;
            foreach (var nodeComponent in _nodeComponents
                .Where(nodeComponent => nodeComponent.AmountOfInputs == 1 || nodeComponent.AmountOfInputs > 1)
                .Where(nodeComponent => nodeComponent.InputValues.Count == 0))
            {
                valid = false;
                Console.WriteLine("Nodes not connected");
                break;
            }

            return valid;
        }

        private void IsCircuitInfinityLoop()
        {
            foreach (var nodeComponent in _nodeComponents)
            {
                var nodesList = new List<NodeComponent> {nodeComponent};
                CheckInfinity(nodeComponent, nodesList);
            }
        }

        private void CheckInfinity(NodeComponent nodeComponent, ICollection<NodeComponent> nodeList)
        {
            if (!(nodeComponent is Composite composite)) return;
            foreach (var childNode in composite.Children)
            {
                if (nodeList.Contains(childNode))
                {
                    this._infinity = true;
                    break;
                }

                var newNodesList = nodeList.ToList();
                newNodesList.Add(childNode);
                CheckInfinity(childNode, newNodesList);
            }
        }

        public void SetNodesValues(IEnumerable<NodeComponent> nodeComponents)
        {
            var start = nodeComponents.First(item => item.Name == "Start");
            start.SetNodeValues();
        }

        private void ResetCircuit()
        {
            var inputs = _nodeComponents.Where(c => c.IsInput()).ToArray();
            foreach (var nodeComponent in inputs)
            {
                nodeComponent.OutputValue = nodeComponent.InputType == "INPUT_HIGH" ? 1 : 0;
            }

            SetNodesValues(_nodeComponents);
        }

        private void UserCommands()
        {
            while (true)
            {
                var inputs = _nodeComponents.Where(c => c.IsInput()).ToArray();
                var key = Console.ReadLine();
                if (!int.TryParse(key, out var i))
                {
                    i = -1;
                }

                if (i >= 1 && i <= inputs.Length)
                {
                    i--;
                    inputs[i].OutputValue = (1 - inputs[i].OutputValue);
                }
                else
                {
                    switch (key)
                    {
                        case "reset":
                            ResetCircuit();
                            break;
                        case "change":
                            _infinity = false;
                            _validCircuit = false;
                            Console.Clear();
                            break;
                        case "stop":
                            Console.WriteLine("See you next time");
                            _canRun = false;
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Wrong entry, try again.");
                            continue;
                    }
                }

                break;
            }
        }
    }
}