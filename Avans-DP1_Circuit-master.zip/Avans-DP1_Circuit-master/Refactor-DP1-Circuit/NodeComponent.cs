﻿using Refactor_DP1_Circuit.State;
using System.Collections.Generic;
using Refactor_DP1_Circuit.Interface;
using Refactor_DP1_Circuit.Nodes;

namespace Refactor_DP1_Circuit
{
    public abstract class NodeComponent
    {
        public int AmountOfInputs { get; set; }
        private IState _state;
        private Dictionary<NodeComponent, int> _inputValues;
        private INode _node;
        private string _name;
        private int _outputValue;
        private int _timesPassed;
        private string _inputType;

        protected NodeComponent()
        {
            _inputValues = new Dictionary<NodeComponent, int>();
            _state = new GateClosed();
            TimesPassed = 0;
        }

        public bool IsInput()
        {
            return _node is InputNode;
        }

        public bool IsProbe()
        {
            return _node is ProbeNode;
        }

        public bool IsStart()
        {
            return _node is StartNode;
        }

        public abstract void Operation();

        public void AddInputValue(NodeComponent nodeComponent)
        {
            this._state.Handle(this, nodeComponent);
        }

        public void SetNodeValues()
        {
            _node.SetNode(this);
            Operation();
        }

        public abstract NodeComponent Clone();

        public abstract void Accept(IVisitor visitor);

        public IState State
        {
            get => _state;
            set => _state = value;
        }

        public Dictionary<NodeComponent, int> InputValues
        {
            get => _inputValues;
            set => _inputValues = value;
        }

        public INode Node
        {
            get => _node;
            set => _node = value;
        }

        public string Name
        {
            get => _name;
            set => _name = value;
        }

        public int OutputValue
        {
            get => _outputValue;
            set => _outputValue = value;
        }

        public int TimesPassed
        {
            get => _timesPassed;
            set => _timesPassed = value;
        }

        public string InputType
        {
            get => _inputType;
            set => _inputType = value;
        }
    }
}