﻿
namespace Refactor_DP1_Circuit.Interface
{
    public interface IState
    {
        void Handle(NodeComponent nodeComponent, NodeComponent component);
    }
}