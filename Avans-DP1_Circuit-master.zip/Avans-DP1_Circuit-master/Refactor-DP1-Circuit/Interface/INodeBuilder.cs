﻿namespace Refactor_DP1_Circuit.Interface
{
    public interface INodeBuilder
    {
        INodeBuilder BuildSetNodesValues(INode node);
        INodeBuilder BuildName(string name);
        INodeBuilder BuildOutputValue(int outputValue);
        INodeBuilder BuildAmountOfInputs(int amountOfInputs);

        INodeBuilder BuildInputType(string inputType);
        NodeComponent GetComponent();
    }
}