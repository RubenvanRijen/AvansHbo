﻿namespace Refactor_DP1_Circuit.Interface
{
    public interface INode
    {
        void SetNode(NodeComponent nodeComponent);
    }
}