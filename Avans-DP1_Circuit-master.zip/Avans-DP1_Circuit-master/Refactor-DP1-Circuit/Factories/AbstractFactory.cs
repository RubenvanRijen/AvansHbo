﻿using System.Collections.Generic;
using Refactor_DP1_Circuit.Builder;

namespace Refactor_DP1_Circuit.Factories
{
    public abstract class AbstractFactory
    {
        public Dictionary<string, BuilderValues> Nodes { get; }

        protected AbstractFactory()
        {
            Nodes = new Dictionary<string, BuilderValues>();
        }


        public abstract void CreateNodes();

        protected void RegisterComponent(string name, BuilderValues data)
        {
            Nodes[name] = data;
        }

        public NodeComponent CreateComponent(string key, string type)
        {
            var director = new Director(Nodes[type].builder);
            director.ConstructComponent(Nodes[type].node, key, Nodes[type].output, Nodes[type].amountOfInputs,
                Nodes[type].inputType);
            return director.GetComponent().Clone();
        }
    }
}