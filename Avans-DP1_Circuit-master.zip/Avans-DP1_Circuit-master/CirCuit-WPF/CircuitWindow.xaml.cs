﻿using Refactor_DP1_Circuit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;


namespace CirCuit_WPF
{
    /// <summary>
    /// Interaction logic for CircuitWindow.xaml
    /// </summary>
    public partial class CircuitWindow : Window
    {
        private List<NodeComponent> _nodeComponents;
        private Canvas _canvas;
        private TextBlock _textBlock;

        public CircuitWindow(List<NodeComponent> nodeComponents)
        {
            InitializeComponent();
            _nodeComponents = nodeComponents;
            SetCircuit();
        }

        private void InitializeCircuit()
        {
            var inputNodes = _nodeComponents.Where(c => c.IsInput()).ToArray();
            var probeNodes = _nodeComponents.Where(c => c.IsProbe()).ToArray();
            var normalNodes = _nodeComponents.Where(c => !c.IsProbe() && !c.IsInput() && !c.IsStart()).ToArray();
            DrawNodes(inputNodes, 15.0, "Input");
            DrawNodes(normalNodes, 95.0, "Normal");
            DrawNodes(probeNodes, 415, "Probe");
        }

        public void InitializeInfoTextBlock()
        {
            _textBlock.Text += "Input Nodes \n";
            _textBlock.SetValue(Canvas.LeftProperty, 500.0);
            _textBlock.SetValue(Canvas.TopProperty, 30.0);
            _textBlock.TextAlignment = TextAlignment.Center;
            _textBlock.Background = new SolidColorBrush {Color = Colors.Black};
            _textBlock.Foreground = new SolidColorBrush() {Color = Colors.White};
            _canvas.Children.Add(_textBlock);
        }

        private void DrawNodes(IReadOnlyList<NodeComponent> nodeComponents, double xPos, string typeNode)
        {
            var yIndex = 0;
            const double xIndex = 95.0;
            var topIndex = 0;
            for (var i = 0; i < nodeComponents.Count(); i++)
            {
                var button = CreateButton(nodeComponents[i]);
                switch (typeNode)
                {
                    case "Normal":
                        button.SetValue(Canvas.LeftProperty, xIndex + (80 * yIndex));
                        button.SetValue(Canvas.TopProperty, 80.0 + (100.0 * topIndex));
                        yIndex++;
                        if (yIndex >= 4)
                        {
                            yIndex = 0;
                            topIndex++;
                        }

                        break;
                    default:
                        button.SetValue(Canvas.LeftProperty, xPos);
                        button.SetValue(Canvas.TopProperty, 80.0 + (100.0 * i));
                        break;
                }

                button.Name = nodeComponents[i].Name;
                if (nodeComponents[i].IsInput())
                {
                    button.Click += ChangeInputValues;
                }

                _canvas.Children.Add(button);
                AddNodeInfoToBlock(nodeComponents[i]);
            }
        }

        private void CreateResetButton()
        {
            var button = new Button {Content = "Reset"};
            button.Click += ResetCircuit;
            button.SetValue(Canvas.LeftProperty, 100.0);
            button.SetValue(Canvas.TopProperty, 40.0);
            button.Background = new SolidColorBrush() {Color = Colors.DimGray};
            button.FontSize = 15;
            button.Foreground = new SolidColorBrush() {Color = Colors.White};
            button.Width = 300;
            button.Height = 30;
            _canvas.Children.Add(button);
        }

        public void ResetCircuit()
        {
            var inputs = _nodeComponents.Where(c => c.IsInput()).ToArray();
            foreach (var nodeComponent in inputs)
            {
                nodeComponent.OutputValue = nodeComponent.InputType == "INPUT_HIGH" ? 1 : 0;
            }

            SetNodesValues();
        }


        private static Button CreateButton(NodeComponent nodeComponent)
        {
            var button = new Button();
            var mySolidColorBrush = new SolidColorBrush
            {
                Color = nodeComponent.OutputValue == 1 ? Colors.Chartreuse : Colors.Crimson,
            };
            button.Background = mySolidColorBrush;
            button.FontSize = 10;
            button.Content = nodeComponent.Name + "\n" + nodeComponent.Node.GetType().Name.ToUpper() + "\n";
            button.Width = 70;
            button.Height = 70;
            return button;
        }


        private void AddNodeInfoToBlock(NodeComponent nodeComponent)
        {
            if (nodeComponent.IsStart()) return;
            _textBlock.Text += nodeComponent.Name + ": ";
            var last = nodeComponent.InputValues.Last();

            foreach (var (key, _) in nodeComponent.InputValues)
            {
                _textBlock.Text += key.Name.ToUpper();
                if (key != last.Key)
                {
                    _textBlock.Text += " - ";
                }
            }

            _textBlock.Text += "\n";
        }


        private void ChangeInputValues(object sender, EventArgs e)
        {
            var button = (Button) sender;
            var inputNode = _nodeComponents.First(item => item.Name == button.Name);
            inputNode.OutputValue = (1 - inputNode.OutputValue);
            SetCircuit();
        }

        private void SetNodesValues()
        {
            var start = _nodeComponents.First(item => item.Name == "Start");
            start.SetNodeValues();
        }

        private void SetCircuit()
        {
            SetNodesValues();
            _textBlock = new TextBlock();
            _canvas = new Canvas();
            CreateResetButton();
            InitializeCircuit();
            InitializeInfoTextBlock();
            Content = _canvas;
        }

        private void ResetCircuit(object sender, EventArgs e)
        {
            ResetCircuit();
            SetCircuit();
        }

        public List<NodeComponent> NodeComponents
        {
            get => _nodeComponents;
            set => _nodeComponents = value;
        }

        public TextBlock TextBlock
        {
            get => _textBlock;
            set => _textBlock = value;
        }
    }
}