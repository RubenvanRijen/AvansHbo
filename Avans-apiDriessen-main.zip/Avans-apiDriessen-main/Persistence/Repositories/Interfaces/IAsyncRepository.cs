﻿using Domain.Models.QueryStringParameters;
using Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Persistence.Repositories.Interfaces
{
    public interface IAsyncRepository<T> where T : BaseEntity
    {
        Task<T> Create(T entity);
        Task<PagedList<T>> GetAll(QueryStringParameters<T> queryStringParameters);
        Task<T> GetById(Guid id);
        Task<T> Update(T entity);

        Task<bool> Delete(Guid id);

        // Extra
        Task<T> FirstOrDefault(Expression<Func<T, bool>> predicate);
        Task<List<T>> GetWhere(Expression<Func<T, bool>> predicate);
        Task<int> CountAll();
        Task<int> CountWhere(Expression<Func<T, bool>> predicate);
        Task<PagedList<T>> GetAllWhere(QueryStringParameters<T> queryStringParameters, Expression<Func<T, bool>> predicate);
    }
}