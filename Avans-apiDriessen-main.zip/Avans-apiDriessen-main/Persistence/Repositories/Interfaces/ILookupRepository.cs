﻿using Domain.Models.QueryStringParameters;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Persistence.Repositories.Interfaces
{
    public interface ILookupRepository<T> where T : class
    {
        Task<T> Create(T entity);
        Task<List<T>> GetAll();

        /// <remarks>
        /// Because the primary is the key that will be updated,
        /// It should replaceh the old entry 
        /// </remarks>
        /// <summary>
        /// Instead of the update. Read remarks for more info.
        /// </summary>
        /// <param name="entityOld"></param>
        /// <param name="entityNew"></param>
        /// <returns></returns>
        Task<T> Replace(T entityOld, T entityNew);

        Task<bool> Delete(T entity);

        // Extra
        Task<T> FirstOrDefault(Expression<Func<T, bool>> predicate);
        Task<List<T>> GetWhere(Expression<Func<T, bool>> predicate);
        Task<int> CountAll();
        Task<int> CountWhere(Expression<Func<T, bool>> predicate);
    }
}