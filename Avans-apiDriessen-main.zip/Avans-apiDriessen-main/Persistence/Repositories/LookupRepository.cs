﻿using Domain.Models.QueryStringParameters;
using Microsoft.EntityFrameworkCore;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Persistence.Repositories
{
    public class LookupRepository<T> : ILookupRepository<T> where T : class
    {
        #region Fields

        protected DataContext Context;

        #endregion

        public LookupRepository(DataContext context)
        {
            Context = context;
        }

        #region Public Methods

        public async Task<T> Create(T entity)
        {
            await Context.Set<T>().AddAsync(entity);
            await Context.SaveChangesAsync();
            return entity;
        }

        public async Task<List<T>> GetAll()
        {
            return await Context.Set<T>().ToListAsync();
        }

        public async Task<T> Replace(T entityOld, T entityNew)
        {
            var isDeleted = await Delete(entityOld);
            if (!isDeleted)
                return entityOld;
            await Create(entityNew);
            return entityNew;
        }

        public async Task<bool> Delete(T entity)
        {
            bool ItemExists = GetAll().Result.Contains(entity);
            if (!ItemExists)
            {
                return false;
            }

            Context.Set<T>().Remove(entity);
            await Context.SaveChangesAsync();
            return true;
        }

        // Extra
        public Task<T> FirstOrDefault(Expression<Func<T, bool>> predicate)
            => Context.Set<T>().FirstOrDefaultAsync(predicate);

        public async Task<List<T>> GetWhere(Expression<Func<T, bool>> predicate)
        {
            return await Context.Set<T>().Where(predicate).ToListAsync();
        }

        public Task<int> CountAll() => Context.Set<T>().CountAsync();

        public Task<int> CountWhere(Expression<Func<T, bool>> predicate)
            => Context.Set<T>().CountAsync(predicate);

        #endregion
    }
}