﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Domain.Models.Base;
using Domain.Models.QueryStringParameters;
using Microsoft.EntityFrameworkCore;
using Persistence.Repositories.Interfaces;

namespace Persistence.Repositories
{
    public class AsyncRepository<T> : IAsyncRepository<T> where T : BaseEntity
    {
        #region Fields

        protected DataContext Context;

        #endregion

        public AsyncRepository(DataContext context)
        {
            Context = context;
        }

        #region Public Methods

        public async Task<T> Create(T entity)
        {
            entity.Id = Guid.NewGuid();
            await Context.Set<T>().AddAsync(entity);
            await Context.SaveChangesAsync();
            return entity;
        }

        public async Task<PagedList<T>> GetAll(QueryStringParameters<T> queryStringParameters)
        {
            var entitiesList = Context.Set<T>().Where(queryStringParameters.Filter).ToList();
            var entitiesQueryable = entitiesList.AsQueryable();

            return PagedList<T>.ToPagedList(entitiesQueryable,
                queryStringParameters.PageNumber,
                queryStringParameters.PageSize);
        }

        public Task<T> GetById(Guid id) => Context.Set<T>().SingleOrDefaultAsync(i => i.Id == id);

        public async Task<T> Update(T entity)
        {
            // In case AsNoTracking is used
            Context.Entry(entity).State = EntityState.Modified;
            await Context.SaveChangesAsync();
            return entity;
        }

        public async Task<bool> Delete(Guid id)
        {
            T entity = await GetById(id);
            if (entity == null)
            {
                return false;
            }

            Context.Set<T>().Remove(entity);
            await Context.SaveChangesAsync();
            return true;
        }

        // Extra
        public Task<T> FirstOrDefault(Expression<Func<T, bool>> predicate)
            => Context.Set<T>().FirstOrDefaultAsync(predicate);

        public async Task<List<T>> GetWhere(Expression<Func<T, bool>> predicate)
        {
            return await Context.Set<T>().Where(predicate).ToListAsync();
        }

        public Task<int> CountAll() => Context.Set<T>().CountAsync();

        public Task<int> CountWhere(Expression<Func<T, bool>> predicate)
            => Context.Set<T>().CountAsync(predicate);

        public async Task<bool> ExistsWithId(Guid id)
        {
            var count = await CountWhere(t => t.Id == id);
            return count != 0;
        }

        public async Task<PagedList<T>> GetAllWhere(QueryStringParameters<T> queryStringParameters, Expression<Func<T, bool>> predicate)
        {
            var entitiesList = Context.Set<T>().Where(predicate).ToList();
            var entities = entitiesList.Where(queryStringParameters.Filter).ToList();
            var entitiesQueryable = entities.AsQueryable();

            return PagedList<T>.ToPagedList(entitiesQueryable,
                queryStringParameters.PageNumber,
                queryStringParameters.PageSize);
        }

        #endregion
    }
}