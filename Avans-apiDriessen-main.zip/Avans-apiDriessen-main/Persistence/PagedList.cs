﻿using Domain.AuxiliaryModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace Persistence
{
    public class PagedList<T> : List<T>
    {
        public PaginationMetaData PaginationMetaData { get; private set; }

        public PagedList(List<T> items, int count, int pageNumber, int pageSize)
        {
            PaginationMetaData = new PaginationMetaData();
            PaginationMetaData.TotalCount = count;
            PaginationMetaData.CurrentPage = pageNumber;
            PaginationMetaData.PageSize = pageSize;
            PaginationMetaData.TotalPages = (int) Math.Ceiling(count / (double) pageSize);

            AddRange(items);
        }

        public static PagedList<T> ToPagedList(IQueryable<T> source, int pageNumber, int pageSize)
        {
            var count = source.Count();
            var items = source.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();

            return new PagedList<T>(items, count, pageNumber, pageSize);
        }

        public static PagedList<T> ToPagedListWhere(IQueryable<T> source, int pageNumber, int pageSize,
            Expression<Func<T, bool>> predicate)
        {
            var count = source.Count();
            var items = source.Where(predicate).Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();

            return new PagedList<T>(items, count, pageNumber, pageSize);
        }
    }
}