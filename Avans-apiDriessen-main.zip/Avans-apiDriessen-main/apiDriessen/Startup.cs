using Application;
using Application.AuxiliaryLogics;
using Application.AuxiliaryLogics.Interfaces;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;
using Domain.AuxiliaryModels;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Persistence;
using Persistence.Repositories;
using Persistence.Repositories.Interfaces;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using EmailService;
using EmailService.Config;
using EmailService.Interfaces;
using System.Reflection;
using System.IO;
using System;


namespace apiDriessen
{
    public class Startup
    {
        public Startup(IConfiguration configuration, IWebHostEnvironment env)
        {
            Configuration = configuration;
            WebHostEnvironment = env;
        }

        public IWebHostEnvironment WebHostEnvironment { get; private set; }
        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAuthentication(x =>
                {
                    x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                    x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddJwtBearer(x =>
                {
                    x.RequireHttpsMetadata = false;
                    x.SaveToken = true;
                    x.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(Configuration["Jwt:Key"])),
                        ValidateIssuer = false,
                        ValidateAudience = false,
                    };
                });
            services.AddControllers();
            services.AddScoped<IWorkHourLogic, WorkHourLogic>();

            services.Configure<MapboxSetting>(Configuration.GetSection("MapboxAPI"));
            services.Configure<JwtSettings>(Configuration.GetSection("Jwt"));
            services.Configure<EmailConfiguration>(Configuration.GetSection("EmailConfiguration"));

            services.AddScoped<IMapboxLogic, MapboxLogic>();
            services.AddScoped<IValidationLogic, ValidationLogic>();
            services.AddScoped<IEmailSender, EmailSender>();
            services.AddScoped<IEmailLogic, EmailLogic>();

            services.AddScoped<IRouteLogic, RouteLogic>();
            services.AddScoped<IUserLogic, UserLogic>();
            services.AddScoped<IKilometerAllowanceLogic, KilometerAllowanceLogic>();
            services.AddScoped<IAuthenticationLogic, AuthenticationLogic>();
            services.AddScoped<IHolidayLogic, HolidayLogic>();
            services.AddScoped<ICompanyHolidayLogic, CompanyHolidayLogic>();
            services.AddScoped<ICompanyLogic, CompanyLogic>();
            services.AddScoped<IPlacementLogic, PlacementLogic>();
            services.AddScoped<IUserPlacementLogic, UserPlacementLogic>();
            services.AddScoped<IExpectedDeclarationLogic, ExpectedDeclarationLogic>();

            services.AddScoped(typeof(IAsyncRepository<>), typeof(AsyncRepository<>));
            services.AddScoped(typeof(ILookupRepository<>), typeof(LookupRepository<>));

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "API Driessen Reiskosten tracker",
                    Version = "v1"
                });
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    In = ParameterLocation.Header,
                    Description = "Please insert JWT with Bearer into field",
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        new string[] { }
                    }
                });
                //Set the comments path for the Swagger JSON and UI.
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);
            });
            services.AddDbContextPool<DataContext>(
                options => options.UseMySql(Configuration.GetConnectionString("MySqlConnection")));
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "API Driessen Reiskosten tracker V1");
                c.RoutePrefix = string.Empty;
            });

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseAuthentication();
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

        }
    }
}