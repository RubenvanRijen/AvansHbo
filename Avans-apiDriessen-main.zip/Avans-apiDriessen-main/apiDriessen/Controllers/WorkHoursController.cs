﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Application;
using Application.AuxiliaryLogics;
using Application.AuxiliaryLogics.Interfaces;
using Domain;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace apiDriessen.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class WorkHoursController : ControllerBase
    {
        private readonly IWorkHourLogic workHourLogic;
        private readonly IValidationLogic validationLogic;

        public WorkHoursController(IWorkHourLogic workHourLogic, IValidationLogic validationLogic)
        {
            this.workHourLogic = workHourLogic ?? throw new ArgumentNullException(nameof(workHourLogic));
            this.validationLogic = validationLogic ?? throw new ArgumentNullException(nameof(validationLogic));
        }

        /// <summary>
        /// This end point will return the workhours.
        /// </summary>
        /// <returns>A JSON with a workhours</returns>
        /// <response code="200"> Returns workhours</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If there are no workhours found this error will be returned</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpGet]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<WorkHour>>> Get([FromQuery] WorkHourParameters workHourParameters)
        {
            if (!workHourParameters.ValidDateRange)
            {
                return BadRequest("Einddatum kan niet eerder zijn dan startdatum");
            }

            var workHours = await workHourLogic.GetWorkHours(workHourParameters);

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(workHours.PaginationMetaData));

            return Ok(workHours);
        }

        /// <summary>
        /// This end point will return all the workhours of the user.
        /// </summary>
        /// <returns>A JSON with a list of workhours</returns>
        /// <response code="200"> Returns all the workhours</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there are no workhours found this error will be returned</response>  
        [HttpGet("User/{userId}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<WorkHour>>> GetByUserId(Guid userId, [FromQuery] WorkHourParameters workHourParameters)
        {
            if (!workHourParameters.ValidDateRange)
            {
                return BadRequest("Einddatum kan niet eerder zijn dan startdatum");
            }

            var workHours = await workHourLogic.FindWorkHourByUserId(userId, workHourParameters);

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(workHours.PaginationMetaData));

            if (workHours.Count == 0)
            {
                return NotFound();
            }

            return Ok(workHours);
        }

        /// <summary>
        /// This end point will return the workhour based the given id.
        /// </summary>
        /// <returns>A JSON with a workhour</returns>
        /// <response code="200"> Returns a workhour</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there is no workhour found this error will be returned</response>  
        [HttpGet("{id}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<WorkHour>> Get(Guid id)
        {
            var workHour = await workHourLogic.FindWorkHourById(id);

            if (workHour == null)
            {
                return NotFound();
            }

            return Ok(workHour);
        }

        /// <summary>
        /// This end point will create a workhour.
        /// </summary>
        /// <returns>A JSON with a workhour</returns>
        /// <response code="201"> Returns a workhour, when the workhour is succesfully created</response>
        /// <response code="400"> If the workhour has incorrect data</response>  
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        public async Task<ActionResult<WorkHour>> Create([FromBody] WorkHour newWorkHour)
        {
            if (await validationLogic.WorkHourOverlaps(newWorkHour))
            {
                return BadRequest("Werkuren mogen niet overlappen");
            }
            
            var createdWorkHour = await workHourLogic.CreateWorkHour(newWorkHour);
            if (createdWorkHour == null)
            {
                return NotFound();
            }

            return Created($"{Request.Path}/{createdWorkHour.Id}", createdWorkHour);
        }

        /// <summary>
        /// This end point will update a workhour.
        /// </summary>
        /// <returns>A JSON with a workhour</returns>
        /// <response code="200"> Returns if the workhour is succesfully updated</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If updating the workhour failed</response>  
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<WorkHour>> Update(Guid id, [FromBody] WorkHour newWorkHour)
        {
            if (await validationLogic.WorkHourOverlaps(newWorkHour, id))
            {
                return BadRequest("Werkuren mogen niet overlappen");
            }
            
            var editedWorkHour = await workHourLogic.UpdateWorkHour(id, newWorkHour);
            if (editedWorkHour == null)
            {
                return NotFound();
            }

            return Ok(editedWorkHour);
        }

        /// <summary>
        /// This end point will delete a workhour.
        /// </summary>
        /// <returns>A JSON with a workhour</returns>
        /// <response code="204"> Returns if the workhour is succesfully deleted</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If deleting the workhour failed</response> 
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Delete(Guid id)
        {
            var deleted = await workHourLogic.DeleteWorkHour(id);

            if (deleted)
            {
                return NoContent();
            }

            return NotFound();
        }
    }
}