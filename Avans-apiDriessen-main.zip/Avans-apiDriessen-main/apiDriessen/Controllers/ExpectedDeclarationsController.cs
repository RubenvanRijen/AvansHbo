﻿using System;
using System.Threading.Tasks;
using Application.AuxiliaryLogics.Interfaces;
using Application.Interfaces;
using Domain.AuxiliaryModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace apiDriessen.Controllers
{
    [ApiController]
    [Route("/api/[controller]")]
    [Authorize]
    public class ExpectedDeclarationsController : ControllerBase
    {
        private readonly IExpectedDeclarationLogic expectedDeclarationLogic;
        private readonly IValidationLogic validationLogic;

        public ExpectedDeclarationsController(IExpectedDeclarationLogic expectedDeclarationLogic, IValidationLogic validationLogic)
        {
            this.expectedDeclarationLogic =  expectedDeclarationLogic ?? throw new ArgumentNullException(nameof(expectedDeclarationLogic));
            this.validationLogic = validationLogic ?? throw new ArgumentNullException(nameof(validationLogic));
        }

        /// <summary>
        /// This end point will return the expected declaration of the current month for the user.
        /// </summary>
        /// <remarks>
        /// This calculation is based on the previous three months
        /// </remarks>
        /// <returns>A JSON with the expected declaration</returns>
        /// <response code="200"> Returns an expected declaration</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there is no expected declaration this error will be returned</response>  
        [HttpGet("{userId}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<ExpectedDeclaration>> ExpectedDeclarationForUser(Guid userId)
        {
            if (await validationLogic.UserDoesNotExist(userId))
            {
                return NotFound();
            }

            var expectedDeclaration = await expectedDeclarationLogic.CalculateExpectedDeclarationForUser(userId);
            return Ok(expectedDeclaration);
        }
    }
}