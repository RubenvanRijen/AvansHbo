﻿using Application.Interfaces;
using Domain.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace apiDriessen.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class HolidaysController : ControllerBase
    {
        private readonly IHolidayLogic holidayLogic;
        private readonly ICompanyHolidayLogic companyHolidayLogic;

        public HolidaysController(IHolidayLogic holidayLogic, ICompanyHolidayLogic companyHolidayLogic)
        {
            this.holidayLogic = holidayLogic ?? throw new ArgumentNullException(nameof(holidayLogic));
            this.companyHolidayLogic =
                companyHolidayLogic ?? throw new ArgumentNullException(nameof(companyHolidayLogic));
        }

        #region User holiday

        /// <summary>
        /// This end point will create a holiday.
        /// </summary>
        /// <returns>A JSON with a holiday</returns>
        /// <response code="201"> Returns a holiday, when the holiday is succesfully created</response>
        /// <response code="400"> If the holiday has incorrect data</response>  
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        public async Task<ActionResult<Holiday>> Create([FromBody] Holiday holiday)
        {
            holiday = await holidayLogic.CreateHoliday(holiday);
            if (holiday == null)
            {
                return ValidationProblem("User id not found");
            }
            return Created($"{Request.Path}/{holiday.Id}", holiday);
        }

        /// <summary>
        /// This end point will return the holiday based the given id.
        /// </summary>
        /// <returns>A JSON with a holiday</returns>
        /// <response code="200"> Returns a holiday</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there is no holiday found this error will be returned</response>  
        [HttpGet("{id}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Holiday>> Get(Guid id)
        {
            var holiday = await holidayLogic.FindHolidayById(id);
            if (holiday == null)
            {
                return NotFound();
            }
            return Ok(holiday);
        }

        /// <summary>
        /// This end point will return all the holidays of the user.
        /// </summary>
        /// <returns>A JSON with a list of holidays</returns>
        /// <response code="200"> Returns all the holidays</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there are no holidays found this error will be returned</response>  
        [HttpGet("{userId}/Users")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Holiday>> GetByUserId(Guid userId)
        {
            var holiday = await holidayLogic.GetHolidayByUserId(userId);
            if (holiday == null)
            {
                return NotFound();
            }
            return Ok(holiday);
        }

        /// <summary>
        /// This end point will update a holiday.
        /// </summary>
        /// <returns>A JSON with a list of holidays</returns>
        /// <response code="200"> Returns if the holiday is succesfully updated</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If updating the holiday failed </response>  
        [HttpPut]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Holiday>> Update([FromBody] Holiday holiday)
        {
            holiday = await holidayLogic.UpdateHoliday(holiday);
            if (holiday == null)
            {
                return NotFound("HolidayId or userId not found");
            }
            return Ok(holiday);
        }

        /// <summary>
        /// This end point will delete a holiday.
        /// </summary>
        /// <returns>A JSON with a holiday</returns>
        /// <response code="204"> Returns if the holiday is succesfully deleted</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If deleting the holiday failed</response>  
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Delete(Guid id)
        {
            var deleted = await holidayLogic.DeleteHoliday(id);
            if (deleted)
            {
                return NoContent();
            }
            return NotFound();
        }
        #endregion

        #region CompanyHoliday

        /// <summary>
        /// This end point will create a holiday.
        /// </summary>
        /// <returns>A JSON with a holiday</returns>
        /// <response code="201"> Returns a holiday, when the holiday is succesfully created</response>
        /// <response code="400"> If the holiday has incorrect data</response>  
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        [Authorize(Roles = "Employer,Admin")]
        [HttpPost("CompanyHolidays")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<ActionResult<CompanyHoliday>> CreateCompanyHoliday([FromBody] CompanyHoliday companyHoliday)
        {
            companyHoliday = await companyHolidayLogic.CreateCompanyHoliday(companyHoliday);
            if (companyHoliday == null)
                return ValidationProblem("Company name not found");
            return Created($"{Request.Path}/{companyHoliday.Id}", companyHoliday);
        }

        /// <summary>
        /// This end point will return the company holiday based the given id.
        /// </summary>
        /// <returns>A JSON with a company holiday</returns>
        /// <response code="200"> Returns a company holiday</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there is no company holiday found this error will be returned</response>  
        [HttpGet("CompanyHolidays/{id}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<CompanyHoliday>> GetCompanyHoliday(Guid id)
        {
            var companyHoliday = await companyHolidayLogic.FindCompanyHolidayById(id);
            if (companyHoliday == null)
            {
                return NotFound();
            }
            return Ok(companyHoliday);
        }

        /// <summary>
        /// This end point will return all the company holidays of a company.
        /// </summary>
        /// <returns>A JSON with a list of company holidays</returns>
        /// <response code="200"> Returns all the company holidays</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there are no company holidays found this error will be returned</response>  
        [HttpGet("CompanyHolidays/{companyName}/Companies")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<Holiday>>> GetByCompanyName(string companyName)
        {
            var holiday = await companyHolidayLogic.GetCompanyHolidaysByCompanyName(companyName);
            if (holiday == null)
            {
                return NotFound();
            }
            return Ok(holiday);
        }

        /// <summary>
        /// This end point will update a company holiday.
        /// </summary>
        /// <returns>A JSON with a company holiday</returns>
        /// <response code="200"> Returns if the company holiday is succesfully updated</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If updating the company holiday failed</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpPut("CompanyHolidays")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<CompanyHoliday>> UpdateCompanyHoliday([FromBody] CompanyHoliday companyHoliday)
        {
            companyHoliday = await companyHolidayLogic.UpdateCompanyHoliday(companyHoliday);
            if (companyHoliday == null)
            {
                return NotFound();
            }
            return Ok(companyHoliday);
        }

        /// <summary>
        /// This end point will delete a company holiday.
        /// </summary>
        /// <returns>A JSON with a company holiday</returns>
        /// <response code="204"> Returns if the company holiday is succesfully deleted</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If deleting the company holiday failed</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpDelete("CompanyHolidays/{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> DeleteCompanyHoliday(Guid id)
        {
            var deleted = await companyHolidayLogic.DeleteCompanyHoliday(id);
            if (deleted)
            {
                return NoContent();
            }
            return NotFound();
        }
        #endregion
    }
}