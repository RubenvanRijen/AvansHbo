﻿using Application.Interfaces;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace apiDriessen.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PlacementsController : ControllerBase
    {
        private readonly IPlacementLogic placementLogic;
        public PlacementsController(IPlacementLogic placementLogic)
        {
            this.placementLogic = placementLogic ?? throw new ArgumentNullException(nameof(placementLogic));
        }

        /// <summary>
        /// This end point will create a placement.
        /// </summary>
        /// <returns>A JSON with a placement</returns>
        /// <response code="201"> Returns a placement, when the placement is succesfully created</response>
        /// <response code="400"> If the placement has incorrect data</response>  
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        [Authorize(Roles = "Employer,Admin")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<ActionResult<Placement>> Create([FromBody]Placement newObject)
        {
            var result = await placementLogic.CreatePlacement(newObject);
            if (result == null)
                return ValidationProblem();
            return Created($"{Request.Path}/{result.Id}", result);
        }

        /// <summary>
        /// This end point will return the placements.
        /// </summary>
        /// <returns>A JSON with a placements</returns>
        /// <response code="200"> Returns placements</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If there are no placements found this error will be returned</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpGet]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<Placement>>> Get([FromQuery] PlacementParameters placementParameters)
        {
            var results = await placementLogic.GetPlacements(placementParameters);
            
            if (results == null)
                return NotFound();

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(results.PaginationMetaData));

            return Ok(results);
        }

        /// <summary>
        /// This end point will return the placement based the given id.
        /// </summary>
        /// <returns>A JSON with a placement</returns>
        /// <response code="200"> Returns a placement</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there is no placement found this error will be returned</response>  
        [HttpGet("{id}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Placement>> Get(Guid id)
        {
            var result = await placementLogic.FindPlacementById(id);
            if (result == null)
                return NotFound();
            return Ok(result);
        }

        /// <summary>
        /// This end point will return all the placements of the company.
        /// </summary>
        /// <returns>A JSON with a list of placements</returns>
        /// <response code="200"> Returns all the placements</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If there are no placements found this error will be returned</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpGet("Companies/{companyName}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<Placement>>> GetByCompanyName(string companyName, [FromQuery] PlacementParameters placementParameters)
        {
            var results = await placementLogic.FindPlacementsByCompanyName(companyName, placementParameters);
            
            if (results == null)
                return NotFound();

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(results.PaginationMetaData));

            return Ok(results);
        }

        /// <summary>
        /// This end point will return all the placements of the user.
        /// </summary>
        /// <returns>A JSON with a list of placements</returns>
        /// <response code="200"> Returns all the placements</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If there are no placements found this error will be returned</response>  
        [HttpGet("Users/{userId}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<Placement>>> GetByUserId(Guid userId, [FromQuery] PlacementParameters placementParameters)
        {
            var results = await placementLogic.FindPlacementsByUserId(userId, placementParameters);
            
            if (results == null)
                return NotFound();

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(results.PaginationMetaData));

            return Ok(results);
        }

        /// <summary>
        /// This end point will update a placement.
        /// </summary>
        /// <returns>A JSON with a placement</returns>
        /// <response code="200"> Returns if the placement is succesfully updated</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If updating the placement failed</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpPut]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Placement>> Update([FromBody]Placement updateObject)
        {
            var result = await placementLogic.UpdatePlacement(updateObject.Id,updateObject);
            if (result == null)
                return NotFound("Placement id not found");
            return Ok(result);
        }

        /// <summary>
        /// This end point will delete a placement.
        /// </summary>
        /// <returns>A JSON with a placement</returns>
        /// <response code="204"> Returns if the placement is succesfully deleted</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If deleting the placement failed</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Delete(Guid id)
        {
            var deleted = await placementLogic.DeletePlacement(id);
            if (deleted)
                return NoContent();
            return NotFound();
        }
    }
}
