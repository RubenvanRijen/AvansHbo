﻿using Application.Interfaces;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace apiDriessen.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class UserPlacementsController : ControllerBase
    {
        private readonly IUserPlacementLogic userPlacementLogic;
        public UserPlacementsController(IUserPlacementLogic userPlacementLogic)
        {
            this.userPlacementLogic = userPlacementLogic ?? throw new ArgumentNullException(nameof(userPlacementLogic));
        }

        /// <summary>
        /// This end point will create an user placement.
        /// </summary>
        /// <returns>A JSON with an user placement</returns>
        /// <response code="201"> Returns an user placement, when the placement is succesfully created</response>
        /// <response code="400"> If the user placement has incorrect data</response>  
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        [Authorize(Roles = "Employer,Admin")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<ActionResult<UserPlacement>> Create([FromBody]UserPlacement newObject)
        {
            if(await userPlacementLogic.UserPlacementAlreadyExists(newObject.UserId,newObject.PlacementId))
                return ValidationProblem($"De combinatie van plaatsing {newObject.PlacementId} en gebruiker {newObject.UserId} bestaat al.");
            var result = await userPlacementLogic.CreateUserPlacement(newObject);
            if (result == null)
                return ValidationProblem();
            return Created($"{Request.Path}/{result.Id}", result);
        }

        /// <summary>
        /// This end point will return the user placements.
        /// </summary>
        /// <returns>A JSON with an user placements</returns>
        /// <response code="200"> Returns placements</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If there are no user placements found this error will be returned</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpGet]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<UserPlacement>>> Get([FromQuery] UserPlacementParameters userPlacementParameters)
        {
            var results = await userPlacementLogic.GetUserPlacements(userPlacementParameters);
            
            if (results == null)
                return NotFound();

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(results.PaginationMetaData));

            return Ok(results);
        }

        /// <summary>
        /// This end point will return the user placement based the given id.
        /// </summary>
        /// <returns>A JSON with a placement</returns>
        /// <response code="200"> Returns an user placement</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there is no user placement found this error will be returned</response>  
        [HttpGet("{id}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<UserPlacement>> Get(Guid id)
        {
            var result = await userPlacementLogic.FindUserPlacementById(id);
            if (result == null)
                return NotFound();
            return Ok(result);
        }

        /// <summary>
        /// This end point will return all the user placements of the placement id.
        /// </summary>
        /// <returns>A JSON with a list of user placements</returns>
        /// <response code="200"> Returns all the user placements</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If there are no user placements found this error will be returned</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpGet("Placements/{placementId}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<UserPlacement>>> GetByPlacementId(Guid placementId, [FromQuery] UserPlacementParameters userPlacementParameters)
        {
            var results = await userPlacementLogic.GetUserPlacementsWithPlacementId(placementId, userPlacementParameters);
            if (results == null)
                return NotFound();

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(results.PaginationMetaData));

            return Ok(results);
        }

        /// <summary>
        /// This end point will return all the user placements of the user id.
        /// </summary>
        /// <returns>A JSON with a list of user placements</returns>
        /// <response code="200"> Returns all the user placements</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there are no user placements found this error will be returned</response>  
        [HttpGet("Users/{userId}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<UserPlacement>>> GetByUserId(Guid userId, [FromQuery] UserPlacementParameters userPlacementParameters)
        {
            var results = await userPlacementLogic.GetUserPlacementsWithUserId(userId, userPlacementParameters);
            if (results == null)
                return NotFound();

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(results.PaginationMetaData));

            return Ok(results);
        }

        /// <summary>
        /// This end point will delete an user placement.
        /// </summary>
        /// <returns>A JSON with an user placement</returns>
        /// <response code="204"> Returns if the user placement is succesfully deleted</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If deleting the user placement failed</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Delete(Guid id)
        {
            var deleted = await userPlacementLogic.DeleteUserPlacement(id);
            if (deleted)
                return NoContent();
            return NotFound();
        }
    }
}
