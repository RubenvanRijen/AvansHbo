﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Application;
using Domain;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace apiDriessen.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class KilometerAllowancesController : ControllerBase
    {
        private readonly IKilometerAllowanceLogic kilometerAllowanceLogic;

        public KilometerAllowancesController(IKilometerAllowanceLogic kilometerAllowanceLogic)
        {
            this.kilometerAllowanceLogic = kilometerAllowanceLogic ??
                                           throw new ArgumentNullException(nameof(kilometerAllowanceLogic));
        }

        /// <summary>
        /// This end point will return the kilometerAllowances.
        /// </summary>
        /// <returns>A JSON with a kilometerAllowances</returns>
        /// <response code="200"> Returns kilometerAllowances</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there are no kilometer allowances found this error will be returned</response>  
        [HttpGet]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<KilometerAllowance>>> Get(
            [FromQuery] KilometerAllowanceParameters kilometerAllowanceParameters)
        {
            var kilometerAllowances =
                await kilometerAllowanceLogic.GetKilometerAllowances(kilometerAllowanceParameters);

            if (kilometerAllowances == null)
                return NotFound();

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(kilometerAllowances.PaginationMetaData));

            return Ok(kilometerAllowances);
        }

        /// <summary>
        /// This end point will return the kilometer allowance based the given id.
        /// </summary>
        /// <returns>A JSON with a kilometer allowance</returns>
        /// <response code="200"> Returns a kilometer allowance</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there is no kilometer allowance found this error will be returned</response>  
        [HttpGet("{id}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<KilometerAllowance>> Get(Guid id)
        {
            var kilometerAllowance = await kilometerAllowanceLogic.FindKilometerAllowanceById(id);

            if (kilometerAllowance == null)
            {
                return NotFound();
            }

            return Ok(kilometerAllowance);
        }

        /// <summary>
        /// This end point will return all the kilometer allowances of the user.
        /// </summary>
        /// <returns>A JSON with a list of kilometer allowances</returns>
        /// <response code="200"> Returns all the kilometer allowances</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there are no kilometer allowances found this error will be returned</response>  
        [HttpGet("Users/{userId}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<KilometerAllowance>>> GetByUserId(Guid userId)
        {
            var results = await kilometerAllowanceLogic.FindKilometerAllowancesByUserId(userId);
            if (results == null)
                return NotFound();
            return Ok(results);
        }

        /// <summary>
        /// This end point will create a kilometer allowance.
        /// </summary>
        /// <returns>A JSON with a kilometer allowance</returns>
        /// <response code="201"> Returns a kilometer allowance, when the kilometer allowance is succesfully created</response>
        /// <response code="400"> If the kilometer allowance has incorrect data</response>  
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        [Authorize(Roles = "Employer,Admin")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<ActionResult<KilometerAllowance>> Create([FromBody] KilometerAllowance newKilometerAllowance)
        {
            var createdKilometerAllowance =
                await kilometerAllowanceLogic.CreateKilometerAllowance(newKilometerAllowance);
            if (createdKilometerAllowance == null)
                return ValidationProblem();
            return Created($"{Request.Path}/{createdKilometerAllowance.Id}", createdKilometerAllowance);
        }

        /// <summary>
        /// This end point will update a kilometer allowance.
        /// </summary>
        /// <returns>A JSON with a kilometer allowance</returns>
        /// <response code="200"> Returns if the kilometer allowance is succesfully updated</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If updating the kilometer allowance failed</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<KilometerAllowance>> Update(Guid id,
            [FromBody] KilometerAllowance newKillometerAllowance)
        {
            var editedKilometerAllowance =
                await kilometerAllowanceLogic.UpdateKilometerAllowance(id, newKillometerAllowance);

            if (editedKilometerAllowance == null)
            {
                return NotFound();
            }

            return Ok(editedKilometerAllowance);
        }

        /// <summary>
        /// This end point will delete a kilometer allowance.
        /// </summary>
        /// <returns>A JSON with a kilometer allowance</returns>
        /// <response code="204"> Returns if the kilometer allowance is succesfully deleted</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If deleting the kilometer allowance failed</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Delete(Guid id)
        {
            var deleted = await kilometerAllowanceLogic.DeleteKilometerAllowance(id);

            if (deleted)
            {
                return NoContent();
            }

            return NotFound();
        }
    }
}