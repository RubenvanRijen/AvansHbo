﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Application.AuxiliaryLogics.Interfaces;
using Application.Interfaces;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace apiDriessen.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class RoutesController : ControllerBase
    {
        private readonly IRouteLogic routeLogic;
        private readonly IValidationLogic validationLogic;

        public RoutesController(IRouteLogic routeLogic, IValidationLogic validationLogic)
        {
            this.routeLogic = routeLogic ?? throw new ArgumentNullException(nameof(routeLogic));
            this.validationLogic = validationLogic ?? throw new ArgumentNullException(nameof(validationLogic));
        }

        /// <summary>
        /// This end point will return routes.
        /// </summary>
        /// <returns>A JSON with routes</returns>
        /// <response code="200"> Returns routes</response>
        /// <response code="400"> If the parameters clash</response>  
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If there are no routes found this error will be returned</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpGet]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<Route>>> Get([FromQuery] RouteParameters routeParameters)
        {
            if (!routeParameters.ValidDateRange)
            {
                return BadRequest("Einddatum kan niet eerder zijn dan startdatum");
            }
            if (!routeParameters.ValidDistanceRange)
            {
                return BadRequest("Maximale afstand kan niet meer zijn dan minimale afstand");
            }

            var routes = await routeLogic.GetRoutes(routeParameters);

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(routes.PaginationMetaData));

            if (routes.Count == 0)
            {
                return NotFound();
            }

            return Ok(routes);
        }

        /// <summary>
        /// This end point will return the routes of the user.
        /// </summary>
        /// <returns>A JSON with routes</returns>
        /// <response code="200"> Returns routes</response>
        /// <response code="400"> If the parameters clash</response>  
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there are no routes found this error will be returned</response>  
        [HttpGet("User/{userId}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Route>> GetByUserId(Guid userId, [FromQuery] RouteParameters routeParameters)
        {
            if (!routeParameters.ValidDateRange)
                return BadRequest("Einddatum kan niet eerder zijn dan startdatum");
            if (!routeParameters.ValidDistanceRange)
                return BadRequest("Maximale afstand kan niet meer zijn dan minimale afstand");

            var routes = await routeLogic.FindRouteByUserId(userId, routeParameters);

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(routes.PaginationMetaData));

            if (routes.Count == 0)
                return NotFound();

            return Ok(routes);
        }

        /// <summary>
        /// This end point will return the route based the given id.
        /// </summary>
        /// <returns>A JSON with a route</returns>
        /// <response code="200"> Returns a route</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there is no route found this error will be returned</response>  
        [HttpGet("{id}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Route>> Get(Guid id)
        {
            var route = await routeLogic.FindRouteById(id);

            if (route == null)
            {
                return NotFound();
            }

            return Ok(route);
        }

        /// <summary>
        /// This end point will create a route.
        /// </summary>
        /// <remarks>
        /// <b>Remarks</b><br/>
        /// When creating a route base on distant (over 500 meters between the coordinates) coordinates use the default post route. <br/>
        /// Otherwise use the parameter isGPSData and give it the value true. <br/> <br/>
        /// When creating the route only give the serializedRoute as the coordinates, the API will calculate the serializedMapRoute.<br/><br/>
        /// <b>Automatically filled in</b><br/>
        /// When the JSON body has the placementId it will automaticaclly set the correct company name that the placement belongs to. <br/>
        /// When the JSON body has the kilometerAllowanceId it will automaticaclly set the correct allowance type name that the kilometer allowance belongs to.<br/>
        /// The start- and end location are also automatically set by the API.
        /// </remarks>
        /// <returns>A JSON with a route</returns>
        /// <response code="201"> Returns a route, when the route is succesfully created</response>
        /// <response code="400"> If the route has incorrect data</response>  
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        public async Task<ActionResult<Route>> Create([FromBody] Route newRoute, [FromQuery] bool isGPSData = false)
        {
            if(await validationLogic.UserDoesNotExist(newRoute.UserId))
                return BadRequest("User id has not been found");
            if (await validationLogic.StatusDoesNotExist(newRoute.StatusName))
                return BadRequest("Status name does not exist");
            if (!isGPSData)
            {
                if (await validationLogic.PlacementDoesNotExist(newRoute.PlacementId))
                    return BadRequest("Placement id does not exist");
                if (await validationLogic.KilometerAllowanceDoesNotExist(newRoute.KilometerAllowanceId))
                    return BadRequest("Kilometer allowance id does not exist");
            }

            var createdRoute = await routeLogic.CreateRoute(newRoute,isGPSData);

            if (createdRoute == null)
                return NotFound();

            return Created($"{Request.Path}/{createdRoute.Id}", createdRoute);
        }

        /// <summary>
        /// This end point will update a route.
        /// </summary>
        /// <remarks>
        /// <b>Automatically filled in</b><br/>
        /// The serializedRoute and serializedMapRoute can't be updated.<br/>
        /// When the JSON body has the placementId it will automaticaclly set the correct company name that the placement belongs to.<br/>
        /// When the JSON body has the kilometerAllowanceId it will automaticaclly set the correct allowance type name that the kilometer allowance belongs to.<br/>
        /// </remarks>
        /// <returns>A JSON with a route</returns>
        /// <response code="200"> Returns if the route is succesfully updated</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If updating the route failed</response>  
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Route>> Update(Guid id, [FromBody] Route newRoute)
        {
            if (await validationLogic.UserDoesNotExist(newRoute.UserId))
                return BadRequest("User id has not been found");
            if (await validationLogic.StatusDoesNotExist(newRoute.StatusName))
                return BadRequest("Status name does not exist");
            if (await validationLogic.PlacementDoesNotExist(newRoute.PlacementId))
                return BadRequest("Placement id does not exist");
            if (await validationLogic.KilometerAllowanceDoesNotExist(newRoute.KilometerAllowanceId))
                return BadRequest("Kilometer allowance id does not exist");

            var editedRoute = await routeLogic.UpdateRoute(id, newRoute);

            if (editedRoute == null)
            {
                return NotFound();
            }

            return Ok(editedRoute);
        }

        /// <summary>
        /// This end point will delete a route.
        /// </summary>
        /// <returns>A JSON with a route</returns>
        /// <response code="204"> Returns if the route is succesfully deleted</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If deleting the route failed</response> 
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Delete(Guid id)
        {
            var deleted = await routeLogic.DeleteRoute(id);

            if (deleted)
            {
                return NoContent();
            }

            return NotFound();
        }
    }
}