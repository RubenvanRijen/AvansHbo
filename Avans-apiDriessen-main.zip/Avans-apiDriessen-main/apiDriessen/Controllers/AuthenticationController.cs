﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Application.Interfaces;
using Domain.Models.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace apiDriessen.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class AuthenticationController : ControllerBase
    {
        private readonly IAuthenticationLogic authenticationLogic;

        public AuthenticationController(IAuthenticationLogic authenticationLogic)
        {
            this.authenticationLogic = authenticationLogic ?? throw new ArgumentNullException(nameof(authenticationLogic));
        }

        /// <summary>
        /// This will return a Bearer JWT if the user credentials are valid.
        /// </summary>
        /// <param name="authenticationRequest"></param>
        /// <returns>A JWT</returns>
        /// <response code="200"> Returns a Bearer JWT if the user credentials are valid </response>
        /// <response code="400"> If the item is null </response>  
        /// <response code="401"> If the user credentials are invalid </response>  
        /// <response code="403"> If the item is null </response>  

        [AllowAnonymous]
        [HttpPost]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> Authenticate([FromBody] AuthenticationRequest authenticationRequest)
        {
            var jwt = await authenticationLogic.Authenticate(authenticationRequest);
            if (jwt == null) return Unauthorized();

            var authenticationResponse = new AuthenticationResponse(jwt);
            return Ok(authenticationResponse);
        }
    }
}