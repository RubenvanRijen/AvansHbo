﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Application.Interfaces;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace apiDriessen.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class UsersController : ControllerBase
    {
        private readonly IUserLogic userLogic;

        public UsersController(IUserLogic userLogic)
        {
            this.userLogic = userLogic ?? throw new ArgumentNullException(nameof(userLogic));
        }

        /// <summary>
        /// This end point will return all the the users.
        /// </summary>
        /// <returns>A JSON with a list of users</returns>
        /// <response code="200"> Returns all the users</response>
        /// <response code="401"> If the user has no or an invalid JWT</response>
        /// <response code="404"> If there are no users found this error will be returned</response>  
        [HttpGet]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<User>>> Get([FromQuery] UserParameters userParameters)
        {
            var users = await userLogic.GetAllUsers(userParameters);

            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(users.PaginationMetaData));

            if (users == null || users.Count <= 0)
            {
                return NotFound();
            }

            return Ok(users);
        }

        /// <summary>
        /// This end point will create an user.
        /// </summary>
        /// <returns>A JSON with an user</returns>
        /// <response code="201"> Returns an user, when the user is succesfully created</response>
        /// <response code="400"> If the placement has incorrect data</response>  
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        public async Task<ActionResult<User>> Create([FromBody] User newUser)
        {
            if (string.IsNullOrEmpty(newUser.RoleName))
            {
                return BadRequest("De rolnaam  mag niet leeg zijn");
            }

            var createdUser = await userLogic.CreateNewUser(newUser);

            if (createdUser == null)
            {
                return ValidationProblem();
            }

            return Created($"{Request.Path}/{createdUser.Id}", createdUser);
        }

        /// <summary>
        /// This end point will return the user based the given id.
        /// </summary>
        /// <returns>A JSON with an user</returns>
        /// <response code="200"> Returns an user</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If there is no user found this error will be returned</response>  
        [HttpGet("{id}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<User>> Get(Guid id)
        {
            var user = await userLogic.FindUserById(id);

            if (user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }

        /// <summary>
        /// This end point will update an user.
        /// </summary>
        /// <returns>A JSON with an user</returns>
        /// <response code="200"> Returns if the user is succesfully updated</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If updating the user failed</response>  
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<User>> Update(Guid id, [FromBody] User newUser)
        {
            var updatedUser = await userLogic.UpdateUser(id, newUser);

            if (updatedUser == null)
            {
                return NotFound();
            }

            return Ok(updatedUser);
        }

        /// <summary>
        /// This end point will delete an user.
        /// </summary>
        /// <returns>A JSON with an user</returns>
        /// <response code="204"> Returns if the user is succesfully deleted</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="404"> If deleting the user failed</response>  
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Delete(Guid id)
        {
            var deleted = await userLogic.SoftDeleteUser(id);

            if (deleted)
            {
                return NoContent();
            }

            return NotFound();
        }

        /// <summary>
        /// This end point will return all the users of the company.
        /// </summary>
        /// <returns>A JSON with a list of users</returns>
        /// <response code="200"> Returns all the users</response>
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        /// <response code="404"> If there are no users found this error will be returned</response>  
        [Authorize(Roles = "Employer,Admin")]
        [HttpGet("company/{companyName}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> GetUsersFromCompany(string companyName, [FromQuery] UserParameters userParameters)
        {
            var users = await userLogic.GetUsersFromCompany(companyName, userParameters);

            if (users == null)
            {
                return NotFound();
            }

            return Ok(users);
        }
    }
}