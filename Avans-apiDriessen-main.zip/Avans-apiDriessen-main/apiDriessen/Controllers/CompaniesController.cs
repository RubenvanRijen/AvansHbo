﻿using Application.Interfaces;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace apiDriessen.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class CompaniesController : ControllerBase
    {
        private readonly ICompanyLogic companyLogic;

        public CompaniesController(ICompanyLogic companyLogic)
        {
            this.companyLogic = companyLogic ?? throw new ArgumentNullException(nameof(companyLogic));
        }


        /// <summary>
        /// This end point will return all the companies, with name and picture.
        /// </summary>
        /// <returns>A JSON with a list of companies</returns>
        /// <response code="200"> Returns all the companies, with name and picture</response>
        /// <response code="401"> If the user has no or an invalid JWT</response>  
        /// <response code="404"> If there are no companies found this error will be returned </response>  
        [HttpGet]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<Company>>> Get()
        {
            var companies = await companyLogic.GetCompanies();

            if (companies.Count == 0)
            {
                return NotFound();
            }

            return Ok(companies);
        }

        /// <summary>
        /// This end point will return all the companies, with name and picture. For which the user has a placement or is a employer for.
        /// </summary>
        /// <returns>A JSON with a list of companies</returns>
        /// <response code="200"> Returns all the companies, with name and picture. For which the user has a placement or is a employer for</response>
        /// <response code="401"> If the user has no or an invalid JWT</response>  
        /// <response code="404"> If there are no companies found this error will be returned </response>  
        [HttpGet("Users/{userId}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<List<Company>>> GetByUserId(Guid userId)
        {
            var companies = await companyLogic.GetCompaniesByUserId(userId);

            if (companies.Count == 0)
            {
                return NotFound();
            }

            return Ok(companies);
        }

        /// <summary>
        /// This end point will return the company, with name and picture.
        /// </summary>
        /// <returns>A JSON with a list of companies</returns>
        /// <response code="200"> Returns all the companies, with name and picture. For which the user has a placement or is a employer for</response>
        /// <response code="401"> If the user has no or an invalid JWT</response>  
        /// <response code="404"> If there is no company found with this name this error will be returned</response>  
        [HttpGet("{name}")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Company>> GetByName(string name)
        {
            var company = await companyLogic.GetCompanyByName(name);
            if (company == null)
            {
                return NotFound();
            }
            return Ok(company);
        }

        /// <summary>
        /// This end point will create a company.
        /// </summary>
        /// <returns>A JSON with a company</returns>
        /// <response code="201"> Returns a company, when the company is succesfully created</response>
        /// <response code="400"> If the company has incorrect data</response>  
        /// <response code="401"> If the user has no or an invalid JWT</response> 
        /// <response code="403"> If the user does not have the required role for using this end point</response> 
        [Authorize(Roles = "Employer,Admin")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<ActionResult<Company>> Create([FromBody] Company newCompany)
        {
            if (string.IsNullOrEmpty(newCompany.Name))
            {
                return BadRequest("De naam mag niet leeg zijn");
            }

            if (string.IsNullOrEmpty(newCompany.Image))
            {
                return BadRequest("Het bedrijfsafbeelding is verplicht");
            }

            var createdCompany = await companyLogic.CreateCompany(newCompany);

            if (createdCompany == null)
            {
                return NotFound();
            }
            
            return Created($"{Request.Path}/{createdCompany.Name}", createdCompany);
        }
    }
}