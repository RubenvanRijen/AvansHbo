﻿namespace Domain.AuxiliaryModels
{
    public class ExpectedDeclaration
    {
        public float Distance { get; }
        public float Payout { get; }

        public ExpectedDeclaration(float distance, float payout)
        {
            Distance = distance;
            Payout = payout;
        }
    }
}