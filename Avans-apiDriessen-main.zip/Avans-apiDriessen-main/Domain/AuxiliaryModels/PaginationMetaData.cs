﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.AuxiliaryModels
{
    public class PaginationMetaData
    {
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }
        public bool HasPrevious => CurrentPage > 1;
        public bool HasNext => CurrentPage < TotalPages;

        private int? _previousPage = null;
        public int? PreviousPage => HasPrevious ? CurrentPage - 1 : _previousPage;

        private int? _nextPage = null;
        public int? NextPage => HasNext ? CurrentPage + 1 : _nextPage;
    }
}
