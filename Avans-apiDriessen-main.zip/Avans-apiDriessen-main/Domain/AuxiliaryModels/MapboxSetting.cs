﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.AuxiliaryModels
{
    public class MapboxSetting
    {
        public string ApiUrlLocation { get; set; }
        public string ApiUrl { get; set; }
        public string ApiGPSUrl { get; set; }
        public string ApiKey { get; set; }

    }
}
