﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.AuxiliaryModels.MapboxModels
{
    public class MapboxRoute
    {
        public List<Routes> Routes { get; set; }
    }
}