﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.AuxiliaryModels.MapboxModels
{
    public class Geometry
    {
        public float[][] Coordinates { get; set; }
    }

}
