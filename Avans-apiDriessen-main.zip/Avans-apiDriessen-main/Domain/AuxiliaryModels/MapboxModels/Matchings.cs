﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.AuxiliaryModels.MapboxModels
{
    public class Matchings
    {
        public Geometry Geometry { get; set; }
        public float Distance { get; set; }
    }
}