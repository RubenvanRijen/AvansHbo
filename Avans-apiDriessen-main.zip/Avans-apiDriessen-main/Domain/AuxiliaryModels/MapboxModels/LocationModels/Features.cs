﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.AuxiliaryModels.MapboxModels.LocationModels
{
    public class Features
    {
        public List<Context> Context { get; set; }
    }
}
