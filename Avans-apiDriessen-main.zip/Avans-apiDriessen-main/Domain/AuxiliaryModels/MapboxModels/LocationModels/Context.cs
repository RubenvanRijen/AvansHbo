﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.AuxiliaryModels.MapboxModels.LocationModels
{
    public class Context
    {
        public string Id { get; set; }
        public string Text { get; set; }
    }
}
