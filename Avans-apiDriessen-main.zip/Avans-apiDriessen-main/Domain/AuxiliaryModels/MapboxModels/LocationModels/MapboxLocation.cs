﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.AuxiliaryModels.MapboxModels.LocationModels
{
    public class MapboxLocation
    {
        public List<Features> Features { get; set; }
    }
}
