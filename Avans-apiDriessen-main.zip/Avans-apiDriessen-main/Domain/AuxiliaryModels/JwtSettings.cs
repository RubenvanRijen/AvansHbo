﻿namespace Domain.AuxiliaryModels
{
    public class JwtSettings
    {
        public string Key { get; set; }
    }
}