﻿using Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domain.Models
{
    public class CompanyHoliday : BaseEntity, IValidatableObject
    {
        //Foreign key values
        [Required]
        [MaxLength(200)]
        [MinLength(3)]
        [RegularExpression(@"^[A-Z]+[a-zA-Z""'\s-]*$", ErrorMessage = "Name can only exists out of letters and needs a Capital letter at the start")]
        public string CompanyName { get; set; }
        //Values
        [Required]
        public DateTime StartDate { get; set; }
        [Required]
        public DateTime EndDate { get; set; }
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (DateTime.Now.AddYears(2) < EndDate)
                yield return
                  new ValidationResult(errorMessage: "Date can't go futher then one year",
                                       memberNames: new[] { "Date can't go futher then one year" });
            if (DateTime.Now.AddYears(-2) > StartDate)
                yield return
                  new ValidationResult(errorMessage: "Date can't go futher back then one year",
                                       memberNames: new[] { "Date can't go futher back then one year" });
            if(EndDate < StartDate)
                yield return
                  new ValidationResult(errorMessage: "EndDateTime must be greater than StartDateTime",
                                       memberNames: new[] { "EndDate" });
        }
    }
}
