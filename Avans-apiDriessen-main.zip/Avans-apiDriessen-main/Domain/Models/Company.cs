﻿using Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domain.Models
{
    public class Company
    {
        [Key]
        [MaxLength(200)]
        [MinLength(3)]
        [Required]
        [RegularExpression(@"^[A-Z]+[a-zA-Z""'\s-]*$", ErrorMessage = "Name can only exists out of letters and needs a Capital letter at the start")]
        public string Name { get; set; }
        [Required]
        [MaxLength]
        public string Image { get; set; }
        //Foreign values
        public List<Placement> Placements { get; set; }
        public List<KilometerAllowance> KilometerAllowances { get; set; }
        public List<User> Users { get; set; }
        public List<CompanyHoliday> CompanyHolidays { get; set; }
    }
}
