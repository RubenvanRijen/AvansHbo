﻿using Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domain.Models
{
    public class Status
    {
        [Key]
        [MaxLength(200)]
        [MinLength(3)]
        [RegularExpression(@"^[A-Z]+[a-zA-Z""'\s-_]*$", ErrorMessage = "Name can only exists out of letters and needs a Capital letter at the start")]
        public string Name { get; set; }
        //Foreign values
        public List<Route> Routes { get; set; }
    }
}
