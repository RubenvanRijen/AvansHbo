﻿using Domain.Models;
using Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace Domain
{
    public class KilometerAllowance : BaseEntity
    {
        //Foreign key values
        [Required]
        [MaxLength(200)]
        [MinLength(3)]
        [RegularExpression(@"^[A-Z]+[a-zA-Z""'\s-]*$", ErrorMessage = "Name can only exists out of letters and needs a Capital letter at the start")]
        public string AllowanceTypeName { get; set; }
        [Required]
        [MaxLength(200)]
        [MinLength(3)]
        public string CompanyName { get; set; }
        //Values
        [Required]
        [Range (0.0, Double.MaxValue)]
        public double Price { get; set; }
        [Required]
        [Range(0.0, Double.MaxValue)]
        public double MinDistance { get; set; }

        public List<Route> Routes { get; set; }
    }
}
