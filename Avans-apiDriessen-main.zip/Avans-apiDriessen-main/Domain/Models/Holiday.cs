﻿using Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domain.Models
{
    public class Holiday : BaseEntity, IValidatableObject
    {
        //Foreign key values
        [Required]
        public Guid UserId { get; set; }
        //Values
        [Required]
        public DateTime Date { get; set; }

        #region Valdation
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (DateTime.Now.AddYears(1) < Date)
                yield return
                  new ValidationResult(errorMessage: "Date can't go futher then one year",
                                       memberNames: new[] { "Date can't go futher then one year" });
            if (DateTime.Now.AddYears(-1) > Date)
                yield return
                  new ValidationResult(errorMessage: "Date can't go futher back then one year",
                                       memberNames: new[] { "Date can't go futher back then one year" });
        }
        #endregion
    }
}
