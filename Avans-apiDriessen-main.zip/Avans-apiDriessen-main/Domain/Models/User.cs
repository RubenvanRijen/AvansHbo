﻿using Domain.Models.Base;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Domain.Models
{
    public class User : BaseEntity
    {
        public User()
        {
            OAuthToken = null;
        }

        //Foreign key values
        //[Required]
        [MaxLength(200)]
        [MinLength(3)]
        [RegularExpression(@"^[A-Za-z]+$", ErrorMessage = "Role may only contain letters.")]
        public string RoleName { get; set; }

        [MaxLength(200)] [MinLength(3)] public string CompanyName { get; set; }

        //Values
        [Required]
        [MaxLength(100)]
        [MinLength(3)]
        [RegularExpression(
            @"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
            , ErrorMessage = "E-mail adress atleast needs a character, a @ and a character")]
        public string Email { get; set; }

        //[Required]
        [MaxLength(64)]
        [MinLength(8)]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$^+=!*()@%&]).{8,}$"
            , ErrorMessage = "Password should at least contain a lower case letter, upper case letter, numeric value and a special case characters")]
        public string Password { get; set; }

        [Required]
        [MaxLength(200)]
        [MinLength(3)]
        [RegularExpression(@"^[A-Za-z]+$", ErrorMessage = "First name may only contain letters.")]
        public string FirstName { get; set; }

        [Required]
        [MaxLength(200)]
        [MinLength(3)]
        [RegularExpression(@"^[A-Za-z]+$", ErrorMessage = "Last name may only contain letters.")]
        public string LastName { get; set; }


        [MaxLength(22)] 
        [MinLength(16)] 
        public string AccountNumber { get; set; }

        public string OAuthToken { get; set; }

        [MaxLength] 
        public string Image { get; set; }

        public bool IsDeleted { get; set; }

        //Foreign values
        public List<Route> Routes { get; set; }
        public AllowanceType allowanceType { get; set; }
        public List<Holiday> Holidays { get; set; }
        public List<UserPlacement> UserPlacements { get; set; }
    }
}