﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Domain.Models.Base;

namespace Domain.Models
{
    public class Route : BaseEntity, IValidatableObject
    {
        //Foreign key values
        [Required]
        public Guid UserId { get; set; }
        [Required]
        [MaxLength(200)]
        [MinLength(3)]
        [RegularExpression(@"^[A-Z]+[a-zA-Z""'\s-_]*$", ErrorMessage = "Name can only exists out of letters and needs a Capital letter at the start")]
        public string StatusName { get; set; }
        public Guid? PlacementId { get; set; }
        public string CompanyName { get; set; }
        public string AllowanceTypeName { get; set; }
        public Guid? KilometerAllowanceId { get; set; }
        //Values
        public string StartLocation { get; set; }
        public string EndLocation { get; set; }
        [Required]
        public DateTime StartTime { get; set; }
        [Required]
        public DateTime EndTime { get; set; }
        [Required]
        public string SerializedRoute { get; set; }

        public string SerializedMapRoute { get; set; }

        public double EstimatedPayment { get; set; }

        [Range(0, float.MaxValue,
        ErrorMessage = "Value for {0} must be between {1} and {2}.")]
        public float Distance { get; set; }

        #region Valdation
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (EndTime < StartTime)
            {
                yield return
                  new ValidationResult(errorMessage: "EndDate must be greater than StartDate",
                                       memberNames: new[] { "EndDate" });
            }
        }
        #endregion
    }
}
