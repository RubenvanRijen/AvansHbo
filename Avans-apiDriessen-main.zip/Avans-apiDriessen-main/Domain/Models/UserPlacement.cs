﻿using Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domain.Models
{
    public class UserPlacement : BaseEntity
    {
        [Required]
        public Guid PlacementId { get; set; }
        [Required]
        public Guid UserId { get; set; }
    }
}
