﻿using Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domain.Models
{
    public class Placement : BaseEntity
    {
        [MaxLength(200)]
        [MinLength(3)]
        public string Name { get; set; }
        //Values
        [Required]
        public DateTime StartDateTime { get; set; }
        [Required]
        public DateTime EndDateTime { get; set; }
        //Foreign values
        [Required]
        public string CompanyName { get; set; }

        public List<Route> Routes { get; set; }
        public List<UserPlacement> UserPlacements { get; set; }

        #region Valdation
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (EndDateTime < StartDateTime)
            {
                yield return
                  new ValidationResult(errorMessage: "Eind datum moet later zijn dan begin datum",
                                       memberNames: new[] { "EndDate" });
            }
        }
        #endregion
    }
}
