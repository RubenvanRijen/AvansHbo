﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domain.Models
{
    public class Role
    {
        [Key]
        [MaxLength(200)]
        [MinLength(3)]
        [RegularExpression(@"^[A-Z]+[a-zA-Z""'\s-]*$", ErrorMessage = "Name can only exists out of letters and needs a Capital letter at the start")]
        public string Name { get; set; }
        //Foreign values
        public List<User> Users { get; set; }
    }
}
