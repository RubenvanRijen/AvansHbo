﻿namespace Domain.Models.Authentication
{
    public class AuthenticationResponse
    {
        public string Jwt { get; set; }

        public AuthenticationResponse(string jwt)
        {
            Jwt = jwt;
        }
    }
}