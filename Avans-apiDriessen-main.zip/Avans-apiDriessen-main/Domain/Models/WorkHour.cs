﻿using Domain.Models;
using Domain.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Domain
{
    public class WorkHour : BaseEntity, IValidatableObject
    {
        //Foreign key values
        [Required]
        public Guid UserId { get; set; }
        //Values
        [Required]
        public DateTime StartDateTime { get; set; }
        [Required]
        public DateTime EndDateTime { get; set; }
        #region Valdation
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (EndDateTime < StartDateTime)
            {
                yield return
                  new ValidationResult(errorMessage: "EndDateTime must be greater than StartDateTime",
                                       memberNames: new[] { "EndDate" });
            }
        }
        #endregion
    }
}
