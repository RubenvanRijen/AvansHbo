﻿using System;

namespace Domain.Models.QueryStringParameters
{
    public class WorkHourParameters : QueryStringParameters<WorkHour>
    {
        public DateTime StartDate { get; set; } = DateTime.MinValue;
        public DateTime EndDate { get; set; } = DateTime.MaxValue;

        public bool ValidDateRange => EndDate >= StartDate;

        public override bool Filter(WorkHour workHour)
        {
            return workHour.StartDateTime >= StartDate && workHour.StartDateTime <= EndDate;                               
        }
    }
}