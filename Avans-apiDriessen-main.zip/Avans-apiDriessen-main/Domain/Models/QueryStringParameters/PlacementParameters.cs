﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Models.QueryStringParameters
{
    public class PlacementParameters : QueryStringParameters<Placement>
    {
        public override bool Filter(Placement entity)
        {
            return true;
        }
    }
}
