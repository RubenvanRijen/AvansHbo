﻿
namespace Domain.Models.QueryStringParameters
{
    public class KilometerAllowanceParameters : QueryStringParameters<KilometerAllowance>
    {
        public override bool Filter(KilometerAllowance entity)
        {
            return true;
        }
    }
}