﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Models.QueryStringParameters
{
    public class UserParameters : QueryStringParameters<User>
    {
        public override bool Filter(User entity)
        {
            return true;
        }
    }
}