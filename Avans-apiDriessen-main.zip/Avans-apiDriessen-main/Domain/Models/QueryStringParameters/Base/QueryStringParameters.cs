using Domain.Models.Base;

namespace Domain.Models.QueryStringParameters
{
    public abstract class QueryStringParameters<T> where T : BaseEntity
    {
        const int maxPageSize = 50;
        public int PageNumber { get; set; } = 1;

        private int _pageSize = 10;

        public int PageSize
        {
            get { return _pageSize; }
            set { _pageSize = (value > maxPageSize) ? maxPageSize : value; }
        }

        public abstract bool Filter(T entity);
    }
}