﻿using System;

namespace Domain.Models.QueryStringParameters
{
    public class RouteParameters : QueryStringParameters<Route>
    {
        public float MinDistance { get; set; } = 0;
        public float MaxDistance { get; set; } = 500000;
        public string Company { get; set; } = "";
        public DateTime StartDate { get; set; } = DateTime.MinValue;
        public DateTime EndDate { get; set; } = DateTime.MaxValue;
        public string RouteType { get; set; } = "";
        public string StartLocation { get; set; } = "";
        public string EndLocation { get; set; } = "";
        public string Status { get; set; } = "";

        public bool ValidDistanceRange => MaxDistance >= MinDistance;
        public bool ValidDateRange => EndDate >= StartDate;

        public override bool Filter(Route route)
        {
            return 
                route.Distance >= MinDistance && route.Distance <= MaxDistance
                && route.StartTime >= StartDate && route.StartTime <= EndDate
                && (Company == "" || route.CompanyName != null && route.CompanyName.ToLower().Contains(Company.ToLower()))
                && (RouteType == "" || route.AllowanceTypeName != null && RouteType.ToLower().Equals(route.AllowanceTypeName.ToLower()))
                && (StartLocation == "" || route.StartLocation != null && route.StartLocation.ToLower().Contains(StartLocation.ToLower()))
                && (EndLocation == "" || route.EndLocation != null && route.EndLocation.ToLower().Contains(EndLocation.ToLower()))
                && (Status == "" || route.StatusName != null && Status.ToLower().Equals(route.StatusName.ToLower()));
        }
    }
}