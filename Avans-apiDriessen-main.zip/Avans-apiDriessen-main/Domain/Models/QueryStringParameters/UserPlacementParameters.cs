﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Models.QueryStringParameters
{
    public class UserPlacementParameters : QueryStringParameters<UserPlacement>
    {
        public override bool Filter(UserPlacement entity)
        {
            return true;
        }
    }
}
