﻿using EmailService.Config;
using EmailService.Interfaces;
using EmailService.Models;
using Microsoft.Extensions.Options;
using System;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Net;
using System.Linq;

namespace EmailService
{
    public class EmailSender : IEmailSender
    {
        private readonly EmailConfiguration _emailConfig;
        public EmailSender(IOptions<EmailConfiguration> emailConfig)
        {
            _emailConfig = emailConfig.Value ?? throw new ArgumentNullException(nameof(emailConfig));
        }

        #region Send email asynce
        public async Task SendEmailAsync(Message message)
        {
            if (_emailConfig.EmailingActive) { 
                var mailMessage = await CreateAsyncEmailMessage(message);
                await SendAsync(mailMessage);
            }
        }
        #endregion

        #region Create email message
        private async Task<MailMessage> CreateAsyncEmailMessage(Message message)
        {
            EmailLayout emailLayout = new EmailLayout(message.Content, _emailConfig.SiteUrl);
            var mail = new MailMessage(_emailConfig.From, message.To.First().ToString(), message.Subject, emailLayout.Layout);
            mail.IsBodyHtml = true;
            return mail;
        }
        #endregion

        #region Send async
        private async Task SendAsync(MailMessage mailMessage)
        {
            var client = new SmtpClient(_emailConfig.SmtpServer, _emailConfig.Port)
            {
                Credentials = new NetworkCredential(_emailConfig.UserName, _emailConfig.Password),
                EnableSsl = true
            };

            using (client)
            {
                try
                {
                    client.Send(mailMessage);       
                }
                catch (Exception e)
                {
                    var reee = e;
                    throw;
                }
                finally
                {
                    client.Dispose();
                }
            }
        }
        #endregion
    }
}
