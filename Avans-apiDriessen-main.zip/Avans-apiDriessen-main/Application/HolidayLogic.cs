﻿using Application.AuxiliaryLogics.Interfaces;
using Application.Interfaces;
using Domain.Models;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application
{
    public class HolidayLogic : IHolidayLogic
    {
        private readonly IAsyncRepository<Holiday> holidayRepository;
        private readonly IValidationLogic validationLogic;

        public HolidayLogic(IAsyncRepository<Holiday> holidayRepository, IValidationLogic validationLogic)
        {
            this.holidayRepository = holidayRepository ?? throw new ArgumentNullException(nameof(holidayRepository));
            this.validationLogic = validationLogic ?? throw new ArgumentNullException(nameof(validationLogic));
        }

        public async Task<Holiday> CreateHoliday(Holiday holiday)
        {
            if (await validationLogic.UserDoesNotExist(holiday.UserId))
                return null;
            return await holidayRepository.Create(holiday);
        }

        public Task<Holiday> FindHolidayById(Guid id)
        {
            return holidayRepository.GetById(id);
        }

        public async Task<List<Holiday>> GetHolidayByUserId(Guid userId)
        {
            if (await validationLogic.UserDoesNotExist(userId))
                return null;
            return await holidayRepository.GetWhere(row => row.UserId == userId);
        }

        public async Task<Holiday> UpdateHoliday(Holiday holiday)
        {
            var oldHoliday = await FindHolidayById(holiday.Id);
            if (null == oldHoliday || await validationLogic.UserDoesNotExist(holiday.UserId))
                return null;
            oldHoliday.Date = holiday.Date;
            return await holidayRepository.Update(oldHoliday);
        }

        public Task<bool> DeleteHoliday(Guid id)
        {
            return holidayRepository.Delete(id);
        }
    }
}