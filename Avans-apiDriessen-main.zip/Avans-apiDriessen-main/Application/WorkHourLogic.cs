﻿using Domain;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using Persistence;
using Persistence.Repositories.Interfaces;
using System;
using System.Threading.Tasks;

namespace Application
{
    public class WorkHourLogic : IWorkHourLogic
    {
        private readonly IAsyncRepository<WorkHour> workHourRepository;
        private readonly IAsyncRepository<User> userRepository;

        public WorkHourLogic(IAsyncRepository<WorkHour> workHourRepository, IAsyncRepository<User> userRepository)
        {
            this.workHourRepository = workHourRepository ?? throw new ArgumentNullException(nameof(workHourRepository));
            this.userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
        }

        public Task<PagedList<WorkHour>> GetWorkHours(WorkHourParameters workHourParameters)
        {
            return workHourRepository.GetAll(workHourParameters);
        }

        public async Task<WorkHour> CreateWorkHour(WorkHour newWorkHour)
        {
            if (userRepository.CountAll().Result > 0
                && userRepository.GetWhere(row => row.Id == newWorkHour.UserId).Result.Count == 0)
                return null;
            return await workHourRepository.Create(newWorkHour);
        }

        public async Task<WorkHour> UpdateWorkHour(Guid id, WorkHour newWorkHour)
        {
            var currentWorkHour = await FindWorkHourById(id);

            if (currentWorkHour == null)
            {
                return null;
            }

            currentWorkHour.StartDateTime = newWorkHour.StartDateTime;
            currentWorkHour.EndDateTime = newWorkHour.EndDateTime;

            return await workHourRepository.Update(currentWorkHour);
        }

        public Task<PagedList<WorkHour>> FindWorkHourByUserId(Guid userId, WorkHourParameters workHourParameters)
        {
            return workHourRepository.GetAllWhere(workHourParameters, row => row.UserId == userId);
        }

        public Task<WorkHour> FindWorkHourById(Guid id)
        {
            return workHourRepository.GetById(id);
        }

        public Task<bool> DeleteWorkHour(Guid id)
        {
            return workHourRepository.Delete(id);
        }
    }
}