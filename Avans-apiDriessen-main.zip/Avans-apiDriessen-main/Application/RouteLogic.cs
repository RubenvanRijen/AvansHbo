﻿using Application.Interfaces;
using Domain.Models;
using Newtonsoft.Json.Linq;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.AuxiliaryLogics.Interfaces;
using Domain;
using Persistence;
using Domain.Models.QueryStringParameters;

namespace Application
{
    public class RouteLogic : IRouteLogic
    {     
        private readonly IAsyncRepository<Route> routeRepository;
        private readonly IAsyncRepository<User> userRepository;
        private readonly ILookupRepository<Status> statusRepository;
        private readonly ILookupRepository<Company> companyRepository;
        private readonly IAsyncRepository<KilometerAllowance> kilometerAllowanceRepository;
        private readonly IAsyncRepository<Placement> placementRepository;


        private readonly IMapboxLogic mapboxLogic;
        private readonly IValidationLogic validationLogic;

        public RouteLogic(IAsyncRepository<Route> routeRepository, IAsyncRepository<User> userRepository, 
            ILookupRepository<Status> statusRepository, ILookupRepository<Company> companyRepository, IAsyncRepository<KilometerAllowance> kilometerAllowanceRepository, IAsyncRepository<Placement> placementRepository, IMapboxLogic mapboxLogic, IValidationLogic validationLogic)
        {
            this.routeRepository = routeRepository ?? throw new ArgumentNullException(nameof(routeRepository));
            this.userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
            this.statusRepository = statusRepository ?? throw new ArgumentNullException(nameof(statusRepository));
            this.companyRepository = companyRepository ?? throw new ArgumentNullException(nameof(companyRepository));
            this.kilometerAllowanceRepository = kilometerAllowanceRepository ?? throw new ArgumentNullException(nameof(kilometerAllowanceRepository));
            this.placementRepository = placementRepository ?? throw new ArgumentNullException(nameof(placementRepository));

            this.mapboxLogic = mapboxLogic ?? throw new ArgumentNullException(nameof(mapboxLogic));
            this.validationLogic = validationLogic ?? throw new ArgumentNullException(nameof(validationLogic));
        }

        public async Task<Route> CreateRoute(Route newRoute, bool isGpsData)
        {
            if (!isGpsData) { 
                newRoute.CompanyName = placementRepository.GetById((Guid)newRoute.PlacementId).Result.CompanyName;
                newRoute.AllowanceTypeName = kilometerAllowanceRepository.GetById((Guid)newRoute.KilometerAllowanceId).Result.AllowanceTypeName;
            }
            var json = newRoute.SerializedRoute;
            JArray parsedJson = JArray.Parse(json);

            var firstCordinates = parsedJson.ToArray().ToList().Select(row => row["longitude"] + "," + row["latitude"]).First().ToString();
            var lastCordinates = parsedJson.ToArray().ToList().Select(row => row["longitude"] + "," + row["latitude"]).Last().ToString();
            newRoute.StartLocation = mapboxLogic.GetLocation(firstCordinates).Result;
            newRoute.EndLocation = mapboxLogic.GetLocation(lastCordinates).Result;

            var route = GetRoute(newRoute, parsedJson, isGpsData);

            if (route == null)
                return null;
            if (route.SerializedMapRoute == null)
                return null;

            return await routeRepository.Create(route);
        }

        private Route GetRoute(Route newRoute, JArray parsedJson, bool isGpsData)
        {
            float distance = 0;
            List<Position> positions = new List<Position>();
            if(isGpsData)
                return GetGPSRoute(newRoute, parsedJson, distance, positions);
            else
                return GetMapRoute(newRoute, parsedJson, distance, positions);
        }

        private Route GetMapRoute(Route newRoute, JArray parsedJson, float distance, List<Position> positions)
        {
            // Divides array into sub arrays with a max length of 99.
            var chunks = parsedJson.ToArray().ToList().Select((s, i) => new { Value = s, Index = i }).GroupBy(x => x.Index / 24).Select(grp => grp.Select(x => x.Value).ToArray())
                     .ToArray();
            // Mapbox only accepts 100 location point at the time. The number of chunks is therefor the number of call to the api.
            for (int i = 0; i < chunks.Length; i++)
            {
                var result = chunks[i].ToList().Select((value, i) => string.Format("{0},{1}", value["longitude"], value["latitude"])).ToArray();

                if (i != chunks.Length - 1)
                    result.Append(chunks[i + 1][0]["longitude"] + "," + chunks[i + 1][0]["latitude"]);

                string coordinatesString = string.Join(";", result);

                var route = mapboxLogic.GetRoute(coordinatesString);
                if (route.Result.Routes == null || route.Result.Routes.Count == 0)
                    return null;

                distance += route.Result.Routes[0].Distance;
                positions.AddRange(route.Result.Routes[0].Geometry.Coordinates.ToList().Select((value, i) => new Position { lat = value[1], lng = value[0] }));
            }
            newRoute.Distance = distance;
            newRoute.SerializedMapRoute = System.Text.Json.JsonSerializer.Serialize(positions);
            return newRoute;
        }

        private Route GetGPSRoute(Route newRoute, JArray parsedJson, float distance, List<Position> positions)
        {
            // Divides array into sub arrays with a max length of 24.
            var chunks = parsedJson.ToArray().ToList().Select((s, i) => new { Value = s, Index = i }).GroupBy(x => x.Index / 99).Select(grp => grp.Select(x => x.Value).ToArray())
                     .ToArray();
            // Mapbox only accepts 25 location point at the time. The number of chunks is therefor the number of call to the api.
            for (int i = 0; i < chunks.Length; i++)
            {
                var result = chunks[i].ToList().Select((value, i) => string.Format("{0},{1}", value["longitude"], value["latitude"])).ToArray();

                if (i != chunks.Length - 1)
                    result.Append(chunks[i + 1][0]["longitude"] + "," + chunks[i + 1][0]["latitude"]);

                string coordinatesString = string.Join(";", result);

                var route = mapboxLogic.GetGPSRoute(coordinatesString);
                if (route.Result.Matchings == null || route.Result.Matchings.Count == 0)
                    return null;

                distance += route.Result.Matchings[0].Distance;
                positions.AddRange(route.Result.Matchings[0].Geometry.Coordinates.ToList().Select((value, i) => new Position { lat = value[1], lng = value[0] }));
            }
            newRoute.Distance = distance;
            newRoute.SerializedMapRoute = System.Text.Json.JsonSerializer.Serialize(positions);
            return newRoute;
        }

        public Task<bool> DeleteRoute(Guid id)
        {
            return routeRepository.Delete(id);
        }

        public async Task<PagedList<Route>> FindRouteByUserId(Guid userId, RouteParameters routeParameters)
        {
            var routes = routeRepository.GetAllWhere(routeParameters, row => row.UserId == userId).Result;
            if (routes == null)
                return null;

            routes.ForEach(row => row.EstimatedPayment = GetRoutePrice(row.Id));

            return routes;
        }

        public async Task<Route> FindRouteById(Guid id)
        {
            var route = routeRepository.GetById(id).Result;
            if (route == null)
                return null;
            route.EstimatedPayment = GetRoutePrice(route.Id);
            return route;
        }

        public async Task<PagedList<Route>> GetRoutes(RouteParameters routeParameters)
        {
            var routes= routeRepository.GetAll(routeParameters).Result;
            if (routes == null) 
                return null;
            
            routes.ForEach(row => row.EstimatedPayment = GetRoutePrice(row.Id));
            return routes;
        }

        public async Task<Route> UpdateRoute(Guid id, Route newRoute)
        {
            var currentRoute = await FindRouteById(id);

            newRoute.CompanyName = placementRepository.GetById((Guid)newRoute.PlacementId).Result.CompanyName;
            newRoute.AllowanceTypeName = kilometerAllowanceRepository.GetById((Guid)newRoute.KilometerAllowanceId).Result.AllowanceTypeName;

            currentRoute.StatusName = newRoute.StatusName;
            currentRoute.Distance = newRoute.Distance;
            currentRoute.PlacementId = newRoute.PlacementId;
            currentRoute.KilometerAllowanceId = newRoute.KilometerAllowanceId;
            currentRoute.AllowanceTypeName = newRoute.AllowanceTypeName;
            currentRoute.CompanyName = newRoute.CompanyName;

            return await routeRepository.Update(currentRoute);
        }

        public double GetRoutePrice(Guid id)
        {
            var route = routeRepository.GetById(id).Result;
            double noPrice = 0.00;
            if (route == null)
            {
                return noPrice;
            }

            if (route.KilometerAllowanceId == null)
            {
                return noPrice;
            }
            var kilometerAllowance = kilometerAllowanceRepository.GetById((Guid)route.KilometerAllowanceId);

            if (kilometerAllowance.Result.MinDistance > route.Distance || kilometerAllowance == null)
            {
                return noPrice;
            }
            var price = kilometerAllowance.Result.Price;
            var totalPrice = (price * (route.Distance / 1000));
            return totalPrice;
        }
    }
    public class Position
    {
        public float lat { get; set; }
        public float lng { get; set; }
    }
}

