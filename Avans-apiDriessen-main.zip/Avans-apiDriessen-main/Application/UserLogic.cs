﻿using Application.AuxiliaryLogics.Interfaces;
using Application.Interfaces;
using Domain.Models;
using EmailService.Interfaces;
using EmailService.Models;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Domain.Models.QueryStringParameters;
using Persistence;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;


namespace Application
{
    public class UserLogic : IUserLogic
    {
        private readonly IAsyncRepository<User> userRepository;

        private readonly IAsyncRepository<UserPlacement> userPlacementRepository;
        private readonly IAsyncRepository<Placement> placementRepository;

        private readonly IEmailLogic emailLogic;

        public UserLogic(IAsyncRepository<User> userRepository, IAsyncRepository<UserPlacement> userPlacementRepository,
            IAsyncRepository<Placement> placementRepository, IEmailLogic emailLogic)
        {
            this.userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
            this.userPlacementRepository = userPlacementRepository ??
                                           throw new ArgumentNullException(nameof(userPlacementRepository));
            this.placementRepository =
                placementRepository ?? throw new ArgumentNullException(nameof(placementRepository));
                this.emailLogic = emailLogic ?? throw new ArgumentNullException(nameof(emailLogic));
        }

        public async Task<User> CreateNewUser(User newUser)
        {
            if (userRepository.CountAll().Result > 0
                && userRepository.GetWhere(row => row.Email == newUser.Email).Result.Count > 0)
                return null;

            newUser.RoleName = char.ToUpper(newUser.RoleName[0]) + newUser.RoleName.Substring(1);
            newUser.FirstName = char.ToUpper(newUser.FirstName[0]) + newUser.FirstName.Substring(1);
            newUser.LastName = char.ToUpper(newUser.LastName[0]) + newUser.LastName.Substring(1);
            
            if(newUser.Password == null)
            {
                newUser.Password = GenerateRandomPassword(true,true,true,true,32,10);
                emailLogic.sendAsynceMail(newUser);
            }
            newUser.Password = BCrypt.Net.BCrypt.HashPassword(newUser.Password);

            var user = await userRepository.Create(newUser);
            return user;
        }

        private static string GenerateRandomPassword(bool requireUppercase, bool requireLowercase, bool requireDigit, bool requireNonAlphanumeric, int requiredLength, int requiredUniqueChars)
        {
            string[] randomChars = new[] {
            "ABCDEFGHJKLMNOPQRSTUVWXYZ",    // uppercase 
            "abcdefghijkmnopqrstuvwxyz",    // lowercase
            "0123456789",                   // digits
            "!@$?_-"                        // non-alphanumeric
            };

            Random rand = new Random(Environment.TickCount);
            List<char> chars = new List<char>();

            if (requireUppercase)
                chars.Insert(rand.Next(0, chars.Count),
                    randomChars[0][rand.Next(0, randomChars[0].Length)]);

            if (requireLowercase)
                chars.Insert(rand.Next(0, chars.Count),
                    randomChars[1][rand.Next(0, randomChars[1].Length)]);

            if (requireDigit)
                chars.Insert(rand.Next(0, chars.Count),
                    randomChars[2][rand.Next(0, randomChars[2].Length)]);
            if (requireNonAlphanumeric)
                chars.Insert(rand.Next(0, chars.Count),
                    randomChars[3][rand.Next(0, randomChars[3].Length)]);

            for (int i = chars.Count; i < requiredLength
                || chars.Distinct().Count() < requiredUniqueChars; i++)
            {
                string rcs = randomChars[rand.Next(0, randomChars.Length)];
                chars.Insert(rand.Next(0, chars.Count),
                    rcs[rand.Next(0, rcs.Length)]);
            }
            return new string(chars.ToArray());
        }

        public async Task<bool> SoftDeleteUser(Guid id)
        {
            var user = await userRepository.GetById(id);
            if (user == null) return false;

            user.IsDeleted = true;
            await userRepository.Update(user);

            return true;
        }

        public Task<User> FindUserById(Guid id)
        {
            return userRepository.GetById(id);
        }

        public Task<PagedList<User>> GetAllUsers(UserParameters userParameters)
        {
            return userRepository.GetAll(userParameters);
        }

        public async Task<User> UpdateUser(Guid id, User updateUser)
        {
            var currentUser = await FindUserById(id);

            if (currentUser == null)
                return null;

            //TODO: we whould improve our error message 'system'
            if (userRepository.CountAll().Result > 0 && updateUser.Email != currentUser.Email
                                                     && userRepository.GetWhere(row => row.Email == updateUser.Email)
                                                         .Result.Count > 0)
                return null;

            currentUser.Email = updateUser.Email ?? currentUser.Email;
            currentUser.FirstName = updateUser.FirstName ?? currentUser.FirstName;
            currentUser.LastName = updateUser.LastName ?? currentUser.LastName;
            currentUser.AccountNumber = updateUser.AccountNumber ?? currentUser.AccountNumber;
            currentUser.Image = updateUser.Image ?? currentUser.Image;
            currentUser.CompanyName = updateUser.CompanyName ?? currentUser.CompanyName;

            if (updateUser.Password != null)
                currentUser.Password = BCrypt.Net.BCrypt.HashPassword(updateUser.Password);

            return await userRepository.Update(currentUser);
        }

        public async Task<PagedList<User>> GetUsersFromCompany(string companyName, UserParameters usersParameters)
        {
            var userPlacements = new List<UserPlacement>();
            var usersID = new List<Guid>();
            var users = new List<User>();

            var placements =
                this.placementRepository.GetWhere(row => row.CompanyName.Equals(companyName)).Result;

            if (placements == null)
                return null;

            placements.ForEach(placement =>
            {
                userPlacements.AddRange(userPlacementRepository.GetWhere(row => row.PlacementId == placement.Id)
                    .Result);
            });

            userPlacements.ForEach(userPlacement =>
            {
                if (!usersID.Contains(userPlacement.UserId))
                {
                    var result = userRepository.FirstOrDefault(row => row.Id == userPlacement.UserId).Result;
                    usersID.Add(result.Id);
                    users.Add(result);
                }
            });
            var employers = userRepository.GetWhere(row => row.CompanyName == companyName && row.RoleName == "Employer")
                .Result;

            employers.ForEach(user =>
            {
                if (!usersID.Contains(user.Id))
                {
                    usersID.Add(user.Id);
                    users.Add(user);
                }
            });

            //This piece of code is to filter the users pased on the queryParameters
            var userFiltered = users.Where(usersParameters.Filter).ToList();
            var usersQueryable = userFiltered.AsQueryable();

            return PagedList<User>.ToPagedList(usersQueryable, usersParameters.PageNumber, usersParameters.PageSize);
        }
    }
}