﻿using Domain.Models;
using Domain.Models.QueryStringParameters;
using Persistence;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application.Interfaces
{
    public interface IUserPlacementLogic
    {
        Task<UserPlacement> CreateUserPlacement(UserPlacement newUserPlacement);
        Task<bool> DeleteUserPlacement(Guid id);
        Task<UserPlacement> FindUserPlacementById(Guid id);
        Task<PagedList<UserPlacement>> GetUserPlacements(UserPlacementParameters userPlacementParameters);
        Task<PagedList<UserPlacement>> GetUserPlacementsWithPlacementId(Guid placementId, UserPlacementParameters userPlacementParameters);
        Task<PagedList<UserPlacement>> GetUserPlacementsWithUserId(Guid userId, UserPlacementParameters userPlacementParameters);
        Task<bool> UserPlacementAlreadyExists(Guid userId, Guid placementId);
    }
}
