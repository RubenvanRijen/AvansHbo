﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Application.Interfaces
{
    public interface ICompanyLogic
    {
        Task<List<Company>> GetCompanies();
        Task<Company> GetCompanyByName(string name);
        Task<List<Company>> GetCompaniesByUserId(Guid userId);
        Task<Company> CreateCompany(Company newCompany);
    }
}