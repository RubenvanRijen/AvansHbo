﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application.Interfaces
{
    public interface ICompanyHolidayLogic
    {
        Task<CompanyHoliday> CreateCompanyHoliday(CompanyHoliday companyHoliday);
        Task<CompanyHoliday> FindCompanyHolidayById(Guid id);

        Task<List<CompanyHoliday>> GetCompanyHolidaysByCompanyName(string companyName);
        Task<CompanyHoliday> UpdateCompanyHoliday(CompanyHoliday companyHoliday);
        Task<bool> DeleteCompanyHoliday(Guid id);
    }
}
