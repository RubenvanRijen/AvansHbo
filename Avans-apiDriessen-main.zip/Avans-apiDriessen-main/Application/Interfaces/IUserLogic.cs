﻿using Domain.Models;
using Domain.Models.QueryStringParameters;
using Persistence;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Application.Interfaces
{
    public interface IUserLogic
    {
        Task<User> CreateNewUser(User newUser);
        Task<bool> SoftDeleteUser(Guid id);
        Task<User> FindUserById(Guid id);
        Task<PagedList<User>> GetAllUsers(UserParameters userParameters);
        Task<User> UpdateUser(Guid id, User updateUser);
        Task<PagedList<User>> GetUsersFromCompany(string companyName, UserParameters userParameters);
    }
}