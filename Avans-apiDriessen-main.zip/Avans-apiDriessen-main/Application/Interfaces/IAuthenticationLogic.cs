﻿using System.Threading.Tasks;
using Domain.Models.Authentication;

namespace Application.Interfaces
{
    public interface IAuthenticationLogic
    {
        Task<string> Authenticate(AuthenticationRequest authenticationRequest);
    }
}