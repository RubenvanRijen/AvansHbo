﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application.Interfaces
{
    public interface IHolidayLogic
    {
        #region All
        Task<Holiday> CreateHoliday(Holiday holiday);
        Task<Holiday> FindHolidayById(Guid id);
        Task<List<Holiday>> GetHolidayByUserId(Guid userId);
        Task<Holiday> UpdateHoliday(Holiday holiday);
        Task<bool> DeleteHoliday(Guid id);
        #endregion
    }
}
