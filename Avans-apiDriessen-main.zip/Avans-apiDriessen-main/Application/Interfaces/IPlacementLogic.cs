﻿using Domain.Models;
using Domain.Models.QueryStringParameters;
using Persistence;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application.Interfaces
{
    public interface IPlacementLogic
    {
        Task<Placement> CreatePlacement(Placement newPlacement);
        Task<bool> DeletePlacement(Guid id);
        Task<Placement> FindPlacementById(Guid id);
        Task<PagedList<Placement>> GetPlacements(PlacementParameters placementParameters);
        Task<Placement> UpdatePlacement(Guid id, Placement newPlacement);
        Task<PagedList<Placement>> FindPlacementsByCompanyName(string companyName, PlacementParameters placementParameters);
        Task<PagedList<Placement>> FindPlacementsByUserId(Guid userId, PlacementParameters placementParameters);
    }
}
