﻿using Domain.Models;
using Domain.Models.QueryStringParameters;
using Persistence;
using System;
using System.Threading.Tasks;

namespace Application.Interfaces
{
    public interface IRouteLogic
    {
        Task<Route> CreateRoute(Route newRoute, bool isGPSData);
        Task<bool> DeleteRoute(Guid id);
        Task<Route> FindRouteById(Guid id);
        Task<PagedList<Route>> FindRouteByUserId(Guid userId, RouteParameters routeParameters);
        Task<PagedList<Route>> GetRoutes(RouteParameters routeParameters);
        Task<Route> UpdateRoute(Guid id, Route newRoute);

        double GetRoutePrice(Guid id);
    }
}