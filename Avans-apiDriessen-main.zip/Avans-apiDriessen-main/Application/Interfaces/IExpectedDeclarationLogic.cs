﻿using System;
using System.Threading.Tasks;
using Domain.AuxiliaryModels;

namespace Application.Interfaces
{
    public interface IExpectedDeclarationLogic
    {
        public Task<ExpectedDeclaration> CalculateExpectedDeclarationForUser(Guid userId);
    }
}