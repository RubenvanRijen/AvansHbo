﻿using Domain;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using Persistence;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Application
{
    public interface IKilometerAllowanceLogic
    {
        Task<KilometerAllowance> CreateKilometerAllowance(KilometerAllowance newKilometerAllowance);
        Task<bool> DeleteKilometerAllowance(Guid id);
        Task<KilometerAllowance> FindKilometerAllowanceById(Guid id);
        Task<PagedList<KilometerAllowance>> GetKilometerAllowances(KilometerAllowanceParameters routeParameters);
        Task<KilometerAllowance> UpdateKilometerAllowance(Guid id, KilometerAllowance newKilometerAllowance);
        Task<List<KilometerAllowance>> FindKilometerAllowancesByUserId(Guid userId);
    }
}