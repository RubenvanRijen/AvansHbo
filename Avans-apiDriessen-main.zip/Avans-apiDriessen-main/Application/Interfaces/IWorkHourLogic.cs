﻿using Domain;
using Domain.Models.QueryStringParameters;
using Persistence;
using System;
using System.Threading.Tasks;

namespace Application
{
    public interface IWorkHourLogic
    {
        Task<WorkHour> CreateWorkHour(WorkHour newWorkHour);
        Task<bool> DeleteWorkHour(Guid id);
        Task<WorkHour> FindWorkHourById(Guid id);
        Task<PagedList<WorkHour>> GetWorkHours(WorkHourParameters routeParameters);
        Task<WorkHour> UpdateWorkHour(Guid id, WorkHour newWorkHour);
        Task<PagedList<WorkHour>> FindWorkHourByUserId(Guid userId, WorkHourParameters workHourParameters);
    }
}