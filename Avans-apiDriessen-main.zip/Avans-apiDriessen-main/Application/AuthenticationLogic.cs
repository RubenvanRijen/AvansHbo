﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Application.Interfaces;
using Domain.AuxiliaryModels;
using Domain.Models;
using Domain.Models.Authentication;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Persistence.Repositories.Interfaces;

namespace Application
{
    public class AuthenticationLogic : IAuthenticationLogic
    {
        private readonly IAsyncRepository<User> userRepository;
        private readonly JwtSecurityTokenHandler tokenHandler;

        private readonly SigningCredentials signingCredentials;

        public AuthenticationLogic(IAsyncRepository<User> userRepository, IOptions<JwtSettings> jwtSettings)
        {
            if (jwtSettings is null)
            {
                throw new System.ArgumentNullException(nameof(jwtSettings));
            }

            this.userRepository = userRepository ?? throw new System.ArgumentNullException(nameof(userRepository));
            tokenHandler = new JwtSecurityTokenHandler();

            var keyBytes = Encoding.UTF8.GetBytes(jwtSettings.Value.Key);
            var symmetricSecurityKey = new SymmetricSecurityKey(keyBytes);
            signingCredentials = new SigningCredentials(symmetricSecurityKey, SecurityAlgorithms.HmacSha256Signature);
        }

        public async Task<string> Authenticate(AuthenticationRequest authenticationRequest)
        {
            var user = await userRepository.FirstOrDefault(u => u.Email == authenticationRequest.Email);
            if (user == null || !BCrypt.Net.BCrypt.Verify(authenticationRequest.Password, user.Password)) return null;

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Role, user.RoleName),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim("sub", user.Id.ToString()),
                new Claim("firstName", user.FirstName),
                new Claim("lastName", user.LastName)
            };

            if (user.CompanyName != null)
            {
                claims.Add(new Claim("company", user.CompanyName));
            }

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = signingCredentials
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);

            return tokenHandler.WriteToken(token);
        }
    }
}