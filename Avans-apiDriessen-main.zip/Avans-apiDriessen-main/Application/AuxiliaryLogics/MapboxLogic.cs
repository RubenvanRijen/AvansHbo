﻿using Application.AuxiliaryLogics.Interfaces;
using Domain.AuxiliaryModels;
using Domain.AuxiliaryModels.MapboxModels;
using Domain.AuxiliaryModels.MapboxModels.LocationModels;
using Domain.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Application.AuxiliaryLogics
{
    public class MapboxLogic : IMapboxLogic
    {
        private readonly MapboxSetting mapboxSetting;
        private string urlParameters = "?alternatives=false&geometries=geojson&steps=false&access_token=";
        private string urlGPSParameters = "?geometries=geojson&access_token=";
        private string urlParametersLocation = ".json?access_token=";

        public MapboxLogic(IOptions<MapboxSetting> mapboxSetting)
        {
            this.mapboxSetting = mapboxSetting.Value ?? throw new ArgumentNullException(nameof(mapboxSetting));
            ;
        }

        public async Task<MapboxRoute> GetRoute(string coordinates)
        {
            HttpClient client = new HttpClient();

            client.BaseAddress = new Uri(mapboxSetting.ApiUrl);

            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));

            // List data response.
            HttpResponseMessage
                response = client.GetAsync(coordinates + urlParameters + mapboxSetting.ApiKey)
                    .Result; // Blocking call! Program will wait here until a response is received or a timeout occurs.            if (response.IsSuccessStatusCode)

            if (response.IsSuccessStatusCode)
            {
                // Parse the response body.
                string responseBody = await response.Content.ReadAsStringAsync();
                var route = JsonConvert.DeserializeObject<MapboxRoute>(responseBody);
                client.Dispose();
                return route;
            }
            else
            {
                client.Dispose();
                return null;
            }
        }

        public async Task<MapboxGPSRoute> GetGPSRoute(string coordinates)
        {
            HttpClient client = new HttpClient();

            client.BaseAddress = new Uri(mapboxSetting.ApiGPSUrl);

            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));

            // List data response.
            HttpResponseMessage
                response = client.GetAsync(coordinates + urlGPSParameters + mapboxSetting.ApiKey)
                    .Result; // Blocking call! Program will wait here until a response is received or a timeout occurs.            if (response.IsSuccessStatusCode)

            if (response.IsSuccessStatusCode)
            {
                // Parse the response body.
                string responseBody = await response.Content.ReadAsStringAsync();
                var route = JsonConvert.DeserializeObject<MapboxGPSRoute>(responseBody);
                client.Dispose();
                return route;
            }
            else
            {
                client.Dispose();
                return null;
            }
        }

        public async Task<string> GetLocation(string coordinates)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(mapboxSetting.ApiUrlLocation);

            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));

            // List data response.
            HttpResponseMessage response = client
                .GetAsync(coordinates + urlParametersLocation + mapboxSetting.ApiKey + "&limit=1")
                .Result; // Blocking call! Program will wait here until a response is received or a timeout occurs.            if (response.IsSuccessStatusCode)

            if (response.IsSuccessStatusCode)
            {
                // Parse the response body.
                string responseBody = await response.Content.ReadAsStringAsync();
                var location = JsonConvert.DeserializeObject<MapboxLocation>(responseBody);
                client.Dispose();
                return location.Features.Select(row => row.Context[1].Text).First();
            }
            else
            {
                client.Dispose();
            }

            return null;
        }
    }
}