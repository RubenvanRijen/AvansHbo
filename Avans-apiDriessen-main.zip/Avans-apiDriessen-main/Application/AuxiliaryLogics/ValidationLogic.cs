﻿using Application.AuxiliaryLogics.Interfaces;
using Domain;
using Domain.Models;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application.AuxiliaryLogics
{
    public class ValidationLogic : IValidationLogic
    {
        private readonly IAsyncRepository<User> userRepository;
        private readonly ILookupRepository<Company> companyRepository;
        private readonly ILookupRepository<Status> statusRepository;
        private readonly IAsyncRepository<KilometerAllowance> kilometerAllowanceRepository;
        private readonly IAsyncRepository<Placement> placementRepository;
        private readonly IAsyncRepository<WorkHour> workHourRepository;

        public ValidationLogic(
            ILookupRepository<Company> companyRepository,
            IAsyncRepository<User> userRepository,
            ILookupRepository<Status> statusRepository,
            IAsyncRepository<KilometerAllowance> kilometerAllowanceRepository,
            IAsyncRepository<Placement> placementRepository, IAsyncRepository<WorkHour> workHourRepository)
        {
            this.companyRepository = companyRepository ?? throw new ArgumentNullException(nameof(companyRepository));
            this.userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
            this.statusRepository = statusRepository ?? throw new ArgumentNullException(nameof(statusRepository));
            this.kilometerAllowanceRepository = kilometerAllowanceRepository ??
                                                throw new ArgumentNullException(nameof(kilometerAllowanceRepository));
            this.placementRepository =
                placementRepository ?? throw new ArgumentNullException(nameof(placementRepository));
            this.workHourRepository = workHourRepository ?? throw new ArgumentNullException(nameof(workHourRepository));
        }

        public async Task<bool> CompanyDoesNotExist(string companyName)
        {
            if (companyRepository.CountAll().Result == 0
                || companyRepository.CountWhere(row => row.Name == companyName).Result == 0)
                return true;
            return false;
        }

        public async Task<bool> UserDoesNotExist(Guid userId)
        {
            if (userRepository.CountAll().Result == 0
                || userRepository.CountWhere(row => row.Id == userId).Result == 0)
                return true;
            return false;
        }

        public async Task<bool> StatusDoesNotExist(string statusName)
        {
            if (statusRepository.CountAll().Result == 0 ||
                statusRepository.CountWhere(row => row.Name.Equals(statusName)).Result == 0)
                return true;
            return false;
        }

        public async Task<bool> CompanyAllowanceTypeNameDoesNotExist(string companyName, string allowanceTypeName)
        {
            if (CompanyDoesNotExist(companyName).Result)
                return true;
            if (kilometerAllowanceRepository.CountAll().Result == 0 || kilometerAllowanceRepository
                .CountWhere(row => row.CompanyName.Equals(companyName)).Result == 0)
                return true;
            if (kilometerAllowanceRepository.CountWhere(row =>
                row.CompanyName.Equals(companyName) && row.AllowanceTypeName.Equals(allowanceTypeName)).Result == 0)
                return true;
            return false;
        }

        public async Task<bool> PlacementDoesNotExist(Guid? placementId)
        {
            if (placementRepository.CountAll().Result == 0 || placementRepository
                                                               .CountWhere(row => row.Id == placementId).Result == 0
                                                           || placementId == null || placementId == Guid.Empty)
                return true;
            return false;
        }

        public async Task<bool> KilometerAllowanceDoesNotExist(Guid? kilometerAllowanceId)
        {
            if (kilometerAllowanceRepository.CountAll().Result == 0 || kilometerAllowanceRepository
                                                                        .CountWhere(row =>
                                                                            row.Id == kilometerAllowanceId).Result == 0
                                                                    || kilometerAllowanceId == null ||
                                                                    kilometerAllowanceId == Guid.Empty)
                return true;
            return false;
        }

        public async Task<bool> WorkHourOverlaps(WorkHour workHour)
        {
            var overlappingWorkHours = await workHourRepository.GetWhere(row =>
                row.UserId == workHour.UserId
                && ((workHour.StartDateTime >= row.StartDateTime && workHour.StartDateTime <= row.EndDateTime)
                    || (workHour.EndDateTime >= row.StartDateTime && workHour.EndDateTime <= row.EndDateTime)
                    || (workHour.StartDateTime < row.StartDateTime && workHour.EndDateTime > row.EndDateTime))
            );
            return overlappingWorkHours.Count > 0;
        }

        public async Task<bool> WorkHourOverlaps(WorkHour workHour, Guid exceptId)
        {
            var overlappingWorkHours = await workHourRepository.GetWhere(row =>
                row.UserId == workHour.UserId && row.Id != exceptId
                && ((workHour.StartDateTime >= row.StartDateTime && workHour.StartDateTime <= row.EndDateTime)
                    || (workHour.EndDateTime >= row.StartDateTime && workHour.EndDateTime <= row.EndDateTime)
                    || (workHour.StartDateTime < row.StartDateTime && workHour.EndDateTime > row.EndDateTime))
            );
            return overlappingWorkHours.Count > 0;
        }
    }
}