﻿using Application.AuxiliaryLogics.Interfaces;
using Domain.Models;
using EmailService.Interfaces;
using EmailService.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application.AuxiliaryLogics
{
    public class EmailLogic :IEmailLogic
    {
        private readonly IEmailSender emailSender;
        public EmailLogic(IEmailSender emailSender)
        {
            this.emailSender = emailSender;
        }

        public async Task sendAsynceMail(User user)
        {
            if (user != null)
            {
                var message = new Message(new string[] { user.Email }, "Registratie mail", user.Password);
                await emailSender.SendEmailAsync(message);
            }
        }
    }
}
