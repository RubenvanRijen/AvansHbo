﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Domain;

namespace Application.AuxiliaryLogics.Interfaces
{
    public interface IValidationLogic
    {
        //https://docs.microsoft.com/en-us/dotnet/standard/design-guidelines/general-naming-conventions
        Task<bool> UserDoesNotExist(Guid userId);
        Task<bool> CompanyDoesNotExist(string companyName);
        Task<bool> StatusDoesNotExist(string statusName);
        Task<bool> CompanyAllowanceTypeNameDoesNotExist(string companyName, string allowanceTypeName);
        Task<bool> PlacementDoesNotExist(Guid? placementId);
        Task<bool> KilometerAllowanceDoesNotExist(Guid? kilometerAllowanceId);
        Task<bool> WorkHourOverlaps(WorkHour workHour);
        Task<bool> WorkHourOverlaps(WorkHour workHour, Guid exceptId);
    }
}
