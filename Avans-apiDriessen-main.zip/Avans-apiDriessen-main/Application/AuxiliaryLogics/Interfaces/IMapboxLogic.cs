﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using static Application.AuxiliaryLogics.MapboxLogic;
using Domain.AuxiliaryModels;
using Domain.AuxiliaryModels.MapboxModels;

namespace Application.AuxiliaryLogics.Interfaces
{
    public interface IMapboxLogic
    {
        Task<MapboxRoute> GetRoute(string coordinates);
        Task<MapboxGPSRoute> GetGPSRoute(string coordinates);
        Task<string> GetLocation(string coordinates);
    }
}
