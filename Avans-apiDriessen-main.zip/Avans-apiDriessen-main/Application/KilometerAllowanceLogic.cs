﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Application.AuxiliaryLogics.Interfaces;
using Domain;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using Persistence;
using Persistence.Repositories.Interfaces;

namespace Application
{
    public class KilometerAllowanceLogic : IKilometerAllowanceLogic
    {
        private readonly IAsyncRepository<KilometerAllowance> kilometerAllowanceRepository;
        private readonly IAsyncRepository<Placement> placementRepository;
        private readonly IAsyncRepository<UserPlacement> userPlacementRepository;

        private readonly IValidationLogic validationLogic;

        public KilometerAllowanceLogic(IAsyncRepository<KilometerAllowance> kilometerAllowanceRepository, IAsyncRepository<Placement> placementRepository, IAsyncRepository<UserPlacement> userPlacementRepository, IValidationLogic validationLogic)
        {
            this.kilometerAllowanceRepository = kilometerAllowanceRepository ?? throw new ArgumentNullException(nameof(kilometerAllowanceRepository));
            this.placementRepository = placementRepository ?? throw new ArgumentNullException(nameof(placementRepository));
            this.userPlacementRepository = userPlacementRepository ?? throw new ArgumentNullException(nameof(userPlacementRepository));
            this.validationLogic = validationLogic ?? throw new ArgumentNullException(nameof(validationLogic));
        }

        public Task<PagedList<KilometerAllowance>> GetKilometerAllowances(KilometerAllowanceParameters kilometerAllowanceParameters)
        {
            return kilometerAllowanceRepository.GetAll(kilometerAllowanceParameters);
        }

        public Task<KilometerAllowance> CreateKilometerAllowance(KilometerAllowance newKilometerAllowance)
        {
            return kilometerAllowanceRepository.Create(newKilometerAllowance);
        }

        public async Task<KilometerAllowance> UpdateKilometerAllowance(Guid id,
            KilometerAllowance newKilometerAllowance)
        {
            var currentKilometerAllowance = await FindKilometerAllowanceById(id);

            if (currentKilometerAllowance == null)
            {
                return null;
            }

            currentKilometerAllowance.Price = newKilometerAllowance.Price;
            currentKilometerAllowance.MinDistance = newKilometerAllowance.MinDistance;

            return await kilometerAllowanceRepository.Update(currentKilometerAllowance);
        }

        public Task<KilometerAllowance> FindKilometerAllowanceById(Guid id)
        {
            return kilometerAllowanceRepository.GetById(id);
        }

        public Task<bool> DeleteKilometerAllowance(Guid id)
        {
            return kilometerAllowanceRepository.Delete(id);
        }

        public async Task<List<KilometerAllowance>> FindKilometerAllowancesByUserId(Guid userId)
        {
            if (await validationLogic.UserDoesNotExist(userId)) { 
                return null;
            }

            List<Placement> placements = new List<Placement>();
            var userPlacements = await userPlacementRepository.GetWhere(row => row.UserId == userId);
            if (userPlacements != null && userPlacements.Count > 0) { 
                foreach (UserPlacement userPlacement in userPlacements) { 
                    placements.Add(await placementRepository.GetById(userPlacement.PlacementId));
                }
            }

            List<KilometerAllowance> kilometerAllowances = new List<KilometerAllowance>();
            if (placements != null && placements.Count > 0) { 
                foreach (Placement placement in placements) { 
                    kilometerAllowances.AddRange(await kilometerAllowanceRepository.GetWhere(row => row.CompanyName == placement.CompanyName));
                }
            }

            return kilometerAllowances;
        }
    }
}