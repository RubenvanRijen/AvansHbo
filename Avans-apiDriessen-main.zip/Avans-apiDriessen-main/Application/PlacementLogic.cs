﻿using Application.AuxiliaryLogics.Interfaces;
using Application.Interfaces;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using Persistence;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application
{
    public class PlacementLogic : IPlacementLogic
    {
        private readonly IAsyncRepository<Placement> placementRepository;
        private readonly IAsyncRepository<UserPlacement> userPlacementRepository;

        private readonly IValidationLogic validationLogic;
        public PlacementLogic(IAsyncRepository<Placement> placementRepository, IAsyncRepository<UserPlacement> userPlacementRepository,IValidationLogic validationLogic)
        {
            this.placementRepository = placementRepository ?? throw new ArgumentNullException(nameof(placementRepository));
            this.userPlacementRepository = userPlacementRepository ?? throw new ArgumentNullException(nameof(userPlacementRepository));
            this.validationLogic = validationLogic ?? throw new ArgumentNullException(nameof(validationLogic));
        }

        public async Task<Placement> CreatePlacement(Placement newPlacement)
        {
            if (await validationLogic.CompanyDoesNotExist(newPlacement.CompanyName))
                return null;
            return await placementRepository.Create(newPlacement);
        }

        public async Task<bool> DeletePlacement(Guid id)
        {
            if (await validationLogic.PlacementDoesNotExist(id))
                return false;
            var userPlacements = await userPlacementRepository.GetWhere(row => row.PlacementId == id);
            if(userPlacements != null && userPlacements.Count > 0) 
                foreach (UserPlacement userPlacement in userPlacements)
                    await userPlacementRepository.Delete(userPlacement.Id);
            
            return await placementRepository.Delete(id);
        }

        public Task<Placement> FindPlacementById(Guid id)
        {
            return placementRepository.GetById(id);
        }

        public Task<PagedList<Placement>> FindPlacementsByCompanyName(string companyName, PlacementParameters placementParameters)
        {
            return placementRepository.GetAllWhere(placementParameters, row => row.CompanyName.Equals(companyName));
        }

        public async Task<PagedList<Placement>> FindPlacementsByUserId(Guid userId, PlacementParameters placementParameters)
        {
            if (await validationLogic.UserDoesNotExist(userId))
                return null;
            //This piece of code is to find the the placements to which the user is coupled
            var userPlacements = await userPlacementRepository.GetWhere(row => row.UserId == userId);
            if (userPlacements == null)
                return null;

            //This piece of code is to get those placements
            List<Placement> placements = new List<Placement>();
            userPlacements.ForEach(
                userPlacement => placements.Add(placementRepository.FirstOrDefault(placement => placement.Id == userPlacement.PlacementId).Result));

            //This piece of code is to filter the placements pased on the queryParameters
            var placementFiltered = placements.Where(placementParameters.Filter).ToList();
            var placementQueryabl = placementFiltered.AsQueryable();

            //This piece of code is to enable pagination 
            return PagedList<Placement>.ToPagedList(placementQueryabl, placementParameters.PageNumber, placementParameters.PageSize);
        }          

        public async Task<PagedList<Placement>> GetPlacements(PlacementParameters placementParameters)
        {
            var placements = await placementRepository.GetAll(placementParameters);
            if (placements == null)
                return null;

            foreach (Placement placement in placements)
            {
                var userPlacements = userPlacementRepository.GetWhere(
                        userPlacement => userPlacement.PlacementId == placement.Id).Result;
            }

            return placements;
        }

        public async Task<Placement> UpdatePlacement(Guid id, Placement newPlacement)
        {
            var currentPlacement = await FindPlacementById(id);

            if (currentPlacement == null)
                return null;
            else if (await validationLogic.CompanyDoesNotExist(newPlacement.CompanyName))
                return null;

            currentPlacement.CompanyName = newPlacement.CompanyName;
            currentPlacement.StartDateTime = newPlacement.StartDateTime;
            currentPlacement.EndDateTime = newPlacement.EndDateTime;
            currentPlacement.Name = newPlacement.Name;

            return await placementRepository.Update(currentPlacement);
        }
    }
}
