﻿using Application.AuxiliaryLogics.Interfaces;
using Application.Interfaces;
using Domain.Models;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application
{
    public class CompanyHolidayLogic : ICompanyHolidayLogic
    {
        private readonly IAsyncRepository<CompanyHoliday> companyHolidayRepository;
        private readonly IValidationLogic validationLogic;

        public CompanyHolidayLogic(IAsyncRepository<CompanyHoliday> companyHolidayRepository,
            IValidationLogic validationLogic)
        {
            this.companyHolidayRepository = companyHolidayRepository ??
                                            throw new ArgumentNullException(nameof(companyHolidayRepository));
            this.validationLogic = validationLogic ?? throw new ArgumentNullException(nameof(validationLogic));
        }

        public async Task<CompanyHoliday> CreateCompanyHoliday(CompanyHoliday companyHoliday)
        {
            if (await validationLogic.CompanyDoesNotExist(companyHoliday.CompanyName))
                return null;
            return await companyHolidayRepository.Create(companyHoliday);
        }

        public Task<CompanyHoliday> FindCompanyHolidayById(Guid id)
        {
            return companyHolidayRepository.GetById(id);
        }

        public async Task<List<CompanyHoliday>> GetCompanyHolidaysByCompanyName(string companyName)
        {
            if (await validationLogic.CompanyDoesNotExist(companyName))
                return null;
            return await companyHolidayRepository.GetWhere(row => row.CompanyName == companyName);
        }

        public async Task<CompanyHoliday> UpdateCompanyHoliday(CompanyHoliday companyHoliday)
        {
            var oldCompanyHoliday = await FindCompanyHolidayById(companyHoliday.Id);
            if (null == oldCompanyHoliday || await validationLogic.CompanyDoesNotExist(companyHoliday.CompanyName))
                return null;
            oldCompanyHoliday.StartDate = companyHoliday.StartDate;
            oldCompanyHoliday.EndDate = companyHoliday.EndDate;
            return await companyHolidayRepository.Update(oldCompanyHoliday);
        }

        public Task<bool> DeleteCompanyHoliday(Guid id)
        {
            return companyHolidayRepository.Delete(id);
        }
    }
}