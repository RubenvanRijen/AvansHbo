﻿using Application.AuxiliaryLogics.Interfaces;
using Application.Interfaces;
using Domain.Models;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Application
{
    public class CompanyLogic : ICompanyLogic
    {
        private readonly ILookupRepository<Company> companyRepository;
        private readonly IAsyncRepository<Placement> placementRepository;
        private readonly IAsyncRepository<UserPlacement> userPlacementRepository;

        private readonly IValidationLogic validationLogic;

        public CompanyLogic(ILookupRepository<Company> companyRepository, IAsyncRepository<Placement> placementRepository, IAsyncRepository<UserPlacement> userPlacementRepository, IValidationLogic validationLogic)
        {
            this.companyRepository = companyRepository ?? throw new ArgumentNullException(nameof(companyRepository));
            this.placementRepository = placementRepository ?? throw new ArgumentNullException(nameof(placementRepository));
            this.userPlacementRepository = userPlacementRepository ?? throw new ArgumentNullException(nameof(userPlacementRepository));

            this.validationLogic = validationLogic ?? throw new ArgumentNullException(nameof(validationLogic));
        }

        public Task<List<Company>> GetCompanies()
        {
            return companyRepository.GetAll();
        }

        public Task<Company> GetCompanyByName(string name)
        {
            return companyRepository.FirstOrDefault(row => row.Name == name);
        }

        public async Task<List<Company>> GetCompaniesByUserId(Guid userId)
        {
            if (await validationLogic.UserDoesNotExist(userId))
                return null;

            List<Placement> placements = new List<Placement>();
            var userPlacements = await userPlacementRepository.GetWhere(row => row.UserId == userId);
            if (userPlacements != null && userPlacements.Count > 0)
                foreach (UserPlacement userPlacement in userPlacements)
                    placements.Add(await placementRepository.GetById(userPlacement.PlacementId));

            
            List<Company> companies = new List<Company>();
            if (placements != null && placements.Count > 0)
            {
                List<string> companyNames = new List<string>();
                foreach (Placement placement in placements)
                {
                    if (!companyNames.Contains(placement.CompanyName))
                    {
                        companies.Add(await companyRepository.FirstOrDefault(row => row.Name.Equals(placement.CompanyName)));
                        companyNames.Add(placement.CompanyName);
                    }
                }
            }

            return companies;
        }

        public async Task<Company> CreateCompany(Company newCompany)
        {
            if (companyRepository.CountAll().Result > 0
                && companyRepository.GetWhere(row => row.Name == newCompany.Name).Result.Count > 0)
            {
                return null;
            }
            
            newCompany.Name = char.ToUpper(newCompany.Name[0]) + newCompany.Name.Substring(1);

            return await companyRepository.Create(newCompany);
        }
    }
}