﻿using Application.AuxiliaryLogics.Interfaces;
using Application.Interfaces;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using Microsoft.AspNetCore.Mvc;
using Persistence;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application
{
    public class UserPlacementLogic : IUserPlacementLogic
    {
        private readonly IAsyncRepository<UserPlacement> userPlacementRepository;

        private readonly IValidationLogic validationLogic;
        public UserPlacementLogic(IAsyncRepository<UserPlacement> userPlacementRepository, IValidationLogic validationLogic)
        {
            this.userPlacementRepository = userPlacementRepository ?? throw new ArgumentNullException(nameof(userPlacementRepository));
            this.validationLogic = validationLogic ?? throw new ArgumentNullException(nameof(validationLogic));
        }

        public async Task<UserPlacement> CreateUserPlacement(UserPlacement newUserPlacement)
        {
            if (await validationLogic.UserDoesNotExist(newUserPlacement.UserId))
                return null;
            if (await validationLogic.PlacementDoesNotExist(newUserPlacement.PlacementId))
                return null;
            return await userPlacementRepository.Create(newUserPlacement);
        }

        public  Task<bool> DeleteUserPlacement(Guid id)
        {
            return userPlacementRepository.Delete(id);
        }

        public Task<UserPlacement> FindUserPlacementById(Guid id)
        {
            return userPlacementRepository.GetById(id);
        }

        public Task<PagedList<UserPlacement>> GetUserPlacements([FromQuery] UserPlacementParameters userPlacementParameters)
        {
            return userPlacementRepository.GetAll(userPlacementParameters);
        }

        public async Task<PagedList<UserPlacement>> GetUserPlacementsWithPlacementId(Guid placementId, UserPlacementParameters userPlacementParameters)
        {
            if (await validationLogic.PlacementDoesNotExist(placementId))
                return null;
            return await userPlacementRepository.GetAllWhere(userPlacementParameters,row => row.PlacementId == placementId);
        }

        public async Task<PagedList<UserPlacement>> GetUserPlacementsWithUserId(Guid userId, UserPlacementParameters userPlacementParameters)
        {
            if (await validationLogic.UserDoesNotExist(userId))
                return null;
            return await userPlacementRepository.GetAllWhere(userPlacementParameters, row => row.UserId == userId);
        }

        public async Task<bool> UserPlacementAlreadyExists(Guid userId, Guid placementId)
        {
            if (userPlacementRepository.FirstOrDefault(row => row.UserId == userId && row.PlacementId == placementId).Result != null)
                return true;
            return false;
        }
    }
}
