﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.Interfaces;
using Domain;
using Domain.AuxiliaryModels;
using Domain.Models;
using Persistence.Repositories.Interfaces;

namespace Application
{
    public class ExpectedDeclarationLogic : IExpectedDeclarationLogic
    {
        private readonly IAsyncRepository<Route> routeRepository;
        private readonly IAsyncRepository<KilometerAllowance> allowanceRepository;

        public ExpectedDeclarationLogic(IAsyncRepository<Route> routeRepository,
            IAsyncRepository<KilometerAllowance> allowanceRepository)
        {
            this.routeRepository = routeRepository;
            this.allowanceRepository = allowanceRepository;
        }

        public async Task<ExpectedDeclaration> CalculateExpectedDeclarationForUser(Guid userId)
        {
            var expectedDistance = await CalculateExpectedDistanceForUser(userId);
            var expectedPayout = await CalculateExpectedPayoutForUser(userId);
            return new ExpectedDeclaration(expectedDistance, expectedPayout);
        }

        public async Task<float> CalculateExpectedDistanceForUser(Guid userId)
        {
            // Get all routes from the previous quarter for the specified user
            var userRoutes = await GetRoutesForUser(userId);

            // Get the average distance and return it
            var total = userRoutes.Aggregate(0.0f, (current, route) => current + route.Distance);
            var amount = userRoutes.Count;

            return amount != 0 ? total / amount : 0;
        }

        public async Task<float> CalculateExpectedPayoutForUser(Guid userId)
        {
            // Get all routes from the previous quarter for the specified user
            var userRoutes = await GetRoutesForUser(userId);

            var total = 0f;
            foreach (var userRoute in userRoutes)
            {
                var allowanceId = userRoute.KilometerAllowanceId;
                if (!allowanceId.HasValue) continue;
                
                var allowance = await allowanceRepository.GetById(allowanceId.Value);
                if (allowance == null) return 0;

                var distanceInKms = userRoute.Distance / 1000;
                total += distanceInKms * (float) allowance.Price;
            }

            var routesAmount = userRoutes.Count;

            return routesAmount != 0 ? total / routesAmount : 0;
        }

        private async Task<List<Route>> GetRoutesForUser(Guid userId)
        {
            // Get the previous quarter
            var firstDayCurrentMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            var firstDayThreeMonthsAgo = firstDayCurrentMonth.AddMonths(-3);

            // Get all routes from the previous quarter for the specified user
            return await routeRepository.GetWhere(routes =>
                routes.UserId == userId &&
                routes.StatusName == "APPROVED" &&
                routes.StartTime >= firstDayThreeMonthsAgo &&
                routes.StartTime < firstDayCurrentMonth);
        }
    }
}