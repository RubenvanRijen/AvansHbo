﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Application;
using Domain;
using Domain.Models;
using FizzWare.NBuilder;
using FluentAssertions;
using Moq;
using Persistence.Repositories.Interfaces;
using Xunit;

namespace ApiDriessenTests.Logic
{
    public class ExpectedDeclarationLogicTests
    {
        private readonly ExpectedDeclarationLogic subject;

        private readonly Guid userId = Guid.NewGuid();

        private readonly DateTime dateRoute1 = DateTime.Now.AddMonths(-4);
        private readonly DateTime dateRoute2 = DateTime.Now.AddMonths(-3);
        private readonly DateTime dateRoute3 = DateTime.Now.AddMonths(-2);

        private const float DistanceRoute1 = 125f;
        private const float DistanceRoute2 = 346f;
        private const float DistanceRoute3 = 211f;

        private const float AllowancePrice = 1.5f;

        #region Setup

        public ExpectedDeclarationLogicTests()
        {
            var mockRouteRepository = new Mock<IAsyncRepository<Route>>();
            var mockAllowanceRepository = new Mock<IAsyncRepository<KilometerAllowance>>();

            var route1 = Builder<Route>.CreateNew()
                .With(route => route.UserId = userId)
                .With(route => route.StartTime = dateRoute1)
                .With(route => route.Distance = DistanceRoute1)
                .With(route => route.StatusName = "APPROVED")
                .Build();
            var route2 = Builder<Route>.CreateNew()
                .With(route => route.UserId = userId)
                .With(route => route.StartTime = dateRoute2)
                .With(route => route.Distance = DistanceRoute2)
                .With(route => route.StatusName = "REJECTED")
                .Build();
            var route3 = Builder<Route>.CreateNew()
                .With(route => route.UserId = userId)
                .With(route => route.StartTime = dateRoute3)
                .With(route => route.Distance = DistanceRoute3)
                .With(route => route.StatusName = "APPROVED")
                .Build();

            var routes = new List<Route>
            {
                route1,
                route2,
                route3
            };

            var allowance = Builder<KilometerAllowance>
                .CreateNew()
                .With(a => a.Price = AllowancePrice)
                .Build();

            mockRouteRepository
                .Setup(mockRepo => mockRepo.GetWhere(It.IsAny<Expression<Func<Route, bool>>>()))
                .ReturnsAsync(routes);

            mockAllowanceRepository
                .Setup(mockRepo => mockRepo.GetById(It.IsAny<Guid>()))
                .ReturnsAsync(allowance);

            subject = new ExpectedDeclarationLogic(mockRouteRepository.Object, mockAllowanceRepository.Object);
        }

        #endregion

        #region Validation

        [Fact]
        public async Task ShouldReturnAverageDistance()
        {
            const float expectedResult = (DistanceRoute1 + DistanceRoute2 + DistanceRoute3) / 3f;

            var result = await subject.CalculateExpectedDistanceForUser(userId);

            result.Should().Be(expectedResult);
        }

        [Fact]
        public async Task ShouldReturnAveragePayout()
        {
            const float expectedPayoutRoute1 = DistanceRoute1 * AllowancePrice;
            const float expectedPayoutRoute2 = DistanceRoute2 * AllowancePrice;
            const float expectedPayoutRoute3 = DistanceRoute3 * AllowancePrice;
            const float expectedResult = (expectedPayoutRoute1 + expectedPayoutRoute2 + expectedPayoutRoute3) / 3f / 1000;

            var result = await subject.CalculateExpectedPayoutForUser(userId);

            result.Should().Be(expectedResult);
        }

        #endregion
    }
}