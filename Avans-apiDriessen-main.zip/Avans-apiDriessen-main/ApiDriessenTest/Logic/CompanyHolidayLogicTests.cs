﻿using Application;
using Application.AuxiliaryLogics.Interfaces;
using Domain.Models;
using FizzWare.NBuilder;
using FluentAssertions;
using Moq;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ApiDriessenTests.Logic
{
    public class CompanyHolidayLogicTests
    {
        //Model
        private readonly CompanyHoliday companyHoliday;
        private readonly CompanyHoliday currentCompanyHoliday;
        //List
        private readonly List<CompanyHoliday> companyHolidays;
        //Repository
        private readonly Mock<IAsyncRepository<CompanyHoliday>> mockHolidayRepository;
        //Logic
        private readonly Mock<IValidationLogic> mockValidationLogic;
        private readonly CompanyHolidayLogic subject;
        #region Setup
        public CompanyHolidayLogicTests()
        {
            //Model
            companyHoliday = Builder<CompanyHoliday>
                .CreateNew()
                .Build();
            currentCompanyHoliday = Builder<CompanyHoliday>
                .CreateNew()
                .Build();
            //List
            companyHolidays = Builder<CompanyHoliday>
            .CreateListOfSize(1)
               .Build()
               .ToList();
            //Repository
            mockHolidayRepository = new Mock<IAsyncRepository<CompanyHoliday>>();
            //mockUserRepository = new Mock<IAsyncRepository<User>>();
            //Logic
            mockValidationLogic = new Mock<IValidationLogic>();
            subject = new CompanyHolidayLogic(mockHolidayRepository.Object, mockValidationLogic.Object);

            SetupMockRouteRepository();
        }
        private void SetupMockRouteRepository()
        {
            mockHolidayRepository
              .Setup(m => m.GetById(It.IsAny<Guid>()))
              .ReturnsAsync(currentCompanyHoliday);
        }
        #endregion
        #region Create
        [Fact]
        public async Task Create_CallsHolidayRepositoryCreateHoliday()
        {
            // Act
            await subject.CreateCompanyHoliday(companyHoliday);

            // Assert
            mockHolidayRepository.Verify(m => m.Create(companyHoliday), Times.Once);
        }

        [Fact]
        public async Task Create_ReturnsHolidayFromHolidayRepository()
        {
            // Arrange
            mockHolidayRepository
                .Setup(m => m.Create(It.IsAny<CompanyHoliday>()))
                .ReturnsAsync(companyHoliday);

            // Act
            var result = await subject.CreateCompanyHoliday(companyHoliday);

            // Assert
            result.Should().Be(companyHoliday);
        }
        #endregion
        #region Read
        [Fact]
        public async Task FindById_CallsHolidayRepositoryFindHoliday()
        {
            // Arrange
            var guid = companyHolidays.First().Id;

            // Act
            await subject.FindCompanyHolidayById(guid);

            // Assert
            mockHolidayRepository.Verify(m => m.GetById(guid), Times.Once);
        }

        [Fact]
        public async Task FindById_ReturnsHolidayFromWorkHourRepositoryFindHoliday()
        {
            // Arrange
            var guid = companyHolidays.First().Id;

            mockHolidayRepository
                .Setup(m => m.GetById(guid))
                .ReturnsAsync(companyHoliday);

            // Act
            var result = await subject.FindCompanyHolidayById(guid);

            // Assert
            result.Should().BeEquivalentTo(companyHoliday);
        }

        [Fact]
        public async Task FindByUserId_CallsHolidayRepositoryFindHoliday()
        {
            // Arrange
            var companyName = companyHolidays.First().CompanyName;

            // Act
            await subject.GetCompanyHolidaysByCompanyName(companyName);

            // Assert
            mockHolidayRepository.Verify(m => m.GetWhere(It.IsAny<Expression<Func<CompanyHoliday, bool>>>()), Times.Once);
        }

        [Fact]
        public async Task FindByUserId_ReturnsHolidayFromHolidayRepositoryFindHoliday()
        {
            // Arrange
            var companNameCompanyHoliday = new List<CompanyHoliday>();
            companNameCompanyHoliday.Add(companyHolidays.First());
            var companyName = "";

            mockHolidayRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<CompanyHoliday, bool>>>()))
                .ReturnsAsync(companNameCompanyHoliday);

            // Act
            var result = await subject.GetCompanyHolidaysByCompanyName(companyName);

            // Assert
            result.Should().BeEquivalentTo(companyHolidays.First());
        }
        #endregion
        #region Update
        [Fact]
        public async Task UpdateHoliday_CallsWorkHourRepositoryFindHoliday()
        {
            // Act
            await subject.FindCompanyHolidayById(companyHoliday.Id);

            // Assert
            mockHolidayRepository.Verify(m => m.GetById(companyHoliday.Id), Times.Once);
        }

        [Fact]
        public async Task UpdateHoliday_CallsWorkHourRepositoryUpdateHoliday()
        {
            // Act
            await subject.UpdateCompanyHoliday(companyHoliday);

            // Assert
            mockHolidayRepository.Verify(m => m.Update(It.IsAny<CompanyHoliday>()), Times.Once);
        }
        [Fact]
        public async Task UpdateHoliday_ReturnsWorkHourFromHolidayRepository()
        {
            // Arrange
            mockHolidayRepository
                .Setup(m => m.Update(It.IsAny<CompanyHoliday>()))
                .ReturnsAsync(() => companyHoliday);

            // Act
            var result = await subject.UpdateCompanyHoliday(new CompanyHoliday());

            // Assert
            result.Should().Be(companyHoliday);
        }
        #endregion
        #region Delete
        [Fact]
        public async Task DeleteHoliday_CallsWorkHourRepositoryDeleteHoliday()
        {
            // Arrange
            var guid = companyHolidays.First().Id;

            // Act
            await subject.DeleteCompanyHoliday(guid);

            // Assert
            mockHolidayRepository.Verify(m => m.Delete(guid), Times.Once);
        }

        [Fact]
        public async Task DeleteHoliday_ReturnsBoolFromWorkHourRepositoryDeleteHoliday()
        {
            // Arrange
            var guid = companyHolidays.First().Id;
            var isDeleted = false;

            mockHolidayRepository
                .Setup(m => m.Delete(guid))
                .ReturnsAsync(isDeleted);

            // Act
            var result = await subject.DeleteCompanyHoliday(guid);

            // Assert
            result.Should().Be(isDeleted);
        }
        #endregion
    }
}
