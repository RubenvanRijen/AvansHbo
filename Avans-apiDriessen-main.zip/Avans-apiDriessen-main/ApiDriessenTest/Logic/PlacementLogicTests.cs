﻿using Application;
using Application.AuxiliaryLogics.Interfaces;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using FizzWare.NBuilder;
using FluentAssertions;
using Moq;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ApiDriessenTests.Logic
{
    public class PlacementLogicTests
    {
        
        //Model
        private readonly Placement placement;
        private readonly Placement currentPlacement;
        private readonly PlacementParameters placementParameters;
        //List
        private readonly List<Placement> placements;
        private readonly List<UserPlacement> userPlacements;
        //Repository
        private readonly Mock<IAsyncRepository<Placement>> mockPlacementRepository;
        private readonly Mock<IAsyncRepository<UserPlacement>> mockUserPlacementRepository;
        //Logic
        private readonly Mock<IValidationLogic> mockValidationLogic;
        private readonly PlacementLogic subject;

        #region Setup
        public PlacementLogicTests()
        {
            //Model
            placement = Builder<Placement>
                .CreateNew()
                .Build();
            currentPlacement = Builder<Placement>
                .CreateNew()
                .Build();
            placementParameters = Builder<PlacementParameters>
                .CreateNew()
                .Build();
            //List
            userPlacements = Builder<UserPlacement>
                .CreateListOfSize(1)
                .All()
                .With(w => w.UserId = Guid.NewGuid())
                .And(w => w.PlacementId = placement.Id)
                .Build()
                .ToList();
            placement.UserPlacements = userPlacements;
            placements = Builder<Placement>
                .CreateListOfSize(3)
                .All()
                .With(w => w.UserPlacements = userPlacements)
                .Build()
                .ToList();
            //Repository
            mockPlacementRepository = new Mock<IAsyncRepository<Placement>>();
            mockUserPlacementRepository = new Mock<IAsyncRepository<UserPlacement>>();
            //Logic
            mockValidationLogic = new Mock<IValidationLogic>();
            subject = new PlacementLogic(mockPlacementRepository.Object,mockUserPlacementRepository.Object,mockValidationLogic.Object);
            SetupMockRepository();
        }
        private void SetupMockRepository()
        {
            mockPlacementRepository
                .Setup(m => m.GetById(It.IsAny<Guid>()))
                .ReturnsAsync(currentPlacement);
        }
        #endregion
        #region Create
        [Fact]
        public async Task Create_CallsPlacementRepositoryCreatePlacement()
        {
            // Act
            await subject.CreatePlacement(placement);

            // Assert
            mockPlacementRepository.Verify(m => m.Create(placement), Times.Once);
        }

        [Fact]
        public async Task Create_ReturnsPlacementFromPlacementRepository()
        {
            // Arrange
            mockPlacementRepository
                .Setup(m => m.Create(It.IsAny<Placement>()))
                .ReturnsAsync(placement);

            // Act
            var result = await subject.CreatePlacement(placement);

            // Assert
            result.Should().Be(placement);
        }
        #endregion
        #region Read
        [Fact]
        public async Task GetUserPlacements_CallsUserPlacementRepositoryGetUserPlacements()
        {
            // Act
            await subject.GetPlacements(placementParameters);

            // Assert
            mockPlacementRepository.Verify(m => m.GetAll(placementParameters), Times.Once);
        }

        [Fact]
        public async Task FindById_CallsRepositoryFindPlacement()
        {
            // Arrange
            var guid = placements.First().Id;

            // Act
            await subject.FindPlacementById(guid);

            // Assert
            mockPlacementRepository.Verify(m => m.GetById(guid), Times.Once);
        }

        [Fact]
        public async Task FindById_ReturnsPlacementFromPlacementRepositoryFindPlacement()
        {
            // Arrange
            var guid = placements.First().Id;

            mockPlacementRepository
                .Setup(m => m.GetById(guid))
                .ReturnsAsync(placement);

            // Act
            var result = await subject.FindPlacementById(guid);

            // Assert
            result.Should().BeEquivalentTo(placements.First());
        }

        [Fact]
        public async Task FindByUserId_ReturnsPlacementFromPlacementRepositoryFindPlacement()
        {
            // Arrange
            var arrangePlacements = new List<Placement>();
            arrangePlacements.Add(placements.First());
            var userId = Guid.NewGuid();

            mockUserPlacementRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<UserPlacement, bool>>>()))
                .ReturnsAsync(userPlacements);

            mockPlacementRepository
                .Setup(m => m.FirstOrDefault(It.IsAny<Expression<Func<Placement, bool>>>()))
                .ReturnsAsync(arrangePlacements.First());

            // Act
            var result = await subject.FindPlacementsByUserId(userId, placementParameters);

            // Assert
            result.Should().BeEquivalentTo(placements.First());
        }

        
        #endregion
        #region Update
        [Fact]
        public async Task UpdatePlacement_CallsPlacementRepositoryFindPlacement()
        {
            // Act
            await subject.FindPlacementById(placement.Id);

            // Assert
            mockPlacementRepository.Verify(m => m.GetById(placement.Id), Times.Once);
        }

        [Fact]
        public async Task UpdatePlacement_CallsPlacementRepositoryUpdatePlacement()
        {
            // Act
            await subject.UpdatePlacement(placement.Id,placement);

            // Assert
            mockPlacementRepository.Verify(m => m.Update(It.IsAny<Placement>()), Times.Once);
        }
        [Fact]
        public async Task UpdatePlacement_ReturnsPlacementFromPlacementRepository()
        {
            // Arrange
            mockPlacementRepository
                .Setup(m => m.Update(It.IsAny<Placement>()))
                .ReturnsAsync(() => placement);

            // Act
            var result = await subject.UpdatePlacement(Guid.Empty, new Placement());

            // Assert
            result.Should().Be(placement);
        }
        #endregion
        #region Delete
        [Fact]
        public async Task DeletePlacement_CallsPlacementRepositoryDeletePlacement()
        {
            // Arrange
            var guid = placements.First().Id;

            // Act
            await subject.DeletePlacement(guid);
            // Assert
            mockPlacementRepository.Verify(m => m.Delete(guid), Times.Once);
        }

        [Fact]
        public async Task DeletePlacement_ReturnsBoolFromPlacementRepositoryDeletePlacement()
        {
            // Arrange
            var guid = placements.First().Id;
            var isDeleted = false;

            mockPlacementRepository
                .Setup(m => m.Delete(guid))
                .ReturnsAsync(isDeleted);

            // Act
            var result = await subject.DeletePlacement(guid);

            // Assert
            result.Should().Be(isDeleted);
        }
        #endregion
    }
}
