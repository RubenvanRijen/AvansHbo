﻿using Application;
using Application.AuxiliaryLogics.Interfaces;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using FizzWare.NBuilder;
using FluentAssertions;
using Moq;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ApiDriessenTests.Logic
{
    public class UserPlacementLogicTests
    {
        //Model
        private readonly UserPlacement userPlacement;
        private readonly UserPlacement currentUserPlacement;
        private readonly UserPlacementParameters userPlacementParameters;
        //List
        private readonly List<UserPlacement> userPlacements;
        //Repository
        private readonly Mock<IAsyncRepository<UserPlacement>> mockUserPlacementRepository;
        //Logic 
        private readonly Mock<IValidationLogic> mockValidationLogic;
        private readonly UserPlacementLogic subject;

        #region Setup
        public UserPlacementLogicTests()
        {
            //Model
            userPlacement = Builder<UserPlacement>
                .CreateNew()
                .Build();
            currentUserPlacement = Builder<UserPlacement>
                .CreateNew()
                .Build();
            userPlacementParameters = Builder<UserPlacementParameters>
                .CreateNew()
                .Build();
            //List
            userPlacements = Builder<UserPlacement>
                .CreateListOfSize(3)
                .All()
                .With(w => w.UserId = Guid.NewGuid())
                .And(w => w.PlacementId = Guid.NewGuid())
                .Build()
                .ToList();
            //Repository
            mockUserPlacementRepository = new Mock<IAsyncRepository<UserPlacement>>();
            //Logic
            mockValidationLogic = new Mock<IValidationLogic>();
            subject = new UserPlacementLogic(mockUserPlacementRepository.Object,mockValidationLogic.Object);
            SetupMockRepository();
        }
        private void SetupMockRepository()
        {
            mockUserPlacementRepository.Setup(m => m.GetById(It.IsAny<Guid>()))
                .ReturnsAsync(currentUserPlacement);
        }
        #endregion
        #region Create
        [Fact]
        public async Task Create_CallsPlacementRepositoryCreatePlacement()
        {
            // Act
            await subject.CreateUserPlacement(userPlacement);

            // Assert
            mockUserPlacementRepository.Verify(m => m.Create(userPlacement), Times.Once);
        }

        [Fact]
        public async Task Create_ReturnsPlacementFromPlacementRepository()
        {
            // Arrange
            mockUserPlacementRepository
                .Setup(m => m.Create(It.IsAny<UserPlacement>()))
                .ReturnsAsync(userPlacement);

            // Act
            var result = await subject.CreateUserPlacement(userPlacement);

            // Assert
            result.Should().Be(userPlacement);
        }
        #endregion
        #region Read
        [Fact]
        public async Task GetUserPlacements_CallsUserPlacementRepositoryGetUserPlacements()
        {
            // Act
            await subject.GetUserPlacements(userPlacementParameters);

            // Assert
            mockUserPlacementRepository.Verify(m => m.GetAll(userPlacementParameters), Times.Once);
        }

        [Fact]
        public async Task FindById_CallsRepositoryFindPlacement()
        {
            // Arrange
            var guid = userPlacements.First().Id;

            // Act
            await subject.FindUserPlacementById(guid);

            // Assert
            mockUserPlacementRepository.Verify(m => m.GetById(guid), Times.Once);
        }

        [Fact]
        public async Task FindById_ReturnsUserPlacementFromUserPlacementRepositoryFindUserPlacements()
        {
            // Arrange
            var guid = userPlacements.First().Id;

            mockUserPlacementRepository
                .Setup(m => m.GetById(guid))
                .ReturnsAsync(userPlacement);

            // Act
            var result = await subject.FindUserPlacementById(guid);

            // Assert
            result.Should().BeEquivalentTo(userPlacement);
        }

        [Fact]
        public async Task FindByUserId_CallsUserPlacementRepositoryFindUserPlacements()
        {
            // Arrange
            var userId = userPlacements.First().UserId;

            // Act
            await subject.GetUserPlacementsWithUserId(userId,userPlacementParameters);

            // Assert
            mockUserPlacementRepository.Verify(m => m.GetAllWhere(userPlacementParameters,It.IsAny<Expression<Func<UserPlacement, bool>>>()), Times.Once);
        }

        [Fact]
        public async Task FindByPlacementId_CallsUserPlacementRepositoryFindUserPlacements()
        {
            // Arrange
            var placementId = userPlacements.First().PlacementId;

            // Act
            await subject.GetUserPlacementsWithPlacementId(placementId, userPlacementParameters);

            // Assert
            mockUserPlacementRepository.Verify(m => m.GetAllWhere(userPlacementParameters,It.IsAny<Expression<Func<UserPlacement, bool>>>()), Times.Once);
        }
        #endregion
        #region Delete
        [Fact]
        public async Task DeletePlacement_CallsPlacementRepositoryDeletePlacement()
        {
            // Arrange
            var guid = userPlacements.First().Id;

            // Act
            await subject.DeleteUserPlacement(guid);

            // Assert
            mockUserPlacementRepository.Verify(m => m.Delete(guid), Times.Once);
        }

        [Fact]
        public async Task DeletePlacement_ReturnsBoolFromPlacementRepositoryDeletePlacement()
        {
            // Arrange
            var guid = userPlacements.First().Id;
            var isDeleted = false;

            mockUserPlacementRepository
                .Setup(m => m.Delete(guid))
                .ReturnsAsync(isDeleted);

            // Act
            var result = await subject.DeleteUserPlacement(guid);

            // Assert
            result.Should().Be(isDeleted);
        }
        #endregion
    }
}
