﻿using Application;
using Application.AuxiliaryLogics.Interfaces;
using Domain;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using FizzWare.NBuilder;
using FluentAssertions;
using Moq;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Xunit;

namespace ApiDriessenTests.Logic
{
    public class KilometerAllowanceTests
    {
        //Model 
        private readonly KilometerAllowance kilometerAllowance;
        private readonly KilometerAllowance newKilometerAllowance;
        private readonly KilometerAllowance currentKilometerAllowance;
        private readonly Placement placement;
        private readonly KilometerAllowanceParameters kilometerAllowanceParameters;
        //List
        private readonly List<KilometerAllowance> kilometerAllowances;
        private readonly List<Placement> placements;
        private readonly List<UserPlacement> userPlacements;
        //Repository
        private readonly Mock<IAsyncRepository<KilometerAllowance>> mockKilometerAllowanceRepository;
        private readonly Mock<IAsyncRepository<Placement>> mockPlacementRepository;
        private readonly Mock<IAsyncRepository<UserPlacement>> mockUserPlacementRepository;
        //Logic
        private readonly Mock<IValidationLogic> mockValidationLogic;
        private readonly KilometerAllowanceLogic subject;

        #region Setup
        public KilometerAllowanceTests()
        {
            //Model
            kilometerAllowance = Builder<KilometerAllowance>
                .CreateNew()
                .Build();

            newKilometerAllowance = Builder<KilometerAllowance>
                .CreateNew()
                .Build();

            currentKilometerAllowance = Builder<KilometerAllowance>
                .CreateNew()
                .Build();
            placement = Builder<Placement>
                .CreateNew()
                .Build();
            kilometerAllowanceParameters = Builder<KilometerAllowanceParameters>
                .CreateNew()
                .Build();
            //List
            kilometerAllowances = Builder<KilometerAllowance>
                .CreateListOfSize(3)
                .Build()
                .ToList();
            userPlacements = Builder<UserPlacement>
                .CreateListOfSize(1)
                .All()
                .With(w => w.UserId = Guid.NewGuid())
                .And(w => w.PlacementId = placement.Id)
                .Build()
                .ToList();
            placement.UserPlacements = userPlacements;
            placements = Builder<Placement>
                .CreateListOfSize(3)
                .All()
                .With(w => w.UserPlacements = userPlacements)
                .Build()
                .ToList();
            //Repository
            mockKilometerAllowanceRepository = new Mock<IAsyncRepository<KilometerAllowance>>();
            mockPlacementRepository = new Mock<IAsyncRepository<Placement>>();
            mockUserPlacementRepository = new Mock<IAsyncRepository<UserPlacement>>();
            //Logic
            mockValidationLogic = new Mock<IValidationLogic>();
            subject = new KilometerAllowanceLogic(mockKilometerAllowanceRepository.Object, mockPlacementRepository.Object, mockUserPlacementRepository.Object, mockValidationLogic.Object);
            SetupMockKilometerAllowanceRepository();
        }

        private void SetupMockKilometerAllowanceRepository()
        {
            mockKilometerAllowanceRepository
                .Setup(m => m.GetById(It.IsAny<Guid>()))
                .ReturnsAsync(currentKilometerAllowance);
        }
        #endregion
        #region Create
        [Fact]
        public async Task CreateKilometerAllowance()
        {
            // Act
            await subject.CreateKilometerAllowance(kilometerAllowance);

            // Assert
            mockKilometerAllowanceRepository.Verify(m => m.Create(kilometerAllowance), Times.Once);
        }

        [Fact]
        public async Task CreateKilometerAllowances()
        {
            // Arrange
            mockKilometerAllowanceRepository
                .Setup(m => m.Create(It.IsAny<KilometerAllowance>()))
                .ReturnsAsync(kilometerAllowance);

            // Act
            var result = await subject.CreateKilometerAllowance(null);

            // Assert
            result.Should().Be(kilometerAllowance);
        }
        #endregion
        #region Read
        [Fact]
        public async Task GetKilometerAllowances_CallsKillometerAllowanceRepository()
        {
            // Act
            await subject.GetKilometerAllowances(kilometerAllowanceParameters);

            // Assert
            mockKilometerAllowanceRepository.Verify(m => m.GetAll(kilometerAllowanceParameters), Times.Once);
        }

        //[Fact]
        //public async Task GetKilometerAllowances_FromKilometerAllowancesRepository()
        //{
        //    // Arrange
        //    mockKilometerAllowanceRepository
        //        .Setup(m => m.GetAll(It.IsAny<KilometerAllowanceParameters>()))
        //        .ReturnsAsync(() => (kilometerAllowances));

        //    // Act
        //    var result = await subject.GetKilometerAllowances(kilometerAllowanceParameters);

        //    // Assert
        //    result.Should().BeEquivalentTo(kilometerAllowances);
        //}

        [Fact]
        public async Task FindKilometerAllowanceById_CallsKilometerAllowanceRepositoryFindKilometerAllowance()
        {
            // Arrange
            var guid = kilometerAllowances.First().Id;

            // Act
            await subject.FindKilometerAllowanceById(guid);

            // Assert
            mockKilometerAllowanceRepository.Verify(m => m.GetById(guid), Times.Once);
        }

        [Fact]
        public async Task
            FindKilometerAllowanceById_ReturnsKilometerAllowanceFromKilometerAllowanceRepositoryFindKilometerAllowance()
        {
            // Arrange
            var guid = kilometerAllowances.First().Id;

            mockKilometerAllowanceRepository
                .Setup(m => m.GetById(guid))
                .ReturnsAsync(kilometerAllowance);

            // Act
            var result = await subject.FindKilometerAllowanceById(guid);

            // Assert
            result.Should().BeEquivalentTo(kilometerAllowance);
        }

        [Fact]
        public async Task FindByUserId_CallsKilometerAllowanceRepositoryFindKilometerAllowances()
        {
            // Arrange
            var userId = kilometerAllowances.First().Id;

            mockUserPlacementRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<UserPlacement, bool>>>()))
                .ReturnsAsync(userPlacements);

            mockPlacementRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<Placement, bool>>>()))
                .ReturnsAsync(placements);

            mockKilometerAllowanceRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<KilometerAllowance, bool>>>()))
                .ReturnsAsync(kilometerAllowances);

            // Act
            await subject.FindKilometerAllowancesByUserId(userId);

            // Assert
            mockKilometerAllowanceRepository.Verify(m => m.GetWhere(It.IsAny<Expression<Func<KilometerAllowance, bool>>>()), Times.Once);
        }

        [Fact]
        public async Task FindByUserId_ReturnsKilometerAllowancesFromKilometerAllowanceRepositoryFindKilometerAllowances()
        {
            // Arrange
            var arrangeKilometerAllowances = new List<KilometerAllowance>();
            arrangeKilometerAllowances.Add(kilometerAllowances.First());
            var userId = Guid.NewGuid();

            mockUserPlacementRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<UserPlacement, bool>>>()))
                .ReturnsAsync(userPlacements);

            mockPlacementRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<Placement, bool>>>()))
                .ReturnsAsync(placements);

            mockKilometerAllowanceRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<KilometerAllowance, bool>>>()))
                .ReturnsAsync(arrangeKilometerAllowances);

            // Act
            var result = await subject.FindKilometerAllowancesByUserId(userId);

            // Assert
            result.Should().BeEquivalentTo(kilometerAllowances.First());
        }
        #endregion
        #region Update
        // [Theory]
        // [InlineData(10.2, 12.2, 10.2)]
        // [InlineData(10.2, 12.2, 12.2)]
        // public async Task UpdateKilometerAllowance_MinDistance(
        //     double newMinDistance, double currentMinDistance, double expectedMinDistance)
        // {
        //     // Arrange
        //     newKilometerAllowance.MinDistance = newMinDistance;
        //     currentKilometerAllowance.MinDistance = currentMinDistance;
        //
        //     // Act
        //     await subject.UpdateKilometerAllowance(Guid.Empty, newKilometerAllowance);
        //
        //     // Assert
        //     mockKilometerAllowanceRepository
        //         .Verify(m => m.Update( /*It.IsAny<Guid>(),*/ It.Is<KilometerAllowance>(c =>
        //             c.MinDistance == (expectedMinDistance))), Times.Once);
        // }
        //
        // [Theory]
        // [InlineData(10.2, 12.2, 10.2)]
        // [InlineData(10.0, 12.0, 12.0)]
        // public async Task UpdateKilometerAllowance_Price(double newPrice,
        //     double currentPrice, double expectedPrice)
        // {
        //     // Arrange
        //     newKilometerAllowance.Price = newPrice;
        //     currentKilometerAllowance.Price = currentPrice;
        //
        //     // Act
        //     await subject.UpdateKilometerAllowance(Guid.Empty, newKilometerAllowance);
        //
        //     // Assert
        //     mockKilometerAllowanceRepository
        //         .Verify(m => m.Update( /*It.IsAny<Guid>(), */It.Is<KilometerAllowance>(c =>
        //             c.Price == (expectedPrice))), Times.Once);
        // }


        [Fact]
        public async Task UpdateKilometerAllowance()
        {
            // Act
            await subject.FindKilometerAllowanceById(kilometerAllowance.Id);

            // Assert
            mockKilometerAllowanceRepository.Verify(m => m.GetById(kilometerAllowance.Id), Times.Once);
        }

        [Fact]
        public async Task UpdateKilometerAllowance_Id()
        {
            // Act
            await subject.UpdateKilometerAllowance(kilometerAllowance.Id, kilometerAllowance);

            // Assert
            mockKilometerAllowanceRepository.Verify(
                m => m.Update( /*It.IsAny<Guid>(),*/ It.IsAny<KilometerAllowance>()),
                Times.Once);
        }

        [Fact]
        public async Task UpdateKilometerAllowance_FromRepo()
        {
            // Arrange
            mockKilometerAllowanceRepository
                .Setup(m => m.Update( /*It.IsAny<Guid>(),*/ It.IsAny<KilometerAllowance>()))
                .ReturnsAsync(() => kilometerAllowance);

            // Act
            var result = await subject.UpdateKilometerAllowance(Guid.Empty, new KilometerAllowance());

            // Assert
            result.Should().Be(kilometerAllowance);
        }
        #endregion
        #region Delete
        [Fact]
        public async Task DeleteKilometerAllowance_CallsKilometerAllowanceRepositoryDeleteKilometerAllowance()
        {
            // Arrange
            var guid = kilometerAllowances.First().Id;

            // Act
            await subject.DeleteKilometerAllowance(guid);

            // Assert
            mockKilometerAllowanceRepository.Verify(m => m.Delete(guid), Times.Once);
        }

        [Fact]
        public async Task DeleteKilometerAllowance_ReturnsBoolFromKilometerAllowanceRepositoryDeleteKilometerAllowance()
        {
            // Arrange
            var guid = kilometerAllowances.First().Id;
            var isDeleted = false;

            mockKilometerAllowanceRepository
                .Setup(m => m.Delete(guid))
                .ReturnsAsync(isDeleted);

            // Act
            var result = await subject.DeleteKilometerAllowance(guid);

            // Assert
            result.Should().Be(isDeleted);
        }
        #endregion
    }
}