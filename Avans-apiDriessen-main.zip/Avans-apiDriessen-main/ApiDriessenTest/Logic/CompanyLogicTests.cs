﻿using Application;
using Application.AuxiliaryLogics.Interfaces;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using FizzWare.NBuilder;
using FluentAssertions;
using Moq;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Xunit;

namespace ApiDriessenTests.Logic
{
    public class CompanyLogicTests
    {
        //List
        private readonly Company company;
        private readonly List<Company> companies;
        private readonly List<Placement> placements;
        private readonly List<UserPlacement> userPlacements;
        //Repository
        private readonly Mock<ILookupRepository<Company>> mockCompanyRepository;
        private readonly Mock<IAsyncRepository<Placement>> mockPlacementRepository;
        private readonly Mock<IAsyncRepository<UserPlacement>> mockUserPlacementRepository;

        //Logic
        private readonly Mock<IValidationLogic> mockValidationLogic;
        private readonly CompanyLogic subject;

        public CompanyLogicTests()
        {
            company = Builder<Company>
                .CreateNew()
                .Build();
            //Lists
           companies = Builder<Company>
                .CreateListOfSize(1)
                .Build()
                .ToList();
           placements = Builder<Placement>
                .CreateListOfSize(1)
                .Build()
                .ToList();
            userPlacements = Builder<UserPlacement>
                .CreateListOfSize(1)
                .Build()
                .ToList();
            //Repository
            mockCompanyRepository = new Mock<ILookupRepository<Company>>();
            mockPlacementRepository = new Mock<IAsyncRepository<Placement>>();
            mockUserPlacementRepository = new Mock<IAsyncRepository<UserPlacement>>();
            //Logic
            mockValidationLogic = new Mock<IValidationLogic>();
            subject = new CompanyLogic(mockCompanyRepository.Object, mockPlacementRepository.Object, mockUserPlacementRepository.Object, mockValidationLogic.Object);
        }

        [Fact]
        public async Task GetCompanies_CallsCompanyRepositoryGetCompanies()
        {
            // Act
            await subject.GetCompanies();

            // Assert
            mockCompanyRepository.Verify(m => m.GetAll(), Times.Once);
        }
        
        [Fact]
        public async Task CreateCompany_CallsCompanyRepositoryCreateNewCompany()
        {
            // Act
            await subject.CreateCompany(company);

            // Assert
            mockCompanyRepository.Verify(m => m.Create(company), Times.Once);
        }

        //[Fact]
        //public async Task GetWorkHours_ReturnsWorkHoursFromWorkHourRepository()
        //{
        //    // Arrange
        //    mockCompanyRepository
        //        .Setup(m => m.GetAll())
        //        .ReturnsAsync(() => (companies));
        //    // Act
        //    var result = await subject.GetCompanies(companyParameters);
        //    // Assert
        //    result.Should().BeEquivalentTo(companies);
        //}

        [Fact]
        public async Task GetCompanyByName_ReturnsCompany()
        {
            // Arrange
            mockCompanyRepository
                .Setup(m => m.FirstOrDefault(It.IsAny<Expression<Func<Company, bool>>>()))
                .ReturnsAsync(() => companies.First());

            // Act
            var result = await subject.GetCompanyByName("Driessen");

            // Assert
            result.Should().BeEquivalentTo(companies.First());
        }

        [Fact]
        public async Task GetCompanyByUserId_ReturnsCompanies()
        {
            // Arrange
            mockCompanyRepository
                .Setup(m => m.FirstOrDefault(It.IsAny<Expression<Func<Company, bool>>>()))
                .ReturnsAsync(() => companies.First());
            mockPlacementRepository
              .Setup(m => m.GetById(It.IsAny<Guid>()))
              .ReturnsAsync(placements.First());
            mockUserPlacementRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<UserPlacement, bool>>>()))
                .ReturnsAsync(userPlacements);
            // Act
            var result = await subject.GetCompaniesByUserId(userPlacements.First().UserId);

            // Assert
            result.Should().BeEquivalentTo(companies.First());
        }
    }
}