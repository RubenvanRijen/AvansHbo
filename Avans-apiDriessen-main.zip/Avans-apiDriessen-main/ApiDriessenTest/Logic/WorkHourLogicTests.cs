using Application;
using Domain;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using FizzWare.NBuilder;
using FluentAssertions;
using Moq;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Xunit;

namespace ApiDriessenTests.Logic
{
    public class WorkHourLogicTests
    {
        private readonly List<WorkHour> workHours;
        private readonly WorkHour workHour;
        private readonly WorkHour currentWorkHour;
        private readonly Mock<IAsyncRepository<WorkHour>> mockWorkHourRepository;
        private readonly Mock<IAsyncRepository<User>> mockUserRepository;
        private readonly WorkHourParameters workHourParameters;
        private readonly WorkHourLogic subject;

        public WorkHourLogicTests()
        {
            workHours = Builder<WorkHour>
                .CreateListOfSize(3)
                .Build()
                .ToList();

            workHour = Builder<WorkHour>
                .CreateNew()
                .Build();

            currentWorkHour = Builder<WorkHour>
                .CreateNew()
                .Build();

            workHourParameters = Builder<WorkHourParameters>
                .CreateNew()
                .Build();

            mockWorkHourRepository = new Mock<IAsyncRepository<WorkHour>>();
            mockUserRepository = new Mock<IAsyncRepository<User>>();
            subject = new WorkHourLogic(mockWorkHourRepository.Object, mockUserRepository.Object);
            SetupMockWorkHourRepository();
        }

        private void SetupMockWorkHourRepository()
        {
            mockWorkHourRepository
                .Setup(m => m.GetById(It.IsAny<Guid>()))
                .ReturnsAsync(currentWorkHour);
        }

        [Fact]
        public async Task GetWorkHours_CallsWorkHourRepositoryGetWorkHours()
        {
            // Act
            await subject.GetWorkHours(workHourParameters);

            // Assert
            mockWorkHourRepository.Verify(m => m.GetAll(workHourParameters), Times.Once);
        }

        //[Fact]
        //public async Task GetWorkHours_ReturnsWorkHoursFromWorkHourRepository()
        //{
        //    // Arrange
        //    mockWorkHourRepository
        //        .Setup(m => m.GetAll(workHourParameters))
        //        .ReturnsAsync(() => (workHours));

        //    // Act
        //    var result = await subject.GetWorkHours(workHourParameters);

        //    // Assert
        //    result.Should().BeEquivalentTo(workHours);
        //}

        [Fact]
        public async Task CreateWorkHour_CallsWorkHourRepositoryCreateWorkHour()
        {
            // Act
            await subject.CreateWorkHour(workHour);

            // Assert
            mockWorkHourRepository.Verify(m => m.Create(workHour), Times.Once);
        }

        [Fact]
        public async Task CreateWorkHour_ReturnsWorkHoursFromWorkHourRepository()
        {
            // Arrange
            mockWorkHourRepository
                .Setup(m => m.Create(It.IsAny<WorkHour>()))
                .ReturnsAsync(workHour);

            // Act
            var result = await subject.CreateWorkHour(null);

            // Assert
            result.Should().Be(workHour);
        }

        [Fact]
        public async Task UpdateWorkHour_CallsWorkHourRepositoryFindWorkHour()
        {
            // Act
            await subject.FindWorkHourById(workHour.Id);

            // Assert
            mockWorkHourRepository.Verify(m => m.GetById(workHour.Id), Times.Once);
        }

        [Fact]
        public async Task UpdateWorkHour_CallsWorkHourRepositoryUpdateWorkHour()
        {
            // Act
            await subject.UpdateWorkHour(workHour.Id, workHour);

            // Assert
            mockWorkHourRepository.Verify(m => m.Update( /*It.IsAny<Guid>(),*/ It.IsAny<WorkHour>()), Times.Once);
        }

        [Fact]
        public async Task UpdateWorkHour_ReturnsWorkHourFromWorkHourRepository()
        {
            // Arrange
            mockWorkHourRepository
                .Setup(m => m.Update( /*It.IsAny<Guid>(),*/ It.IsAny<WorkHour>()))
                .ReturnsAsync(() => workHour);

            // Act
            var result = await subject.UpdateWorkHour(Guid.Empty, new WorkHour());

            // Assert
            result.Should().Be(workHour);
        }

        [Fact]
        public async Task FindWorkHourById_CallsWorkHourRepositoryFindWorkHour()
        {
            // Arrange
            var guid = workHours.First().Id;

            // Act
            await subject.FindWorkHourById(guid);

            // Assert
            mockWorkHourRepository.Verify(m => m.GetById(guid), Times.Once);
        }

        [Fact]
        public async Task FindWorkHourById_ReturnsWorkHourFromWorkHourRepositoryFindWorkHour()
        {
            // Arrange
            var guid = workHours.First().Id;

            mockWorkHourRepository
                .Setup(m => m.GetById(guid))
                .ReturnsAsync(workHour);

            // Act
            var result = await subject.FindWorkHourById(guid);

            // Assert
            result.Should().BeEquivalentTo(workHour);
        }

        [Fact]
        public async Task DeleteWorkHour_CallsWorkHourRepositoryDeleteWorkHour()
        {
            // Arrange
            var guid = workHours.First().Id;

            // Act
            await subject.DeleteWorkHour(guid);

            // Assert
            mockWorkHourRepository.Verify(m => m.Delete(guid), Times.Once);
        }

        [Fact]
        public async Task DeleteWorkHour_ReturnsBoolFromWorkHourRepositoryDeleteWorkHour()
        {
            // Arrange
            var guid = workHours.First().Id;
            var isDeleted = false;

            mockWorkHourRepository
                .Setup(m => m.Delete(guid))
                .ReturnsAsync(isDeleted);

            // Act
            var result = await subject.DeleteWorkHour(guid);

            // Assert
            result.Should().Be(isDeleted);
        }

        //[Fact]
        //public async Task FindWorkHourByUserId_CallsRouteRepositoryFindWorkHour()
        //{
        //    // Arrange
        //    var userId = workHours.First().UserId;
        //    // Act
        //    await subject.FindWorkHourByUserId(userId, workHourParameters);

        //    // Assert
        //    mockWorkHourRepository.Verify(m => m.GetWhere(It.IsAny<Expression<Func<WorkHour, bool>>>()), Times.Once);
        //}

        //[Fact]
        //public async Task FindWorkHourByUserId_ReturnsRouteFromRouteRepositoryFindWorkHour()
        //{
        //    // Arrange
        //    var userIdWorkHour = new List<WorkHour>();
        //    userIdWorkHour.Add(workHours.First());
        //    var userId = userIdWorkHour.First().UserId;

        //    mockWorkHourRepository
        //        .Setup(m => m.GetWhere(It.IsAny<Expression<Func<WorkHour, bool>>>()))
        //        .ReturnsAsync(userIdWorkHour);

        //    // Act
        //    var result = await subject.FindWorkHourByUserId(userId, workHourParameters);

        //    // Assert
        //    result.Should().BeEquivalentTo(workHours.First());
        //}
    }
}