﻿using Application;
using Application.AuxiliaryLogics;
using Application.AuxiliaryLogics.Interfaces;
using Application.Interfaces;
using Domain;
using Domain.AuxiliaryModels.MapboxModels;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using FizzWare.NBuilder;
using FluentAssertions;
using Moq;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Xunit;
using static Application.AuxiliaryLogics.MapboxLogic;

namespace ApiDriessenTests.Logic
{
    public class RouteLogicTests
    {
        //Model
        private readonly Route route;
        private readonly Route currentRoute;
        private readonly MapboxGPSRoute mapboxRoute;
        private readonly RouteParameters routeParameters;
        //List
        private readonly List<Route> routes;
        private readonly List<Route> createdRoutes;
        private readonly List<User> user;
        private readonly List<Status> status;
        private readonly KilometerAllowance kilometerAllowance;
        private readonly List<KilometerAllowance> kilometerAllowances;
        private readonly List<Company> companies;
        private readonly List<Placement> placements;
        //Repository
        private readonly Mock<IAsyncRepository<Route>> mockRouteRepository;
        private readonly Mock<IAsyncRepository<User>> mockUserRepository;
        private readonly Mock<ILookupRepository<Status>> mockStatusRepository;
        private readonly Mock<ILookupRepository<Company>> mockCompanyRepository;
        private readonly Mock<IAsyncRepository<KilometerAllowance>> mockKilometerAllowanceRepository;
        private readonly Mock<IAsyncRepository<Placement>> mockPlacementRepository;
        //Logic
        private readonly Mock<IMapboxLogic> mockMapboxLogic;
        private readonly Mock<IValidationLogic> mockValidationLogic;
        private readonly RouteLogic subject;

        public RouteLogicTests()
        {
            mapboxRoute = new MapboxGPSRoute();
            mapboxRoute.Matchings = new List<Matchings>();
            mapboxRoute.Matchings.Add(new Matchings()
            {
                Distance = 24746.08F,
                Geometry = new Geometry()
                {
                    Coordinates = new float[][] {
                         new float[]{
                            5.452155F,
                            52.162922F
                          },
                          new float[]{
                            5.44841F,
                            52.162041F
                          },
                          new float[]{
                            5.439157F,
                            52.163006F
                          },
                          new float[]{
                            5.434711F,
                            52.167545F
                          },
                          new float[]{
                            5.434548F,
                            52.168602F
                          },
                          new float[]{
                            5.435307F,
                            52.170956F
                          },
                          new float[]{
                            5.431076F,
                            52.172749F
                          },
                          new float[]{
                            5.427803F,
                            52.171597F
                          },
                          new float[]{
                            5.421219F,
                            52.162014F
                          },
                          new float[]{
                            5.415398F,
                            52.160225F
                          },
                          new float[]{
                            5.417509F,
                            52.155487F
                          },
                          new float[]{
                            5.413303F,
                            52.148323F
                          },
                          new float[]{
                            5.401618F,
                            52.137146F
                          },
                          new float[]{
                            5.395106F,
                            52.134117F
                          },
                          new float[]{
                            5.38371F,
                            52.132305F
                          },
                          new float[]{
                            5.382136F,
                            52.132183F
                          },
                          new float[]{
                            5.378152F,
                            52.132366F
                          },
                          new float[]{
                            5.37423F,
                            52.133511F
                          },
                          new float[]{
                            5.364727F,
                            52.126045F
                          },
                          new float[]{
                            5.36028F,
                            52.112003F
                          },
                          new float[]{
                            5.362568F,
                            52.103008F
                          },
                          new float[]{
                            5.362134F,
                            52.094044F
                          },
                          new float[]{
                            5.35712F,
                            52.067097F
                          },
                          new float[]{
                            5.356296F,
                            52.065853F
                          },
                          new float[]{
                            5.348112F,
                            52.065536F
                          },
                          new float[]{
                            5.28977F,
                            52.065197F
                          },
                          new float[]{
                            5.277443F,
                            52.064785F
                          },
                          new float[]{
                            5.266467F,
                            52.061466F
                          },
                          new float[]{
                            5.259363F,
                            52.06683F
                          },
                          new float[]{
                            5.265144F,
                            52.070122F
                          },
                          new float[]{
                            5.266607F,
                            52.069248F
                          }
                    }
                }
            });
            var kilometerAllowanceId = Guid.NewGuid();
            kilometerAllowance = Builder<KilometerAllowance>
                .CreateNew()
                .With(m => m.Id = kilometerAllowanceId)
                .And(m => m.CompanyName = "Driessen")
                .And(m => m.AllowanceTypeName = "WORK")
                .And(m => m.Price = 1)
                .And(m => m.MinDistance = 1)
                .Build();

            routes = Builder<Route>
          .CreateListOfSize(10)
                .All()
                .With(w => w.SerializedRoute = "[{\"longitude\":\"5.4521542\",\"latitude\":\"52.1629296\"},{\"longitude\":\"5.2666049\",\"latitude\":\"52.0692473\"}]")
                .And(w => w.UserId = Guid.NewGuid())
                //.And(w => w.PlacementId = Guid.NewGuid())
                .And(w => w.KilometerAllowanceId = kilometerAllowanceId)
            .Build()
            .ToList();

            createdRoutes = Builder<Route>
         .CreateListOfSize(1)
                   .All()
                   .With(w => w.SerializedRoute = "[{\"longitude\":\"5.4521542\",\"latitude\":\"52.1629296\"},{\"longitude\":\"5.2666049\",\"latitude\":\"52.0692473\"}]")
                   .And(w => w.SerializedMapRoute = "[{\"lat\":52.16292,\"lng\":5.452155},{\"lat\":52.16204,\"lng\":5.44841},{\"lat\":52.163006,\"lng\":5.439157},{\"lat\":52.167545,\"lng\":5.434711},{\"lat\":52.168602,\"lng\":5.434548},{\"lat\":52.170956,\"lng\":5.435307},{\"lat\":52.17275,\"lng\":5.431076},{\"lat\":52.171597,\"lng\":5.427803},{\"lat\":52.162014,\"lng\":5.421219},{\"lat\":52.160225,\"lng\":5.415398},{\"lat\":52.155487,\"lng\":5.417509},{\"lat\":52.149605,\"lng\":5.414343},{\"lat\":52.140163,\"lng\":5.405226},{\"lat\":52.1344,\"lng\":5.396032},{\"lat\":52.125023,\"lng\":5.34754},{\"lat\":52.117374,\"lng\":5.323537},{\"lat\":52.114723,\"lng\":5.297431},{\"lat\":52.107815,\"lng\":5.265821},{\"lat\":52.107006,\"lng\":5.26051},{\"lat\":52.10864,\"lng\":5.261083},{\"lat\":52.108456,\"lng\":5.261676},{\"lat\":52.104942,\"lng\":5.26287},{\"lat\":52.101105,\"lng\":5.266142},{\"lat\":52.100918,\"lng\":5.266448},{\"lat\":52.092422,\"lng\":5.280726},{\"lat\":52.092205,\"lng\":5.280683},{\"lat\":52.084267,\"lng\":5.252751},{\"lat\":52.08416,\"lng\":5.252369},{\"lat\":52.08247,\"lng\":5.246427},{\"lat\":52.082245,\"lng\":5.246376},{\"lat\":52.075294,\"lng\":5.256153},{\"lat\":52.075115,\"lng\":5.256493},{\"lat\":52.06925,\"lng\":5.266607}]")
                   .And(w => w.Distance = 24746.08F)
               .Build()
               .ToList();

            placements = Builder<Placement>
                .CreateListOfSize(1)
                .Build()
                .ToList();

            route = Builder<Route>
                .CreateNew()
                    .Build();

            user = Builder<User>
          .CreateListOfSize(1)
               .Build()
               .ToList();

            companies = Builder<Company>
      .CreateListOfSize(1)
           .Build()
           .ToList();

            status = Builder<Status>
       .CreateListOfSize(1)
            .Build()
            .ToList();

            kilometerAllowances = Builder<KilometerAllowance>
       .CreateListOfSize(1)
            .Build()
            .ToList();

            currentRoute = Builder<Route>
                .CreateNew()
                    .Build();

            routeParameters = Builder<RouteParameters>
               .CreateNew()
                   .Build();

            mockRouteRepository = new Mock<IAsyncRepository<Route>>();
            mockUserRepository = new Mock<IAsyncRepository<User>>();
            mockStatusRepository = new Mock<ILookupRepository<Status>>();
            mockCompanyRepository = new Mock<ILookupRepository<Company>>();
            mockKilometerAllowanceRepository = new Mock<IAsyncRepository<KilometerAllowance>>();
            mockPlacementRepository = new Mock<IAsyncRepository<Placement>>();

            mockMapboxLogic = new Mock<IMapboxLogic>();
            mockValidationLogic = new Mock<IValidationLogic>();
            subject = new RouteLogic(mockRouteRepository.Object, mockUserRepository.Object, mockStatusRepository.Object, mockCompanyRepository.Object, mockKilometerAllowanceRepository.Object, mockPlacementRepository.Object, mockMapboxLogic.Object, mockValidationLogic.Object);

            SetupMockRouteRepository();
        }

        private void SetupMockRouteRepository()
        {
            mockRouteRepository
              .Setup(m => m.GetById(It.IsAny<Guid>()))
              .ReturnsAsync(currentRoute);
        }


        [Fact]
        public async Task GetRoutes_CallsRouteRepositoryGetRoutes()
        {
            // Act
            await subject.GetRoutes(routeParameters);

            // Assert
            mockRouteRepository.Verify(m => m.GetAll(routeParameters), Times.Once);
        }

        //[Fact]
        //public async Task GetRoutes_FromRoutesRepository()
        //{
        //    // Arrange
        //    mockRouteRepository
        //        .Setup(m => m.GetAll(routeParameters))
        //        .ReturnsAsync(() => (routes));

        //    // Act
        //    var result = await subject.GetRoutes(routeParameters);

        //    // Assert
        //    result.Should().BeEquivalentTo(routes);
        //}

        [Fact]
        public async Task FindRoutesById_CallsRouteRepositoryFindRoute()
        {
            // Arrange
            var guid = routes.First().Id;

            mockKilometerAllowanceRepository
              .Setup(m => m.GetById(It.IsAny<Guid>()))
              .ReturnsAsync(kilometerAllowances.First());

            // Act
            await subject.FindRouteById(guid);

            // Assert
            mockRouteRepository.Verify(m => m.GetById(guid), Times.AtLeastOnce);
        }

        [Fact]
        public async Task FindRouteById_ReturnsRouteFromRouteRepositoryFindRoute()
        {
            // Arrange
            var guid = routes.First().Id;

            mockRouteRepository
                .Setup(m => m.GetById(guid))
                .ReturnsAsync(route);

            mockKilometerAllowanceRepository
              .Setup(m => m.GetById(It.IsAny<Guid>()))
              .ReturnsAsync(kilometerAllowances.First());

            // Act
            var result = await subject.FindRouteById(guid);

            // Assert
            result.Should().BeEquivalentTo(route);
        }

        [Fact]
        public async Task UpdateRoute_CallsRouteRepositoryUpdateRoute()
        {
            // Arrrange
            mockPlacementRepository
              .Setup(m => m.GetById(It.IsAny<Guid>()))
              .ReturnsAsync(placements.First());

            mockKilometerAllowanceRepository
              .Setup(m => m.GetById(It.IsAny<Guid>()))
              .ReturnsAsync(kilometerAllowances.First());

            // Act
            await subject.UpdateRoute(route.Id, route);

            // Assert
            mockRouteRepository.Verify(m => m.GetById(route.Id), Times.AtLeastOnce);
        }

        [Fact]
        public async Task UpdateRoute_ReturnsRouteFromRouteRepository()
        {
            // Arrange
            mockRouteRepository
                .Setup(m => m.Update(/*It.IsAny<Guid>(),*/ It.IsAny<Route>()))
                .ReturnsAsync(() => route);

            mockUserRepository
              .Setup(m => m.CountAll())
              .ReturnsAsync(user.Count);

            mockUserRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<User, bool>>>()))
                .ReturnsAsync(user);

            mockCompanyRepository
             .Setup(m => m.CountAll())
             .ReturnsAsync(companies.Count);

            mockCompanyRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<Company, bool>>>()))
                .ReturnsAsync(companies);

            mockStatusRepository
               .Setup(m => m.CountAll())
               .ReturnsAsync(status.Count);

            mockStatusRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<Status, bool>>>()))
                .ReturnsAsync(status);

            mockPlacementRepository
              .Setup(m => m.GetById(It.IsAny<Guid>()))
              .ReturnsAsync(placements.First());

            mockKilometerAllowanceRepository
              .Setup(m => m.GetById(It.IsAny<Guid>()))
              .ReturnsAsync(kilometerAllowances.First());

            // Act
            var result = await subject.UpdateRoute(Guid.Empty, currentRoute);

            // Assert
            result.Should().Be(route);
        }

        [Fact]
        public async Task CreateRoute()
        {
            // Arrange
            mockUserRepository
               .Setup(m => m.CountAll())
               .ReturnsAsync(user.Count);

            mockUserRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<User, bool>>>()))
                .ReturnsAsync(user);

            mockStatusRepository
              .Setup(m => m.CountAll())
              .ReturnsAsync(status.Count);

            mockStatusRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<Status, bool>>>()))
                .ReturnsAsync(status);

            mockCompanyRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<Company, bool>>>()))
                .ReturnsAsync(companies);

            mockKilometerAllowanceRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<KilometerAllowance, bool>>>()))
                .ReturnsAsync(kilometerAllowances);

            mockKilometerAllowanceRepository
                .Setup(m => m.FirstOrDefault(It.IsAny<Expression<Func<KilometerAllowance, bool>>>()))
                .Returns((Expression<Func<KilometerAllowance, bool>> expression) =>
                {
                    var task = new Task<KilometerAllowance>(() => kilometerAllowance);

                    if (!expression.Compile().Invoke(kilometerAllowance))
                    {
                        task = new Task<KilometerAllowance>(() => null);
                    }

                    task.Start();
                    return task;
                });

            mockPlacementRepository
              .Setup(m => m.GetById(It.IsAny<Guid>()))
              .ReturnsAsync(placements.First());

            mockMapboxLogic.Setup(m => m.GetGPSRoute(It.IsAny<string>())).ReturnsAsync(mapboxRoute);

            // Act
            await subject.CreateRoute(routes.First(),true);


            // Assert
            mockRouteRepository.Verify(m => m.Create(routes.First()), Times.Once);
        }

        [Fact]
        public async Task CreateRoutes()
        {
            // Arrange
            mockRouteRepository
                .Setup(m => m.Create(It.IsAny<Route>()))
                .ReturnsAsync(createdRoutes.FirstOrDefault());

            mockUserRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(user.Count);

            mockUserRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<User, bool>>>()))
                .ReturnsAsync(user);

            mockStatusRepository
               .Setup(m => m.CountAll())
               .ReturnsAsync(status.Count);

            mockStatusRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<Status, bool>>>()))
                .ReturnsAsync(status);

            mockCompanyRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<Company, bool>>>()))
                .ReturnsAsync(companies);

            mockKilometerAllowanceRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<KilometerAllowance, bool>>>()))
                .ReturnsAsync(kilometerAllowances);

            mockKilometerAllowanceRepository
                .Setup(m => m.FirstOrDefault(It.IsAny<Expression<Func<KilometerAllowance, bool>>>()))
                .Returns((Expression<Func<KilometerAllowance, bool>> expression) =>
                {
                    var task = new Task<KilometerAllowance>(() => kilometerAllowance);

                    if (!expression.Compile().Invoke(kilometerAllowance))
                    {
                        task = new Task<KilometerAllowance>(() => null);
                    }

                    task.Start();
                    return task;
                });

            mockPlacementRepository
              .Setup(m => m.GetById(It.IsAny<Guid>()))
              .ReturnsAsync(placements.First());

            mockMapboxLogic.Setup(m => m.GetGPSRoute(It.IsAny<string>())).ReturnsAsync(mapboxRoute);

            // Act
            var result = await subject.CreateRoute(routes.FirstOrDefault(),true);

            // Assert
            result.Should().Be(createdRoutes.FirstOrDefault());
        }

        [Fact]
        public async Task DeleteRoute_CallsRouteRepositoryDeleteRoute()
        {
            // Arrange
            var guid = routes.First().Id;

            // Act
            await subject.DeleteRoute(guid);

            // Assert
            mockRouteRepository.Verify(m => m.Delete(guid), Times.Once);
        }

        [Fact]
        public async Task DeleteRoute_ReturnsBoolFromRouteRepositoryDeleteRoute()
        {
            // Arrange
            var guid = routes.First().Id;
            var isDeleted = false;

            mockRouteRepository
                .Setup(m => m.Delete(guid))
                .ReturnsAsync(isDeleted);

            // Act
            var result = await subject.DeleteRoute(guid);

            // Assert
            result.Should().Be(isDeleted);
        }

        //[Fact]
        //public async Task FindRoutesByUserId_CallsRouteRepositoryFindRoute()
        //{
        //    // Arrange
        //    var userId = routes.First().UserId;

        //    // Act
        //    await subject.FindRouteByUserId(userId, routeParameters);

        //    // Assert
        //    mockRouteRepository.Verify(m => m.GetWhere(It.IsAny<Expression<Func<Route, bool>>>()), Times.Once);
        //}

        //[Fact]
        //public async Task FindRouteByUserId_ReturnsRouteFromRouteRepositoryFindRoute()
        //{
        //    // Arrange
        //    var userIdRoutes = new List<Route>();
        //    userIdRoutes.Add(routes.First());
        //    var userId = userIdRoutes.First().UserId;

        //    mockRouteRepository
        //        .Setup(m => m.GetAllWhere(routeParameters, It.IsAny<Expression<Func<Route, bool>>>()))
        //        .ReturnsAsync(userIdRoutes);

        //    // Act
        //    var result = await subject.FindRouteByUserId(userId, routeParameters);

        //    // Assert
        //    result.Should().BeEquivalentTo(routes.First());
        //}

    }
}
