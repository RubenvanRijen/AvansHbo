﻿using Application;
using Application.AuxiliaryLogics.Interfaces;
using Domain.Models;
using FizzWare.NBuilder;
using FluentAssertions;
using Moq;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ApiDriessenTests.Logic
{
    public class HolidayLogicTests
    {
        //Model
        private readonly Holiday holiday;
        private readonly Holiday currentHoliday;
        //List
        private readonly List<Holiday> holidays;
        private readonly List<User> users;
        //Repository
        private readonly Mock<IAsyncRepository<Holiday>> mockHolidayRepository;
        //Logic
        private readonly Mock<IValidationLogic> mockValidationLogic;
        private readonly HolidayLogic subject;

        #region Setup
        public HolidayLogicTests()
        {
            //Model
            holiday = Builder<Holiday>
                .CreateNew()
                .Build();
            currentHoliday = Builder<Holiday>
                .CreateNew()
                .Build();
            //List
            holidays = Builder<Holiday>
            .CreateListOfSize(1)
               .Build()
               .ToList();
            users = Builder<User>
            .CreateListOfSize(1)
               .Build()
               .ToList();
            //Repository
            mockHolidayRepository = new Mock<IAsyncRepository<Holiday>>();
            //Logic
            mockValidationLogic = new Mock<IValidationLogic>();
            subject = new HolidayLogic(mockHolidayRepository.Object, mockValidationLogic.Object);

            SetupMockRouteRepository();
        }
        private void SetupMockRouteRepository()
        {
            mockHolidayRepository
              .Setup(m => m.GetById(It.IsAny<Guid>()))
              .ReturnsAsync(currentHoliday);
        }
        #endregion
        #region Create
        [Fact]
        public async Task Create_CallsHolidayRepositoryCreateHoliday()
        {
            // Act
            await subject.CreateHoliday(holiday);

            // Assert
            mockHolidayRepository.Verify(m => m.Create(holiday), Times.Once);
        }

        [Fact]
        public async Task Create_ReturnsHolidayFromHolidayRepository()
        {
            // Arrange
            mockHolidayRepository
                .Setup(m => m.Create(It.IsAny<Holiday>()))
                .ReturnsAsync(holiday);

            // Act
            var result = await subject.CreateHoliday(holiday);

            // Assert
            result.Should().Be(holiday);
        }
        #endregion
        #region Read
        [Fact]
        public async Task FindById_CallsHolidayRepositoryFindHoliday()
        {
            // Arrange
            var guid = holidays.First().Id;

            // Act
            await subject.FindHolidayById(guid);

            // Assert
            mockHolidayRepository.Verify(m => m.GetById(guid), Times.Once);
        }

        [Fact]
        public async Task FindById_ReturnsHolidayFromWorkHourRepositoryFindHoliday()
        {
            // Arrange
            var guid = holidays.First().Id;

            mockHolidayRepository
                .Setup(m => m.GetById(guid))
                .ReturnsAsync(holiday);

            // Act
            var result = await subject.FindHolidayById(guid);

            // Assert
            result.Should().BeEquivalentTo(holiday);
        }

        [Fact]
        public async Task FindByUserId_CallsHolidayRepositoryFindHoliday()
        {
            // Arrange
            var userId = holidays.First().UserId;

            // Act
            await subject.GetHolidayByUserId(userId);

            // Assert
            mockHolidayRepository.Verify(m => m.GetWhere(It.IsAny<Expression<Func<Holiday, bool>>>()), Times.Once);
        }

        [Fact]
        public async Task FindByUserId_ReturnsHolidayFromHolidayRepositoryFindHoliday()
        {
            // Arrange
            var userIdRoutes = new List<Holiday>();
            userIdRoutes.Add(holidays.First());
            var userId = Guid.NewGuid();

            mockHolidayRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<Holiday, bool>>>()))
                .ReturnsAsync(userIdRoutes);

            // Act
            var result = await subject.GetHolidayByUserId(userId);

            // Assert
            result.Should().BeEquivalentTo(holidays.First());
        }
        #endregion
        #region Update
        [Fact]
        public async Task UpdateHoliday_CallsWorkHourRepositoryFindHoliday()
        {
            // Act
            await subject.FindHolidayById(holiday.Id);

            // Assert
            mockHolidayRepository.Verify(m => m.GetById(holiday.Id), Times.Once);
        }

        [Fact]
        public async Task UpdateHoliday_CallsWorkHourRepositoryUpdateHoliday()
        {
            // Act
            await subject.UpdateHoliday(holiday);

            // Assert
            mockHolidayRepository.Verify(m => m.Update(It.IsAny<Holiday>()), Times.Once);
        }
        [Fact]
        public async Task UpdateHoliday_ReturnsWorkHourFromHolidayRepository()
        {
            // Arrange
            mockHolidayRepository
                .Setup(m => m.Update(It.IsAny<Holiday>()))
                .ReturnsAsync(() => holiday);

            // Act
            var result = await subject.UpdateHoliday(new Holiday());

            // Assert
            result.Should().Be(holiday);
        }
        #endregion
        #region Delete
        [Fact]
        public async Task DeleteHoliday_CallsWorkHourRepositoryDeleteHoliday()
        {
            // Arrange
            var guid = holidays.First().Id;

            // Act
            await subject.DeleteHoliday(guid);

            // Assert
            mockHolidayRepository.Verify(m => m.Delete(guid), Times.Once);
        }

        [Fact]
        public async Task DeleteHoliday_ReturnsBoolFromWorkHourRepositoryDeleteHoliday()
        {
            // Arrange
            var guid = holidays.First().Id;
            var isDeleted = false;

            mockHolidayRepository
                .Setup(m => m.Delete(guid))
                .ReturnsAsync(isDeleted);

            // Act
            var result = await subject.DeleteHoliday(guid);

            // Assert
            result.Should().Be(isDeleted);
        }
        #endregion
    }
}
