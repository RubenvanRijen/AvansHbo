﻿using Application;
using Application.AuxiliaryLogics.Interfaces;
using Domain;
using EmailService.Interfaces;
using Domain.Models;
using Domain.Models.QueryStringParameters;
using FizzWare.NBuilder;
using FluentAssertions;
using Moq;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace ApiDriessenTests.Logic
{
    public class UserLogicTests
    {
        private readonly List<User> users;

        private readonly User user;

        //private readonly User newUser;
        private readonly User currentUser;
        private readonly Mock<IAsyncRepository<User>> mockUserRepository;
        private readonly UserParameters userParameters;
        private readonly UserLogic subject;
        private readonly Mock<IEmailSender> mockEmailSender;
        private readonly Mock<IEmailLogic> mockEmailLogic;
        private readonly Mock<IAsyncRepository<Placement>> mockPlacementRepository;
        private readonly Mock<IAsyncRepository<UserPlacement>> mockUserPlacementRepository;

        public UserLogicTests()
        {
            users = Builder<User>
                .CreateListOfSize(3)
                .Build()
                .ToList();

            user = Builder<User>
                .CreateNew()
                .Build();

            //newUser = Builder<User>
            //    .CreateNew()
            //    .Build();

            currentUser = Builder<User>
                .CreateNew()
                .Build();

            userParameters = Builder<UserParameters>
                .CreateNew()
                .Build();

            mockUserRepository = new Mock<IAsyncRepository<User>>();
            mockPlacementRepository = new Mock<IAsyncRepository<Placement>>();
            mockUserPlacementRepository = new Mock<IAsyncRepository<UserPlacement>>();
            mockEmailLogic = new Mock<IEmailLogic>();
            subject = new UserLogic(mockUserRepository.Object, mockUserPlacementRepository.Object, mockPlacementRepository.Object,mockEmailLogic.Object);
            SetupUserRepository();
        }

        private void SetupUserRepository()
        {
            mockUserRepository
                .Setup(m => m.GetById(It.IsAny<Guid>()))
                .ReturnsAsync(currentUser);
        }

        [Fact]
        public async Task GetUsers_CallUserRepositoryGetAllUsers()
        {
            // Act
            await subject.GetAllUsers(userParameters);

            // Assert
            mockUserRepository.Verify(m => m.GetAll(userParameters), Times.Once);
        }

        //[Fact]
        //public async Task GetUsers_ReturnsAllUsersFromUserRepository()
        //{
        //    // mockUserRepository
        //    mockUserRepository
        //        .Setup(m => m.GetAll(userParameters))
        //        .ReturnsAsync(() => (users));

        //    // Act
        //    var result = await subject.GetAllUsers(userParameters);

        //    // Assert
        //    result.Should().BeEquivalentTo(users);
        //}

        [Fact]
        public async Task CreateUser_CallsUserRepositoryCreateNewUser()
        {
            // Act
            await subject.CreateNewUser(user);

            // Assert
            mockUserRepository.Verify(m => m.Create(user), Times.Once);
        }

        [Fact]
        public async Task CreateUser_ReturnsUserFromUserRepository()
        {
            // Arrange
            mockUserRepository
                .Setup(m => m.Create(It.IsAny<User>()))
                .ReturnsAsync(user);

            // Act
            var result = await subject.CreateNewUser(user);

            // Assert
            result.Should().Be(user);
        }

        [Fact]
        public async Task UpdateUser_CallsUserositoryFindUserById()
        {
            // Act
            await subject.FindUserById(user.Id);

            // Assert
            mockUserRepository.Verify(m => m.GetById(user.Id), Times.Once);
        }

        [Fact]
        public async Task UpdateUser_CallsUserRepositoryUpdateUser()
        {
            // Act
            await subject.UpdateUser(user.Id, user);

            // Assert
            mockUserRepository.Verify(m => m.Update(It.IsAny<User>()), Times.Once);
        }

        [Fact]
        public async Task UpdateUser_ReturnsUserFromUserRepository()
        {
            // Arrange
            mockUserRepository
                .Setup(m => m.Update(It.IsAny<User>()))
                .ReturnsAsync(() => user);

            // Act
            var result = await subject.UpdateUser(Guid.Empty, new User());

            // Assert
            result.Should().Be(user);
        }

        [Fact]
        public async Task FindUserById_CallsUserRepositoryFindUser()
        {
            // Arrange
            var guid = users.First().Id;

            // Act
            await subject.FindUserById(guid);

            // Assert
            mockUserRepository.Verify(m => m.GetById(guid), Times.Once);
        }

        [Fact]
        public async Task FindUserById_ReturnsUserFromUserRepositoryFindUser()
        {
            // Arrange
            var guid = users.First().Id;

            mockUserRepository
                .Setup(m => m.GetById(guid))
                .ReturnsAsync(user);

            // Act
            var result = await subject.FindUserById(guid);

            // Assert
            result.Should().BeEquivalentTo(user);
        }

        [Fact]
        public async Task SoftDeleteUser_CallsUserRepositoryDeleteUser()
        {
            // Arrange
            var guid = users.First().Id;

            // Act
            await subject.SoftDeleteUser(guid);

            // Assert
            mockUserRepository.Verify(m => m.GetById(guid), Times.Once);
            mockUserRepository.Verify(m => m.Update(It.Is<User>(userParam => userParam.IsDeleted)), Times.Once);
        }

        [Fact]
        public async Task SoftDeleteUser_ReturnsBoolFromUserRepositoryDeleteUser()
        {
            // Arrange
            var guid = users.First().Id;
            var isDeleted = false;

            // Act
            var result = await subject.SoftDeleteUser(guid);

            // Assert
            result.Should().Be(true);
        }
    }
}