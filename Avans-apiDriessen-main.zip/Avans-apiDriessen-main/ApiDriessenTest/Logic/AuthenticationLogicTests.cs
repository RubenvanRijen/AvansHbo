﻿using Application;
using Domain.Models;
using Domain.Models.Authentication;
using Microsoft.Extensions.Configuration;
using Moq;
using Persistence.Repositories.Interfaces;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq.Expressions;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Domain.AuxiliaryModels;
using Microsoft.Extensions.Options;
using Xunit;
using Xunit.Abstractions;

namespace ApiDriessenTests.Logic
{
    public class AuthenticationLogicTests
    {
        private readonly ITestOutputHelper testOutputHelper;
        private readonly JwtSecurityTokenHandler tokenHandler;
        
        private readonly Mock<IAsyncRepository<User>> mockUserRepository;

        private readonly AuthenticationLogic subject;

        private readonly User testUser;

        public AuthenticationLogicTests(ITestOutputHelper testOutputHelper)
        {
            this.testOutputHelper = testOutputHelper;
            tokenHandler = new JwtSecurityTokenHandler();
            
            mockUserRepository = new Mock<IAsyncRepository<User>>();
            SetupMocks();

            subject = new AuthenticationLogic(
                mockUserRepository.Object,
                new OptionsWrapper<JwtSettings>(new JwtSettings
                {
                    Key = "abcdefghijklmnopqrstuvwxyzabcdef"
                })
            );

            testUser = new User
            {
                Id = Guid.NewGuid(),
                Email = "jasper@example.com",
                Password = "$2a$11$QtIMGhg./KfWrAH7X2xRleJFtPeTZS422EX7ZeBVitf079CzcTA16", // jasper
                FirstName = "Jasper",
                LastName = "Example",
                AccountNumber = "1234",
                RoleName = "Employer",
                CompanyName = "Driessen"
            };
        }

        private void SetupMocks()
        {
            mockUserRepository
                .Setup(m => m.FirstOrDefault(It.IsAny<Expression<Func<User, bool>>>()))
                .Returns((Expression<Func<User, bool>> expression) =>
                {
                    var task = new Task<User>(() => testUser);
                    
                    if (!expression.Compile().Invoke(testUser))
                    {
                        task = new Task<User>(() => null);
                    }
                    
                    task.Start();
                    return task;
                });
        }

        [Fact]
        public async Task Authenticate_WithValidData_ReturnsJwt()
        {
            // Arrange
            var authenticationRequest = new AuthenticationRequest
            {
                Email = "jasper@example.com",
                Password = "jasper"
            };

            // Act
            var result = await subject.Authenticate(authenticationRequest);

            // Assert
            Assert.NotNull(result);

            var token = tokenHandler.ReadJwtToken(result);
            Assert.NotNull(token.Payload["email"]);
            Assert.NotNull(token.Payload["sub"]);
            Assert.NotNull(token.Payload["company"]);
        }

        [Fact]
        public async Task Authenticate_WithInvalidEmail_ReturnsNull()
        {
            // Arrange
            var authenticationRequest = new AuthenticationRequest
            {
                Email = "invalid@invalid.com",
                Password = "jasper"
            };

            // Act
            var result = await subject.Authenticate(authenticationRequest);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task Authenticate_WithInvalidPassword_ReturnsNull()
        {
            // Arrange
            var authenticationRequest = new AuthenticationRequest
            {
                Email = "jasper@invalid.com",
                Password = "invalid"
            };

            // Act
            var result = await subject.Authenticate(authenticationRequest);

            // Assert
            Assert.Null(result);
        }
    }
}