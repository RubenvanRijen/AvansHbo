﻿using Application.AuxiliaryLogics;
using Domain;
using Domain.Models;
using FizzWare.NBuilder;
using FluentAssertions;
using Moq;
using Persistence.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Xunit;

namespace ApiDriessenTests.AuxiliaryLogics
{
    public class ValidationLogicTests
    {
        //Model
        private readonly User user;
        private readonly User currentUser;

        private readonly Company company;
        private readonly Company currentCompany;

        private readonly Status status;
        private readonly Status currentStatus;

        private readonly KilometerAllowance kilometerAllowance;
        private readonly KilometerAllowance currentKilometerAllowance;

        private readonly Placement placement;

        private readonly Placement currentPlacement;

        //List
        private readonly List<User> users;
        private readonly List<Company> companies;
        private readonly List<Status> statuses;
        private readonly List<KilometerAllowance> kilometerAllowances;
        private readonly List<Placement> placements;

        //Repository
        private readonly Mock<IAsyncRepository<User>> mockUserRepository;
        private readonly Mock<ILookupRepository<Company>> mockCompanyRepository;
        private readonly Mock<ILookupRepository<Status>> mockStatusRepository;
        private readonly Mock<IAsyncRepository<KilometerAllowance>> mockKilometerAllowanceRepository;
        private readonly Mock<IAsyncRepository<Placement>> mockPlacementRepository;
        private readonly Mock<IAsyncRepository<WorkHour>> mockWorkHourRepository;

        //Logic
        private readonly ValidationLogic subject;

        #region Setup

        public ValidationLogicTests()
        {
            //Model
            user = Builder<User>
                .CreateNew()
                .Build();
            currentUser = Builder<User>
                .CreateNew()
                .Build();

            company = Builder<Company>
                .CreateNew()
                .Build();
            currentCompany = Builder<Company>
                .CreateNew()
                .With(w => w.Name = "Test")
                .Build();

            status = Builder<Status>
                .CreateNew()
                .Build();
            currentStatus = Builder<Status>
                .CreateNew()
                .With(w => w.Name = "Test")
                .Build();

            kilometerAllowance = Builder<KilometerAllowance>
                .CreateNew()
                .Build();
            currentKilometerAllowance = Builder<KilometerAllowance>
                .CreateNew()
                .With(w => w.CompanyName = "Test")
                .With(w => w.AllowanceTypeName = "Test")
                .Build();

            currentPlacement = Builder<Placement>
                .CreateNew()
                .Build();

            //List
            users = Builder<User>
                .CreateListOfSize(1)
                .All()
                .With(w => currentUser)
                .Build()
                .ToList();

            companies = Builder<Company>
                .CreateListOfSize(1)
                .All()
                .With(w => currentCompany)
                .Build()
                .ToList();

            statuses = Builder<Status>
                .CreateListOfSize(1)
                .All()
                .With(w => currentStatus)
                .Build()
                .ToList();

            kilometerAllowances = Builder<KilometerAllowance>
                .CreateListOfSize(1)
                .All()
                .With(w => currentKilometerAllowance)
                .Build()
                .ToList();

            placements = Builder<Placement>
                .CreateListOfSize(1)
                .All()
                .With(w => currentPlacement)
                .Build()
                .ToList();

            //Repository
            mockUserRepository = new Mock<IAsyncRepository<User>>();
            mockCompanyRepository = new Mock<ILookupRepository<Company>>();
            mockStatusRepository = new Mock<ILookupRepository<Status>>();
            mockKilometerAllowanceRepository = new Mock<IAsyncRepository<KilometerAllowance>>();
            mockPlacementRepository = new Mock<IAsyncRepository<Placement>>();
            mockWorkHourRepository = new Mock<IAsyncRepository<WorkHour>>();

            //Logic
            subject = new ValidationLogic(mockCompanyRepository.Object, mockUserRepository.Object,
                mockStatusRepository.Object, mockKilometerAllowanceRepository.Object, mockPlacementRepository.Object,
                mockWorkHourRepository.Object);

            SetupMockRouteRepository();
        }

        private void SetupMockRouteRepository()
        {
            mockUserRepository
                .Setup(m => m.GetById(It.IsAny<Guid>()))
                .ReturnsAsync(currentUser);
        }

        #endregion

        #region Validation

        [Fact]
        public async Task UserDoesNotExist_ReturnTrueBoolFromUserDoesNotExist()
        {
            // Arrange
            var guid = Guid.NewGuid();
            mockUserRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(users.Count);

            mockUserRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<User, bool>>>()))
                .ReturnsAsync(0);

            // Act
            var result = await subject.UserDoesNotExist(guid);

            // Assert
            result.Should().Be(true);
        }

        [Fact]
        public async Task UserDoesNotExist_ReturnFalseBoolFromUserDoesNotExist()
        {
            // Arrange
            var guid = currentUser.Id;
            mockUserRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(users.Count);

            mockUserRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<User, bool>>>()))
                .ReturnsAsync(1);

            // Act
            var result = await subject.UserDoesNotExist(guid);

            // Assert
            result.Should().Be(false);
        }

        [Fact]
        public async Task CompanyDoesNotExist_ReturnTrueBoolFromCompanyDoesNotExist()
        {
            // Arrange
            var guid = Guid.NewGuid();
            mockCompanyRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(users.Count);

            mockCompanyRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<Company, bool>>>()))
                .ReturnsAsync(0);

            // Act
            var result = await subject.CompanyDoesNotExist("");

            // Assert
            result.Should().Be(true);
        }

        [Fact]
        public async Task CompanyDoesNotExist_ReturnFalseBoolFromCompanyDoesNotExist()
        {
            // Arrange
            mockCompanyRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(companies.Count);

            mockCompanyRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<Company, bool>>>()))
                .ReturnsAsync(1);

            // Act
            var result = await subject.CompanyDoesNotExist("Test");

            // Assert
            result.Should().Be(false);
        }

        [Fact]
        public async Task StatusDoesNotExist_ReturnTrueBoolFromStatusDoesNotExist()
        {
            // Arrange
            var guid = Guid.NewGuid();
            mockCompanyRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(statuses.Count);

            mockStatusRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<Status, bool>>>()))
                .ReturnsAsync(0);

            // Act
            var result = await subject.StatusDoesNotExist("");

            // Assert
            result.Should().Be(true);
        }

        [Fact]
        public async Task StatusDoesNotExist_ReturnFalseBoolFromStatusDoesNotExist()
        {
            // Arrange
            mockStatusRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(statuses.Count);

            mockStatusRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<Status, bool>>>()))
                .ReturnsAsync(1);

            // Act
            var result = await subject.StatusDoesNotExist("Test");

            // Assert
            result.Should().Be(false);
        }

        [Fact]
        public async Task CompanyAllowanceTypeNameDoesNotExist_ReturnTrueBoolFromCompanyAllowanceTypeNameDoesNotExist()
        {
            // Arrange
            mockKilometerAllowanceRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(kilometerAllowances.Count);

            mockKilometerAllowanceRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<KilometerAllowance, bool>>>()))
                .ReturnsAsync(0);

            // Act
            var result = await subject.CompanyAllowanceTypeNameDoesNotExist("", "");

            // Assert
            result.Should().Be(true);
        }

        [Fact]
        public async Task CompanyAllowanceTypeNameNotExist_ReturnFalseBoolFromCompanyAllowanceTypeNameDoesNotExist()
        {
            // Arrange
            mockCompanyRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(companies.Count);

            mockCompanyRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<Company, bool>>>()))
                .ReturnsAsync(1);

            mockKilometerAllowanceRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(kilometerAllowances.Count);

            mockKilometerAllowanceRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<KilometerAllowance, bool>>>()))
                .ReturnsAsync(1);

            // Act
            var result = await subject.CompanyAllowanceTypeNameDoesNotExist("Test", "Test");

            // Assert
            result.Should().Be(false);
        }

        [Fact]
        public async Task NullDoesNotExist_ReturnTrueBoolFromPlacementDoesNotExist()
        {
            // Arrange
            mockPlacementRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(placements.Count);

            mockPlacementRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<Placement, bool>>>()))
                .ReturnsAsync(0);

            // Act
            var result = await subject.PlacementDoesNotExist(null);

            // Assert
            result.Should().Be(true);
        }

        [Fact]
        public async Task PlacementDoesNotExist_ReturnTrueBoolFromPlacementDoesNotExist()
        {
            // Arrange
            var guid = Guid.NewGuid();
            mockPlacementRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(placements.Count);

            mockPlacementRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<Placement, bool>>>()))
                .ReturnsAsync(0);

            // Act
            var result = await subject.PlacementDoesNotExist(guid);

            // Assert
            result.Should().Be(true);
        }

        [Fact]
        public async Task PlacementDoesNotExist_ReturnFalseBoolFromPlacementDoesNotExist()
        {
            // Arrange
            var guid = currentPlacement.Id;
            mockPlacementRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(placements.Count);

            mockPlacementRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<Placement, bool>>>()))
                .ReturnsAsync(1);

            // Act
            var result = await subject.PlacementDoesNotExist(guid);

            // Assert
            result.Should().Be(false);
        }

        [Fact]
        public async Task NullDoesNotExist_ReturnTrueBoolFromKilometerAllowanceDoesNotExist()
        {
            // Arrange
            mockKilometerAllowanceRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(kilometerAllowances.Count);

            mockKilometerAllowanceRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<KilometerAllowance, bool>>>()))
                .ReturnsAsync(0);

            // Act
            var result = await subject.KilometerAllowanceDoesNotExist(null);

            // Assert
            result.Should().Be(true);
        }

        [Fact]
        public async Task KilometerAllowanceDoesNotExist_ReturnTrueBoolFromKilometerAllowanceDoesNotExist()
        {
            // Arrange
            var guid = Guid.NewGuid();
            mockKilometerAllowanceRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(kilometerAllowances.Count);

            mockKilometerAllowanceRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<KilometerAllowance, bool>>>()))
                .ReturnsAsync(0);

            // Act
            var result = await subject.KilometerAllowanceDoesNotExist(guid);

            // Assert
            result.Should().Be(true);
        }

        [Fact]
        public async Task KilometerAllowanceDoesNotExist_ReturnFalseBoolFromKilometerAllowanceDoesNotExist()
        {
            // Arrange
            var guid = currentKilometerAllowance.Id;
            mockKilometerAllowanceRepository
                .Setup(m => m.CountAll())
                .ReturnsAsync(kilometerAllowances.Count);

            mockKilometerAllowanceRepository
                .Setup(m => m.CountWhere(It.IsAny<Expression<Func<KilometerAllowance, bool>>>()))
                .ReturnsAsync(1);

            // Act
            var result = await subject.KilometerAllowanceDoesNotExist(guid);

            // Assert
            result.Should().Be(false);
        }

        [Fact]
        public async Task WorkHourOverlaps_ReturnFalse()
        {
            var guid = Guid.NewGuid();
            
            var workHour = new WorkHour
            {
                UserId = guid,
                StartDateTime = DateTime.Now,
                EndDateTime = DateTime.Now.AddHours(8)
            };
            
            mockWorkHourRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<WorkHour, bool>>>()))
                .ReturnsAsync(new List<WorkHour>());

            var result = await subject.WorkHourOverlaps(workHour);

            result.Should().BeFalse();
        }
        
        [Fact]
        public async Task WorkHourOverlaps_ReturnTrue()
        {
            var guid = Guid.NewGuid();
            
            var workHour = new WorkHour
            {
                UserId = guid,
                StartDateTime = DateTime.Now,
                EndDateTime = DateTime.Now.AddHours(8)
            };
            
            mockWorkHourRepository
                .Setup(m => m.GetWhere(It.IsAny<Expression<Func<WorkHour, bool>>>()))
                .ReturnsAsync(new List<WorkHour>
                {
                    new WorkHour
                    {
                        UserId = guid,
                        StartDateTime = DateTime.Now.AddHours(2),
                        EndDateTime = DateTime.Now.AddHours(10)
                    }
                });

            var result = await subject.WorkHourOverlaps(workHour);

            result.Should().BeTrue();
        }

        #endregion
    }
}