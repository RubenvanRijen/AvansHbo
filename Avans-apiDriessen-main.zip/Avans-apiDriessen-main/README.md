# Introduction 
API of Driessen Reiskosten Tracker.

# Getting Started
Installeer mysql
Open het project met visual studio 2019(De laatste versie)
Klik op api Driessen
[https://cdn.discordapp.com/attachments/669440150949855244/698964126294081566/unknown.png]
Klik op user secrets
[https://cdn.discordapp.com/attachments/669440150949855244/698964264807039046/unknown.png]

Voeg aan user secrets deze JSON toe met de bijbehorende inloggegevens.
{
  "ConnectionStrings": {
    "MySqlConnection": "server=localhost;database=localDriesen;user=USERNAMEDB;password=PASSWORD"
  },
  "MapboxAPI": {
    "ApiUrlLocation": "https://api.mapbox.com/geocoding/v5/mapbox.places/",
    "ApiUrl": "https://api.mapbox.com/directions/v5/mapbox/driving/",
    "ApiKey": "KEYNEEDED"
  },
  "UseExternalConnection": "false",
  "Jwt:Key": "KEYNEEDED"
}
