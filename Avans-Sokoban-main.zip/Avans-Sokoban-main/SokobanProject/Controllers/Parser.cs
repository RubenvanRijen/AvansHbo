﻿using SokobanProject.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SokobanProject
{
    public class Parser
    {
        public static string stringLevel;

        public Level LoadLevel(bool notRestart, string level)
        {
            if (notRestart == true)
            {
                stringLevel = level;
                Level CurLevel = new Level(MakeList(ReadLevel(level)));
                return CurLevel;
            }
            else
            {
                Level CurLevel = new Level(MakeList(ReadLevel(stringLevel)));
                return CurLevel;
            }
        }

        public String ReadLevel(string levelNum)
        {
            int level = Int32.Parse(levelNum);
            if (level <= 6 && level >= 1)
            {
                string text = System.IO.File.ReadAllText("..\\..\\Doolhof\\doolhof" + levelNum + ".txt");
                return text;
            }
            else
            {
                string text = System.IO.File.ReadAllText("..\\..\\Doolhof\\doolhof" + 1 + ".txt");
                return text;
            }
        }

        public FieldList MakeList(String text)
        {
            FieldList list = new FieldList();
            char[] chars = text.ToCharArray();
            bool nextLine = false;
            foreach (char c in chars)
            {
                if (c == '\n' || c == '\r')
                {
                    nextLine = true;
                }
                else if (nextLine)
                {
                    nextLine = false;
                    list.InsertNextLine(ConvertGameObject(c));
                }
                else
                {
                    if (c == '\n' || c == '\r')
                    {
                        nextLine = true;
                    }
                    else
                    {
                        list.InsertToRight(ConvertGameObject(c));
                    }
                }
            }
            return list;
        }

        private Field ConvertGameObject(Char c)
        {
            switch (c)
            {
                case '#':
                    return new Wall();

                case 'o':
                    Field crate = new Field();
                    crate.HasCrate = true;
                    crate.Char = 'O';
                    crate.IsEmpty = true;
                    return crate;

                case 'x':
                    return new Destination();
                case '~':
                    return new Valkuil();
                case '@':
                    Field player = new Field();
                    player.AddObject("player");
                    player.Char = c;
                    return player;
                case '$':
                    Field medewerker = new Field();
                    medewerker.AddObject("medewerker");
                    medewerker.Char = 'Z';
                    return medewerker;
                case '.':
                    Field field = new Field();
                    field.Char = c;
                    field.IsEmpty = true;
                    return field;
                case ' ':
                    Field empty = new Field();
                    empty.Char = ' ';
                    return empty;

                default: return null;
            }
        }
    }
}