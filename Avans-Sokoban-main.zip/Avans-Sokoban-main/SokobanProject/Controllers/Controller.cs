﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SokobanProject
{
    public class Controller
    {
        private Level _level;
        private OutputView _outputView;
        private Parser _parser;
        private InputView _inputView;
        private bool awake = false;
        public Level Level { get { return _level; } set { _level = value; } }

        public OutputView OutputView { get { return _outputView; } set { _outputView = value; } }

        public Controller()
        {
            OutputView = new OutputView();
            _parser = new Parser();
            _inputView = new InputView(this);
            _inputView.ChooseLevel();
            this.Level = _parser.LoadLevel(true, _inputView.CurrentLevel);
            OutputView.PrintLevel(Level.LevelToText());
            _inputView.KeyPressed();
        }

        public void Move(int direction)
        {

            if (direction >= 0 && direction < 4)
            {
                Level.LevelList.Move(direction, "player", 0);
                OutputView.PrintLevel(Level.LevelToText());
                if (Level.LevelList.WinCheck() == true)
                {
                    _outputView.wonTekst(Level.LevelToText());
                    _inputView.Won();
                    Console.Clear();
                    this.NewLevel(true);
                }
                else
                {
                    OutputView.PrintLevel(Level.LevelToText());
                }
            }
            if (Level.LevelList.Find(1) != null)
            {
                MoveMedewerker();
            }
        }

        public void MoveMedewerker()
        {
            Random wakeUp = new Random();
            Random goToSleep = new Random();
            if (awake == true)
            {
                if (goToSleep.Next(1, 100) < 25)
                {
                    awake = false;
                    Level.LevelList.Find(1).SetAwake(false);
                }
                Random number = new Random();
                int directions = number.Next(0, 4);
                Level.LevelList.Move(directions, "medewerker", 1);
                OutputView.PrintLevel(Level.LevelToText());

            }
            else
            {
                if (wakeUp.Next(1, 100) < 10)
                {
                    awake = true;
                    Level.LevelList.Find(1).SetAwake(true);
                }
            }
        }

        public void NewLevel(Boolean restart)
        {
            if (restart == true)
            {
                _outputView.PrintBeginning();
                _inputView.ChooseLevel();
                this.Level = _parser.LoadLevel(restart, _inputView.CurrentLevel); ;
                OutputView.PrintLevel(Level.LevelToText());
                _inputView.KeyPressed();
            }
            else
            {
                this.Level = _parser.LoadLevel(restart, _inputView.CurrentLevel); ;
                OutputView.PrintLevel(Level.LevelToText());
                _inputView.KeyPressed();
            }


        }
    }
}

