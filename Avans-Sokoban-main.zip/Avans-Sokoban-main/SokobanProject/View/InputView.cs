﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SokobanProject
{
    public class InputView
    {

        private Controller controller;
        public string CurrentLevel { get; set; }
        public InputView(Controller controller)
        {
            this.controller = controller;
        }

        public void KeyPressed()
        {
            while (true)
            {
                var ch = Console.ReadKey(false).Key;
                switch (ch)
                {
                    case ConsoleKey.LeftArrow:
                        this.controller.Move(3);
                        break;
                    case ConsoleKey.UpArrow:
                        this.controller.Move(0);
                        break;
                    case ConsoleKey.DownArrow:
                        this.controller.Move(2);
                        break;
                    case ConsoleKey.RightArrow:
                        this.controller.Move(1);
                        break;
                    case ConsoleKey.R:
                        Console.Clear();
                        this.controller.NewLevel(false);
                        break;
                    case ConsoleKey.S:
                        Console.Clear();
                        this.controller.NewLevel(true);
                        return;
                    default:
                        Console.WriteLine("pijltjes gebruiken altublieft of s om te stoppen en r om te herstarten");
                        break;
                }
            }
        }

        public void Won()
        {
            Console.ReadKey();
        }

        public string ChooseLevel()
        {
            while (true)
            {
                var input = Console.ReadKey(false).Key;
                switch (input)
                {
                    case ConsoleKey.D1:
                        CurrentLevel = "1";
                        return "1";
                    case ConsoleKey.D2:
                        CurrentLevel = "2";
                        return "2";
                    case ConsoleKey.D3:
                        CurrentLevel = "3";
                        return "3";
                    case ConsoleKey.D4:
                        CurrentLevel = "4";
                        return "4";
                    case ConsoleKey.D5:
                        CurrentLevel = "5";
                        return "5";
                    case ConsoleKey.D6:
                        CurrentLevel = "6";
                        return "6";
                    case ConsoleKey.S:
                        System.Environment.Exit(1);
                        return null;
                    default:
                        Console.WriteLine("een nummer tussen 1 en 6 of s om te stoppen");
                        break;
                }
            }
        }
    }
}