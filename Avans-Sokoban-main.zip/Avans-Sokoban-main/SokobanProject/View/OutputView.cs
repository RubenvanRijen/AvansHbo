﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SokobanProject
{
    public class OutputView
    {
        public OutputView()
        {
            PrintBeginning();
        }
        public void PrintLevel(String levelText)
        {
            Console.Clear();
            PrintLogo();
            Console.WriteLine(levelText);
        }
        public void PrintBeginning()
        {
            Console.WriteLine("┌───────────────────────────────────────────────────────────────┐");
            Console.WriteLine("│ Welkom bij Sokoban                                            │");
            Console.WriteLine("| betekenis van de symbolen                                     |");
            Console.WriteLine("|                                                               |");
            Console.WriteLine("| spatie : outerspace          |    doel van het spel           |");
            Console.WriteLine("|      █ : muur                |                                |");
            Console.WriteLine("|      . : vloer               |    duw met de truck            |");
            Console.WriteLine("|      O : krat                |    de krat(ten)                |");
            Console.WriteLine("|      0 : krat op bestemming  |    naar de bestemming          |");
            Console.WriteLine("|      x : bestemming          |                                |");
            Console.WriteLine("|      @ : truck               |                                |");
            Console.WriteLine("└───────────────────────────────────────────────────────────────┘");
            Console.WriteLine("");
            Console.WriteLine("> Kies een doolhof (1 - 6), s = stop");
        }
        public void PrintLogo()
        {
            Console.WriteLine("┌───────┐");
            Console.WriteLine("|SOKOBAN|");
            Console.WriteLine("└───────┘");
        }

        public void wonTekst(string levelTekst)
        {
            Console.Clear();
            this.PrintLevel(levelTekst);
            Console.WriteLine();
            Console.WriteLine("=== Hoera opgelost ===");
            Console.WriteLine("> press key to continue");
        }
    }
}