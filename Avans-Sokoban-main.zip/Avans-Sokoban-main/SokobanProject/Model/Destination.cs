﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SokobanProject
{
    public class Destination : Field
    {
        public Destination()
        {
            this.Char = 'x';
            this.IsEmpty = true;
        }
        public override void  RemoveObject()
        {
            this.Char = 'x';
            this.HasPlayer = false;
            this.HasCrate = false;
            this.HasMedewerker = false;
        }
        public override void AddObject(string item)
        {
            if (item.Equals("crate"))
            {
                this.Char = '0';
                this.HasCrate = true;
                this.HasPlayer = false;
            }
            else if (item.Equals("player"))
            {
                this.Char = '@';
                this.HasCrate = false;
                this.HasPlayer = true;
            }
        }
    }
}