﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SokobanProject.Model
{
    class Valkuil: Field
    {
        private int aantalKeer = 0;

        public Valkuil()
        {

            this.aantalKeer = 0;
            this.Char = '~';
            this.IsEmpty = true;

        }
        public override void RemoveObject()
        {
            this.Char = '~';
            this.HasPlayer = false;
            this.HasCrate = false;
            if(aantalKeer >= 3)
            {
                this.Char = ' ';
            }

        }
        public override void AddObject(string item)
        {
            if (item.Equals("crate"))
            {
               
                this.Char = 'O';
                this.HasCrate = true;
                this.HasPlayer = false;
                if(aantalKeer >= 3)
                {
                    this.HasCrate = false;
                    this.Char = ' ';
                }
                aantalKeer++;
            }
            else if (item.Equals("player"))
            {
                this.Char = '@';
                this.HasCrate = false;
                this.HasPlayer = true;
                aantalKeer++;
            }
        }
    }
}
