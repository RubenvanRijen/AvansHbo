﻿using SokobanProject.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SokobanProject
{
    public class Level
    {
        private FieldList _fieldList;
        public FieldList LevelList { get { return _fieldList; } }

        public Level(FieldList levelList)
        {
            this._fieldList = levelList;
        }
        public String LevelToText()
        {
            String text = "";
            Field temp = LevelList.First;
            while (temp != LevelList.Last)
            {
                int counter = 0;
                while (temp.Right != null)
                {
                    text = text.Insert(text.Length, temp.Char.ToString());
                    temp = temp.Right;
                    counter++;
                }
                text = text.Insert(text.Length, temp.Char.ToString());
                text = text.Insert(text.Length, "\r\n");
                if (temp != LevelList.Last)
                {
                    for (int i = 0; i < counter; i++)
                    {
                        temp = temp.Left;
                    }
                    if (temp.Bottom != null)
                    {
                        temp = temp.Bottom;
                    }
                }
            }
            return text;
        }
    }
}