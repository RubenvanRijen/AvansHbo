﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SokobanProject
{
    public class Field
    {
        public Field Right { get; set; }
        public Field Left { get; set; }
        public Field Top { get; set; }
        public Field Bottom { get; set; }
        private bool _hasPlayer;
        private bool _hasCrate;
        private bool _isEmpty;
        private bool _hasMedewerker;
        public bool HasPlayer { get { return _hasPlayer; } set { _hasPlayer = value; } }
        public bool HasCrate { get { return _hasCrate; } set { _hasCrate = value; } }
        public bool IsEmpty { get { return _isEmpty; } set { _isEmpty = value; } }
        public bool HasMedewerker { get { return _hasMedewerker; } set { _hasMedewerker = value; } }
        public char Char { get; set; }

        public Field()
        {
            HasPlayer = false;
            HasCrate = false;
            IsEmpty = false;
            HasMedewerker = false;
        }
        public virtual void RemoveObject()
        {
            this.Char = '.';
            this.HasPlayer = false;
            this.HasCrate = false;
            this.HasMedewerker = false;
            this.IsEmpty = true;
        }
        public virtual void AddObject(string item)
        {
            if (item.Equals("crate"))
            {
                this.Char = 'O';
                this.HasCrate = true;
                this.HasPlayer = false;
            }
            else if (item.Equals("player"))
            {
                this.Char = '@';
                this.HasCrate = false;
                this.HasPlayer = true;
            }
            else if (item.Equals("medewerker"))
            {
                this.Char = '$';
                this.HasCrate = false;
                this.HasPlayer = false;
                this.HasMedewerker = true;
                this.IsEmpty = false;
            }
        }
        public void SetAwake(bool value)
        {
            if (this.HasMedewerker)
            {
                if (value)
                {
                    this.Char = '$';
                }
                else
                {
                    this.Char = 'Z';
                }
            }
        }
    }
}