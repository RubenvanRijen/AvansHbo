﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SokobanProject.Model
{
    public class FieldList
    {
        public Field First { get; set; }
        public Field Last { get; set; }

        public void InsertToRight(Field newField)
        {
            if (First == null)
            {
                First = newField;
                Last = newField;
            }
            else
            {
                newField.Left = Last;
                Last.Right = newField;
                if (Last.Top != null && Last.Top.Right != null)
                {
                    newField.Top = Last.Top.Right;
                    Last.Top.Right.Bottom = newField;
                }
                Last = newField;
            }

        }
        public void InsertNextLine(Field newField)
        {
            Field temp = Last;
            while (temp.Left != null)
            {
                temp = temp.Left;
            }
            newField.Top = temp;
            temp.Bottom = newField;
            Last = newField;
        }

        public Field Find(int whatToFind)
        {
            Field current = First;
            while (current != Last)
            {
                while (current.Right != null)
                {
                    current = current.Right;
                    if (whatToFind == 0)
                    {
                        if (current.HasPlayer)
                        {
                            return current;
                        }
                    }
                    else if (whatToFind == 1)
                    {
                        if (current.HasMedewerker)
                        {
                            return current;
                        }

                    }
                }
                if (current != Last)
                {
                    while (current.Left != null)
                    {
                        current = current.Left;
                    }
                    if (current.Bottom != null)
                    {
                        current = current.Bottom;
                    }
                }
            }
            return null;
        }

        public bool Move(int direction, string objects, int whatToMove)
        {
            Field currentField = Find(whatToMove);
            switch (direction)
            {
                case 0:
                    if (currentField.Top.IsEmpty)
                    {
                        if (currentField.Top.HasCrate)
                        {
                            if (!currentField.Top.Top.IsEmpty || currentField.Top.Top.HasCrate)
                            {
                                return false;
                            }
                            currentField.Top.Top.AddObject("crate");
                        }
                        if (currentField.Top.HasPlayer)
                        {
                            if (currentField.HasMedewerker && !Move(direction, "player", 0))
                            {
                                return false;
                            }
                        }
                        if (currentField.Top.HasMedewerker)
                        {
                            currentField.Top.SetAwake(true);
                            return false;
                        }
                        currentField.RemoveObject();
                        currentField.Top.AddObject(objects);
                        return true;
                    }
                    if (currentField.Top.HasMedewerker)
                    {
                        currentField.Top.SetAwake(true);
                    }
                    return false;
                case 1:
                    if (currentField.Right.IsEmpty)
                    {
                        if (currentField.Right.HasCrate)
                        {
                            if (!currentField.Right.Right.IsEmpty || currentField.Right.Right.HasCrate)
                            {
                                return false;
                            }
                            currentField.Right.Right.AddObject("crate");
                        }
                        if (currentField.Right.HasPlayer)
                        {
                            if (currentField.HasMedewerker && !Move(direction, "player", 0))
                            {
                                return false;
                            }
                        }
                        if (currentField.Right.HasMedewerker)
                        {
                            currentField.Right.SetAwake(true);
                            return false;
                        }
                        currentField.RemoveObject();
                        currentField.Right.AddObject(objects);
                        return true;
                    }
                    if (currentField.Right.HasMedewerker)
                    {
                        currentField.Right.SetAwake(true);
                    }
                    return false;
                case 2:
                    if (currentField.Bottom.IsEmpty)
                    {
                        if (currentField.Bottom.HasCrate)
                        {
                            if (!currentField.Bottom.Bottom.IsEmpty || currentField.Bottom.Bottom.HasCrate)
                            {
                                return false;
                            }
                            currentField.Bottom.Bottom.AddObject("crate");
                        }
                        if (currentField.Bottom.HasPlayer)
                        {
                            if (currentField.HasMedewerker && !Move(direction, "player", 0))
                            {
                                return false;
                            }
                        }
                        if (currentField.Bottom.HasMedewerker)
                        {
                            currentField.Bottom.SetAwake(true);
                            return false;
                        }
                        currentField.RemoveObject();
                        currentField.Bottom.AddObject(objects);
                        return true;
                    }
                    if (currentField.Bottom.HasMedewerker)
                    {
                        currentField.Bottom.SetAwake(true);
                    }
                    return false;
                case 3:
                    if (currentField.Left.IsEmpty)
                    {
                        if (currentField.Left.HasCrate)
                        {
                            if (!currentField.Left.Left.IsEmpty || currentField.Left.Left.HasCrate)
                            {
                                return false;
                            }
                            currentField.Left.Left.AddObject("crate");
                        }
                        if (currentField.Left.HasPlayer)
                        {
                            if (currentField.HasMedewerker && !Move(direction, "player", 0))
                            {
                                return false;
                            }
                        }
                        if (currentField.Left.HasMedewerker)
                        {
                            currentField.Left.SetAwake(true);
                            return false;
                        }
                        currentField.RemoveObject();
                        currentField.Left.AddObject(objects);
                        return true;
                    }
                    if (currentField.Left.HasMedewerker)
                    {
                        currentField.Left.SetAwake(true);
                    }
                    return false;
            }
            return false;
        }

        public bool WinCheck()
        {
            Field current = First;
            while (current != Last)
            {
                while (current.Right != null)
                {
                    current = current.Right;
                    if (current is Destination && !current.HasCrate)
                    {
                        return false;
                    }
                }
                if (current != Last)
                {
                    while (current.Left != null)
                    {
                        current = current.Left;
                    }
                    if (current.Bottom != null)
                    {
                        current = current.Bottom;
                    }
                }
            }
            return true;
        }
    }
}
